/* (C)1992 Perihelion Software Limited                                */
/* Author: Alex Schuilenburg                                          */
/* Date: 5 August 1992                                                */
/* File: server.c                                                     */
/*                                                                    */
/* This file contains the main routine for the ufs file server.       */
/* It initialises the device, starts up the device server, mounts     */
/* the root filing system and calls the server.                       */
/*                                                                    */
/* $Id$ */
/* $Log$ */

#include "param.h"
#include "proc.h"
#include "user.h"
#include "malloc.h"
#include "buf.h"
#include "sem.h"
#include "queue.h"
#include "filedesc.h"
#include "mount.h"
#include "vnode.h"

#include <helios.h>
#include <syslib.h>
#include <stdarg.h>
#include <servlib.h>
#include <codes.h>
#include <gsp.h>
#include <module.h>
#include <device.h>

/*
 * HELIOS filesystem resource variables.
 */
char *progname;		/* The name of this program. */
char *canonname;	/* The canonical path name of the F/S under HELIOS */

Environ env;

int init_unix(void);
void hd_init(void);
void hd_intr_server(Semaphore *hd_terminate);
void *load_devinfo(void);
InfoNode *find_info(void *devinfo, word type, char *name);
void usage(void);
void dispatcher(Port p);

/*
 * stdlib is not used, so define atoi here.
 */
int atoi(char *num)
{	int val = 0;
	while ((*num >= '0') && (*num <= '9')) {
		val = (val*10) + (*num++ - '0');
	}
}

/* 
 * Add a name to the name table, returning the object associated with it.
 */
Object *AddName(char *name, Port reqport)
{
	Object *o, *r;
	char mcname[100];
	NameInfo info;
	
	MachineName(mcname);
	o = Locate(NULL,mcname);
	
	info.Port = reqport;
	info.Flags = Flags_StripName;
	info.Matrix = DefNameMatrix;
	info.LoadData = NULL;
	
	r = Create(o, name, Type_Name, sizeof(NameInfo), (byte *)&info);

	Close(o);
	return(r);
}

/*
 * Return the malloced file name of the canonical path name of the
 * root mount point of the file system under Helios.
 */
char *make_canonical(char *mount)
{	char fullname[MAXPATHLEN];
	char *ret;

	MachineName(fullname);
	pathcat(fullname,mount);
	ret = (char *)Malloc(strlen(fullname)+1);
	strcpy(ret,fullname);
	return(ret);
}

/*
 * The MAIN routine.
 */
extern struct filedesc0 filedesc0;
extern int (*mountroot)();
extern struct vnode *rootvp;

/* XXX AMS.  This must go when multiple dev support implemented */
DCB *rootdcb;

int main(void)
{
	char **argv;
	int argc;
	char *devname, *msg;
	char *mountname;	/* The name the root is mounted on in Helios. */
	dev_t rootdev;
	void *devinfo;
	InfoNode *deviceinfo;
	DiscDevInfo *ddi;
	Semaphore hd_terminate;
	Port ufs_port;
	Object *ufs_object;

	/* Initialise Environment */
	GetEnv(MyTask->Port, &env);
	msg="ufs: Helios File System Version 2.0 Alpha (BSD 4.4 Compatible)\n\r";
	Write(env.Strv[1],msg,strlen(msg),-1);
	
	/* Get information from environment */
	for (argc=0, argv = env.Argv; *argv; argv++, argc++);
	argv = env.Argv;
	progname = *argv++;
	argc--; 
	if (argc != 2) usage();
	devname = *argv++;
	for (mountname=devname; *mountname && (*mountname!=':'); mountname++);
	if (*mountname != ':') usage();
	*mountname++ = '\0';
	if (!*mountname) usage();
	rootdev = atoi(mountname);
	mountname = *argv++;

	/* Load devinfo and get device information */
	/* XXX AMS
	 * The code below up to "Initialise UNIX" should only be conditionally
	 * entered (to maintain downward compatibility) when multiple devices
	 * are supported on a single device driver.  If they are, then this
	 * code should initialise the controller, leaving the Sub-Devices to
	 * be initialised in the hd_open (hd.c) code.
	 */
	if ((devinfo = load_devinfo()) == NULL) {
		printf("Failed to load devinfo\n");
		Exit(1);
	}
	if ((deviceinfo = find_info(devinfo,Info_DiscDev,devname)) == NULL) {
		printf("Error: No entry for device '%s' in devinfo\n",devname);
		Free(devinfo);
		Exit(1);
	}
	ddi = (DiscDevInfo *)RTOA(deviceinfo->Info);
	rootdcb = OpenDevice(RTOA(ddi->Name),ddi);
	if (!rootdcb) {
		printf("Failed to open device '%s'\n",RTOA(ddi->Name));
		Free(devinfo);
		Exit(1);
	}

	/* Create the full canonical mount name */
	canonname = make_canonical(mountname);

	/* Initialise UNIX and device driver routines */
	if (init_unix()) {
		panic("HELIOS; Failed to initialise UNIX kernel");
		goto shutdown;
	}
	hd_init();
	InitSemaphore(&hd_terminate,0);
	if (!Fork(5000,hd_intr_server,sizeof(&hd_terminate),&hd_terminate)) {
		panic("HELIOS; Failed to initialise Helios-UNIX device server");
		goto shutdown;
	}

	/* Start mounting the root filesystem */
printf("%s: Mounting root filesystem on device '%s' dev:%d  Mount point '%s'\n",
	progname,devname,rootdev,mountname);
	vfsinit();
	if (bdevvp(rootdev,&rootvp)) {
		panic("can't setup bdevvp for rootdev");
		goto shutdown;
	}
	if ((*mountroot)()) {
		panic("cannot mount root");
		goto shutdown;
	}

	/* Get vnode for '/' */
	if (VFS_ROOT(rootfs, &rootdir)) {
		panic("cannot find root vnode");
		goto shutdown;
	}
	filedesc0.fd_fd.fd_cdir = rootdir;
	VREF(filedesc0.fd_fd.fd_cdir);
	VOP_UNLOCK(rootdir);
	filedesc0.fd_fd.fd_rdir = NULL;
printf("%s: Disk mounted O.K.\n",progname);

	/* Setup a Helios Message Port */
	if ((ufs_port = NewPort()) == NullPort) {
		panic("HELIOS; Failed to obtain a message port");
		goto shutdown;
	}
	if ((ufs_object = AddName(mountname,ufs_port)) == NULL) {
		panic("HELIOS; Failed to create the name table entry");
		FreePort(ufs_port);
		goto shutdown;
	}

	/* Run the dispatcher */
	dispatcher(ufs_port);

	/* Free the message port and other Helios objects */
	FreePort(ufs_port);
	Delete(ufs_object, NULL);

	/* ShutDown */
shutdown:
printf("%s: Shutting down\n",progname);
	Signal(&hd_terminate);
	Free(devinfo);
	Free(canonname);
	CloseDevice(rootdcb);
printf("%s: Down\n",progname);
	Exit(0);
}

/*
 * This is the usage message.
 */
void usage(void)
{
	char msgbuf[256];

	strcpy(msgbuf,"usage: ");  strcat(msgbuf,progname);  
	strcat(msgbuf," devicename:device mountname\n");
	Write(env.Strv[1],msgbuf,strlen(msgbuf),-1);
	Exit (1);
}


