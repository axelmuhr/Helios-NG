/* (C)1992 Perihelion Software Limited                                */
/* Author: Alex Schuilenburg                                          */
/* Date: 6 August 1992                                                */
/* File: syscall.c                                                    */
/*                                                                    */
/*
 * This file contains the system call interface to UNIX from Helios.
 */
/*
 * $Id$ 
 * $Log$
 */

#include <helios.h>
#include <syslib.h>
#include <stdarg.h>
#include <servlib.h>
#include <codes.h>
#include <gsp.h>
#include <module.h>
#include <device.h>
#include <limits.h>

#include "param.h"
#include "buf.h"
#include "filedesc.h"
#include "file.h"
#include "namei.h"
#include "specdev.h"
#include "user.h"
#include "proc.h"
#include "mount.h"
#include "vnode.h"
#include "quota.h"
#include "inode.h"
#include "time.h"
#include "malloc.h"
#include "socketvar.h"
#include "fcntl.h"
#include "uio.h"

#include "dispatch.h"

/*
 * Necessary stub routines for interfacing Helios directly into the
 * kernel.
 */

/*
 * General routine to delete a file/directory off the disk.  The
 * name is passed and depending whether the target is a file or a directory
 * the corresponding routine will be called.  This is a merge of unlink and
 * rmdir.
 */
int sysdelete(p, uap, retval)
	register struct proc *p;
	register struct name_args *uap;
	int *retval;
{
	struct nameidata nd;
	struct nameidata *ndp = &nd;
	struct vnode *vp;
	int error;
	bool isdir;
	
#ifdef SHOWCALLS
	IOdebug("ufs: sysdelete called: '%s'",uap->name);
#endif
	/* Setup for the name search */
	ndp->ni_nameiop = DELETE | LOCKPARENT | LOCKLEAF;
	ndp->ni_segflg = UIO_USERSPACE;
	ndp->ni_dirp = uap->name;

	/* Lookup the object 1st */
	error = namei(ndp,p);
	if (!error) {	/* Object found, do appropriate deletion. */
		vp = ndp->ni_vp;
		
		if (isdir = (vp->v_type == VDIR)) {
			/* Delete directory.  AMS- Code from UNIX rmdir */
			/*
			 * No rmdir "." please.
			 */
			if (ndp->ni_dvp == vp)
				error = EINVAL;
			else if (vp->v_flag & VROOT)
				/*
				 * Don't unlink a mounted directory.
				 */
				error = EBUSY;

		} else {
			/* Delete a file.  -AMS Code from UNIX unlink. */
			if (vp->v_flag & VROOT) 
				/*
				 * Don't unlink a mounted file.
				 */
				error = EBUSY;
		}
		if (!error) {
			if (isdir) 	error = VOP_RMDIR(ndp,p);
			else 		error = VOP_REMOVE(ndp,p);
		} else {
			VOP_ABORTOP(ndp);
			if (ndp->ni_dvp == vp)
				vrele(ndp->ni_dvp);
			else
				vput(ndp->ni_dvp);
			vput(vp);
		}
	}
	return(error);
}

/* 
 * System Call from HELIOS to UNIX.
 */
int syscall(	ClientState *cs, 
		int (*fn)(), 
		struct syscall_args *uap,
		int *retval )
{
	int error;

#ifdef DEBUG
IOdebug("syscall %s made ",(char *)procname(*fn));
#endif
	if (cs->SysCall != NULL) {
		IOdebug("SysCall %s: Call to %s already in progress",
			 (char *)procname(fn),procname(cs->SysCall));
		return(EALREADY);
	}

	/* Set the call and get kernel */
	cs->SysCall = (VoidFnPtr)fn;
	tokernel();

	/* Setup the process state */
	curproc = &cs->p;

	/* Make the call */
#ifdef DEBUG
IOdebug("syscall: about to do its call");
#endif
	error = (*fn)(&(cs->p),uap,retval);

	/* Reset state */
	cs->SysCall = NULL;

	/* Free the kernel */
	fromkernel();
#ifdef DEBUG
IOdebug("syscall %s done: error %d (0x%x)",(char *)procname(fn),error,error);
#endif
	/* Back To Originator */
	return(error);
}

