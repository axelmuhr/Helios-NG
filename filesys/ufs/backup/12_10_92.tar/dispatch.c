/* (C)1992 Perihelion Software Limited                                */
/* Author: Alex Schuilenburg                                          */
/* Date: 6 August 1992                                                */
/* File: dispatch.c                                                   */
/*                                                                    */
/*
 * This file contains the main dispatcher routine, as well as its
 * support routines.  These support routines provide the interface
 * from Helios into the UNIX kernel.
 */
/*
 * $Id$ 
 * $Log$
 */

#include "param.h"
#include "malloc.h"
#include "buf.h"
#include "filedesc.h"
#include "file.h"
#include "user.h"
#include "stat.h"
#include "proc.h"
#include "mount.h"
#include "vnode.h"
#include "fcntl.h"

#include <helios.h>
#include <syslib.h>
#include <stdarg.h>
#include <servlib.h>
#include <codes.h>
#include <gsp.h>
#include <module.h>
#include <device.h>

#include "dispatch.h"

/*
 * Variables local to the dispatcher.
 */
#define STACKSIZE	10000		/* whatalotigot */
#define PID_MIN		42		/* Life the universe and everything */
static List ClientsRoot;		/* Root of clients */
static Semaphore ClientsLock;		/* Semaphore for access to list */
static Semaphore ClientsActive;		/* Number of active clients */
static int pid_counter = PID_MIN;	/* The answer !!! */

/*
 * HELIOS filesystem resource variables.
 */
word SyncTime;		/* Maximum idle time before sync */

/*
 * UNIX resource variables.
 */
extern struct plimit limit0;

/*
 * Prototypes for UNIX system call routines.
 */
extern sync();

/*
 * Create a client structure and add it to the list.
 */
int createclient(ClientState **client)
{
	struct proc *proc;
	
	*client = (ClientState *)malloc(sizeof(ClientState),M_TEMP,M_NOWAIT);
	if (*client == NULL) {
		panic("No more memory to create clients");
		return(ENOMEM);
	}
	bzero(*client,sizeof(ClientState));	/* Sets ofname + force_close */
	InitSemaphore(&((*client)->refs),1);	/* Also indicates open files */

	/* Initial Values etc. */
	proc = &(*client)->p;
		
	/* Initialise proc */
	proc->p_cred = (struct pcred *)malloc(sizeof(struct pcred),M_TEMP,M_NOWAIT);
	bcopy(proc0.p_cred, proc->p_cred, sizeof(struct pcred)); /* Dup proc0 */
	proc->p_ucred = crget();		/* Zero Credentials */
	proc->p_fd = fdcopy(&proc0);		/* Copy proc0's fd */
	proc->p_pid = pid_counter++;
	if (pid_counter < PID_MIN) pid_counter = PID_MIN;

	/* Initial limits for all the same */
	proc->p_limit = proc0.p_limit;		/* Copy proc0's limit */
	proc->p_limit->p_refcnt++;

	/* Set the pointers to the root file system and vnode. */
	proc->p_fd->fd_cdir = rootdir;
	vref(proc->p_fd->fd_cdir);
	proc->p_fd->fd_rdir = NULL;

	/* Add to the HELIOS client list */
	Wait(&ClientsLock);
	AddHead(&ClientsRoot,&(*client)->node);
	Signal(&ClientsLock);
	Signal(&ClientsActive);

#ifdef MONITOR
IOdebug("ufs: Client 0x%x   PID %d Created",*client,(*client)->p.p_pid);
#endif
	return(0);
}

/*
 * Remove a client from the list.
 */
void removeclient(ClientState *client) 
{	struct proc *p = &(client->p);
	int done = TRUE;	/* No more work to do */

#ifdef MONITOR
IOdebug("ufs: Client 0x%x   PID %d Terminated",client,p->p_pid);
#endif
	/* Delete a reference */
	if (!TestWait(&(client->refs))) {
		IOdebug("removeclient: PANIC, deleting unreferenced client");
	}

	/* Remove client from list */
	Wait(&ClientsLock);
	if (TestSemaphore(&(client->refs)) == 0) {
		/* Client is no longer referenced */
		Wait(&ClientsActive);
		Remove(&client->node);
		done = FALSE;		/* More work to do */
	}
	Signal(&ClientsLock);

	/* If not removed from list, then return else more work */
	if (done) return;

	/* Free references and memory */
	fdfree(p);
	p->p_limit->p_refcnt--;
	vrele(p->p_fd->fd_cdir);
	crfree(p->p_ucred);
	if (--p->p_cred->p_refcnt == 0) {
		free(p->p_cred,M_TEMP);
	} else {
		p->p_ucred = NOCRED;
		IOdebug("PANIC: Client terminate with ref count = %d",
			p->p_cred->p_refcnt);
	}

	free(client,M_TEMP);
}

/*
 * Look for a client which matches the user in the list.
 */
word is_user(ClientState *client, uid_t uid)
{
	if (client->p.p_cred->p_ruid == uid) {
		Signal(&(client->refs));
		return TRUE;
	} else {
		return FALSE;
	}
}

ClientState *findclient(uid_t uid, gid_t gid)
{
	ClientState *client;
	struct ucred *cr;
	int i;

	/* This maintains downward capability below 1.3 */
	if (uid == 0xFFFF)	return (NULL);

	/* Lock the list while we search for the client. */
	Wait(&ClientsLock);
	client = (ClientState *)SearchList(&ClientsRoot,(WordFnPtr)is_user,uid);
	Signal(&ClientsLock);

	/* Setup the group structure */
	if (client != NULL) {
		/* This has been signalled in is_user */
		/* Just check out the group structure */
		cr = client->p.p_ucred;
		for (i=0; (i < cr->cr_ngroups) && (cr->cr_groups[i] != gid); i++);
		if ((i == cr->cr_ngroups) && (cr->cr_ngroups < NGROUPS)) {
			/* Not found, so add group to credentials */
			cr->cr_groups[cr->cr_ngroups++] = gid;
		}
	}

	return(client);
}

/* 
 * Create a new MCB structure 
 */
MyMCB *NewMyMCB(void)
{
	MyMCB *m;
	
	while ((m = (MyMCB *)malloc(sizeof(MyMCB),M_TEMP,M_WAITOK)) == NULL) 
		Delay(OneSec);
	m->mcb.Control = (word *)&m->control;
	m->mcb.Data = (byte *)&m->data;
	return(m);
}

/*
 * Routine to perform a system sync on the disks when the disk is quiet.
 */
/* 
 * Handle Sync Request
 */
void system_sync(ClientState *client)
{
	struct fd_args fd_args;
	int error,retval=0;

	/* Sync the disk */
	error = syscall(client,sync,(struct syscall_args *)&fd_args,&retval);

	/* Remove the client */
	removeclient(client);
}

/*
 * The MAIN dispatcher.
 */
/* Dispatch until doloop is false. */
void dispatcher(Port reqport)
{
	MyMCB *mymcb = NULL;
	MCB *mcb;
	IOCMsg2 *req;
	ClientState *newclient = NULL;
	ClientState *c;
	Capability *cap;
	void (*fn)();
	int doloop = TRUE;
	int e;
	word ugid;
	uid_t uid;
	gid_t gid;
	struct ucred *cr;

	/* Initialise HELIOS Filesystem Variables */
	SyncTime = IOCTimeout;

	/* Setup the list of clients and the semaphore */
	InitList(&ClientsRoot);
	InitSemaphore(&ClientsLock,1);
	InitSemaphore(&ClientsActive,0);

	while (doloop) {
		/* Prepare to receive */
		if (mymcb == NULL) {
			mymcb = NewMyMCB();

			/* Quick Access Variables */
			mcb = &(mymcb->mcb);
			req = (IOCMsg2 *)mcb->Control;
			cap = &(req->Common.Access);
		}
		mcb->MsgHdr.Dest = reqport;
		mcb->Timeout = SyncTime;

		/* Create a new client if required */ 
		if (newclient == NULL) 
			while (createclient(&newclient)) Delay(OneSec);
#ifndef MONITOR
IOdebug("dispatch: waiting for msg");
#endif
		/* Receive the message */
		e = GetMsg(mcb);
		if ((e & EG_Mask) == EG_Invalid) {
			IOdebug("ufs: Invalid message received");
			break;
		}

		/* Process the message */	
		if (e > 0) {
			/* Extract the user and group ids */
			ugid = ((word *)cap)[1];
			uid = ugid & 0xFFFF;
			gid = (ugid >> 16) & 0xFFFF;
			if ((c = findclient(uid,gid)) == NULL) {
				c = newclient;
				newclient = NULL;

				if (uid != 0xFFFF) { /* Downward compatability */
					c->ugid = (gid << 16) | uid;
IOdebug("newclient 0x%x used",c);
					/* Set up user id */
					c->p.p_cred->p_ruid = uid;
					c->p.p_cred->p_svuid = uid;
					c->p.p_cred->p_rgid = gid;
					c->p.p_cred->p_svgid = gid;

					/* And in the credentials. */
					cr = c->p.p_ucred;
					cr->cr_uid = uid;
					cr->cr_gid = gid;
					cr->cr_ngroups = 1;
				}
			}
/*	MCB *mcb = &m->mcb;
	IOCMsg2 *req = (IOCMsg2 *)mcb->Control;
	nfshandle *fh = NULL;
	word error = Err_Null;
	Capability cap = req->Common.Access;
	AccMask mask =  req->Arg.AccMask;
*/

/* IOdebug("user id = %d     group id = %d     Msg 0x%x",uid,gid,e); */

#ifndef MONOTOR
IOdebug("ufs: dispatch %F",e);
#endif
			switch (e & FG_Mask)
			{
			case FG_Open:		fn = do_open;	   break;
			case FG_Create:		fn = do_create;	   break;
			case FG_Locate:		fn = do_locate;	   break;
			case FG_ObjectInfo:	fn = do_objinfo;   break; 
			case FG_ServerInfo:	fn = do_servinfo;  break; 
			case FG_Delete:		fn = do_delete;	   break; 
			case FG_Rename:		fn = do_rename;	   break; 
			case FG_Link:		fn = do_link;	   break; 
/*			case FG_Protect:	fn = do_protect;   break; */
			case FG_SetDate:	fn = do_setdate;   break; 
/*			case FG_Refine:		fn = do_refine;	   break; */
/*			case FG_CloseObj:	fn = do_closeobj;  break; */
/*			case FG_Revoke:		fn = do_revoke;	   break; */
/*			case FG_Private:	fn = do_private;   break; */
			case FG_Terminate:	doloop = FALSE;
						/* Sync the disks and the like. */
/*						removeclient(c); c = NULL;
						FreeMyMCB(mymcb); mymcb = NULL;
*/
						fn = do_sync;
						break;
			default:
				IOdebug("ufs: dispatcher received unknown request");
				InitMCB(mcb,0,mcb->MsgHdr.Reply,NullPort,
					EC_Error|SS_HardDisk|EG_WrongFn);
				PutMsg(mcb);
				continue;
			}

			/* Fork off the handler */
			if (!Fork(STACKSIZE,fn,sizeof(mymcb)+sizeof(c),mymcb,c)) {
				InitMCB(mcb,0,mcb->MsgHdr.Reply,NullPort,
					EC_Error|SS_HardDisk|EG_NoMemory);
				PutMsg(mcb);
				continue;
			}
			mymcb = NULL;
		} else if ((e & EG_Mask) == EG_Timeout) {
			/* On a timeout, sync the disks */
			if (Fork(STACKSIZE,system_sync,
			    sizeof(newclient),newclient)) {
				newclient = NULL;
			} else {
				IOdebug("ufs: Could not perform a system sync");
			}
			continue;
		} else {
			IOdebug("ufs: dispatcher error in receiving message");
		}
	}

	/* Empty the client list */
	while (TestSemaphore(&ClientsActive)) {
		IOdebug("dispatcher: waiting for clients to terminate");
		Delay(OneSec*5);
	}
}


