/* (C)1992 Perihelion Software Limited                                */
/* Author: Alex Schuilenburg                                          */
/* Date: 29 July 1992                                                 */
/* File: conf.c                                                       */
/*                                                                    */
/* This file contains the configuration parameters for the UFS under  */
/* helios.                                                            */
/*                                                                    */
/* $Id$ */
/* $Log$ */

#include "sys/param.h"
#include "sys/systm.h"
#include "sys/mount.h"
#include "sys/buf.h"
#include "sys/vnode.h"
#include "sys/ioctl.h"
#include "sys/conf.h"
#include "sys/proc.h"

extern int nullop(), enxio(), enodev();

/* System arameters */
#define MAXUSERS 20
#define	NPROC (20 + 16 * MAXUSERS)
int	maxproc = NPROC;
#define	NTEXT (80 + NPROC / 8)			/* actually the object cache */
#define	NVNODE (NPROC + NTEXT + 100)
long	desiredvnodes = NVNODE;
int	maxfiles = 3 * (NPROC + MAXUSERS) + 80;

/* The block device driver definitions */
/* Currently only one: hard disk.      */
int	hd_open(), hd_close(), hd_strategy(), hd_ioctl(), 
	hd_dump(), hd_size();

#define NBLKDEV 1
struct bdevsw bdevsw[NBLKDEV] = {
{  hd_open,	hd_close,	hd_strategy,	hd_ioctl,
   hd_dump,	hd_size,	NULL}
};
int nblkdev = sizeof(bdevsw) / sizeof(bdevsw[0]);

/* The character device driver definitions */
/* Currently only one: memory.             */
int	mm_rw();
#define mm_select	seltrue

#define NCHRDEV 1
struct cdevsw cdevsw[NCHRDEV] = {
{  nullop,	nullop,		mm_rw,		mm_rw,
   enodev,	nullop,		nullop,		NULL,
   mm_select,	enodev,		NULL}
};
int nchrdev = sizeof(cdevsw) / sizeof(cdevsw[0]);
int mem_no = 0;	/* major device number of memory special file /dev/kmem */

/* Define the UNIX filesystem operations */
/*
 * This specifies the filesystem used to mount the root.
 * This specification should be done by /etc/config.
 */
extern int ufs_mountroot();
int (*mountroot)() = ufs_mountroot;

/*
 * These define the root filesystem and device.
 */
struct mount *rootfs;
struct vnode *rootdir;	/* The vnode of '/' */

/*
 * Set up the filesystem operations for vnodes.
 * The types are defined in mount.h.
 */
extern	struct vfsops ufs_vfsops;

#define NVFSDEV 5
struct vfsops *vfssw[NVFSDEV] = {
	(struct vfsops *)0,	/* 0 = MOUNT_NONE */
	&ufs_vfsops,		/* 1 = MOUNT_UFS */
	(struct vfsops *)0,	/* 2 = MOUNT_NFS - &nfs_vfsops */
	(struct vfsops *)0,	/* 3 = MOUNT_MFS - &mfs_vfsops */
	(struct vfsops *)0,	/* 4 = MOUNT_PC */
};


