/* (C)1992 Perihelion Software Limited                                */
/* Author: Alex Schuilenburg                                          */
/* Date: 7 August 1992                                                */
/* File: fileserv.c                                                   */
/*                                                                    */
/*
 * This file contains the open file server and its service routines.
 * Other service routines for open directories may be found in dirserv.c 
 * with the main service routines in services.c
 */
/*
 * $Id$ 
 * $Log$
 */

#include "param.h"
#include "malloc.h"
#include "buf.h"
#include "filedesc.h"
#include "file.h"
#include "user.h"
#include "stat.h"
#include "proc.h"
#include "mount.h"
#include "vnode.h"
#include "fcntl.h"

#include <helios.h>
#include <syslib.h>
#include <stdarg.h>
#include <servlib.h>
#include <codes.h>
#include <gsp.h>
#include <module.h>
#include <device.h>
#include <dirent.h>

#include "dispatch.h"

/*
 * Prototypes for HELIOS->UNIX system call routines (direct into kernel).
 */
extern sysvnstat();

/*
 * Prototypes for UNIX system call routines.
 */
extern read(), write(), lseek(), ftruncate(), fstat(), close();

/* Reading from a file */
static void do_read(MyMCB *mymcb, struct ufsrw *ar)
{
	MCB *mcb = &mymcb->mcb;
	byte *oldbuffer = mcb->Data;
	ReadWrite *rw = (ReadWrite *)mcb->Control;
	word pos = rw->Pos;
	word size = rw->Size;
	Port replyport = mcb->MsgHdr.Reply;
	struct rdwr_args *args = &ar->rdwr_args;
	word sent = 0;
	word seq = 0;
	word send, e;
	int error, retval;

#ifdef DEBUG
IOdebug("ufs: do_read; Request for %d bytes",size);
#endif
	/* This seek is absolute.  Subsequent reads (below) need no
	 * seeks as the pointer is advanced automatically anyway.
	 * - WARNING: Pipe check ? 
	 */
	ar->fp->f_offset = pos;

	/* Read up to end of block limit */	
	send = MAXBSIZE - (pos % MAXBSIZE);
	if (send > size) send = size;

	while (send)  {
		/* Prevent OverFlow */
		if (send > MAXBSIZE) send = MAXBSIZE;
	
		/* Setup for call */
		args->fd = ar->handle;
		args->buf = (char *)&ar->buf;
		args->count = send;
		error = syscall(ar->client,read,
				(struct syscall_args *)args,&retval);
		if (error) {
			mcb->Data = oldbuffer;
			ErrorMsg(mcb,EC_Error|EG_Errno|error);
			return;
		}

		/* Add data read */
		sent += retval;
		pos += retval;

		/* Reply */
		InitMCB(mcb,0,replyport,NullPort,seq);
		if (send != retval) {
			/* EOF Reached prematurely */
			mcb->MsgHdr.FnRc |= ReadRc_EOF;
			sent = size;	/* Force exit condition */

#ifdef DEBUG
IOdebug("do_read: EOF; read=%d   wanted=%d  flags=0x%x",retval,send,mcb->MsgHdr.Flags);
#endif
		} else if (sent == size) {
			mcb->MsgHdr.FnRc |= ReadRc_EOD;

#ifdef DEBUG
IOdebug("do_read: EOD; read=%d   wanted=%d  flags=0x%x",retval,send,mcb->MsgHdr.Flags);
#endif

		} else {	/* More Data Will Follow */
			mcb->MsgHdr.Flags |= MsgHdr_Flags_preserve;

#ifdef DEBUG
IOdebug("do_read: MOR; read=%d   wanted=%d  flags=0x%x",retval,send,mcb->MsgHdr.Flags);
#endif

		}
		mcb->MsgHdr.DataSize = retval;
		mcb->Data = (byte *)&ar->buf;

		if ((e = PutMsg(mcb)) < Err_Null) {
			IOdebug("ufs: File Read; client disappeared");
#ifdef DEBUG
IOdebug("do_read: PutMsg returned 0x%x  Port=0x%x  Actual=0x%x",e,replyport,mcb->MsgHdr.Dest);
#endif
		}
		
		/* Keep the ball rolling */
		send = size - sent;
		seq += ReadRc_SeqInc;
	}

	/* Restore the old buffer */
	mcb->Data = oldbuffer;
}

/* Writing to a file */
static void do_write(MyMCB *mymcb, struct ufsrw *ar)
{
	MCB *mcb = &mymcb->mcb;
	byte *oldbuffer = mcb->Data;
	ReadWrite *rw = (ReadWrite *)mcb->Control;
	word pos = rw->Pos;
	word size = rw->Size;
	Port replyport = mcb->MsgHdr.Reply;
	Port dataport = NewPort();
	struct rdwr_args *args = &ar->rdwr_args;
	word e, got, seq;
	word wrt;
	int error, retval;

#ifdef DEBUG
IOdebug("ufs: do_write; Request for %d bytes",size);
#endif

	/* Send back 1st reply */
	InitMCB(mcb,MsgHdr_Flags_preserve,replyport,dataport,WriteRc_Sizes);
	MarshalWord(mcb,MAXBSIZE);	
	MarshalWord(mcb,MAXBSIZE);	
	e = PutMsg(mcb);
	
	InitMCB(mcb,0,dataport,NullPort,0);
	mcb->Data = (byte *)&ar->buf;
	e = got = seq = 0;
	
	/* This seek is absolute.  Subsequent reads (below) need no
	 * seeks as the pointer is advanced automatically anyway.
	 * - WARNING: Pipe check ? 
	 */
	ar->fp->f_offset = pos;

	while (got < size) {
		e = GetMsg(mcb);
		if (e < Err_Null) break;
		if ((e & ~ReadRc_Mask) != seq) {
			e = EC_Warn|SS_HardDisk;
			break;
		}
		
		wrt = mcb->MsgHdr.DataSize;

		/* Setup for call */
		args->fd = ar->handle;
		args->buf = (char *)&ar->buf;
		args->count = wrt;
		error = syscall(ar->client,write,
				(struct syscall_args *)args,&retval);
		if (error) {
			mcb->Data = oldbuffer;
			mcb->MsgHdr.Reply = replyport;
			ErrorMsg(mcb,EC_Error|EG_Errno|error);
			return;
		}

		/* Check (superfluous I hope) */
		if (retval != wrt) 
			IOdebug("ufs: do_write failed. Wrote %d when wanted to write %d",retval,wrt);
			
		/* Update for Next Write */
		got += retval;
		seq += ReadRc_SeqInc;
	}
		
	FreePort(dataport);
	
	InitMCB(mcb,0,replyport,NullPort,e<0?e:WriteRc_Done);
	MarshalWord(mcb,got);
	e = PutMsg(mcb);

	/* Restore Data */
	mcb->Data = oldbuffer;
}

/* Close a file (calls the close routine). */
static void do_close(MyMCB *mymcb, struct ufsrw *ar)
{
	struct fd_args fd_args;
	int error, retval;
	
	fd_args.fd = ar->handle;
	error = syscall(ar->client,close,(struct syscall_args *)&fd_args,
			&retval);
}

/* Wrong Function */
static void do_wrong(MyMCB *mymcb)
{
	MCB *mcb = &mymcb->mcb;
	ErrorMsg(mcb,EC_Error|EG_WrongFn|EO_File);
}

/* Seek to a location */
static void do_seek(MyMCB *mymcb, struct ufsrw *ar)
{
	MCB *mcb = &mymcb->mcb;
	SeekRequest *req = (SeekRequest *)mcb->Control;
	struct lseek_args lseek_args;
	int error, retval;

	lseek_args.fd = ar->handle;
	lseek_args.off = req->NewPos;
	switch (req->Mode)
	{
	case S_Beginning:	lseek_args.sbase = L_SET;	break;
	case S_Relative:	lseek_args.off += req->CurPos;
				lseek_args.sbase = L_SET; 	break;
	case S_End:		lseek_args.sbase = L_XTND;	break;
	}

	if (error = syscall(ar->client,lseek,(struct syscall_args *)&lseek_args,
			&retval)) {
		ErrorMsg(mcb,EC_Error|EG_Errno|error);
		return;
	}
	
	InitMCB(mcb,0,mcb->MsgHdr.Reply,NullPort,Err_Null);
	MarshalWord(mcb,lseek_args.off);
	PutMsg(mcb);
}

/* Get the file size */
static void do_getsize(MyMCB *mymcb, struct ufsrw *ar)
{
	MCB *mcb = &mymcb->mcb;
	struct stat stat;
	struct fstat_args fstat_args;
	int retval, error;

	fstat_args.fd = ar->handle;
	fstat_args.buf = &stat;	
	if (error = syscall(ar->client,fstat,
			    (struct syscall_args *)&fstat_args,&retval)) {
		ErrorMsg(mcb,EC_Error|EG_Errno|error);
		return;
	}
	
	InitMCB(mcb,0,mcb->MsgHdr.Reply,NullPort,0);
	MarshalWord(mcb,stat.st_size);
	PutMsg(mcb);	
}

/* Set a file size (truncate) */
static void do_setsize(MyMCB *mymcb, struct ufsrw *ar)
{
	MCB *mcb = &mymcb->mcb;
	struct ftrunc_args ftrunc_args;
	word *size = mcb->Control;
	int error, retval;
		
	ftrunc_args.fd = ar->handle;
	ftrunc_args.length = *size;
	if (error = syscall(ar->client,ftruncate,
			(struct syscall_args *)&ftrunc_args,&retval)) {
		ErrorMsg(mcb,EC_Error|EG_Errno|error);
		return;
	}
	InitMCB(mcb,0,mcb->MsgHdr.Reply,NullPort,Err_Null);
	PutMsg(mcb);	
}

/*
 * The actual file server server.
 */
void file_server(MyMCB *mymcb, ClientState *client, word handle)
{
	MCB *mcb = &mymcb->mcb;
	Port reqport = mcb->MsgHdr.Reply;
	struct ufsrw *rw = (struct ufsrw *)malloc(sizeof(struct ufsrw),M_TEMP,M_WAITOK);
	word oldtimeout = mcb->Timeout;
	word e;
	int *force_close;
	char *ofname;

	if (rw == NULL) {
		ErrorMsg(mcb,EC_Error|EG_NoMemory|EO_File);
		IOdebug("ufs: file_server panic; No memory left to service requests.");
		return;
	}
	
	/* Setup Credentials */
	rw->client = client;
	rw->handle = handle;
	rw->fp = client->p.p_fd->fd_ofiles[handle];	/* Quick Reference */
	
	/* Other quick references */
	force_close = &(client->force_close[handle]);
	ofname = client->ofname[handle];

	/* Process Messages */
	for (;;) {
		InitMCB(mcb,0,reqport,NullPort,0);
		mcb->Timeout = IdleTimeout;	/* Idle, check for force close */
		e = GetMsg(mcb);
		mcb->Timeout = oldtimeout;	/* Restore */
		if (e < 0) {
			if ((e & EG_Mask) == EG_Timeout) {
				if (*force_close) {
					IOdebug("ufs: Forcing close of file %s for PID #%d",ofname,client->p.p_pid);
					do_close(mymcb,rw);
					goto done;
				}
			}
#ifdef DEBUG
IOdebug("file_server: serving open file %s for 0x%x",ofname,client);
#endif

			continue;
		}

		mcb->MsgHdr.FnRc = SS_HardDisk;

#ifdef DEBUG
IOdebug("ufs: file_server %F  file %s",e,ofname);
#endif
		switch (e & FG_Mask)
		{
		case FG_Read:		do_read(mymcb,rw);	break;
		case FG_Write:		do_write(mymcb,rw);	break;
		case FG_Seek:		do_seek(mymcb,rw);	break;
		case FG_GetInfo:	do_wrong(mymcb);	break;
		case FG_SetInfo:	do_wrong(mymcb);	break;
		case FG_GetSize:	do_getsize(mymcb,rw);	break;
		case FG_SetSize:	do_setsize(mymcb,rw);	break;
		case FG_Select:
			/* a select will always succeed immediately */
			ErrorMsg(mcb,e&Flags_Mode);
			break;
		case FG_Close:		do_close(mymcb,rw);	goto done;
		default:		
			ErrorMsg(mcb,EC_Error|EG_WrongFn|EO_File);
			break;
		}
	}	
done:
	/* Free Buffers and return */
	free(rw,M_TEMP);
	return;
}



