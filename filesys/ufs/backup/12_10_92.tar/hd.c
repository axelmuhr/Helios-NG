/* (C)1992 Perihelion Software Limited                                */
/* Author: Alex Schuilenburg                                          */
/* Date: 29 July 1992                                                 */
/* File: hd.c                                                         */
/*                                                                    */
/* This file contains the UNIX device driver routines for Helios.     */
/* It also contains the controlling routines for the device.          */
/*                                                                    */
/* $Id$ */
/* $Log$ */

#include <string.h>
#include <gsp.h>
#include <module.h>
#include <device.h>
#include <sem.h>
#include <codes.h>

#include "param.h"
#include "vnode.h"
#include "quota.h"
#include "inode.h"
#include "buf.h"
#include "fs.h"
#include "file.h"
#include "ioctl.h"
#define DFLT_SIZES
#include "disklabel.h"

/*
 * Define the drive states.
 */
#define RAWDISK		8
#define ISRAWSTATE(s)	(RAWDISK&(s))		/* Are we in raw state */
#define DISKSTATE(s)	(~RAWDISK&(s))		/* Ignore raw mode */

#define CLOSED		0
#define READLABEL	1
#define	OPEN		2

#define RAWOPEN		(RAWDISK|OPEN)

#define b_cylin		b_resid

/*
 * Semaphore to signal the number of buffers waiting on the controller.
 */
Semaphore hd_numbufs;

/*
 * The DCB for each of the drives, plus partition info required.
 */
struct disk {
	struct disklabel dk_lab;		/* Disk label		*/
	short	dk_wlabel;			/* Label writable?	*/
	short	dk_state;			/* Disk state		*/
	short	dk_protected;			/* Write protected?	*/
	long	dk_reads, dk_writes;		/* No of r/w		*/
	Semaphore dk_numq;			/* Number of bufs in q	*/
	Semaphore dk_guard;			/* Guard for dk_queue.	*/
	struct buf dk_queue;			/* Head of disk queue	*/
	short	dk_pstatus[MAXPARTITIONS];	/* Status of partitions	*/
};

struct disk hd[MAXDISKS];			/* Disk information.	*/

/*
 * Initialise the device routines
 */
void hd_init(void)
{
	int i,j;

	InitSemaphore(&hd_numbufs,0);
	for (i=0; i<MAXDISKS; i++) {
		hd[i].dk_lab = dflt_sizes;
		hd[i].dk_wlabel = 0;
		hd[i].dk_state = CLOSED;
		hd[i].dk_protected = FALSE;
		hd[i].dk_reads = 0;
		hd[i].dk_writes = 0;
		InitSemaphore(&hd[i].dk_numq,0);
		InitSemaphore(&hd[i].dk_guard,1);
		hd[i].dk_queue.b_actf = NULL;
		hd[i].dk_queue.b_forw = NULL;
		for (j=0; j<MAXPARTITIONS; j++)
			hd[i].dk_pstatus[j]=CLOSED;
	}

}

/*
 * Read/Write routine for a buffer.  Finds the proper unit (minor dev),
 * range checks arguments and schedules the transfer.  Does not wait
 * for the transfer to complete.  All I/O requests must be a multiple
 * of a sector in length.
 */
int hd_strategy(struct buf *bp)
{
	u_int unit = dkunit(bp->b_dev);
	u_int part = dkpart(bp->b_dev);
	struct disk *du = &hd[unit];
	struct buf *dp;
	struct partition *p;
	long maxsz, sz;
#ifdef MONITOR
IOdebug("hd_strategy: Called with bp=0x%x, dev=%d, blck=%d  by %s",
	bp,bp->b_dev,bp->b_blkno,procname(returnlink_(bp)));
#endif
	/* Simple parameter check */
	if ((unit >= MAXDISKS) || (bp->b_blkno < 0) 
	    || (part >= du->dk_lab.d_npartitions)) {
		printf("hd_strategy: unit=%d, part=%d, blkno=%d, bcount=%d\n",
			unit,part,bp->b_blkno,bp->b_bcount);
		printf("hd: Error in hd_strategy");
		bp->b_flags |= B_ERROR;
		goto bad;
	}

	/* Check for write protection */
	if (du->dk_protected && ((bp->b_flags & B_READ) == 0)) {
		printf("hd%d: write protected\n",unit);
		goto bad;
	}

	if (DISKSTATE(du->dk_state) != OPEN)
		goto q;

	/* Determine size of xfer and make sure it fits. */
	p = &(du->dk_lab.d_partitions[part]);
	maxsz = p->p_size;
	sz = (bp->b_bcount + DEV_BSIZE - 1) >> DEV_BSHIFT;

	/* XXX Check disk label writing at a later stage */

	/* Check the parameters */
	if ((bp->b_blkno < 0) || ((bp->b_blkno + sz) > maxsz)) {
		/* if exactly at end of disk, return an EOF. */
		if (bp->b_blkno == maxsz) {
			bp->b_resid = bp->b_bcount;
			biodone(bp);
			return(0);
		}
		/* or truncate if part of it fits */
		sz = maxsz - bp->b_blkno;
		if (sz <= 0) goto bad;
		bp->b_bcount = sz << DEV_BSHIFT;
	}
	bp->b_cylin = (bp->b_blkno + p->p_offset) / du->dk_lab.d_secpercyl;

q:
	dp = &(du->dk_queue);

	/* Lock buffer head, add item, free buffer head and signal */
	Wait(&du->dk_guard);		/* Lock */
	disksort(dp, bp);		/* Add */
	Signal(&du->dk_guard);		/* Free */
	Signal(&du->dk_numq);		/* Signal another buffer in this q */
	Signal(&hd_numbufs);		/* Signal Device Driver */
	
#ifdef MONITOR
IOdebug("hd_strategy: Done OK");
#endif
	return(0);

bad:
#ifdef MONITOR
IOdebug("hd_strategy: Done Failed");
#endif
	bp->b_error = EINVAL;
	biodone(bp);
	return(1);
}

/*
 * Open a minor device (relative to controller).
 * If the disk has not been opened, it is.  Since the minor device number
 * also refers to the partition, this will also setup the partition state.
 */
int hd_open(dev_t dev,	int flags, int fmt)
{
	struct disk *du;
	unsigned int unit, part;
	struct buf *bp;
	int error = 0;

#ifdef MONITOR
 IOdebug("hd_open: Called with dev=%d,  flags=%d,   fmt=%d  by %s",
	dev,flags,fmt,procname(returnlink_(dev)));
#endif
	/* Get the unit info */
	unit = dkunit(dev);
	if (unit >= MAXDISKS) return(ENXIO);
	du = &hd[unit];

	/* Has the disk already been opened. */
	if (du->dk_state != CLOSED) {
		/* Already open, so don't mess with it. */
		goto getpart;
	}

	/* Get the disk label */
	du->dk_lab = dflt_sizes;
	du->dk_state = READLABEL;
	bp = geteblk(512);
	bp->b_dev = dev & 0xfff8;	/* Force to boot partition (a) */
	bp->b_blkno = LABELSECTOR;
	bp->b_flags = B_READ;
	hd_strategy(bp);		/* Start the operation. */
	biowait(bp);			/* Wait until complete */
	if (bp->b_flags & B_ERROR) {
		error = ENXIO;
		du->dk_state = CLOSED;
		goto done;
	}

	/* Is label there, otherwise open as raw. */
	if (((struct disklabel *)
	    (bp->b_un.b_addr + LABELOFFSET))->d_magic == DISKMAGIC) {
		du->dk_lab = *(struct disklabel *)
				(bp->b_un.b_addr + LABELOFFSET);
		du->dk_state = OPEN;
	} else {
		printf("hd%d: Bad disk label (%x)\n",bp->b_dev,
    ((struct disklabel *)(bp->b_un.b_addr + LABELOFFSET))->d_magic);
		du->dk_state = RAWOPEN;
	}

done:
	/* Release buffer. */
	bp->b_flags = B_INVAL | B_AGE;
	brelse(bp);

getpart:
	/* Get and set the partition info */
	part = dkpart(dev);
	if (part >= MAXPARTITIONS) return(ENXIO);
	if (du->dk_pstatus[part] != CLOSED) {
		/* Partition is already open, don't mess with it. */
		return(0);
	}
	if (du->dk_state == RAWOPEN) {
		/* If no label, then only allow raw */
		if (part == (RAWPARTITION - 'a')) {
			du->dk_pstatus[part] = RAWOPEN;
		} else {
			du->dk_state = CLOSED;
			return(ENXIO);	
		}
	} else {
		/* Label found, so check overlap with other open partitions */
		struct partition *pp;
		int start,end,i;

		if (part >= du->dk_lab.d_npartitions) return(ENXIO);
		
		pp = &du->dk_lab.d_partitions[part];
		start = pp->p_offset;
		end = start + pp->p_size;
		for (pp = du->dk_lab.d_partitions, i=0;
		     i < du->dk_lab.d_npartitions;
		     pp++, i++) {
			/* Ends before this starts or starts before this ends */
			if (pp->p_offset + pp->p_size <= start ||
			    pp->p_offset >= end)
				continue;
			if (du->dk_pstatus[i]) {
				printf("hd%d%c: overlaps open partition (%c)\n",
				    unit,part+'a',i+'a');
			}
		}

		du->dk_pstatus[part] = OPEN;
	}
	return(error);
}

/*
 * Close a drive.  Does nothing at the moment.
 */
int hd_close(dev_t dev, int flags, int fmt)
{
	unsigned int unit, part;
	struct disk *du;

#ifdef MONITOR
IOdebug("hd_close: Called with dev=%d,  flags=%d,   fmt=%d  by %s",
	dev,flags,fmt,procname(returnlink_(dev)));
#endif
	
	/* Get the unit info */
	unit = dkunit(dev);
	if (unit >= MAXDISKS) return(ENXIO);
	du = &hd[unit];
	if (du->dk_state == CLOSED) return(0);
	if (du->dk_state == RAWOPEN) {
		du->dk_state = CLOSED;
		for (part=0; part<MAXPARTITIONS; part++)
			du->dk_pstatus[part] = CLOSED;
		return(0);
	}

	part = dkpart(dev);
	if (part >= du->dk_lab.d_npartitions) return(ENXIO);
	du->dk_pstatus[part] = CLOSED;
	for (part=0; 
		(part<MAXPARTITIONS) && (du->dk_pstatus[part] == CLOSED); 
		part++);
	if (part == MAXPARTITIONS) du->dk_state = CLOSED;

	return(0);
}

/*
 * The ioctl routine.  
 */
int hd_ioctl(dev_t dev, int cmd, caddr_t addr, int flag)
{
	u_int unit = dkunit(dev);
	u_int part = dkpart(dev);
	struct disk *du;
	int error = 0;

#ifdef MONITOR
IOdebug("hd_ioctl: Called with dev=%d,  cmd=%d,  flag=%d  by %s",
	dev,cmd,flag,procname(returnlink_(dev)));
#endif

	if ((unit >= MAXDISKS) || (part >= MAXPARTITIONS)) return(ENXIO);
	du = &hd[unit];

	switch(cmd) {
	case DIOCGDINFO:
		*(struct disklabel *)addr = du->dk_lab;
		break;
	case DIOCGPART:
		((struct partinfo *)addr)->disklab = &du->dk_lab;
		((struct partinfo *)addr)->part =
			&du->dk_lab.d_partitions[part];
		break;
	case DIOCSDINFO:
		if ((flag & FWRITE) == 0)
			error = EBADF;
		else
			error = setdisklabel(&du->dk_lab,
					(struct disklabel *)addr,0);
		/* XXX AMS Set this info at controller as well. */
		break;
	case DIOCWLABEL:
		if ((flag & FWRITE) == 0)
			error = EBADF;
		else
			du->dk_wlabel = *(int *)addr;
		break;
	case DIOCWDINFO:
		if ((flag & FWRITE) == 0)
			error = EBADF;
		else if ((error = setdisklabel(&du->dk_lab,
					(struct disklabel *)addr,0)) == 0) {
			int wlab;

			/* XXX AMS Set this info at controller as well. */

			wlab = du->dk_wlabel;
			du->dk_wlabel = 1;
			error = writedisklabel(dev,hd_strategy,&du->dk_lab,part);
			du->dk_wlabel = wlab;			
		}
		break;
	default:
		error = ENOTTY;
		break;
	}

	return(error);
}

/*
 * This returns the size of the passed device in number of 512 blocks (?)
 */
int hd_size(dev_t dev)
{
	u_int unit = dkunit(dev);
	u_int part = dkpart(dev);
	struct disk *du;
	int val;

	if (unit >= MAXDISKS) return(-1);
	if (hd[unit].dk_state == CLOSED) {
		val = hd_open(dev,0,0);
		if (val < 0) return(-1);
	}
	du = &hd[unit];
	return((int)((u_long)du->dk_lab.d_partitions[part].p_size *
		du->dk_lab.d_secsize / 512));
}

/*
 * This routine performs the unit core dump.  Since we are not UNIX
 * we don't.
 */
int hd_dump(dev_t dev)
{
	printf("hd_dump: PANIC called with dev=%d\n",dev);
	IOdebug("hd_dump: PANIC called with dev=%d\n",dev);
	return(0);
}

/*
 * Routine to wake up the hd_intr routine below on completion of disk I/O.
 */
void hd_iodone(DiscReq *req)
{
	Signal(&req->WaitLock);
}

/*
 * The controller interrupt routine.  This checks the minor device queues
 * and performs the required operations on each of the minor devices.
 * The device scheduling is on a round-robin basis with control passing
 * to the next minor device when a queue becomes empty.
 */
extern DCB *rootdcb;	/* This goes later with multiple dev support */
int hd_intr_server(Semaphore *terminate)
{
	static struct disk *last_hd = hd;
	int searched;
	DiscReq req;
	struct partition *pp;
	struct buf *dp, *bp;
#ifdef DEBUG
IOdebug("hd_intr_server: Running");
#endif
	/* Loop until ordered to shut down and no more buffers to work on. */
	while (!TestWait(terminate) || TestSemaphore(&hd_numbufs)) {
		/* Wait for a block to work on. */
		Wait(&hd_numbufs);

		/* Look for a disk to work on */
		searched = 0;
		while (!TestWait(&last_hd->dk_numq) && searched != MAXDISKS) {
			last_hd++;
			searched++;
			if (last_hd >= &hd[MAXDISKS]) last_hd = hd;
		}
		if (searched == MAXDISKS) {
			printf("hd_intr: PANIC, Failed to find buffer\n");
			continue;
		}

		/* Extract the buffer */
		dp = &(last_hd->dk_queue);
		bp = dp->b_actf;

		/* Get the partition (offset) */
		pp = &(last_hd->dk_lab.d_partitions[dkpart(bp->b_dev)]);

		/* Perform the operation */
		req.DevReq.Request = ((bp->b_flags & B_READ)?FG_Read:FG_Write);
		req.DevReq.Action = hd_iodone;
		req.DevReq.SubDevice = dkunit(bp->b_dev);/* XXX AMS Not supported yet */
		req.DevReq.Timeout = -1;	/* No Timeout */
		req.Size = bp->b_bcount;
		req.Pos = (bp->b_blkno + pp->p_offset) * 
				last_hd->dk_lab.d_secsize;
		req.Buf =  bp->b_un.b_addr;
#ifdef DEBUG
IOdebug("hd_intr_server: Performing %s on dev=%d  buf=0x%x (dcb=0x%x",
	((bp->b_flags & B_READ)?"Read":"Write"),bp->b_dev,buf,rootdcb);
IOdebug("hd_intr_server: Request=0x%x, SubDevice=%d, Timeout=%d, Size=%d",
	req.DevReq.Request,req.DevReq.SubDevice,req.DevReq.Timeout,req.Size);
IOdebug("hd_intr_server: Pos=%d, Buf=0x%x",
	req.Pos,req.Buf);
#endif
		InitSemaphore(&(req.WaitLock),0);
		Operate(rootdcb,&req);		/* XXX AMS rootdcb goes later */
		Wait(&(req.WaitLock));		/* XXX Implement multiple ops
						 * later.  (i.e.TestWait for
						 * each hd)
						 */

		/* Operation complete, lock queue and remove bp */
		Wait(&last_hd->dk_guard);
		dp->b_actf = bp->av_forw;
		bp->b_resid = 0;
		bp->av_forw = NULL;
		Signal(&last_hd->dk_guard);

		/* Need to go into UNIX kernel to call biodone */
		tokernel();
		biodone(bp);
		fromkernel();
	}
}

