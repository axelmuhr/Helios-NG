/* Changes (C)1992 Perihelion Software Limited                        */
/* Author: Alex Schuilenburg                                          */
/* Date: 29 July 1992                                                 */
/* File: disksubr.c                                                   */
/*                                                                    */
/* This file contains the "faked" UNIX routines to allow the UNIX     */
/* program disklabel to run on top of Helios.                         */
/*                                                                    */
/* $Id: disksubr.c,v 1.2 1992/08/03 11:23:18 al Exp $ */
/* $Log: disksubr.c,v $
 * Revision 1.2  1992/08/03  11:23:18  al
 * Disk driver routines for helios.
 * */
/*
 * Copyright (c) 1987 The Regents of the University of California.
 * All rights reserved.
 *
 * This code is derived from software contributed to Berkeley by
 * Symmetric Computer Systems.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the University of
 *	California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */


#include "param.h"
#include "systm.h"
#include "buf.h"
#include "disklabel.h"
#include "syslog.h"
#include "errno.h"

#include <gsp.h>
#include <module.h>
#include <device.h>
#include <sem.h>
#include <codes.h>

/* Default sizes */
extern struct disklabel dflt_sizes;

/* Device Driver Variables */
DCB *discdcb = NULL;
struct disk {
	struct disklabel lab;
	word	discsecsize;
};

#define MAXUNITS 1
struct disk helios_drives[MAXUNITS];

/*
 * DEVINFO operations
 */

/* Routines to get the device driver etc info from devinfo */
void *load_devinfo(void)
{
  Stream *s = NULL;
  Object *o;
  void *devinfo = NULL;
  int size;
  ImageHdr hdr;

  /* Locate the devinfo information */
  o = Locate(NULL,"/rom/devinfo");
  if (o == NULL) o = Locate(NULL,"/loader/DevInfo");
  if (o == NULL) o = Locate(NULL,"/helios/etc/devinfo");
  if (o == NULL) return NULL;

  /* Open it and read it */
  s = Open(o,NULL,O_ReadOnly);
  if (s == NULL) { 
    Close(o);
    return NULL;
  }
  if (Read(s,(byte *)&hdr,sizeof(hdr),-1) == sizeof(hdr)) {
    /* The header was read o.k., just check it */
    if (hdr.Magic == Image_Magic ) {
      /* Header was fine, read in from the file */
      size = hdr.Size;
      devinfo = Malloc(size);
      if (devinfo != NULL) {
      	/* Malloc OK, actual read */
        if (Read(s,devinfo,size,-1) != size) { 
          /* Read Failed */
          Free(devinfo);
          devinfo = NULL;
        }
      }
    }
  }
  Close(s);
  Close(o);

  return(devinfo);
}

InfoNode *find_info(void *devinfo, word type, char *name)
{ InfoNode *info = (InfoNode *)((Module *)devinfo + 1);

  forever {
    if ((strcmp(name,RTOA(info->Name)) == 0) && (info->Type == type))
      return(info);
		    
    if (info->Next == 0) break;
    info = (InfoNode *)RTOA(info->Next);
  }
  return(NULL);
}

/*
 * Device Operations
 */
int open_dev(DiscDevInfo *ddi, dev_t dev)
{
  DriveInfo *dvi;

  if (discdcb != NULL) {
	printf("open_dev: Disk device already opened\n");
	return(0);
  }

  discdcb = OpenDevice(RTOA(ddi->Name), ddi);
  if (discdcb) {
	dvi = (DriveInfo *)RTOA(ddi->Drives);
	helios_drives[dkunit(dev)].lab = dflt_sizes;
	helios_drives[dkunit(dev)].discsecsize = dvi->SectorSize;
	return(0); 
  } else return(1);
}

void close_dev (void)
{
  if (discdcb == NULL) {
	printf("close_dev: Disk device not yet opened\n");
	return;
  }

  CloseDevice(discdcb);
  discdcb = NULL;
}

void dev_action(DiscReq *req)
{
  Signal(&req->WaitLock);
}

/* This is the absolute read/write routine */
word do_dev_rdwr(word fn, word dev, word timeout, word size, word pos,
				char *buf, word *deverror )
{
  DiscReq req;

  req.DevReq.Request = fn;
  req.DevReq.Action = dev_action;
  req.DevReq.SubDevice = dev;
  req.DevReq.Timeout = timeout;
  req.Size = size;
  req.Pos  = pos;
  req.Buf = buf;

#ifdef DEBUG
	IOdebug("do_dev_rdwr: function %d,subdevice = %d, no. %d, size %d",
				fn,req.DevReq.SubDevice,pos,size);
#endif

  InitSemaphore(&(req.WaitLock),0);
  Operate(discdcb,&req);
  Wait(&(req.WaitLock));

#ifdef DEBUG
	IOdebug("do_dev_rdwr: done");
#endif
  *deverror = req.DevReq.Result;
  return req.Actual;
}

/* This is the read/write routine which operates relative to a partition. */
/* It is passed the full device number.  No checks are performed on dev.  */
word dev_rdwr(word fn, word dev, word timeout, word size, word pos,
			char *buf, word *deverror )
{
  DiscReq req;
  int unit = dkunit(dev);
  struct disklabel *lab =  &helios_drives[unit].lab;
  word sectorsize = lab->d_secsize;
  struct partition *part = &(lab->d_partitions[dkpart(dev)]);
  word part_offset = part->p_offset;

  req.DevReq.Request = fn;
  req.DevReq.Action = dev_action;
  req.DevReq.SubDevice = unit;
  req.DevReq.Timeout = timeout;
  req.Size = size;
  req.Pos  = pos + part_offset*sectorsize;
  req.Buf = buf;

#ifdef DEBUG
	IOdebug("dev_rdwr: function %d,subdevice = %d, no. %d, size %d",
				fn,req.DevReq.SubDevice,req.Pos,size);
#endif

  InitSemaphore(&(req.WaitLock),0);
  Operate(discdcb,&req);
  Wait(&(req.WaitLock));

#ifdef DEBUG
	IOdebug("dev_rdwr: done");
#endif
  *deverror = req.DevReq.Result;
  return req.Actual;
}

/*
 * Attempt to read a disk label from a device.
 * The label must be partly set up before this:
 * secpercyl and anything required in the strategy routine
 * (e.g., sector size) must be filled in before calling us.
 * Returns null on success and an error string on failure.
 */
char *
readdisklabel(dev, lp)
	dev_t dev;
	register struct disklabel *lp;
{
	register char *buf;
	struct disklabel *dlp;
	char *msg = NULL;
	word n, err;

	if (lp->d_secperunit == 0)
		lp->d_secperunit = 0x1fffffff;
	lp->d_npartitions = 1;
	if (lp->d_partitions[0].p_size == 0)
		lp->d_partitions[0].p_size = 0x1fffffff;
	lp->d_partitions[0].p_offset = 0;

	/* Get the memory to store the label */
	buf = (char *)Malloc((word)lp->d_secsize);

	/* Read the label */
	n = do_dev_rdwr(FG_Read,dkunit(dev),-1,(word)lp->d_secsize,
			LABELSECTOR*helios_drives[dkunit(dev)].discsecsize,
			buf,&err);
        if (n != lp->d_secsize) {
		msg = "I/O error, failed to read correct size";
		IOdebug("readdisklabe2: Disk drive only read %d when requested to read %d",n,lp->d_secsize);
	} else if (err) {
		msg = "I/O error";
		IOdebug("Disk drive error %d\n",err);
	} else for (dlp = (struct disklabel *)buf;
	    dlp <= (struct disklabel *)(buf+DEV_BSIZE-sizeof(*dlp));
	    dlp = (struct disklabel *)((char *)dlp + sizeof(long))) {
		if (dlp->d_magic != DISKMAGIC || dlp->d_magic2 != DISKMAGIC) {
			if (msg == NULL)
				msg = "no disk label";
		} else if (dlp->d_npartitions > MAXPARTITIONS ||
			   dkcksum(dlp) != 0)
			msg = "disk label corrupted";
		else {
			helios_drives[dkunit(dev)].lab = *dlp;
			*lp = *dlp;
			msg = NULL;
			break;
		}
	}
	Free(buf);
	return (msg);
}

/*
 * Check new disk label for sensibility
 * before setting it.
 */
setdisklabel(olp, nlp, openmask)
	register struct disklabel *olp, *nlp;
	u_long openmask;
{
	register i;
	register struct partition *opp, *npp;

	if (nlp->d_magic != DISKMAGIC || nlp->d_magic2 != DISKMAGIC ||
	    dkcksum(nlp) != 0)
		return (EINVAL);
	while ((i = ffs((long)openmask)) != 0) {
		i--;
		openmask &= ~(1 << i);
		if (nlp->d_npartitions <= i)
			return (EBUSY);
		opp = &olp->d_partitions[i];
		npp = &nlp->d_partitions[i];
		if (npp->p_offset != opp->p_offset || npp->p_size < opp->p_size)
			return (EBUSY);
		/*
		 * Copy internally-set partition information
		 * if new label doesn't include it.		XXX
		 */
		if (npp->p_fstype == FS_UNUSED && opp->p_fstype != FS_UNUSED) {
			npp->p_fstype = opp->p_fstype;
			npp->p_fsize = opp->p_fsize;
			npp->p_frag = opp->p_frag;
			npp->p_cpg = opp->p_cpg;
		}
	}
 	nlp->d_checksum = 0;
 	nlp->d_checksum = dkcksum(nlp);
	*olp = *nlp;
	return (0);
}

/*
 * Write disk label back to device after modification.
 */
writedisklabel(dev, lp)
	dev_t dev;
	register struct disklabel *lp;
{
	char *buf;
	struct disklabel *dlp;
	int labelpart;
	word n, error = 0;

	labelpart = dkpart(dev);
	if (lp->d_partitions[labelpart].p_offset != 0) {
		if (lp->d_partitions[0].p_offset != 0)
			return (EXDEV);			/* not quite right */
		labelpart = 0;
	}

	buf = (char*)Malloc((word)lp->d_secsize);

	/* Read in current partition info */
	n = do_dev_rdwr(FG_Read,dkunit(dev),-1,(word)lp->d_secsize,
			LABELSECTOR*helios_drives[dkunit(dev)].discsecsize,
			buf,&error);
        if (n != lp->d_secsize) {
		IOdebug("writedisklabel2: Disk drive only read %d when requested to read %d",n,lp->d_secsize);
	} else if (error) {
		IOdebug("Disk drive error %d\n",error);
	}
	if (error || (n != lp->d_secsize)) goto done;
	for (dlp = (struct disklabel *)buf;
	    dlp <= (struct disklabel *)
	      (buf + lp->d_secsize - sizeof(*dlp));
	    dlp = (struct disklabel *)((char *)dlp + sizeof(long))) {
		if (dlp->d_magic == DISKMAGIC && dlp->d_magic2 == DISKMAGIC &&
		    dkcksum(dlp) == 0) {
			*dlp = *lp;
			n = do_dev_rdwr(FG_Write,dkunit(dev),-1,
					(word)lp->d_secsize,
					LABELSECTOR*helios_drives[dkunit(dev)].discsecsize,
					buf,&error);
		        if (n != lp->d_secsize) {
				IOdebug("Disk drive only read %d when requested to read %d",n,lp->d_secsize);
			} else if (error) {
				IOdebug("Disk drive error %d\n",error);
			}
			helios_drives[dkunit(dev)].lab = *dlp;
			goto done;
		}
	}
	error = ESRCH;
done:
	Free(buf);
	return (error);
}

/*
 * Compute checksum for disk label.
 */
dkcksum(lp)
	register struct disklabel *lp;
{
	register u_short *start, *end;
	register u_short sum = 0;

	start = (u_short *)lp;
	end = (u_short *)&lp->d_partitions[lp->d_npartitions];
	while (start < end)
		sum ^= *start++;
	return (sum);
}

