static char rcsid[] = "$Header: /Cluster/00/raw/filesys/devs/msc/RCS/msc.c,v 1.2 90/08/06 14:21:13 guenter Exp Locker: guenter $";

/* $Log:	msc.c,v $
 * Revision 1.2  90/08/06  14:21:13  guenter
 * minor bugs fixed
 * 
 * Revision 1.1  90/08/06  14:03:59  guenter
 * Initial revision
 * 
 *
 *
 */

/*************************************************************************
**                                                                      **
**                     H E L I O S   F I L E S E R V E R                **
**                     ---------------------------------                **
**                                                                      **
**             Copyright (C) 1988, Parsytec GmbH                        **
**                        All Rights Reserved.                          **
**                                                                      **
** msc.c								**
**                                                                      **
**	Routines of block I/O to the MSC driver.			**
**                                                                      **
**	Author:   M.Clauss   1/9/88					**
**                                                                      **
**      Modified: A.Ishan    9/1/89                                     **
**                                                                      **
**      Modified: A.Ishan    9/6/89                                     **
**                                                                      **
**      Modified: G.Lauven  20/3/90   Multipartition implementation     **
**                                                                      **
*************************************************************************/

#define DEBUG 		0
#define GEPDEBUG 	0

#include "msc.h"

/* ==================================================================== */
/*  General procedures */

DiscDCB *DevOpen(Device *, DiscDevInfo *);
word 	 DevClose(DiscDCB *);
void 	 DevOperate(DiscDCB *,DiscReq *);

int 	 load_code (string,string, O_HEADER *, byte **, byte **, byte **, word);
word	 init_load_dev (DiscDCB *, word, char *);
word	 unload_dev (DiscDCB *, word);

/* ==================================================================== */

/* Sub procedures 1 */

void 	msc_clear (DiscDCB *,word, word, word);
void 	msc_init (DiscDCB *,word, word, word, word);
void 	msc_load (DiscDCB *,word, word);
void 	msc_unload (DiscDCB *,word, word);
word	msc_wp_sense (DiscDCB *,word, word);
word	get_blocksize (DiscDCB *,word, word);
void	prev_removal (DiscDCB *,word, word, word);
word	format_disc (DiscDCB *,word);
void	msc_format_winch (DiscDCB *, word, word *, word *, word);
void	mode_select (DiscDCB *, word, word, word *, word *, word);
void	reassign_block (DiscDCB *, word, word, word *, word);
void	start_unit (DiscDCB *,word, word);
void	stop_unit (DiscDCB *,word, word);
void 	reserve (DiscDCB *,word, word);
void 	release (DiscDCB *,word, word);
word 	msc_read (DiscDCB *,word, word, byte *, word, word, word *);	
word	msc_write (DiscDCB *,word, word, byte *, word, word, word *);
void	msc_verify (DiscDCB *, word, word, word, word);	
word	msc_seek (DiscDCB *,word, word, word);
void	msc_rewind (DiscDCB *,word);
void 	msc_finish (DiscDCB *);

/* ==================================================================== */

/* Sub procedures 2 */

void 	dummy_c_read (DiscDCB *);
void 	dummy_c_write (DiscDCB *);
word	get_protocol (DiscDCB *,word, word *, word);
void 	wait_for_result (DiscDCB *);

/* ==================================================================== */
/* ==================================================================== */

/* several subroutines used by DevOpen and others			*/


word
check_scsi_addr (word *used, word drivenum, word addr)

/*
*  Checks whether the scsi address 'addr' of drive 'drivenum'is 
*  plausible and not marked reserved (=1) in the array 'used'. 
*  On error it returns NULL else it reserves the address and
*  returns TRUE.
*/

{	

	if ( (addr < 0) || (addr > HIGH_SCSI_ADDR) ) {
IOdebug(" open_dev() : Illegal scsi address (%d) of drive %d !",addr,drivenum);
		return (FALSE);
	}
	if (used[addr]) {
IOdebug(" open_dev() : Scsi address %d is used more than once !",addr);
		return(FALSE);
	}
	used[addr] = 1;	
	return (TRUE);			
}


word
cls_dev_to_drvnum (DiscDCB *dcb, word class, word device) 

/*
 *   looks for the drive number having this class and device
 *   Returns -1 if drive number not found.
 */

{
	word i;
	
	for (i = 0; i < dcb->num_of_drives; i++) {
		if ( (class == dcb->drivelist[i].class) && 
		 	(device == dcb->drivelist[i].device))
		 	return (i);
	}
	return (-1);
}


word
count_partitions (PartitionInfo *partinfo)

/*
*  counts partitions in partitionlist
*/

{
	word 	count = 0; 
	forever	{ 
		count++;
		if (partinfo->Next == -1)
			return (count);
		partinfo = (PartitionInfo *)RTOA(partinfo->Next);
	}
}


word
medium_corrupted_check (DiscDCB *dcb, word drvnum)

/*
*   checks if last result means medium format corrupted
*/

{
	word	class,type;
	
	class = dcb->drivelist[drvnum].class;
	type = dcb->drivelist[drvnum].type;
	if ( class == CLASS_WINCH ) {
		switch (type) {
		   case (TYPE_OPTICAL) :  
#if GEPDEBUG
IOdebug(" medium_corrupted_check() : sense length %d",dcb->len);
#endif		      	 
		   
		      if (dcb->len == EXTSENSE ) {
#if GEPDEBUG
IOdebug(" medium_corrupted_check() : sense %x, additional %x",dcb->dummy_buffer[SB+SE]&SENSE_MASK,dcb->dummy_buffer[SB+AD]&ADD_MASK);
#endif		      	 
			 if (((dcb->dummy_buffer[SB+SE]&SENSE_MASK)==MEDIUM_ERROR)
			      && ((dcb->dummy_buffer[SB+AD]&ADD_MASK)==MEDIUM_FORMAT_CORRUPTED))
			    return (TRUE);  
		      }	
		      return (FALSE);
			
		   default : return (FALSE);	
		}	
	}
	else if ( class == CLASS_STREAMER ) {
		switch (type) {
			
			default : return (FALSE);			
		}	
	}
	else return (FALSE);	/* illegal class */
}



word
poss_reassign (DiscDCB *dcb, word drvnum)

/*
*   checks if last result can be recovered by a reassign (after read)
*/

{
	word	class,type;
	
	class = dcb->drivelist[drvnum].class;
	type = dcb->drivelist[drvnum].type;
	if ( class == CLASS_WINCH ) {
#if GEPDEBUG
IOdebug(" poss_reassign () : sense length %d",dcb->len);
#endif		      	 
		   
	      if (dcb->len == EXTSENSE ) {
#if GEPDEBUG
IOdebug(" poss_reassign () : sense %x, additional %x",dcb->dummy_buffer[SB+SE]&SENSE_MASK,dcb->dummy_buffer[SB+AD]&ADD_MASK);
#endif		      	 
		 if (((dcb->dummy_buffer[SB+SE]&SENSE_MASK)==MEDIUM_ERROR)
		      && ((dcb->dummy_buffer[SB+AD]&ADD_MASK)==MEDIUM_ID_ERROR))
		    return (TRUE);  
		 if (((dcb->dummy_buffer[SB+SE]&SENSE_MASK)==MEDIUM_ERROR)
		      && ((dcb->dummy_buffer[SB+AD]&ADD_MASK)==MEDIUM_ECC_ERROR))
		    return (TRUE);  
		 if (((dcb->dummy_buffer[SB+SE]&SENSE_MASK)==MEDIUM_ERROR)
		      && ((dcb->dummy_buffer[SB+AD]&ADD_MASK)==MEDIUM_ADM1_ERROR))
		    return (TRUE);  
		 if (((dcb->dummy_buffer[SB+SE]&SENSE_MASK)==MEDIUM_ERROR)
		      && ((dcb->dummy_buffer[SB+AD]&ADD_MASK)==MEDIUM_ADM2_ERROR))
		    return (TRUE);  
		 if (((dcb->dummy_buffer[SB+SE]&SENSE_MASK)==MEDIUM_ERROR)
		      && ((dcb->dummy_buffer[SB+AD]&ADD_MASK)==MEDIUM_REC_ERROR))
		    return (TRUE);  
		 
	      }	
	      return (FALSE);
			
	}
	else if ( class == CLASS_STREAMER ) {
		switch (type) {
			
			default : return (FALSE);			
		}	
	}
	else return (FALSE);	/* illegal class */
}


word
no_spare_blocks (DiscDCB *dcb, word drvnum)

/*
*   checks if last result means no more spare blocks available for
*   a reassign
*/

{
	word	class,type;
	
	class = dcb->drivelist[drvnum].class;
	type = dcb->drivelist[drvnum].type;
	if ( class == CLASS_WINCH ) {
#if GEPDEBUG
IOdebug(" no_spare_blocks () : sense length %d",dcb->len);
#endif		      	 
		   
	      if (dcb->len == EXTSENSE ) {
#if GEPDEBUG
IOdebug(" no_spare_blocks () : sense %x, additional %x",dcb->dummy_buffer[SB+SE]&SENSE_MASK,dcb->dummy_buffer[SB+AD]&ADD_MASK);
#endif		      	 
		    if ( (dcb->dummy_buffer[SB+AD]&ADD_MASK)==SPARE_ERROR)
			    return (TRUE);  
		 
	      }	
	      return (FALSE);
			
	}
	else if ( class == CLASS_STREAMER ) {
		switch (type) {
			
			default : return (FALSE);			
		}	
	}
	else return (FALSE);	/* illegal class */
}



word
medium_ecc_error (DiscDCB *dcb, word drvnum)

/*
*   checks if last result means medium ecc error (during read)
*/

{
	word	class,type;
	
	class = dcb->drivelist[drvnum].class;
	type = dcb->drivelist[drvnum].type;
	if ( class == CLASS_WINCH ) {
		switch (type) {
		   case (TYPE_OPTICAL) :  
#if GEPDEBUG
IOdebug(" medium_ecc_error() : sense length %d",dcb->len);
#endif		      	 
		   
		      if (dcb->len == EXTSENSE ) {
#if GEPDEBUG
IOdebug(" medium_ecc_error() : sense %x, additional %x",dcb->dummy_buffer[SB+SE]&SENSE_MASK,dcb->dummy_buffer[SB+AD]&ADD_MASK);
#endif		      	 
			 if (((dcb->dummy_buffer[SB+SE]&SENSE_MASK)==MEDIUM_ERROR)
			      && ((dcb->dummy_buffer[SB+AD]&ADD_MASK)==MEDIUM_ECC_ERROR))
			    return (TRUE);  
		      }	
		      return (FALSE);
			
		   default : return (FALSE);	
		}	
	}
	else if ( class == CLASS_STREAMER ) {
		switch (type) {
			
			default : return (FALSE);			
		}	
	}
	else return (FALSE);	/* illegal class */
}



word
recovered_error (DiscDCB *dcb)

/*
*   checks if last result means recovered error
*/

{

	if (dcb->len > SB+SE) {
#if GEPDEBUG
IOdebug(" recovered_error() : sense %x",dcb->dummy_buffer[SB+SE]&SENSE_MASK);
#endif		      	 
		if ( (dcb->dummy_buffer[SB+SE]&SENSE_MASK)==RECOVERED_ERROR )
			return (TRUE);  
		else
			return (FALSE);
	}
	else return (FALSE);
}


word
data_protect_error (DiscDCB *dcb)

/*
*   checks if last result means data protect error
*/

{

	if (dcb->len > SB+SE) {
#if GEPDEBUG
IOdebug(" recovered_error() : sense %x",dcb->dummy_buffer[SB+SE]&SENSE_MASK);
#endif		      	 
		if ( (dcb->dummy_buffer[SB+SE]&SENSE_MASK)==DATA_PROTECT )
			return (TRUE);  
		else
			return (FALSE);
	}
	else return (FALSE);
}



word
no_medium_check (DiscDCB *dcb, word drvnum)

/*
*   checks if last result means medium not loaded
*/

{
	word	class,type;
	
	class = dcb->drivelist[drvnum].class;
	type = dcb->drivelist[drvnum].type;
	if ( class == CLASS_WINCH ) {
		switch (type) {
		   case (TYPE_OPTICAL) :  
#if GEPDEBUG
IOdebug(" no_medium_check() : sense length %d",dcb->len);
#endif		      	 
		   
		      if (dcb->len == EXTSENSE ) {
#if GEPDEBUG
IOdebug(" no_medium_check() : sense %x, additional %x",dcb->dummy_buffer[SB+SE]&SENSE_MASK,dcb->dummy_buffer[SB+AD]&ADD_MASK);
#endif		      	 
			 if (((dcb->dummy_buffer[SB+SE]&SENSE_MASK)==NOT_READY)
			      && ((dcb->dummy_buffer[SB+AD]&ADD_MASK)==NO_DISK))
			    return (TRUE);  
		      }	
		      return (FALSE);
			
		   default : return (FALSE);	
		}	
	}
	else if ( class == CLASS_STREAMER ) {
		switch (type) {
		   case (TYPE_EXABYTE) :
		      if (dcb->len == EXABYTE_SENSE ) {
		      	 if ( ((dcb->dummy_buffer[SB+SE]&SENSE_MASK) == NOT_READY )
		      	 	&& ( (dcb->dummy_buffer[SB+19]&2) == 2) )
		      	    return (TRUE);
		      	 else
		      	    return (FALSE);   
		      }	
		      return (FALSE);
		      
		   default : return (FALSE);			
		}	
	}
	else return (FALSE);	/* illegal class */
}



word
busy (DiscDCB *dcb, word drvnum)

/*
*   checks if last result means device is busy
*/

{
		
	if (dcb->len == STATUS_SENSE) {
		if ( (dcb->dummy_buffer[3] & STATUS_MASK) == STATUS_BUSY) 
			return (TRUE);
	}
	
	return (FALSE);
}


/* ==================================================================== */

DiscDCB *
DevOpen(Device *dev, DiscDevInfo *ddi)

/*
*  After loading the MSC-board with MSC-driver routines,
*  initialises MSC-driver protocol with communiction routines.
*/

{
	string 		fname,cdname; 
	O_HEADER 	ohdr; 
	byte 		*code, *wspace, *vspace;
	word 		psize, load;
	byte 		*proc;
	word 		winnies = 0;
	word		floppies = 0;
	word 		streamer = 0;
	word 		dev_in_class[HIGHEST_CLASS+1];
	word		type_to_class[HIGHEST_TYPE+1];
	word		dev_type[HIGHEST_TYPE+1];
	word		used[HIGH_SCSI_ADDR+1];
	word		i,addr,class,device,drvtype;
	word		num_of_drives,num_of_partitions;
	DriveInfo 	*dri;		
	PartitionInfo	*partinfo;
	DriveDescriptor	*drive;
	DiscDCB 	*dcb = Malloc(sizeof(DiscDCB));
	
	
	if( dcb == NULL ) {
		IOdebug(" open_dev() : Failed to allocate dcb! ");
		return (NULL);
	}

	dcb->DCB.Device = dev;
	dcb->DCB.Operate = DevOperate;
	dcb->DCB.Close = DevClose;

	InitSemaphore(&dcb->Lock,1);
	
	dcb->cmd_out = MinInt;
	dcb->cmd_in = MinInt;
	dcb->data_out = MinInt;
	dcb->data_in = MinInt;
	
	cdname = CURRENT_DIR;
	fname = MSC_DRIVER;
	psize = sizeof(Channel *)*6;
	load = load_code (cdname,fname,&ohdr,&code,&wspace,&vspace,psize);
	if (load) {
		IOdebug(" open_dev() : Failed to load MSC_DRIVER !");
		return (NULL);
	} 
	
	proc = code + ohdr.entry;
	O_Run (proc, wspace, ohdr.wspace, vspace, psize, 
	        &dcb->cmd_out, &dcb->cmd_in, &dcb->data_in, &dcb->data_out,
	        &dcb->dum_1, &dcb->dum_2);

	for (i = 0; i <= HIGHEST_CLASS; i++)	/* init device in class */
		dev_in_class[i] = 0;		/* counter array	*/
		
	dev_type[TYPE_WINCH] = DEV_TYPE_WINCH;		/* init type to  */
	dev_type[TYPE_OPTICAL] = DEV_TYPE_OPTICAL;	/* devtype con-  */
	dev_type[TYPE_FLOPPY] = DEV_TYPE_FLOPPY;	/* version array */
	dev_type[TYPE_TANDBERG] = DEV_TYPE_TANDBERG;
	dev_type[TYPE_EXABYTE] = DEV_TYPE_EXABYTE;

	for (i = 0; i <= HIGH_SCSI_ADDR; i++)	/* initialize scsi address map */
		used[i] = 0;

	dcb->msc_blocksize = ddi->Addressing;
	if ( !check_scsi_addr(used,-1,ddi->Controller) ) { /* check controller scsi address */
		IOdebug
		(" open_dev() : Illegal MSC scsi-address (%d) (Controller-parameter in devinfo)",ddi->Controller);
		return (NULL);
	}
	dcb->msc_scsi_addr = ddi->Controller;	
	
	dri = (DriveInfo *)RTOA(ddi->Drives);	
	num_of_drives = 0;
	forever	{    /* count number of devices in all classes in drivelist */
		switch (dri->DriveType) {
			case TYPE_WINCH		:
			case TYPE_OPTICAL	: winnies++;
						type_to_class[dri->DriveType] = CLASS_WINCH;					
					  	break;
					  	
			case TYPE_TANDBERG	:
			case TYPE_EXABYTE	: streamer++;
						type_to_class[dri->DriveType] = CLASS_STREAMER;					
					  	break;
/* currently not implemented ! 
			case TYPE_FLOPPY	: floppies++;
						type_to_class[dri->DriveType] = CLASS_FLOPPY;					
					  	break;
*/					  	
			default 		: 	
						IOdebug
						("	open_dev() : Unknown drivetype in devinfo.src (%d)!",dri->DriveType);
					  	return (NULL);	
		}
#if GEPDEBUG
IOdebug(" open_dev : %d winnie(s), %d floppie(s), %d streamer(s) found",winnies,floppies,streamer);
#endif			
		num_of_drives++;
		if (dri->Next == -1) 
			break;
		dri = (DriveInfo *)RTOA(dri->Next);	
	} 
	
	drive = Malloc( num_of_drives * sizeof(DriveDescriptor)); /* allocate drivelist */
	if (drive == NULL) {
		IOdebug(" open_dev() : Failed to allocate drivelist !");
		return (NULL);	
	}
	dcb->num_of_drives = num_of_drives;
	dcb->drivelist = drive;
	
	msc_clear (dcb,winnies,floppies,streamer);	/* initialize MSC */
	if ( !dcb->ok ) {
		IOdebug
		(" open_dev() : MSC_Clear command failed; check your hardware!");
		return (NULL);
	}
#if GEPDEBUG
IOdebug(" open_dev : msc_clear done");
#endif	
	
	dri = (DriveInfo *)RTOA(ddi->Drives);	
	i = 0;
	forever	{  /* initialize parameters in drivelist as far as possible */
		   /* ! ATTENTION ! drives are not initialized itself in    */
		   /* this routine!					    */
		   
		addr = dri->DriveId;
		if ( !check_scsi_addr(used,i,addr) ) {	/* check scsi address */
			Free (drive);
			return (NULL);
		}	
		drvtype	= dri->DriveType;
		class = type_to_class[drvtype];
		device = dev_in_class[class];
#if GEPDEBUG
IOdebug(" open_dev() : InitSemaphore(&drive[%d].Lock,1);",i);
#endif		
		InitSemaphore(&drive[i].Lock,1);
		drive[i].scsi_addr = addr;
		drive[i].type = drvtype;
		drive[i].device_type = dev_type[drvtype];
		drive[i].class = class;
		drive[i].device = device;
		drive[i].initialized = FALSE;
		
		switch (drvtype) { /* loadable medium ? */	
			case TYPE_OPTICAL	:
			case TYPE_TANDBERG	:
			case TYPE_EXABYTE	: drive[i].loadable = TRUE;
						break;
			default			: drive[i].loadable = FALSE;
		}
		switch (drvtype) { /* device raw or structured ? */	
			case TYPE_TANDBERG	:
			case TYPE_EXABYTE	: drive[i].raw = TRUE;
						break;
			default			: drive[i].raw = FALSE;
		}
		
		dev_in_class[class]++;
#if GEPDEBUG
IOdebug(" open_dev() : initialized drive %d with following parameters : ",i);
IOdebug("    type %d, device type %d, scsi_addr %d, class %d, device %d,",drive[i].type,drive[i].device_type,drive[i].scsi_addr,drive[i].class,drive[i].device);
IOdebug("    loadable (%d), raw (%d), initialized (%d)",drive[i].loadable,drive[i].raw,drive[i].initialized);
#endif
		i++;
		if (dri->Next == -1) 
			break;
		dri = (DriveInfo *)RTOA(dri->Next);	
	}

	num_of_partitions = count_partitions((PartitionInfo *)RTOA(ddi->Partitions));
	
	/* allocate partitionlist */
	
	dcb->partition = Malloc( num_of_partitions * sizeof(Part_Descr));
	if ( dcb->partition == NULL ) {
		IOdebug(" open_dev() : Failed to allocate partitionlist !");
		return (NULL);
	}
	dcb->num_of_partitions = num_of_partitions;
	
	/* initialize partitionlist in DiscDCB */

	partinfo = (PartitionInfo *)RTOA(ddi->Partitions);
	i = 0;
	forever	{
		if (partinfo->Drive >= num_of_drives) {
			IOdebug
			(" open_dev : drive %d does not exist in drivelist in devinfo.src!",partinfo->Drive);
			Free (drive);
			Free (dcb->partition);
			return (NULL);
		}
		dcb->partition[i].class = drive[partinfo->Drive].class;
		dcb->partition[i].device = drive[partinfo->Drive].device;
		dcb->partition[i].drivenumber = partinfo->Drive;
		dcb->partition[i].firstblock = partinfo->StartCyl;
		if (drive[partinfo->Drive].raw || drive[partinfo->Drive].loadable )
			partinfo->EndCyl = -1; 
		dcb->partition[i].dflt_lastblock = partinfo->EndCyl;
		dcb->partition[i].lastblock = 0;
#if GEPDEBUG
IOdebug(" open_dev() : initialized partition %d in partitionlist : ",i);
IOdebug("   drivenumber %d, class %d, device %d,",dcb->partition[i].drivenumber,dcb->partition[i].class,dcb->partition[i].device);
IOdebug("   firstblock %d, lastblock %d, found lastblock %d.",dcb->partition[i].firstblock,dcb->partition[i].lastblock,dcb->partition[i].dflt_lastblock);
#endif

		i++;
		if (partinfo->Next == -1)
			break;
		partinfo = (PartitionInfo *)RTOA(partinfo->Next);
	}

	{
		RootStruct *root;
		root = GetRoot();
		root->MaxBuffers = 400;
	}
	return (dcb);	
}


/* ==================================================================== */


word
init_load_dev (DiscDCB *dcb, word partnum, char *buffer)

/*  
 *  The device belonging to partition partnum is tried to be initialized.
 *  If it is a raw device or a loadable medium device and the device is
 *  initialized already then it returns an error.
 *  If the device is structured with no changable medium (harddisk) and is
 *  initialized already the device is not touched a second time.
 *  In any other case the device is tried to be initialized.
 *  In req->DevReq.Result an error code is returned or Err_Null.
 *  req->Buf points to a buffer where the results obtained are be stored.
 *  This result structure is defined in fs.h.
 */

{
	DriveDescriptor	*drive;
	Part_Descr	*partition;
	load_res_type	*load_result;
	word		drvnum;
		
	drvnum = dcb->partition[partnum].drivenumber;
	partition = &dcb->partition[partnum];
	drive = &dcb->drivelist[drvnum];
	load_result = (load_res_type *)buffer;

/*	Wait (&drive->Lock); */

	load_result->loaded = FALSE;
	load_result->writeprotected = FALSE;
	load_result->med_removable = FALSE;
	load_result->hard_formatted = FALSE;
	load_result->error = FALSE;
#if GEPDEBUG
IOdebug(" init_load_dev() : load physical partition %d, drive %d",partnum,drvnum);
#endif
	if ( (drive->initialized)&&((drive->raw)||(drive->loadable)) ) {
		load_result->error = TRUE;
		IOdebug
		(" init_load_dev() : Drive %d is already initialized and may not be",drvnum);
		IOdebug
		("                    accessed by more than one volume!");
/*		Signal (&drive->Lock);		*/
		return (Err_Null);		
	}

	load_result->raw = drive->raw;
	load_result->loadable = drive->loadable;

	if ( (drive->initialized) ) {  /* device already initialized */
		load_result->hard_formatted = TRUE;
		load_result->loaded = TRUE;
	}
	else {	/* try to initialize and load device */
#if GEPDEBUG
IOdebug(" open_dev() : msc_init address %d, class %d, device type %d",drive->scsi_addr,drive->class,drive->device_type);
#endif	
		msc_init (dcb,drive->class,drive->device,drive->device_type,drive->scsi_addr);	
		if ( !dcb->ok  ) { /* device not initialized succesfully */
			/* test if medium not loaded */
			if ( no_medium_check(dcb,drvnum) ) {
#if GEPDEBUG
IOdebug(" open_dev() : no medium present in device %d",drive->scsi_addr);
#endif
			}
			else if ( busy(dcb,drvnum) ) {
#if GEPDEBUG
IOdebug(" open_dev() : device %d busy",drive->scsi_addr);
#endif
			}
			/* several other checks have to be added here to find */
			/* out other possible reasons for init() failure      */
		
			else { /* reason for init() failure not detected */
				IOdebug
				(" open_dev() : failed to init drive %d with scsi-address %d !",drvnum,drive->scsi_addr);
				load_result->error = TRUE;
			}
		}
		else { /* device initialized succesfully; now try to load */
#if GEPDEBUG
IOdebug(" open_dev() : msc_load, class %d, device %d",drive->class,drive->device);
#endif	
			msc_load (dcb,drive->class,drive->device);
			if ( !dcb->ok ) { /* device initialized but not loaded succesfully */
				if ( busy(dcb,drvnum) ) {
#if GEPDEBUG
IOdebug(" open_dev() : device %d busy",drive->scsi_addr);
#endif
				}
				else if ( medium_corrupted_check(dcb,drvnum) ) {
#if GEPDEBUG
IOdebug(" open_dev() : medium corrupted in device %d",drive->scsi_addr);
#endif
					load_result->hard_formatted = FALSE;
				}
				else if ( medium_ecc_error(dcb,drvnum) ) {
#if GEPDEBUG
IOdebug(" open_dev() : medium ecc error in device %d",drive->scsi_addr);
#endif
					load_result->hard_formatted = FALSE;
				}

				/* several other checks have to be added here to find */
				/* out other possible reasons for load() failure      */

				else { /* reason for load() failure not detected */
					IOdebug
					(" open_dev() : failed to load drive %d with scsi-address %d !",drvnum,drive->scsi_addr);
					load_result->error = TRUE;
				}
			}
			else {	/* device initialized and loaded succesfully */
				load_result->loaded = TRUE;
				load_result->hard_formatted = TRUE;
			}

		}  /* end of try load */
					
	}  /* end of try init and load */
	
	if ( load_result->error || !load_result->loaded ) {
/*		Signal (&drive->Lock);*/
#if GEPDEBUG
IOdebug(" open_dev() : return without locking and wp check");
#endif
		return (Err_Null);
	}

	/* else check writeprotection and complete partitiontable */
	load_result->writeprotected = msc_wp_sense (dcb,drive->class,drive->device);
	if (load_result->loadable) { /* if loadable medium try to preserve removal */
		prev_removal (dcb,drive->class,drive->device,TRUE);
		if ( !dcb->ok ) { /* medium removal cannot be preserved */
			load_result->med_removable = TRUE;
		}
		else
			load_result->med_removable = FALSE;
	}

	if ( (partition->dflt_lastblock == -1) && (!drive->raw) ) {
		partition->lastblock = get_blocksize(dcb,drive->class,drive->device) - 1;
		if ( partition->lastblock <= 0 ) {
			IOdebug
			(" open_dev() : Size of partition %d cannot be detected",partnum);
			load_result->error = TRUE;
		}
	}
	else {
		partition->lastblock = partition->dflt_lastblock;
	}
	
	if ( !load_result->error ) {	/* drive initialized succesfully */
		drive->initialized = TRUE;
	}

/*	Signal (&drive->Lock); */

#if GEPDEBUG
IOdebug(" init_load_dev() : initialized partition %d in partitionlist : ",partnum);
IOdebug("   drivenumber %d, class %d, device %d,",partition->drivenumber,partition->class,partition->device);
IOdebug("   firstblock %d, lastblock %d, found lastblock %d.",partition->firstblock,partition->lastblock,partition->dflt_lastblock);
#endif
		
	return (Err_Null);	
}


/* ==================================================================== */


word
unload_dev (DiscDCB *dcb, word partnum)

/*
 *   if device of partition partnum is loadable medium removal is allowed here
 */
 
{
	word	drvnum;
	word	class,device;
	
	
#if GEPDEBUG
IOdebug(" unload_dev() : working");
#endif
	drvnum = dcb->partition[partnum].drivenumber;
	class = dcb->drivelist[drvnum].class;
	device = dcb->drivelist[drvnum].device;
	if (dcb->drivelist[drvnum].loadable) {
		prev_removal (dcb,class,device,FALSE);
	}
	if (dcb->drivelist[drvnum].raw || dcb->drivelist[drvnum].loadable)
		dcb->drivelist[drvnum].initialized = FALSE;
	msc_unload (dcb,class,device);	
	return (Err_Null);
}


/* ==================================================================== */

word 
DevClose(DiscDCB *dcb)

/*
*  Terminates communication with the MSC-board.
*/

{
	
	Wait(&dcb->Lock);
	msc_finish (dcb);
	
	return (Err_Null);
}

/* ==================================================================== */

void
DevOperate(DiscDCB *dcb,DiscReq *req)

/* 
 *  positions and sizes are in addressing size 
 */
 
{
	daddr_t 	bnr = req->Pos;
	word 		bcnt = req->Size;
	byte 		*buf = req->Buf;
	word		partnum = req->DevReq.SubDevice;
	word		class;
	word		device;
	word		error;
	
	Wait(&dcb->Lock);
	
	class = dcb->partition[partnum].class;
	device = dcb->partition[partnum].device;
	bnr = bnr + dcb->partition[partnum].firstblock;
	
	switch( req->DevReq.Request & FG_Mask )
	{
	case FG_Read:
	case FG_Write:	
	case FG_Seek:
	case FG_GetSize:
	case FG_Open:
	case FG_Close:	
	case FG_Format:
		if (partnum >= dcb->num_of_partitions) {
			IOdebug
			(" dev_operate() : invalid partition number (%d) !",partnum);
			req->DevReq.Result = EC_Error + SS_IOProc + EG_Invalid;
			goto finish;
		}
	}
		
	switch( req->DevReq.Request & FG_Mask )
	{
	case FG_Read:
		req->Actual = 0;
		/* read requested size of blocks into pointed packet */
		/* number of read blocks is returned		     */
		req->Actual = msc_read (dcb,bnr, bcnt, buf, class, device, 
							&error);
		req->DevReq.Result = error;
		break;	

	case FG_Write:
		req->Actual = 0;
		/* write requested size of blocks from the pointed packet */
		/* number of written blocks is returned			  */
		req->Actual = msc_write (dcb,bnr, bcnt, buf, class, device,
							&error);
		req->DevReq.Result = error;
		break;	

	case FG_Seek:
		/* seek desired block (for tapes) */
		if ( bnr == 0 )
			msc_rewind (dcb, device);
		else	
			req->DevReq.Result = msc_seek (dcb, bnr, class, device);
		break;

	case FG_GetSize:
		req->DevReq.Result = dcb->partition[partnum].lastblock -
				     dcb->partition[partnum].firstblock + 1;
		req->Actual = dcb->msc_blocksize;
		break;

	case FG_Format:
		req->DevReq.Result = format_disc (dcb,dcb->partition[partnum].drivenumber);
		break;			
		
	case FG_Open:
#if GEPDEBUG
IOdebug(" dev_operate() : init_load_dev() requested"); 
#endif
		req->DevReq.Result = init_load_dev (dcb,partnum,buf);
		break;
		
	case FG_Close:
		req->DevReq.Result = unload_dev (dcb,partnum);
		break;
	
	}
finish:	Signal(&dcb->Lock);

	(*req->DevReq.Action)(req);
	
	return;	
}

/* ==================================================================== */

/* load_code:								     */
/* =========								     */	
/*	Load the given object file (occam generated) into a buffer , and     */
/* 	return the information necessary to run this code.	             */

int load_code(	string cdname,
		string fname, 
		O_HEADER *ohdr, 
		byte **code, byte **wspace, byte **vspace,
		word  psize )
	
{
	Stream	*sfile;
	Object  *current;
	int	nwords;

	current = Locate(NULL,cdname);
	if ((sfile = Open(current,fname,O_ReadOnly)) == Null(Stream))
		{
IOdebug("Object file '%s'does not exist\n",fname);
		return(-1);}
		
	if (Read(sfile, (BYTE *)ohdr, sizeof(O_HEADER), IOCTimeout) 
		!= sizeof(O_HEADER))
		{
IOdebug("Error reading %s\n",fname);
		return(-1);}

	*code  = Malloc(ohdr->csize);

	if (Read(sfile, *code, ohdr->csize, IOCTimeout) != ohdr->csize)
		{
IOdebug("Error reading %s\n",fname);
		return(-1);}

	/* determine how many words of parameters 		*/
	/* N.B all byte parameters are still passed as words 	*/
	
	nwords = (psize / bytesperword);
	nwords += psize%bytesperword ? 1:0;
	
	/* allocate wspace */
	
	ohdr->wspace = (ohdr->wspace+nwords+2);
	*wspace = Malloc(ohdr->wspace * sizeof(word));
	if (*wspace == Null(byte))
		{return(-1);}
#if GEPDEBUG
IOdebug("allocating %d words work space",ohdr->wspace);	
#endif
	if (ohdr->vspace > 0)
		{
#if GEPDEBUG			
IOdebug("allocating %d words vector space",ohdr->vspace);
#endif
		*vspace = Malloc(ohdr->vspace * sizeof(word));
		if (*vspace == Null(byte))
			{Free(*wspace); return(-1);}
		}
	else
		{*vspace = Null(byte);}
		
	
	return(0);

}
	
/* ==================================================================== */
/* ==================================================================== */

void 
msc_clear (DiscDCB *dcb,word winnies,word floppies,word streamer)

{	
	word *pw, len;
						    
	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = CLASS_SPECIAL;
	*pw++ = CO_CLEAR;
	*pw++ = dcb->msc_scsi_addr;
	*pw++ = winnies;
	*pw++ = floppies;
	*pw++ = streamer;
	len = 8;
#if DEBUG
IOdebug ("clear: wslice->");
#endif
	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);
#if DEBUG
IOdebug (":");
#endif
	dummy_c_read (dcb);
	dummy_c_write (dcb);

	wait_for_result (dcb);
}

/* ==================================================================== */

void 
msc_init (DiscDCB *dcb,word class,word device,word dev_type,word addr)

{	
	word *pw, len;
	bool first_try = TRUE;
	
retry:		
	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = class;
	*pw++ = device;
	*pw++ = CO_INIT;
	*pw++ = dcb->msc_blocksize;
	*pw++ = dev_type;
	*pw++ = addr;
	*pw++ = DEFAULT_LUN;	/* logical unit */
	len = 9;
	
	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);
	dummy_c_read (dcb);
	dummy_c_write (dcb);

	wait_for_result (dcb);
	if (!dcb->ok && first_try)
	{
		first_try = FALSE;
		goto retry;
	}
}

/* ==================================================================== */

word
msc_wp_sense (DiscDCB *dcb, word class, word device)

{
	word *pw, len;		
	word *buffer;	
	word wp;
	
	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = class;
	*pw++ = device;
	*pw++ = CO_MODE_SENSE;
	*pw++ = 0;
	len = 6;

	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);

	ChanRead (&dcb->data_in, (byte *)&len, 4);
	
#if GEPDEBUG
IOdebug(" msc_mode_sense() : result length %d",len);
#endif	

	if (len > 0) {
		buffer = Malloc( len * sizeof(word) );
		ChanRead (&dcb->data_in, (byte *)buffer, len*4);	
	}
	dummy_c_write (dcb);

#if GEPDEBUG
IOdebug(" msc_mode_sense() : result 0-3: 0x%x 0x%x 0x%x 0x%x",buffer[0],buffer[1],buffer[2],buffer[3]);
#endif	
	wp = ( (buffer[1] & 0x800000) == 0x800000 );
	wait_for_result (dcb);	
		
	Free (buffer);
	return (wp);
}

/* ==================================================================== */

word
get_blocksize (DiscDCB *dcb, word class, word device)

/* tries to find out the blocksize of the addressed device */

{
	word *pw, len;		
	word *buffer;
	word blocksize;
	
	blocksize = 0;
	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = class;
	*pw++ = device;
	*pw++ = CO_GET_PARAMS;
	len = 5;

	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);
	
	ChanRead (&dcb->data_in, (byte *)&len, 4);
	buffer = Malloc(len*4*sizeof(byte));
#if GEPDEBUG
IOdebug(" get_blocksize() : result length is %d",len);
#endif	
	if (len > 0)
		ChanRead (&dcb->data_in, (byte *)buffer, len*4);	
	dummy_c_write (dcb);
		
	wait_for_result (dcb);	
#if GEPDEBUG
IOdebug(" get_blocksize() : result read");
#endif	
	if (dcb->ok) {
		blocksize = buffer[2];
	}
	Free (buffer);
	return (blocksize);
}


/* ==================================================================== */

void
start_stop_unit (DiscDCB *dcb, word class, word device, word modus)

/* if modus is true issues a start command else a stop command */

{
	word *pw, len;		
	word *buffer;
	
	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = class;
	*pw++ = device;
	*pw++ = CO_START_STOP;
	*pw++ = modus;
	len = 6;

	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);
	
	ChanRead (&dcb->data_in, (byte *)&len, 4);
	buffer = Malloc(len*4*sizeof(byte));
	if (len > 0)
		ChanRead (&dcb->data_in, (byte *)buffer, len*4);	
	dummy_c_write (dcb);
		
	wait_for_result (dcb);	
	if (!dcb->ok) {
		if (modus == 0) 
IOdebug(" start_stop_unit() : failed to stop unit");
		else
IOdebug(" start_stop_unit() : failed to start unit");		
	}
	Free (buffer);
}

void
start_unit (DiscDCB *dcb, word class, word device)
{
	start_stop_unit(dcb,class,device,TRUE);
}

void
stop_unit (DiscDCB *dcb, word class, word device)
{
	start_stop_unit(dcb,class,device,FALSE);
}

/* ==================================================================== */

void
prev_removal (DiscDCB *dcb, word class, word device, word prevent)

/* if prevent is true disables medium removal */

{
	word *pw, len;		
	
	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = class;
	*pw++ = device;
	*pw++ = CO_PREV_REMOVAL;
	*pw++ = prevent;
	len = 6;

	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);
	dummy_c_read (dcb);
	dummy_c_write (dcb);
		
	wait_for_result (dcb);	
}

/* ==================================================================== */

#define VERIFY_LENGTH 	4096
#define MAX_REASSIGN	8

word
format_disc (DiscDCB * dcb, word drivenumber)

/* medium in this drive is formated */
/* known drives so far :  SMO-D501 optical disc 	 */

{
	word		cdb[5];
	word		buffer[30];
	word		start,length;
	word		old_reass,new_reass,reass_count,all_reass;
	word		defect_block,blocks;
 	DriveDescriptor	*drive = &dcb->drivelist[drivenumber];

	if (drive->type != TYPE_OPTICAL) {
#if GEPDEBUG
IOdebug(" format_disc() : cannot format device with scsi address %d",drive->scsi_addr);
#endif		
		return (EC_Error + SS_IOProc + EG_Invalid);
	}
	
	if ( msc_wp_sense (dcb,drive->class,drive->device) ) {
#if GEPDEBUG
IOdebug(" format_disc() : device with scsi address %d is writeprotected",drive->scsi_addr);
#endif		
		return (EC_Error + SS_IOProc + EG_Protected);
	}

 	cdb[0] = 0x10;
 	cdb[1] = 0x00;
 	cdb[2] = 0x00;
 	cdb[3] = 0x10;		/* list length ! */
	cdb[4] = 0x00;
	
	buffer[0] = 0x00000000;
	buffer[1] = 0x01020A20;
	buffer[2] = 0x64000000;
	buffer[3] = 0x00001400;
	
/*
 *	format parameters for format mode 2:
 *	page code 0x20, page length 0x0A, format mode 2, format type 1
 *	number of bands 100 (0x64), size of spare band 20 (blocks)
 *
 */
#if GEPDEBUG
IOdebug(" format_disc() : mode select device with scsi address %d",drive->scsi_addr);
#endif	
	mode_select (dcb, drive->class, drive->device, cdb, buffer, 16);

	if (!dcb->ok) {
#if GEPDEBUG
IOdebug(" format_disc() : mode select of device %d failed",drive->scsi_addr);
#endif	
		return (EC_Error + SS_IOProc + EG_Invalid);		
	}
	
 	cdb[0] = 0;
 	cdb[1] = 3;
 	cdb[2] = 0;
 	cdb[3] = 0;
 	cdb[4] = 0;
#if GEPDEBUG
IOdebug(" format_disc() : format class winchester device %d",drive->device);
#endif	
	msc_format_winch (dcb, drive->device, cdb, buffer, 0);
	 	
	if (!dcb->ok)  {
#if GEPDEBUG
IOdebug(" format_disc() : failed to format device with scsi address %d",drive->scsi_addr);
#endif
		return (EC_Error + SS_IOProc + EG_Invalid);
	}

	blocks = get_blocksize (dcb, drive->class, drive->device);
#if GEPDEBUG
IOdebug(" format_disc() : Verify %d blocks",blocks);
#endif

	old_reass = -1;
	reass_count = 0;
	all_reass = 0;
	start = 0;
	length = VERIFY_LENGTH;
	if ( (start + length) > blocks )
		length = blocks - start;
	while (length > 0) {
#if GEPDEBUG
IOdebug(" format_disc() : verify from block %d for %d blocks",start,length);
#endif
		msc_verify (dcb, start, length, drive->class, drive->device);
		if (dcb->ok) {
			start = start + length;	
			if ( (start + length) > blocks )
				length = blocks - start;
		}
		else {
			if ( !poss_reassign (dcb,drivenumber) ) {
#if GEPDEBUG
IOdebug(" format_disc() : verify of device %d failed",drive->scsi_addr);
#endif	
				return (EC_Error + SS_IOProc + EG_Invalid);
			}
			new_reass =   (dcb->dummy_buffer[8] << 8)
				    + (dcb->dummy_buffer[9] << 16)
				    + (dcb->dummy_buffer[10] << 24);
			defect_block = 	  dcb->dummy_buffer[10]
					+ (dcb->dummy_buffer[9] << 8)
					+ (dcb->dummy_buffer[8] << 16);
			defect_block = defect_block >> (dcb->msc_blocksize / 512);

/*			
			if ( new_reass == old_reass ) {
				reass_count++;
				if (reass_count > MAX_REASSIGN) {
#if GEPDEBUG
IOdebug(" format_disc() : found block %d still defect after %d times reassigning!",defect_block,reass_count);
#endif	
					return (EC_Error + SS_IOProc + EG_Invalid);
				}
			}
			else
				reass_count = 0;
*/							
			buffer[0] = 0x04000000;
			buffer[1] = new_reass;
			old_reass = new_reass;
			
#if GEPDEBUG
IOdebug(" format_disc() : reassign block 0x%x ",defect_block);
IOdebug("                  buffer[0] = 0x%x",buffer[0]);
IOdebug("                  buffer[1] = 0x%x",buffer[1]);
#endif	
			all_reass++;
			reassign_block (dcb, drive->class, drive->device, buffer, 2);
			if (!dcb->ok) {
				if ( no_spare_blocks (dcb, drivenumber) ) {
IOdebug(" format_disc() : No spare blocks available for reassign() !");
					return (EC_Error + SS_IOProc + EG_Invalid);
				}
#if GEPDEBUG
IOdebug(" format_disc() : Reassign on device %d failed!",drive->scsi_addr);
IOdebug("                 %d blocks reassigned during verify.",all_reass);
#endif	
IOdebug(" format_disc() : Reassign() failed for unknown reason !");
				return (EC_Error + SS_IOProc + EG_Invalid);
			}
			start = (defect_block) - 10;
			if ( start < 0 )
				start = 0;
			if ( (start + length) > blocks )
				length = blocks - start;
		}
	}
		
#if GEPDEBUG
IOdebug(" format_disc() : Format device with scsi address %d succeded!",drive->scsi_addr);
IOdebug("                 %d blocks reassigned during verify.",all_reass);
#endif
	return (Err_Null);

}


/* ==================================================================== */

void
reassign_block (DiscDCB *dcb, word class, word device, 
					word *buffer, word length)
{
	word	*pw, len;	
	
	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = class;
	*pw++ = device;
	*pw++ = CO_REASSIGN_BLOCK;
	len = 5;
	
	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);
	dummy_c_read (dcb);
#if GEPDEBUG
IOdebug(" reassign_block() : reassign command sent");
#endif	

	ChanWrite (&dcb->data_out, (byte *)&length, 4);
	ChanWrite (&dcb->data_out, (byte *)buffer, length*4);
#if GEPDEBUG
IOdebug(" reassign_block() : reassign data sent");
#endif	

	wait_for_result (dcb);	
}					

/* ==================================================================== */


void
msc_format_winch (DiscDCB *dcb, word device, word *cdb, 
					word *buffer, word length)
{
	word 	*pw, len;		

	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = CO_WINCH;
	*pw++ = device;
	*pw++ = CO_FORMAT;
	*pw++ = cdb[0];
	*pw++ = cdb[1];
	*pw++ = cdb[2];
	*pw++ = cdb[3];
	*pw++ = cdb[4];
	len = 10;

	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);
	dummy_c_read (dcb);
#if GEPDEBUG
IOdebug(" format_msc() : format command sent");
#endif	

	ChanWrite (&dcb->data_out, (byte *)&length, 4);
	if (len)
		ChanWrite (&dcb->data_out, (byte *)buffer, length*4);
#if GEPDEBUG
IOdebug(" format_msc() : format data sent");
#endif	

	wait_for_result (dcb);	

}

/* ==================================================================== */

void
mode_select (DiscDCB *dcb, word class, word device, word *cdb, 
					word *buffer, word length)
{
	word 		*pw, len;		
 	
	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = class;
	*pw++ = device;
	*pw++ = CO_MODE_SELECT;
	*pw++ = length;		/* length of mode page data in byte */
	*pw++ = cdb[0];
	*pw++ = cdb[1];
	*pw++ = cdb[2];
	*pw++ = cdb[3];
	*pw++ = cdb[4];
	len = 11;

	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);
	dummy_c_read (dcb);
#if GEPDEBUG
IOdebug(" mode_select() : mode select command sent");
#endif	
		
	len = (length / 4) + 1;
	ChanWrite (&dcb->data_out, (byte *)&len, 4);
	ChanWrite (&dcb->data_out, (byte *)buffer, len*4);
#if GEPDEBUG
IOdebug(" mode_select() : mode select data sent");
#endif	

	wait_for_result (dcb);	
	
}

/* ==================================================================== */

void 
reserve (DiscDCB *dcb,word class, word device)

{	
	word *pw, len;
						    
#if GEPDEBUG
IOdebug(" reserve() : reserving");
#endif
	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = class;
	*pw++ = device;
	*pw++ = CO_RESERVE;
	len = 5;

	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);
	dummy_c_read (dcb);
	dummy_c_write (dcb);

	wait_for_result (dcb);
}

/* ==================================================================== */

void 
release (DiscDCB *dcb,word class, word device)

{	
	word *pw, len;
 
#if GEPDEBUG
IOdebug(" release() : releasing");
#endif
	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = class;
	*pw++ = device;
	*pw++ = CO_RELEASE;
	len = 5;

	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);
	dummy_c_read (dcb);
	dummy_c_write (dcb);

	wait_for_result (dcb);
}

/* ==================================================================== */

void 
msc_load (DiscDCB *dcb,word class,word device)

{	
	word *pw, len;
						    
	pw = dcb->command;

#if 0
	if ( (class != CLASS_FLOPPY) && (class != CLASS_STREAMER) )
		reserve (dcb,class, device);
#endif
	if (dcb->ok)
	{
#if GEPDEBUG
IOdebug(" msc_load() : loading");
#endif
		*pw++ = DEFAULT_PID;
		*pw++ = DEFAULT_PRI;
		*pw++ = class;
		*pw++ = device;
		*pw++ = CO_LOAD;
		len = 5;

		ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
		ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);
		dummy_c_read (dcb);
		dummy_c_write (dcb);

		wait_for_result (dcb);
	}
#if 0	
	if ( (class != CLASS_FLOPPY) && (class != CLASS_STREAMER) )
		release (dcb,class, device);
#endif		
}


/* ==================================================================== */

void 
msc_unload (DiscDCB *dcb,word class,word device)

{	
	word *pw, len;
						    
	pw = dcb->command;

	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = class;
	*pw++ = device;
	*pw++ = CO_UNLOAD;
	len = 5;

	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);
	dummy_c_read (dcb);
	dummy_c_write (dcb);

	wait_for_result (dcb);
}
	
/* ==================================================================== */

word 
msc_read (DiscDCB *dcb, word blknr, word blk_cnt, byte *buffer, word class,
			word device, word *error)

/* Returns the number of blocks read successfully and an error code */
/* in "error" or 0 if no error occurred */

{	
	word 	*pw, len;
	word	reass_buf[10];
	word	new_reass, defect_block;
	word	reassigned_block;
	word	drivenum;
	DriveDescriptor *drive;
	

	reassigned_block = FALSE;				
					      
#if GEPDEBUG
IOdebug("READ  %d blocks from %d, class %d, device %d\n", blk_cnt, blknr, class, device);
#endif

retry_read:
	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = class;
	*pw++ = device;
	*pw++ = CO_READ;
	*pw++ = blknr;
	*pw++ = blk_cnt;
	len = 7;

	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);

	ChanRead (&dcb->data_in, (byte *)&len, 4);
	if (len > 0)	
		ChanRead (&dcb->data_in, (byte *)buffer, len*4);
	/* len is in units of words */
	dummy_c_write (dcb);

	wait_for_result (dcb);
	if (!dcb->ok) {
		drivenum = cls_dev_to_drvnum( dcb, class, device);
		drive = &dcb->drivelist[drivenum];
		if ( recovered_error (dcb)) {
			*error = Err_Null;
			len = len*4 / dcb->msc_blocksize;	/* in blocks */
		}
		elif ( (class == CLASS_WINCH) && poss_reassign (dcb, drivenum) ) {
			new_reass =   (dcb->dummy_buffer[8] << 8)
				    + (dcb->dummy_buffer[9] << 16)
				    + (dcb->dummy_buffer[10] << 24);
			defect_block = 	  dcb->dummy_buffer[10]
					+ (dcb->dummy_buffer[9] << 8)
					+ (dcb->dummy_buffer[8] << 16);
			defect_block = defect_block >> (dcb->msc_blocksize / 512);
			reass_buf[0] = 0x04000000;
			reass_buf[1] = new_reass;
			
#if GEPDEBUG
IOdebug(" msc_read() : reassign block 0x%x ",defect_block);
IOdebug("                  buffer[0] = 0x%x",reass_buf[0]);
IOdebug("                  buffer[1] = 0x%x",reass_buf[1]);
#endif	
			reassign_block (dcb, drive->class, drive->device, reass_buf, 2);
			if (!dcb->ok) {
				if ( no_spare_blocks (dcb, drivenum) ) {
IOdebug(" msc_read() : No spare blocks available for reassign() !");
					*error = EC_Error + SS_IOProc + EG_Invalid + EO_Medium;
					return (0);
				}
#if GEPDEBUG
IOdebug(" msc_read() : Reassign on device %d failed!",drive->scsi_addr);
#endif	
IOdebug(" msc_read() : Reassign() failed for unknown reason !");
				*error = EC_Error + SS_IOProc + EG_Invalid + EO_Medium;
				return (0);
			}
			reassigned_block = TRUE;
IOdebug(" msc_read() : ATTENTION : Reassigned block %d of device %d !",defect_block,drive->scsi_addr);
IOdebug("	       Device may become unusable, make sure having a backup !");
			goto retry_read;			
		}
		else {
			*error = EC_Fatal + EG_Invalid + EO_Medium;
			len = 0;
		}
	} 
	elif ( reassigned_block ) {
		len = len*4 / dcb->msc_blocksize;	/* in blocks */
		*error = EC_Recover + SS_IOProc + EO_Medium;
	}
	else {
		len = len*4 / dcb->msc_blocksize;	/* in blocks */
		*error = Err_Null;			/* no error */
	}
	return (len);
}

/* ==================================================================== */

word 
msc_write (DiscDCB *dcb,word blknr, word blk_cnt, byte *buffer, word class,
			word device, word *error)

/* Returns the number of blocks written successfully and an error code */
/* in "error" or 0 if no error occurred */

{	
	word 	*pw, len;
	word	reass_buf[10];
	word	new_reass, defect_block;
	word	reassigned_block;
	word	drivenum;
	DriveDescriptor *drive;
	

	reassigned_block = FALSE;				
						    
#if GEPDEBUG
IOdebug("WRITE %d blocks from %d, class %d, device %d\n", blk_cnt, blknr, class, device);
#endif
retry_write:
	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = class;
	*pw++ = device;
	*pw++ = CO_WRITE;
	*pw++ = blknr;
	*pw++ = blk_cnt;
	len = 7;

	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);
	dummy_c_read (dcb);
	
	len = dcb->msc_blocksize * blk_cnt;	/* len in bytes */
	len = len/4;				/* len in words */
	ChanWrite (&dcb->data_out, (byte *)&len, 4);
	ChanWrite (&dcb->data_out, (byte *)buffer, len*4);

	wait_for_result (dcb);
	if (!dcb->ok) {
		if ( recovered_error (dcb)) {
			*error = Err_Null;
			len = blk_cnt;
		}
		elif ( data_protect_error (dcb)) {
			*error = EC_Fatal + EG_Protected + EO_Medium;
			len = 0;
		}
		elif ( (class == CLASS_WINCH) && poss_reassign (dcb, drivenum) ) {
			drivenum = cls_dev_to_drvnum( dcb, class, device);
			drive = &dcb->drivelist[drivenum];
			new_reass =   (dcb->dummy_buffer[8] << 8)
				    + (dcb->dummy_buffer[9] << 16)
				    + (dcb->dummy_buffer[10] << 24);
			defect_block = 	  dcb->dummy_buffer[10]
					+ (dcb->dummy_buffer[9] << 8)
					+ (dcb->dummy_buffer[8] << 16);
			defect_block = defect_block >> (dcb->msc_blocksize / 512);
			reass_buf[0] = 0x04000000;
			reass_buf[1] = new_reass;
			
#if GEPDEBUG
IOdebug(" msc_write() : reassign block 0x%x ",defect_block);
IOdebug("                  buffer[0] = 0x%x",reass_buf[0]);
IOdebug("                  buffer[1] = 0x%x",reass_buf[1]);
#endif	
			reassign_block (dcb, drive->class, drive->device, reass_buf, 2);
			if (!dcb->ok) {
				if ( no_spare_blocks (dcb, drivenum) ) {
IOdebug(" msc_write() : No spare blocks available for reassign() !");
					*error = EC_Error + SS_IOProc + EG_Invalid + EO_Medium;
					return (0);
				}
#if GEPDEBUG
IOdebug(" msc_write() : Reassign on device %d failed!",drive->scsi_addr);
#endif	

IOdebug(" msc_write() : Reassign() failed for unknown reason !");
				*error = EC_Error + SS_IOProc + EG_Invalid + EO_Medium;
				return (0);
			}
			reassigned_block = TRUE;
IOdebug(" msc_write() : ATTENTION : Reassigned block %d of device %d !",defect_block,drive->scsi_addr);
IOdebug("	        Device may become unusable, make sure having a backup !");
			goto retry_write;			
		}
		
		else {
			*error = EC_Fatal + EG_Invalid + EO_Medium;
			len = 0;
		}
	} 
	elif ( reassigned_block ) {
		len = blk_cnt;				/* in blocks */
		*error = EC_Recover + SS_IOProc + EO_Medium;
	}
	else {
		len = blk_cnt;				/* in blocks */
		*error = Err_Null;			/* no error */
	}
	return (len);
}


/* ==================================================================== */

void 
msc_verify (DiscDCB *dcb, word blknr, word blk_cnt, word class, word device)
{	
	word *pw, len;
						      
	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = class;
	*pw++ = device;
	*pw++ = CO_VERIFY;
	*pw++ = blknr;
	*pw++ = blk_cnt;
	len = 7;

	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);

	dummy_c_read (dcb);
	dummy_c_write (dcb);

	wait_for_result (dcb);
}

/* ==================================================================== */

word
msc_seek (DiscDCB *dcb, word bnr, word class, word device)

{
	word *pw, len;

	if (class != CLASS_STREAMER)
		return (-1);

	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = CO_STREAMER;
	*pw++ = device;
	*pw++ = CO_SEEK_BLOCK;
	*pw++ = bnr;
	len = 6;

	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);

	dummy_c_read (dcb);
	dummy_c_write (dcb);
	
	wait_for_result (dcb);
	
	if (!dcb->ok)
		return (-1);
	else
		return (bnr);	
}


/* ==================================================================== */

void
msc_rewind (DiscDCB *dcb, word device)

{
	word *pw, len;
	word retry_count;
	
	retry_count = MAX_RETRIES;
retry:
	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = CO_STREAMER;
	*pw++ = device;
	*pw++ = CO_REWIND;
	len = 5;

	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);

	dummy_c_read (dcb);
	dummy_c_write (dcb);
	
	wait_for_result (dcb);
	if (!dcb->ok) {
		if ((dcb->dummy_buffer[3] & STATUS_MASK) == STATUS_BUSY) {
			Delay (OneSec);
			retry_count--;
			if (retry_count) {
#if GEPDEBUG
				IOdebug(" msc_rewind() : retry rewind");
#endif
				goto retry;
			}
		}
	}
}


/* ==================================================================== */

void 
msc_finish (DiscDCB *dcb)

{	
	word *pw, len;
						    
	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = CLASS_SPECIAL;
	*pw++ = CO_FINISH;
	len = 4;

	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);
	dummy_c_read (dcb);
	dummy_c_write (dcb);

	wait_for_result (dcb);
}

/* ==================================================================== */
/* ==================================================================== */

void 
dummy_c_read (DiscDCB *dcb)

/* Reads unexpected, senseless data from data channel */

{
	word len;
						      
#if DEBUG
IOdebug ("d.rd");
#endif
	ChanRead (&dcb->data_in, (byte *)&len, 4);
	if (len > 0)
		ChanRead (&dcb->data_in, (byte *)dcb->dummy_buffer, len*4);
#if DEBUG
IOdebug (": ");
#endif
}

/* ==================================================================== */

void 
dummy_c_write (DiscDCB *dcb)				

/* Writes a Null-slice to the data channel */

{
	word len = 0;
#if DEBUG
IOdebug ("d.wt");
#endif
	ChanWrite (&dcb->data_out, (byte *)&len, 4);
#if DEBUG
IOdebug (": ");
#endif
}

/* ==================================================================== */

word
get_protocol (DiscDCB *dcb, word buffer_size, word *buffer, word init)

/* read the internal protocol of MSC in buffer with length buffer_size. */
/* If init == TRUE then the transfer will be initialized and no buffer  */
/* be filled.								*/
/* get_protocol() returns TRUE if there is more information to read.	*/
/* One entry occupies 64 bytes with the following structure:		*/
/*  byte  0 - 39 :  text string describing the action			*/
/*  byte 40 - 43 :  the action number (word)				*/
/*  byte 44 - 47 :  parameter1 (word)					*/
/*  byte 48 - 51 :  parameter2 (word)					*/
/*  byte 52 - 55 :  parameter3 (word)					*/
/*  byte 56 - 63 :  unused 						*/

{
	word *pw, len;
						    
	pw = dcb->command;
	*pw++ = DEFAULT_PID;
	*pw++ = DEFAULT_PRI;
	*pw++ = CO_SPECIAL;
	*pw++ = CO_GET_PROTOCOL;
	*pw++ = buffer_size;
	*pw++ = init;
	len = 6;

	ChanWrite (&dcb->cmd_out, (byte *)&len, 4);
	ChanWrite (&dcb->cmd_out, (byte *)dcb->command, len*4);
	
	ChanRead (&dcb->data_in, (byte *)&len, 4);
	if (len > 0)
		ChanRead (&dcb->data_in, (byte *)buffer, len*4);	
	dummy_c_write (dcb);

	wait_for_result (dcb);
	return (dcb->dummy_buffer[2]);
}

void
read_protocol (DiscDCB *dcb)
{
	typedef struct result_type {
		char	text[40];
		word	action;
		word	param1;
		word	param2;
		word	param3;
		word	unused1;
		word	unused2;
	} result_type;
	
	result_type	buffer;
	word		more,i;
	word		number = 0;
	char		text[41];
	
	text[40] = '0';
	more = get_protocol(dcb,16,(word *)(&buffer),TRUE);
IOdebug(" read_protocol() : Printing Protocol");
	while (more) {
		more = get_protocol(dcb,16,(word *)(&buffer),FALSE);
		for (i=0;i < 40;i++) 
			text[i] = buffer.text[i];
IOdebug(" entry (%d) : %s (%d) (%x, %x, %x)",number,*text,buffer.action,buffer.param1,buffer.param2,buffer.param3);				
		number++;
	}		
}



/* ==================================================================== */

void
wait_for_result (DiscDCB *dcb)

/* Expects an answer on command channel and set global 'ok' accordingly */

{	
	word len, i;

	ChanRead (&dcb->cmd_in, (byte *)&len, 4);
	dcb->len = len;
	if (len > 0)
		ChanRead (&dcb->cmd_in, (byte *)dcb->dummy_buffer, len*4);

	/* the first word is pid */	
	dcb->ok = (dcb->dummy_buffer[1] == CO_OK);
	if (!dcb->ok)
	{
		IOdebug ("result (%d): ", (len-1));
		for (i=1;i<len;i+=4)
		    IOdebug ("%x %x %x %x", dcb->dummy_buffer[i],dcb->dummy_buffer[i+1],dcb->dummy_buffer[i+2],dcb->dummy_buffer[i+3]);
#if GEPDEBUG
/*		read_protocol(dcb);  */
#endif
		    
	}
}

/* ==================================================================== */

/* end of msc.c */

