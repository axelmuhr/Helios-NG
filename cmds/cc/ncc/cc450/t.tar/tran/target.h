
/* C compiler file sparc/target.h :  Copyright (C) Codemist Ltd., 1991. */
/* Copyright (c) 1991 Perihelion Software Ltd.
   All Rights Reserved */
/* version 5 */
/* $Header: /dsl/HeliosRoot/Helios/cmds/cc/ncc/cc450/tran/RCS/target.h,v 1.1 1995/05/19 11:38:17 nickc Exp $ */

#ifndef _target_LOADED
#define _target_LOADED 1

#define TARGET_MACHINE 			"Transputer"
#define TARGET_PREDEFINES 		{ "__tran", "__JMP_BUF_SIZE=8" }

   #define TARGET_IS_XPUTER				1

   #define NON_CODEMIST_MIDDLE_END			1
/*   #define HOST_USES_CCOM_INTERFACE			1 */
   #define NO_CONFIG					1
   
/* #define TARGET_IS_BIG_ENDIAN    			0 */	/* but doubles are big endian ! */
   #define TARGET_IS_LITTLE_ENDIAN    			1  	/* because of C40 byte instructions */

#if !(defined TARGET_HAS_AOUT || defined TARGET_HAS_COFF)
   #define TARGET_HAS_AOUT 				1	/* XXX we do not actually care about this */
#endif

   #define target_coff_magic 				0577     /* inspected if TARGET_HAS_COFF */

   #define TARGET_HAS_DEBUGGER				1	/* It may not be DBX, but hey! */

   #define TARGET_HAS_BLOCKMOVE 			1	/* XXX - well, we are faking it */
   #define TARGET_HAS_COND_EXEC				1	/* can do conditionally execution */
   #define TARGET_HAS_FP_LITERALS			1	/* FP constants can be included in OP codes */
   #define TARGET_HAS_IEEE 				1	/* XXX - not quite true ... */
   #define TARGET_HAS_MULTIPLY 				1   	/* but see also config_init in mcdep.c */
   #define TARGET_HAS_SEPARATE_CODE_DATA_SEGS		1	/* because of seperqte address buses */
   #define TARGET_HAS_SIGN_EXTEND			1	/* XXX we can fake it */
   #define TARGET_HAS_TAILCALL 				1	/* yup we can do tailcalls */
   #define TARGET_HAS_TAILCALLR 			1	/* XXX - does this work ? */
   #define TARGET_ONLY_HAS_CONDITIONAL_LOAD		1	/* but only for load instructions */

/* #define TARGET_HAS_2ADDRESS_CODE 			0 */	/* implies only supports diadic operations */
/* #define TARGET_HAS_370_FP				0 */	/* IBM370 specific */
/* #define TARGET_HAS_BSS 				0 */	/* XXX - do we ? */
/* #define TARGET_HAS_BYTE_INSTRUCTIONS			0 */	/* indicates instructions are byte sized */
/* #define TARGET_HAS_DIVIDE   				0 */
/* #define TARGET_HAS_DIVREM_FUNCTION			0 */
/* #define TARGET_HAS_EBCDIC				0 */
/* #define TARGET_HAS_HALFWORD_INSTRUCTIONS		0 */	/* indicates that instructions can be 16 bits */
/* #define TARGET_HAS_LINKER_NAME_LIMIT			0 */	/* not that I know of */
/* #define TARGET_HAS_NEGATIVE_INDEXING			0 */	/* XXX - what does this do ? */
/* #define TARGET_HAS_NON_FORTRAN_DIVIDE		0 */	/* XXX - we do not have any divide ops */
/* #define TARGET_HAS_OTHER_IEEE_ORDER			0 */	/* IEEE doubles are stored big-endian */
/* #define TARGET_HAS_PROFILE 				0 */	/* XXX - not for now */
/* #define TARGET_HAS_RISING_STACK			0 */	/* XXX - added by NC, see c40/flowgraf.c */
/* #define TARGET_HAS_ROTATE                            0 */	/* C40 rotates not sufficient for this */
/* #define TARGET_HAS_SCALED_ADDRESSING			0 */	/* indicates that load offsets can be in bytes, words, etc */
/* #define TARGET_HAS_SCALED_OPS			0 */	/* XXX - what does this do ? */
/* #define TARGET_HAS_SCCK				0 */	/* m68k specific */
/* #define TARGET_HAS_SWITCH_BRANCHTABLE 		0 */	/* indicates that target has special support for switching */

   #define TARGET_ADDRESSES_UNSIGNED			1
   #define TARGET_ALLOWS_COMPARE_CSES			1
   #define TARGET_COUNT_IS_PROC 			1
   #define TARGET_LACKS_DIVIDE_LITERALS 		1
   #define TARGET_LINKER_OMITS_DOLLAR 			1	/* XXX - what does this do ? */

#define TARGET_CALL_USES_DESCRIPTOR			1
/* #define TARGET_CORRUPTS_SWITCH_REGISTER 		0 */	/* switch might corrupt index register */
/* #define TARGET_FLAGS_VA_CALLS			0 */	/* IBM370 specific */
/* #define TARGET_GEN_NEEDS_VOLATILE_INFO		0 */	/* do we ? */
/* #define TARGET_INLINES_MONADS			0 */	/* XXX - what does this do ? */
/* #define TARGET_LACKS_3WAY_COMPARE			0 */
/* #define TARGET_LACKS_FP_DIVIDE			0 */	/* we can simulate it efficiently */
/* #define TARGET_LACKS_HALFWORD_STORE			0 */	/* implies that we cannot store half words */
/* #define TARGET_LACKS_MULDIV_LITERALS			0 */	/* cannot multiply or divide by a constant */
/* #define TARGET_LACKS_MULTIPLY_LITERALS		0 */
/* #define TARGET_LACKS_REMAINDER			0 */
/* #define TARGET_LACKS_RIGHTSHIFT			0 */
/* #define TARGET_LACKS_ROL				0 */	/* no Rotate Left instruction */
/* #define TARGET_LACKS_RR_STORE			0 */	/* XXX - what does this do ? */
/* #define TARGET_LACKS_UNSIGNED_FIX 			0 */
/* #define TARGET_LDRK_MAX 				0 */	/* maximum permitted pointer offset */
/* #define TARGET_LDRK_MIN 				0 */	/* maximum permitted negative pointer offset */
/* #define TARGET_LDRK_QUANTUM				0 */	/* superceeded by LDRK_MIN and LDRK_MAX */
/* #define TARGET_NULL_BITPATTERN			0 */	/* defined elsewhere */
/* #define TARGET_R0_ALWAYS_ZERO 			0 */	
/* #define TARGET_SHARES_INTEGER_AND_FP_REGISTERS	0 */ 	/* removed on advice from AM */
/* #define TARGET_STACKS_LINK				0 */	/* link address is placed on stack */
/* #define TARGET_STACK_MOVES_ONCE			0 */	/* Hitachi specific */
/* #define TARGET_STRUCT_RESULT_REGISTER		0 */	/* names register used to return structs */
/* #define TARGET_SWITCH_isdense			0 */	/* advanced tuning for switch statements */

/*
 * This disables the -l option to list a file (to stdout?) which screws up
 * the make system.  Tony 18/1/95
 */
#define NO_LISTING_OUTPUT	1

/* #define ADDRESS_REG_STUFF 				0 */	/* indicates seperate address and data regs */
/* #define RANGECHECK_SUPPORED				0 */	/* only for FORTRAN / PASCAL */

/* #define DO_NOT_OPTIMISE_CHAR_AND_SHORT_ARITHMETIC 	0 */	/* XXX - experimentally put in ?? */

   #define NO_INSTORE_FILES				1 

#if defined __hp9000s700 || defined _AIX
#define REVERSE_OBJECT_BYTE_ORDER			1 	/* big endian host */
#endif

/* #define SOFTWARE_FLOATING_POINT			0 */	/* defined if no FP support in op codes */


#define sizeof_char		1	/* a bit of a tautology, but what the hell */
#define sizeof_short		2
#define sizeof_int      	4
#define sizeof_long		4
#define sizeof_ptr		4
#define sizeof_float		4
#define sizeof_double		8
#define sizeof_ldble		8

#define alignof_short		2
#define alignof_int     	4
#define alignof_long		4
#define alignof_ptr		4
#define algn_of_float		4
#define alignof_double  	4
#define alignof_ldble		4
#define alignof_max		4
#define alignof_struct  	4
#define alignof_toplevel	4

#define NUM_BITS_PER_BYTE	8

 
#endif /* _target_LOADED */

/* end of tran/target.h */
