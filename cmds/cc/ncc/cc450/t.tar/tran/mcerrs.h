/*
 * sparc/mcerrs.h - prototype for machine-specific error messages file
 */

%O  /* Ordinary error messages - mapped onto numeric codes */

/*
 * The following message is always machine specific since it may include
 * information about the source of support for the product.
 */
#define misc_disaster_banner   "\n\
*************************************************************************\n\
* The compiler has detected an internal inconsistency.  This can occur  *\n\
* because it has run out of a vital resource such as memory or disk     *\n\
* space or because there is a fault in it.  If you cannot easily alter  *\n\
* your program to avoid causing this rare failure, please contact your  *\n\
* dealer.  The dealer may be able to help you immediately and will be   *\n\
* able to report a suspected compiler fault to the support centre.      *\n\
*************************************************************************\n\
\n"

%S  /* System failure messages - text not preserved */

#define syserr_fromq "C_FROMQ(%lx)"
#define syserr_local_address "local_address %lx"
#define syserr_local_addr "local_addr"
#define syserr_local_base "local_base %lx"
#define syserr_firstbit "firstbit"
#define syserr_outHW "outHW(%lx)"
#define syserr_litaddr "code/literal addressing error %lx"
#define syserr_unknown_labref_type "unknown label reference type %.8lx"
#define syserr_push "push(VARREGS)"
#define syserr_pop "pop(VARREGS)"
#define syserr_back_coderef "back. code. ref. off %#lx"
#define syserr_movc "MOVC overlong"
#define syserr_movr "movr r,r"
#define syserr_asymrrop "asymrrop"
#define syserr_movdr1 "MOVDR1 not finished"
#define syserr_movfdr "MOVF/DR r,r"
#define syserr_frrop "frrop"
#define syserr_show_inst "show_inst(%#lx)"
#define syserr_asmlab "odd asmlab(%lx)"
#define syserr_display_asm "display_asm(%lx)"
#define syserr_asm_trailer "asm_trailer(%ld)"
#define syserr_datalen "asm_data len=%ld"
#define syserr_asm_trailer1 "asm_trailer(%ldF%ld)"
#define syserr_asm_trailer2 "asm_trailer(LIT_ADCON rpt)"
#define syserr_asm_confused "Assembler output confused - find '?'"
#define syserr_debug_addr "local_fpaddress"

/* end of sparc/mcerrs.h */
