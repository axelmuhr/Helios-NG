/************************************************************************/
/*									*/
/*			TYPES.H						*/
/*									*/
/************************************************************************/

/************************************************************************/
/*									*/
/* Contains all the data types needed by the Atari graphics library	*/
/*									*/
/************************************************************************/

/*			TYPES						*/

/*	Storage elements */

/*	Offset of in pixels, measured from the screen origin at top left */

typedef long		PIX_OFFSET;

#ifndef NO_DEFINES

typedef long		WORD;
typedef unsigned long	UWORD;
typedef char		BYTE;
typedef unsigned char	UBYTE;

#define MinInt          0x80000000
#define NULL		((void *)MinInt)

#endif
/*			WORKSTATION PARAMETERS				*/

typedef struct {
	/*		General marking controls			*/
	WORD COLOR[3];	/* COLOR[0]= Red; COLOR[1]= Green; COLOR[3]= Blue */
			/* All values are 0-1000 */
	WORD WRITE_MODE;

	/*		Line marking controls				*/
	WORD LINE_TYPE;
	WORD LINE_USER_PATTERN;
	UWORD LINE_PATTERN_OFFSET;
	WORD LINE_WIDTH;
	WORD LINE_END_STYLE[2];
	WORD LINE_COLOR_INDEX;
	WORD LINE_MASK;

	/*		Marker marking controls				*/
	WORD MARKER_HEIGHT;
	WORD MARKER_WIDTH;
	WORD MARKER_TYPE;
	WORD MARKER_COLOR_INDEX;
	WORD MARKER_SET_HEIGHT;

	/*		Text marking controls				*/
	WORD TEXT_FACE;		/* Index 1 ..., identifying typeface */
	WORD TEXT_COLOR_INDEX;
	WORD TEXT_ANGLE;
	WORD TEXT_ALIGN[2];
	WORD TEXT_EFFECT;
	WORD TEXT_CHAR_WIDTH;		/* Character width */
	WORD TEXT_CHAR_HEIGHT;		/* Character height from baseline */
	WORD TEXT_CELL_WIDTH;		/* Character cell width */
	WORD TEXT_CELL_HEIGHT;		/* Character cell height */

	/*		Area marking controls				*/
	WORD FILL_INTERIOR_STYLE;
	WORD FILL_STYLE_INDEX;
	WORD FILL_COLOR_INDEX;
	WORD FILL_OUTLINED;
	WORD *FILL_USER_PATTERN;	/* pointer to the user defined */
					/* fill pattern */
	WORD *FILL_MASK;		/* pointer to the current fill mask */

	/*		Coordinate controls				*/
	WORD NDC_TO_RC_FLAG;

	/*		Clip region control				*/
	WORD CLIP_XMIN;
	WORD CLIP_YMIN;
	WORD CLIP_XMAX;
	WORD CLIP_YMAX;
	WORD CLIP_FLAG;

	WORD A_CURSOR_X;	/* Alpha cursor column (in cells) */
	WORD A_CURSOR_Y;	/* Alpha cursor row (in cells) */
	WORD A_ON;		/* Alpha-cursor-enabled flag */	

} HANDLE;


/*		SCREEN VARIANT DATA RECORD				*/
typedef struct {
	WORD	WIDTH;		/* In pixels */
	WORD	HEIGHT;		/* In pixels */
	WORD	DEPTH;		/* In bits */
	WORD	MINFONTNUM;
	WORD	MAXFONTNUM;
	WORD	CHAR_ROWS;	/* Number of characters per row */
	WORD	CHAR_COLS;	/* Number of characters per column */
	WORD	MODE;		/* Format variant */
	WORD	MAP;		/* Pointer to RAM origin of video map */
	WORD	G_CUR_PAT[16];	/* Graphics cursor pattern */
	UBYTE	G_CUR_COPY[16][16];	/* Storage for what is under graphics cursor */
	UBYTE	G_CUR_COL[16][16];	/* Cursor colour mask */
	WORD	STRIDE;		/* Width of memory map containing the screen */
	WORD	PIX_SIZE;	/* Size in inches of one pixel */

	WORD	G_CURSOR_X;	/* Graphics cursor x coordinate */
	WORD	G_CURSOR_Y;	/* Graphics cursor y coordinate */
	WORD	G_ON;		/* Graphics cursor enable flag */

	WORD	MAGIC;		/* the magic colour for this mode */
} SCREEN_PARAMS;

/* The record associated with scan-converting polygons */

typedef struct EDGE_RECORD {
	WORD	edge_xvalue;
	WORD	edge_gradient;
	WORD	edge_ymax;
	struct EDGE_RECORD	*edge_next;

} EDGE_RECORD;

typedef struct FILL_STACK_RECORD {
	PIX_OFFSET	left;		/* the left most pixel inclusive */
	PIX_OFFSET	right;		/* the right most pixel inclusive */
	PIX_OFFSET	parent;		/* the first pixel on the scan-line */
	WORD	direction;		/* the next direction to check */

} FILL_STACK_RECORD;
