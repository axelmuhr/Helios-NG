/************************************************************************/
/*									*/
/*			GEM VIRTUAL DEVICE INTERFACE			*/
/*									*/
/*				GEM.C					*/
/*PJW/TJK/NC								*/
/************************************************************************/

#include "sthelios.h"
#include <stdio.h>
#include "stextra.h"
#include "defines.h"

#include <basepage.h>
#include <osbind.h>
#include <xbios.h>

#ifdef MODE0
#define SCREEN_MODE 0
#else
#ifdef MODE1
#define SCREEN_MODE 1
#else
#ifdef MODE2
#define SCREEN_MODE 2
#endif
#endif
#endif

#ifndef SCREEN_MODE

Please compile with option -DMODE0, -DMODE1 or -DMODE2

#endif

/* CONTAINS FUNCTIONS:							*/
/*									*/
/* main:        Entered to install the trap handler & boot transputer	*/
/* atari:	Entry point for all graphics utilities			*/

typedef struct mouse {
	BYTE	topmode;
	BYTE	buttons;
	BYTE	xscale;
	BYTE	yscale;
	SHORT	xmax;
	SHORT	ymax;
	SHORT	xstart;
	SHORT	ystart;
} MOUSE;

extern void	catch();
extern void	loadboot(), boot_transputer();
void		(*old_vec)();

static SHORT sending = 0; /* true if atari - transputer send in progress */

/* The routine main calls some asembler to initialise us, and then
   terminates but stays resident. Subsequent uses of the GEM trap
   will end up calling our routine vdi(). If the d flag is given
   the program is assumed to be installed under an existing (open)
   VDI and does not open the ROM version when opened.
*/

SHORT	opened = 0;
WORD	Ports[3];

SHORT main(argc,argv)
SHORT argc;
BYTE *argv[];
{
	SHORT arg;

	for (arg =1 ; arg < argc; arg++) {
		BYTE *s = argv[arg];
		BYTE c;

		while ( c = *s++ ) {
			switch (c) {
				case 'd': opened = 1;
					  break;
				default:  fprintf(stderr,
					"Unkown option %c ignored\n",c);
			}
		}
	}

        loadboot();

        boot_transputer("c:\\trans");

	install();

	getports(&Ports[0]);

	Ptermres(BP->p_hitpa-BP->p_lowtpa+0x1024L,0);
} /* main() */

/* The VDI routine is called by the Gem VDI trap handler. If this routine
   returns 1, the trap routine assumes that the routine was suitably dealt with
   but if 0 is returned, the trap routine allows the original trap handler to
   process the request.
 */

/* The single argument is the parameter block, with the following format */

typedef struct pb {
   SHORT *ctrlarry;	/* control array address */
   SHORT *intin;		/* input array */
   SHORT *ptsin;		/* Input coordinate array */
   SHORT *intout;		/* Output array */
   SHORT *ptsout;		/* Output coordinate array */
} PB;

UBYTE	block[BUF_SIZE];

static	SHORT	*A_CONTRL;
static	SHORT	*A_INTIN;
static	SHORT	*A_PTSIN;
static	SHORT	*A_INTOUT;
static	SHORT	*A_PTSOUT;

static void pack()
/* Pack the gem arrays into a byte stream */
{
	register SHORT	j;
	register UBYTE	*array = block;
	void		sendm();
	void		poll_for_msgs();

        if (A_CONTRL[0]==122) A_CONTRL[3] = 1; /* Fix GEM bug!! */

	*array++ = A_CONTRL[0];
	*array++ = A_CONTRL[1];
	*array++ = A_CONTRL[3];
	*array++ = A_CONTRL[6];

	switch (A_CONTRL[0]) {

		case 11:	/* pack sub-code */
				*array++ = A_CONTRL[5];
				break;

		case 10:	/* cell array variables */
				*array++ = A_CONTRL[7];
				*array++ = A_CONTRL[8];
				*array++ = A_CONTRL[9];
				*array++ = A_CONTRL[10];
				break;

		case 1:		/* pack screen mode */
				*array++ = SCREEN_MODE;
				break;

		default:	/* no extras */
				break;
	}

	for( j = A_CONTRL[3] ; j>0 ; ) {
		*array++ = A_INTIN[--j] >> 8;
		*array++ = A_INTIN[j];
	}

	for( j = 0; j < A_CONTRL[1] * 2 ; j++ ) {
		*array++ = A_PTSIN[j] >> 8;
		*array++ = A_PTSIN[j++];
		*array++ = A_PTSIN[j] >> 8;
		*array++ = A_PTSIN[j];
	}

	/* NB/ in Mark Williams C results of pionter arithmatic are shorts */

	sending++;
	sendm((array - block),block,ATARI_MESS);

	poll_for_msgs();
	--sending;

} /* pack() */

void sendm(len,buffer,FnRc)
USHORT	len;
UBYTE	*buffer;
WORD	FnRc;
/* send a message to the atari */
{
	MCB	mcb;
	WORD	PutMsg();

	mcb.MsgHdr.DataSize	= len;
	mcb.MsgHdr.ContSize	= 0;
	mcb.MsgHdr.Flags	= MsgHdr_Flags_preserve;
	mcb.MsgHdr.Dest		= Ports[0];
	mcb.MsgHdr.Reply	= NullPort;
	mcb.MsgHdr.FnRc		= FnRc;
	mcb.Data		= (BYTE *)buffer;
	mcb.Control		= (WORD *)NULL;
	mcb.Timeout		= 0x77fffL;

	if (!PutMsg(&mcb)) printf("bad PutMsg (atari)\n");

} /* sendm() */

void poll_for_msgs()
/* collect and disperse messages from the transputer */
{
	MCB	mcb;
	void	accept_mem();

	mcb.Data	= (BYTE *)block;
	mcb.Timeout	= 0x77fffL;

	for(;;) {

		while( !GetMsg(&mcb) ) {
			printf("waiting for reply to opcode %d\n",A_CONTRL[0]);
		}

		if        (mcb.MsgHdr.FnRc == PRINT) {

			putchar(*block);

		} else if (mcb.MsgHdr.FnRc == DATA_BACK) {

			if (receive(block)) break;

		} else if (mcb.MsgHdr.FnRc == SEND_FONT) {

			break;

		} else if (mcb.MsgHdr.FnRc == SEND_MFDB) {

			break;

		} else if (mcb.MsgHdr.FnRc == MEM_BACK) {

			accept_mem(block,mcb.MsgHdr.DataSize);

		} else {
			printf("unexpected FnRc %lx\n",mcb.MsgHdr.FnRc);
		}
	}

} /* poll_for_msgs() */

SHORT receive(array)
register UBYTE *array;
/* returns 1 if ok, 0 if error message returned */
{
	register SHORT	j;

	A_CONTRL[4] = *array++;
	A_CONTRL[2] = *array++;

	switch(A_CONTRL[4]) {

		case RET_HANDLE: /* Extract handle */	
				A_CONTRL[6] = A_CONTRL[2];
				A_CONTRL[4] = *array++;
				A_CONTRL[2] = *array++;
				/* and fall through */

		default:	/* Extract info */

			for (j = A_CONTRL[4]; j ; ) {
				A_INTOUT[--j] = *array++;
				A_INTOUT[j] <<= 8;
				A_INTOUT[j] |= *array++;
			}

			for (j = 0; j < A_CONTRL[2] * 2; j++ ) {
				A_PTSOUT[j] = *array++;
				A_PTSOUT[j] <<= 8;
				A_PTSOUT[j++] |= *array++;
				A_PTSOUT[j] = *array++;
				A_PTSOUT[j] <<= 8;
				A_PTSOUT[j] |= *array++;
			}
			return(1);
	}

} /* receive() */

static SHORT	oldx = MOUSE_X,
		oldy = MOUSE_Y;

SHORT atari(p)
PB *p;
/* Atari side of atari-transputer interface */
{
	void callvdi();
	void init_mouse();
	void close_mouse();
	void get_fonts();
	void send_MFDB();

	/* Copy the paramter arrays into our global workspace */

	A_CONTRL = p->ctrlarry;
	A_INTIN  = p->intin;
	A_PTSIN  = p->ptsin;
	A_INTOUT = p->intout;
	A_PTSOUT = p->ptsout;

	switch(A_CONTRL[0]) {
		case 1:		/* v_opnwk() */
				if (!opened) callvdi(p);
				pack();

				get_fonts();
				init_mouse();
				break;

		case 100:	/* v_opnvwk() */
				if (!opened) {
					callvdi(p);
				} else {
					opened = 0;
				}
				pack();
				break;

		case 101:	/* v_clsvwk() */
				pack();
				if (A_CONTRL[6] != 2) {
					return(0);
				}
				break;

	/* The following functions execute on transputer only */

		case 2:		/* v_clswk() */
				close_mouse();
		case 3:		/* v_clrwk() */
		case 4:		/* v_updwk() */
		case 5:		/* v_escape() */
		case 6:		/* v_pline() */
		case 7:		/* v_pmarker() */
		case 8:		/* v_gtext() */
		case 9:		/* v_fillarea() */
		case 11:	/* Generalised Drawing Primitive */
		case 14:	/* vs_color() */
		case 15:	/* vsl_type() */
		case 16:	/* vsl_width() */
		case 17:	/* vsl_color() */
		case 18:	/* vsm_type() */
		case 19:	/* vsm_height() */
		case 20:	/* vsm_color() */
		case 21:	/* vst_font() */
		case 22:	/* vst_color() */
		case 23:	/* vsf_interior() */
		case 24:	/* vsf_style() */
		case 25:	/* vsf_color() */
		case 26:	/* vq_color() */
		case 32:	/* vswr_mode() */
		case 35:	/* vql_attributes() */
		case 36:	/* vqm_attributes() */
		case 37:	/* vqf_attributes() */
		case 102:	/* vq_extnd() */
		case 103:	/* v_contourfill() */
		case 104:	/* vsf_perimeter() */
		case 106:	/* vst_effects() */
		case 108:	/* vsl_ends() */
		case 111:	/* vsc_form() */
		case 112:	/* vsf_udpat() */
		case 113:	/* vsl_udsty() */
		case 114:	/* vr_recfl() */
		case 122:	/* v_show_c() */
		case 123:	/* v_hide_c() */
		case 129:	/* vs_clip() */

				pack();
				break;

	/* The following functions execute on transputer and atari */

		case 12:	/* vst_height() */
		case 13:	/* vst_rotation() */
		case 39:	/* Set graphics text alignment */
		case 107:	/* vst_point() */

				pack();
				return(0);
				break;

	/* The following functions almost execute on the atari */

		case 28:	/* Input locator */
				callvdi(p);
				A_PTSOUT[0] = oldx;
				A_PTSOUT[1] = oldy;
				break;

	/* The following functions execute on the atari only */

		case 119:	/* load fonts */
callvdi(p);
printf("la_init.li_a1[2]->font_next = %lx\n",la_init.li_a1[2]->font_next);
break;
		case 120:	/* unload fonts */

		case 116:	/* Inquire text extent */
		case 117:	/* Inquire character cell width */
		case 130:	/* Inquire face name and index */
		case 131:	/* Inquire current face information */
		case 31:	/* Input string */
		case 38:	/* Inquire current graphic text attributes */
		case 33:	/* Set input mode */
		case 115:	/* Inquire input mode */
		case 118:	/* Exchange timer interrupt vector */
		case 124:	/* Sample mouse button state */
		case 125:	/* Exchange button change vector */
		case 126:	/* Exchange mouse movement vector */
		case 127:	/* Exchange cursor change vector */
		case 128:	/* Sample keyboard state information */

				return(0);
				break;

	/* the following functions execute on either the transputer or */
	/* the atari */

		case 109:	/* copy raster, opaque */
		case 110:	/* transform form */
		case 121:	/* Copy raster, transparent */
				{
				MFDB	*src,*dest;

				src  = (MFDB *)(*(WORD *)(A_CONTRL + 7));
				dest = (MFDB *)(*(WORD *)(A_CONTRL + 9));

				if (A_CONTRL[0] != 110 &&
					src->addr && dest->addr ) {
					/* mem - mem copy */
					return(0);
				} else {
					sending++;
					pack();
					send_MFDB(src,SEND_MEM);
					send_MFDB(dest,NOT_SEND_MEM);
					--sending;
				}
				break;
				}

	/* the following functions execute on neither machine */


	/* the following functions should never be called */

		default:	printf("BAD OPCODE %d\n",A_CONTRL[0]);
				return(0);
				break;
	}

	return(1);

} /* atari() */

#if SCREEN_MODE == 0

#define SCREEN_WIDTH	1279
#define SCREEN_HEIGHT	959
#define SCREEN_DEPTH	4

#else
#if SCREEN_MODE == 1

#define SCREEN_WIDTH	1020
#define SCREEN_HEIGHT	765
#define SCREEN_DEPTH	8

#else
#if SCREEN_MODE == 2

#define SCREEN_WIDTH	639
#define SCREEN_HEIGHT	479
#define SCREEN_DEPTH	8

#else

Please specify the screen mode

#endif
#endif
#endif

SHORT	*mouse_clip_x = (SHORT *)0x26e6;
SHORT	*mouse_clip_y = (SHORT *)0x26e8;

void init_mouse()
{
	MOUSE		mouse;
	struct kbdvbase *base;

	/* get old mouse vector */

	base = Kbdvbase();

	old_vec = base->kb_mousevec;

	/* now install new routine */

	mouse.topmode = 0;
	mouse.buttons = 0x2;
	mouse.xscale  = MOUSE_SCALE;
	mouse.yscale  = MOUSE_SCALE;
	mouse.xmax    = SCREEN_WIDTH;
	mouse.ymax    = SCREEN_HEIGHT;
	mouse.xstart  = MOUSE_X;
	mouse.ystart  = MOUSE_Y;

	Initmous(1,(BYTE *)&mouse,(WORD)catch);

	*mouse_clip_x = SCREEN_WIDTH;
	*mouse_clip_y = SCREEN_HEIGHT;

} /* init_mouse() */

void close_mouse()
{
	MOUSE	mouse;

	/* restore old routine as best we can */

	mouse.topmode = 0;
	mouse.buttons = 0x2;
	mouse.xscale  = 10;
	mouse.yscale  = 10;
	mouse.xmax    = 639;
	mouse.ymax    = 399;
	mouse.xstart  = oldx;
	mouse.ystart  = oldy;

	Initmous(1,(BYTE *)&mouse,(WORD)old_vec);

} /* close_mouse() */

void copy_font(from,number)
FONT	*from;
SHORT	number;
/* copy fonts */
{
	register SHORT	i,j;
	register UBYTE	*array,*ptr;
	void		sendm();

	array = block;

	*array++ = number;

	/* NB only low byte of these words is being taken ... */

	*array++ = from->font_low_ade;
	*array++ = from->font_hi_ade;
	*array++ = from->font_top_dst;
	*array++ = from->font_ascent_dst;
	*array++ = from->font_half_dst;
	*array++ = from->font_descent_dst;
	*array++ = from->font_bottom_dist;
	*array++ = from->font_fatest;
	*array++ = from->font_thickening;
	*array++ = from->font_underline;
	*array++ = (from->font_lightening) >> 8;
	*array++ = from->font_lightening;
	*array++ = (from->font_width) >> 8;
	*array++ = from->font_width;
	*array++ = from->font_height;

	/* now get char offset table.  This has font_high_ade - font_low_ade */
	/* + 1 word entries but we only take the low byte of each entry */

	ptr = (UBYTE *)(from->font_char_off);

	for(i = 0; i <= from->font_hi_ade - from->font_low_ade; i++) {

		*array++ = *ptr++;
		*array++ = *ptr++;
	}

	/* now get the font data itself.  This consists of font_height rows */
	/* of font_width bytes */

	ptr = (UBYTE *) from->font_data;

	for(j = 0; j < from->font_height; j++) {

		for(i = 0; i < from->font_width; i++) {

			*array++ = *ptr++;
		}
	}

	/* now send this information */

	sending++;
	sendm(array - block,block,ATARI_MESS);

	/* Wait until xptr ready */
	poll_for_msgs();
	--sending;

} /* copy_font() */

void get_fonts()
/* get the screen fonts */
{
	void copy_font();

	linea0();

	copy_font(la_init.li_a1[0],0);

	copy_font(la_init.li_a1[1],1);
	
	copy_font(la_init.li_a1[2],2);

} /* get_fonts() */

#define CLIP(val,max)\
((val) = (((val) < 0) ? (0) : (((val) > (max)) ? (max) : (val))))

UBYTE mbuffer[5];

void handler(x,y)
register SHORT	x,y;
{
	void	sendm();

	if (!x && !y) return;

	oldx += x;
	oldy += y;

	CLIP(oldx,SCREEN_WIDTH);
	CLIP(oldy,SCREEN_HEIGHT);

	if (sending) return;

	/* send x,y to transputer */

	mbuffer[0] = MOUSE_COORDS;
	mbuffer[1] = oldx >> 8;
	mbuffer[2] = oldx;
	mbuffer[3] = oldy >> 8;
	mbuffer[4] = oldy;

	sendm(5,mbuffer,ATARI_MESS);

} /* handler() */

static MFDB	*dest;

void send_MFDB(from, send)
MFDB	*from;	/* source MFDB */
SHORT	send;	/* true if memory image can be sent */
/* send an MFDB and associated memory to the transputer */
{
	SHORT	width;
	UWORD	x, size;
	UBYTE	*array, *ptr;
	void	sendm();

	array = block;

	/* point to source MFDB block */

	dest = from;

	ptr = (UBYTE *)from;

	/* NB byte swapping not done here */

	for(x = sizeof(MFDB); x ; --x) {

		*array++ = *ptr++;
	}

	/* now send memory block if necessary */

	width = from->width / 8 + 1;

	if (send == SEND_MEM && from->addr && A_CONTRL[0] != 109) {

		*array++ = SEND_MEM;

		if (A_CONTRL[0] == 110) {

			size = from->word_width * from->height *
				SCREEN_DEPTH * sizeof(short);
		} else {

			size = width * from->height * from->planes;
		}

		ptr  = (UBYTE *)from->addr;
	
		for(x = size ; x ; --x) {

			*array++ = *ptr++;
		}

	} else {

		*array++ = NOT_SEND_MEM;
	}

	sending++;
	sendm(array - block,block,ATARI_MESS);

	/* wait for replies */

	poll_for_msgs();
	--sending;

} /* send_MFDB() */

void accept_mem(array,length)
UBYTE	*array;
SHORT	length;
/* accept a memory image back from the transputer  */
/* the image is stored in the area pointed to by   */
/* the address field of the MFDB pointed to by the */
/* global variable 'dest'.  This should point to   */
/* the last MFDB sent to the transputer, and hence */
/* the destination MFDB of the vr_trnfm operation  */
/* note this operation does not stop the poll_for_ */
/* msgs loop - it will continue after this fn is   */
/* finished.					   */
{
	UBYTE	*ptr;
	SHORT	x;

	/* set destination's flag to standard form*/

	dest->flag = STANDARD;

	/* copy data */

	ptr = (UBYTE *)dest->addr;

	for (x = length; x; --x) {

		*ptr++ = *array++;
	}

} /* accept_mem() */
