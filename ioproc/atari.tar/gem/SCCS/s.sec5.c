h10402
s 00740/00000/00000
d D 2.1 88/10/26 18:43:57 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/************************************************************************/
/*									*/
/*				SEC5.C					*/
/*									*/
/************************************************************************/

/************************************************************************/
/*									*/
/* Contains all the "set" routines for modes, indices and styles 	*/
/* which are in the GEM VDI manual Section 5 and needed by the		*/
/* screen driver.							*/
/* PJW									*/
/*									*/
/************************************************************************/

#include "header.h"

/*  FUNCTIONS IN THIS MODULE:						*/
/*									*/
/*  FUNCTION	DESCRIPTION		NAME		MANUAL SECTION	*/
/*	 12:	Set character height					*/
/*		absolute mode	 	vst_height		5	*/
/*	 13:	Set Character baseline					*/
/*		vector			vst_rotation		5	*/
/*	 14:	Set color						*/
/*		representation	 	vs_color		5	*/
/*	 15:	Set polyline linetype 	vsl_type		5	*/
/*	 16:	Set polyline width 	vsl_width		5	*/
/*	 17:	Set polyline color					*/
/*		index		 	vsl_color		5	*/
/*	 18:	Set polymarker type 	vsm_type		5	*/
/*	 19:	Set polymarker height	vsm_height		5	*/
/*	 20:	Set polymarker color					*/
/*		index		 	vsm_color		5	*/
/*	 21:	Set text face 		vst_font		5	*/
/*	 22:	set text color index 	vst_color		5	*/
/*	 23:	Set fill interior style	vsf_interior		5	*/
/*	 24:	Set fill style index 	vsf_style		5	*/
/*	 25:	Set fill color index 	vsf_color		5	*/
/*	 32:	Set writing mode 	vswr_mode		5	*/
/*	 39:	Set graphics text					*/
/*		alignment	 	vst_alignment		5	*/
/*	 104:	Set fill perimeter					*/
/*		visibility	 	vsf_perimeter		5	*/
/*	 106:	Set graphic text					*/
/*		special effects 	vst_effects		5	*/
/*	 107:	Set character cell					*/
/*		height, points mode 	vst_point		5	*/
/*	 108:	Set polyline						*/
/*		end styles	 	vsl_ends		5	*/
/*	 112:	Set user-defined					*/
/*		fill pattern	 	vsf_udpat		5	*/
/*	 113:	Set user-defined					*/
/*		linestyle pattern 	vsl_udsty		5	*/
/*									*/

void vst_height()
/* Function 12:  Set character height absolute mode */
{
	WORD height;

	/* Get requested height */
	height = PTSIN[1];	

	/* Any height restrictions should be imposed here */

	if (height < MIN_TEXT_HEIGHT) height = MIN_TEXT_HEIGHT;
	else if (height > MAX_TEXT_HEIGHT) height = MAX_TEXT_HEIGHT;

	/* Update the height in pixels */
	/* height = points_to_pixels(height); */

	WS_INFO->TEXT_CHAR_HEIGHT = height;
	if (height == 12) {
		WS_INFO->TEXT_CHAR_HEIGHT = 13;
	}
	if (height == 26) {
		WS_INFO->TEXT_CHAR_HEIGHT = 27;
	}

	WS_INFO->TEXT_CHAR_WIDTH  = height + 1;
	if (height > 9) {
		WS_INFO->TEXT_CHAR_WIDTH += 1;
	}
	if (height > 12) {
		WS_INFO->TEXT_CHAR_WIDTH = (height + 2) / 2;
	}

	WS_INFO->TEXT_CELL_HEIGHT = height + 2;
	if (height > 9) {
		WS_INFO->TEXT_CELL_HEIGHT += 1;
	}
	if (height == 12) {
		WS_INFO->TEXT_CELL_HEIGHT = 16;
	}
	if (height > 16) {
		WS_INFO->TEXT_CELL_HEIGHT += 1;
	}
	if (height > 22) {
		WS_INFO->TEXT_CELL_HEIGHT += 1;
	}
	if (height == 26) {
		WS_INFO->TEXT_CELL_HEIGHT = 32;
	}

	WS_INFO->TEXT_CELL_WIDTH  = height + 2;
	if (height > 7) {
		WS_INFO->TEXT_CELL_WIDTH += 1;
	}
	if (height > 10) {
		WS_INFO->TEXT_CELL_WIDTH += 1;
	}
	if (height > 12) {
		WS_INFO->TEXT_CELL_WIDTH = (height + 4) / 2;
	}
	if (height > 18) {
		WS_INFO->TEXT_CELL_WIDTH = 12;
	}
	if (height > 20) {
		WS_INFO->TEXT_CELL_WIDTH = (height +6) / 2;
	}
	/* choose a system font appropriate to the character height */
	if (height < 6) {
		WS_INFO->TEXT_FACE = 0;
	} else if (height < 10) {
		WS_INFO->TEXT_FACE = 1;
	} else {
		WS_INFO->TEXT_FACE = 2;
	}

	/* Return values */
	CONTRL[2] = 2;
	CONTRL[4] = 0;
	PTSOUT[0] = WS_INFO->TEXT_CHAR_WIDTH;
	PTSOUT[1] = WS_INFO->TEXT_CHAR_HEIGHT;
	PTSOUT[2] = WS_INFO->TEXT_CELL_WIDTH;
	PTSOUT[3] = WS_INFO->TEXT_CELL_HEIGHT;

} /* vst_height() */

void vst_rotation()
/* Function 13: Set character baseline vector */
/* Only 90 degree rotations supported */
{
	WORD angle;

	angle = INTIN[0];

	/* force angle to an appropriate value */

	if 	(angle <= 450 || angle > 3150 ) angle = 0;
	else if (angle > 450  && angle <= 1350) angle = 900;
	else if (angle > 1350 && angle <= 2250) angle = 1800;
	else                                    angle = 2700;

	WS_INFO->TEXT_ANGLE = angle;

	/* return values */
	CONTRL[2] = 0;
	CONTRL[4] = 1;

	INTOUT[0] = angle;

} /* vst_rotation() */

void vs_color()
/* Function 14:  Set color representation */
/* Binary monochrome not supported */
{
	WORD index;
	WORD red, green, blue;
	void set_clu(WORD,WORD,WORD,WORD);

	CONTRL[2] = 0;
	CONTRL[4] = 0;

	/* Does this implementation have a color table? */
	if (!CLU_PRESENT) return;

	index = INTIN[0];	/* Index of color to be changed */

	/* Check that the color index is in range */
	
	if (index < 0) return;
	if (index == SCREEN.MAGIC) return;

	if (SCREEN.MODE != 0 && index > 255) return;

	if (SCREEN.MODE == 0 && index > 15)  return;

	/* Get the color components */
	red   = INTIN[1];
	green = INTIN[2];
	blue  = INTIN[3]; 

	/* Clamp to within range */

	if (red   < 0) red   = 0;
	if (green < 0) green = 0;
	if (blue  < 0) blue  = 0;

	if (SCREEN.MODE != 0) {

		if (red   > 255) red   = 255;
		if (green > 255) green = 255;
		if (blue  > 255) blue  = 255;

	} else {

		if (red   > 15) red   = 15;
		if (green > 15) green = 15;
		if (blue  > 15) blue  = 15;

	}

	/* Load the color to the table */

	set_clu(index,red,green,blue);

	/* Load its inverse as well */
	if (SCREEN.MODE != 0) {

		set_clu(255 - index, 255 - red, 255 - green, 255 - blue);

	} else {

		set_clu(15 - index, 15 - red, 15 - green, 15 - blue);
	}

} /* vs_color() */

void vsl_type()
/* Function 15:  Set polyline linetype */
{
	if (INTIN[0] >= 1 && INTIN[0] <= MAX_LINE_TYPES)
		WS_INFO->LINE_TYPE = INTIN[0];
	else
		/* solid if out of range */
		WS_INFO->LINE_TYPE = 1;

	WS_INFO->LINE_MASK = LINE_PATTERNS[WS_INFO->LINE_TYPE];

	/* Return values */
	CONTRL[2] = 0;			/* Number of output vertices */
	CONTRL[4] = 1;			/* Length of INTOUT */

	INTOUT[0] = WS_INFO->LINE_TYPE;

} /* vsl_type() */

void vsl_width()
/* Function 16:  Set polyline width */
{
	WORD index;

	index= PTSIN[0];

	/* Test that index is odd */
	if (index > 1)
		if (index & 1)
			WS_INFO->LINE_WIDTH = index;
		else
			WS_INFO->LINE_WIDTH = index - 1;
	else
		/* set to 1 if an invalid size is chosen */
		WS_INFO->LINE_WIDTH = 1;

	/* Return values */
	CONTRL[2] = 1;			/* Number of output vertices */
	CONTRL[4] = 0;			/* Length of INTOUT */
	PTSOUT[0] = WS_INFO->LINE_WIDTH;		/* Width selected */
	PTSOUT[1] = 0;

} /* vsl_width() */

void vsl_color()
/* Function 17:  Set polyline color index */
{
	WORD index;

	index = INTIN[0];

	if (SCREEN.MODE != 0) {

		index &= 0xff;

	} else {

		index &= 0xf;
	}

	if (index == SCREEN.MAGIC)	++index;

	WS_INFO->LINE_COLOR_INDEX = index;	/* Set new line colour */

	/* Return values */
	CONTRL[2] = 0;			/* Number of output vertices */
	CONTRL[4] = 1;			/* Length of INTOUT */
	INTOUT[0] = index;		/* Index selected */

} /* vsl_color() */

void vsm_type()
/* Function 18:  Set polymarker type */
{
	WORD mtype;
	void marker_size(WORD,WORD *,WORD *);

	mtype = INTIN[0];

	/* If out of range, marker type defaults to 3 */
	if (mtype < 1) mtype = 3;
	else if (mtype > MAX_MARKER_TYPES) mtype = 3;

	/* Set the type */
	WS_INFO->MARKER_TYPE = mtype;

	/* Now make the necessary side-effects */
	marker_size(mtype-1,&WS_INFO->MARKER_WIDTH,&WS_INFO->MARKER_HEIGHT);

	/* Return values */
	CONTRL[2] = 0;			/* Number of output vertices */
	CONTRL[4] = 1;			/* Length of INTOUT */
	INTOUT[0] = mtype;

} /* vsm_type() */

void vsm_height()
/* Function 19:  Set polymarker height */
/* Each marker has its own defining box width and height */
/* These values are given at the beginning of the list of values */
/* describing each marker type in Mark_Info */
/* Given a user defined height this function calculates the scale */
/* factor so that this height is obtained. */
/* NOTE this may or may not be what is required by GEM - manual is not */
/* clear. That is does GEM only allow integer scaling?? */
{
	UWORD	tmpscale;
	UWORD	height;
	UWORD		mtype;

	/* Note for efficiency the scale could be stored in the WS_INFO */
	/* structure; it is recalculated in the plot_marker routine */

	mtype = WS_INFO->MARKER_TYPE - 1;

	height = PTSIN[1];

	if (height < MIN_MARKER_HEIGHT) height = MIN_MARKER_HEIGHT;
	else if (height > MAX_MARKER_HEIGHT) height = MAX_MARKER_HEIGHT;
	
	/* Save the required height for future marker type changes */
	WS_INFO->MARKER_SET_HEIGHT = height;

	tmpscale = (height << N_FRACT_BITS) / MARK_INFO[mtype][0];
	WS_INFO->MARKER_HEIGHT= (tmpscale*MARK_INFO[mtype][0]) >> N_FRACT_BITS;
	WS_INFO->MARKER_WIDTH = (tmpscale*MARK_INFO[mtype][1]) >> N_FRACT_BITS;

	/* Return Values */
	CONTRL[2] = 1;
	CONTRL[4] = 0;
	PTSOUT[0] = WS_INFO->MARKER_WIDTH;
	PTSOUT[1] = WS_INFO->MARKER_HEIGHT;

} /* vsm_height */

void vsm_color()
/* Function 20:  Set polymarker color index */
{
	WORD index;

	index = INTIN[0];

	if (SCREEN.MODE != 0) {

		index &= 0xff;

	} else {

		index &= 0xf;
	}

	if (index == SCREEN.MAGIC) ++index;

	WS_INFO->MARKER_COLOR_INDEX = index;

	/* Return values */
	CONTRL[2] = 0;			/* Number of output vertices */
	CONTRL[4] = 1;			/* Length of INTOUT */
	INTOUT[0] = index;

} /* vsm_color() */

void vst_font()
/* Function 21:  Set text face */
{
	WORD fontnum;

	fontnum = INTIN[0];

	/* If out of range, face type defaults to 1 */
	/* NOTE: Atari documentation does not define this default */
	if (fontnum < 0)      fontnum = 1;
	else if (fontnum > 2) fontnum = 1;

	/* UNFINISHED */
	/* this is not correct as TEXT_FACE is used as an internal switch */
	WS_INFO->TEXT_FACE = fontnum;

	/* Return values */
	CONTRL[2] = 0;			/* Number of output vertices */
	CONTRL[4] = 1;			/* Length of INTOUT */
	INTOUT[0] = fontnum;

} /* vst_font() */

void vst_color()
/* Function 22:  Set graphic text color index */
{
	WORD index;

	index = INTIN[0];

	if (SCREEN.MODE != 0) {

		index &= 0xff;

	} else {

		index &= 0xf;
	}

	if (index == SCREEN.MAGIC) ++index;

	WS_INFO->TEXT_COLOR_INDEX = index;

	/* Return values */
	CONTRL[2] = 0;			/* Number of output vertices */
	CONTRL[4] = 1;			/* Length of INTOUT */
	INTOUT[0] = index;

} /* vst_color() */

void vsf_interior()
/* Function 23:  Set fill interior style */
{
	WS_INFO->FILL_INTERIOR_STYLE = HOLLOW;

	if (INTIN[0] >= 1 && INTIN[0] < MAX_FILL_INTERIOR_STYLES)
		WS_INFO->FILL_INTERIOR_STYLE = INTIN[0];
	
	/* Return values */
	CONTRL[2] = 0;			/* Number of output vertices */
	CONTRL[4] = 1;			/* Length of INTOUT */
	INTOUT[0] = WS_INFO->FILL_INTERIOR_STYLE;

	if (INTIN[0] == USER_DEFINED_STYLE) {
		if (WS_INFO->FILL_USER_PATTERN != (WORD *)NULL) {
			WS_INFO->FILL_INTERIOR_STYLE = PATTERN;
			WS_INFO->FILL_MASK = WS_INFO->FILL_USER_PATTERN;
		} else {
			INTOUT[0] = WS_INFO->FILL_INTERIOR_STYLE = HOLLOW;
		}
	}

 } /* vsf_interior() */

void vsf_style()
/* Function 24:  Set fill style index */
{
	CONTRL[2] = 0;
	CONTRL[4] = 1;

	INTOUT[0] = 0;

	if (	WS_INFO->FILL_INTERIOR_STYLE == HOLLOW ||
		WS_INFO->FILL_INTERIOR_STYLE == SOLID ) {
			WS_INFO->FILL_MASK = OPEN_MASK;
		return;
	}

	if (WS_INFO->FILL_MASK == WS_INFO->FILL_USER_PATTERN) {
		return;
	}

	switch ( WS_INFO->FILL_INTERIOR_STYLE) {
	case PATTERN:
		if (INTIN[0] >= 1 && INTIN[0] <= N_DOTTED_PATTERNS) {
			INTOUT[0] = INTIN[0];
			WS_INFO->FILL_MASK = FILL_PATTERN[ INTIN[0] ];
		} else {
			INTOUT[0] = 1;
			WS_INFO->FILL_MASK = FILL_PATTERN[1];
		}
		break;

	case HATCH:
		if (INTIN[0] >= 1 && INTIN[0] <= N_CROSS_PATTERNS) {
			INTOUT[0] = INTIN[0];
			WS_INFO->FILL_MASK = CROSS_PATTERN[ INTIN[0] ];
		} else {
			INTOUT[0] = 1;
			WS_INFO->FILL_MASK = CROSS_PATTERN[1];
		}
		break;
	}

	WS_INFO->FILL_STYLE_INDEX = INTOUT[0];

} /* vsf_style() */

void vsf_color()
/* Function 25:  Set fill color index */
{
	WORD index;

	index = INTIN[0];

	if (SCREEN.MODE != 0) {

		index &= 0xff;

	} else {

		index &= 0xf;
	}

	if (index == SCREEN.MAGIC) ++index;

	WS_INFO->FILL_COLOR_INDEX = index;

	/* Return values */
	CONTRL[2] = 0;			/* Number of output vertices */
	CONTRL[4] = 1;			/* Length of INTOUT */
	INTOUT[0] = index;

} /* vsf_index() */

void vswr_mode()
/* Function 32:  Set writing mode */
{
	WORD mode;

	mode = INTIN[0];

	/* Trap out of range modes */
	if      (mode < 1) mode = 1;
	else if (mode > 4) mode = 1;

	/* Return values */
	WS_INFO->WRITE_MODE= mode;
	CONTRL[2] = 0;		/* Number of output vertices */
	CONTRL[4] = 1;		/* Length of INTOUT */

	INTOUT[0] = mode;

} /* vswr_mode() */

void vst_alignment()
/* Function 39:  Set graphics text alignment */
{
	WORD align;

	/* First determine the horizontal alignment */
	align = INTIN[0];

	/* Trap invalid alignment */
	if      (align < 0) align = 0;		/* default is left = 0 */
	else if (align > 2) align = 0;

	WS_INFO->TEXT_ALIGN[0] = align;
	INTOUT[0] = align;

	/* Now determine the vertical alignment */
	align = INTIN[1];

	/* Trap invalid alignment */
	if (align < 0) align = 0;
	else if (align > 5) align = 0;	/* default is baseline = 0 */

	WS_INFO->TEXT_ALIGN[1] = align;
	INTOUT[1] = align;

	/* Other return values */
	CONTRL[2] = 0;		/* Number of output vertices */
	CONTRL[4] = 2;		/* Length of INTOUT */

} /* vst_alignment() */

void vsf_perimeter()
/* Function 104: Set fill perimeter visibility */
{
	WORD visibility;

	visibility = INTIN[0];

	/* Return values */
	WS_INFO->FILL_OUTLINED = visibility;
	CONTRL[2] = 0;		/* Number of output vertices */
	CONTRL[4] = 1;		/* Length of INTOUT */
	INTOUT[0] = visibility;

} /* vsf_perimeter() */

void vst_effects()
/* Function 106:  Set graphic text special effects */
{
	WORD effect;

	effect = INTIN[0] & 0x3F;	/* Lowest 6 bits */

	/* Return values */
	WS_INFO->TEXT_EFFECT = effect;
	CONTRL[2] = 0;		/* Number of output vertices */
	CONTRL[4] = 1;		/* Length of INTOUT */

	INTOUT[0] = effect;

} /* vst_effects() */

void vst_point()
/* Function 107:  Set character cell height, points mode */
{
	/* FINE TUNE */
	/* Leaves the scale factor alone i.e. at 1 */	
	
	/* Return values */
	CONTRL[2] = 2;
	CONTRL[4] = 1;

	/* Character cell height in points */
	INTOUT[0] = (SCREEN.PIX_SIZE * WS_INFO->TEXT_CELL_HEIGHT 
		>> N_FRACT_BITS) / POINTS_PER_INCH;

	/* These are all in pixels (RC) */
	PTSOUT[0] = WS_INFO->TEXT_CHAR_WIDTH;	/* Character width */
	PTSOUT[1] = WS_INFO->TEXT_CHAR_HEIGHT;	/* Character height from baseline */
	PTSOUT[2] = WS_INFO->TEXT_CELL_WIDTH;	/* Character cell width */
	PTSOUT[3] = WS_INFO->TEXT_CELL_HEIGHT;	/* Character cell height */

} /* vst_point() */

void vsl_ends()
/* Function 108:  Set polyline end styles */
{
	WORD style;

	/* First end */
	style = INTIN[0];

	/* Trap invalid styles */
	if (style < SQUARED || style > ROUNDED) style = SQUARED;

	WS_INFO->LINE_END_STYLE[0] = style;

	/* Second end */
	style =	INTIN[1];

	/* Trap invalid styles */
	if (style < SQUARED || style > ROUNDED) style = SQUARED;
 
	WS_INFO->LINE_END_STYLE[1] = style;

	/* Return values */
	CONTRL[2] = 0;		/* Number of output vertices */
	CONTRL[4] = 0;		/* Length of INTOUT */

} /* vsl_ends() */

WORD bit_swap(WORD shrt)
/* rotate a 16 bit word */
{
	WORD i,res = 0;

	for(i = 0; i < 16; i++) {
		res <<= 1;
		res |=  shrt & 1;
		shrt >>= 1;
	}

	return(res);
}

void vsf_udpat()
/* Function 112:  Set user-defined fill pattern */
{
	WORD		*ptr,y;
	extern WORD	old_s_ptr;
	WORD		bit_swap(WORD);

	ptr = WS_INFO->FILL_USER_PATTERN;

	for (y = 0; y < 16 ; y++) {
		*ptr        =  bit_swap(INTIN[y]);
		*ptr        |= (*ptr << 16);
		*(ptr + 16) =  *ptr;
		*ptr++;
	}

	/* ensure pattblat updates its pattern copy */
	old_s_ptr = ~old_s_ptr;

	/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* vsf_udpat() */

void vsl_udsty()
/* Function 113:  Set user-defined linestyle pattern */
{
	WS_INFO->LINE_USER_PATTERN = INTIN[0];	/* Set new pattern */
	LINE_PATTERNS[7] = INTIN[0];		/* Save new pattern */

	/* If user defined patterns selected then set the line mask */

	if (WS_INFO->LINE_TYPE == 7) {
		WS_INFO->LINE_MASK = INTIN[0];
	}

	/* Return values */
	CONTRL[2] = 0;		/* Number of output vertices */
	CONTRL[4] = 0;		/* Length of INTOUT */

} /* vsl_udsty() */

void marker_size(mtype,width,height)
/* For the given marker returns the default width and height */
WORD	mtype;
UWORD	*width,*height;
{
	UWORD tmpscale;

	tmpscale = WS_INFO->MARKER_SET_HEIGHT << N_FRACT_BITS;
	tmpscale /= MARK_INFO[mtype][0];

	*width = (tmpscale * MARK_INFO[mtype][0]) >> N_FRACT_BITS;
	*height = (tmpscale * MARK_INFO[mtype][1]) >> N_FRACT_BITS;

} /* marker_size() */
E 1
