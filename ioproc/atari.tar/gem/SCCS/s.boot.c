h25286
s 00348/00000/00000
d D 2.1 88/10/26 18:42:40 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/*------------------------------------------------------------------------
--                                                                      --
--          H E L I O S   I N P U T / O U T P U T   S E R V E R	        --
--          ---------------------------------------------------      	--
--                                                                      --
--             Copyright (C) 1987, Perihelion Software Ltd.             --
--                        All Rights Reserved.                          --
--                                                                      --
--      tload.c	                                                        --
--                                                                      --
--              This module is responsible for bootstrapping the	--
--									--
--		root transputer on start-up, and interacting with the	--
--									--
--		transputer network.					--
--									--
--	Author:  BLV 8/10/87						--
--                                                                      --
------------------------------------------------------------------------*/
/* SccsId: %I% %G%	 Copyright (C) 1987, Perihelion Software Ltd.	*/


#include <stdio.h>
#include <setjmp.h>
#include <sthelios.h>
#include <debug.h>

#define ne !=
#define eq ==

PRIVATE WORD bootsize;
PRIVATE char *bootstrap;
extern char *lmalloc();

/**
*** The bits below are pretty horrible. The code for booting up the transputer
*** used to be a separate program tload, but it is necessary for the server
*** and the debugger to be able to do this themselves. Hence the code from
*** tload.c was inserted here and fiddled about to make it work. Things become
*** very nasty because the Server and the debugger have rather different
*** requirements.
***
*** The following declarations are all rather boring.
**/

#define MAXREAD  0xffffL
#define MAXCHUNK 0x1000L

UBYTE *ibuf = NULL;
WORD  isize;

FILE  *infd;

WORD xpwrbyte(), xpwrrdy(), xprdrdy(), xpwrword(), xpwrint(), xpwrdata();
WORD xprddata(), dbwrword(), xprdint(), xprdword(), xprdbyte(), dbrdword();
WORD dbrdint();
void resetlnk();

PRIVATE void timeout(), send_boot(), send_conf();
int loadboot();
int loadimage();

word swap(a)
word a;
{ word b = 0;
  int i;

  if (a eq 0L) return(0L);

  for (i=0; i<4; i++)
    { b <<= 8; b |= (a & 0xFF); a >>= 8; }

  return(b);
}

/**
*** When the Server or the debugger wants to boot the transputer it calls
*** this routine in either mode debugboot or serverboot. The routine loads
*** the bootstrap code and the system image, and sends them off to the
*** transputer. Then the space take up by the bootstrap code is freed, and
*** if the system is in Server mode the space taken up by the system image
*** is freed as well because this lets me have a couple more coroutines before
*** running out of memory, and that is rather important on a 640K PC.
**/


static jmp_buf failure_buf;

void boot_transputer(system_image)
char *system_image;
{ if (setjmp(failure_buf) ne 0) goto failed;

  infd = (FILE *)NULL;
  if (!loadimage(system_image)) goto failed;

  send_boot();

  return;

failed:                      /* to bootstrap the transputer for some reason */
   exit(1);
}

/**
*** The following bits of code deal with loading items off disk. The file name
*** corresponding to the system image is known because the system cannot
*** start up without it - either it is in the configuration file or it is on
*** the command line. Also, the system image may be loaded already if in
*** debugging mode so I check for that. The system image is loaded in chunks
*** because some systems object to loading vast quantities of data in one go.
***
*** loadboot() is called once only, from main() in module server.c . A bootfile
*** may be specified in the configuration file, with the default being nboot.i
*** The space for the bootstrap code is freed at the end of main().
**/
 
int loadimage(system_image)
char *system_image;
{ WORD l,csize;
  UBYTE *cbuf;

  if (ibuf ne NULL) return(1);               /* already loaded ? */

  infd = fopen(system_image,"rb");
  if( infd eq (FILE *) NULL ) 
    infd = fopen("a:\\trans", "rb");

  if( infd eq (FILE *) NULL ) 
   { printf("Cannot open '%s' for input.\n",system_image); return(0); }

  if( fread(&isize,1,4,infd) ne 4)
   { printf("Cannot read image header.\n"); goto done; }

  isize = swap(isize);                   /* extract size of system image */

  ibuf = (UBYTE *) lmalloc(isize);       /* get image buffer */
  if (ibuf eq NULL )
   { printf("Cannot get image buffer.\n"); goto done; }

  csize = isize - 4;                     /* how many bytes left to read */
  cbuf  = (UBYTE *)(ibuf  + 4);          /* and where to put them */

  while (csize > 0)
   { WORD len = csize;
     if (len > MAXCHUNK) len = MAXCHUNK;
     if( (l = fread(cbuf,1,(int)len,infd)) ne len )      /* read in some more */
      { printf("Image too small, (read %ld).\n",l); goto done; }
     csize -= len;
     cbuf  = cbuf + len;
   }

  ((WORD *)ibuf)[0] = swap(isize);          /* place size back in image */

  fclose( infd );                           /* finished successfully */
  infd = (FILE *) NULL;
  return(1);

done:
  fclose( infd );
  infd = (FILE *) NULL;
  return(0);	/* return error */
}


int loadboot()
{ int s;
  WORD ihdr[3];
  char *name = "c:\\nboot.i";

  infd = fopen(name,"rb");
  if( infd eq (FILE *) NULL ) 
    infd = fopen("a:\\nboot.i");

  if( infd eq (FILE *) NULL ) 
   { printf("Cannot open '%s' for input.\n",name); return(0); }

  if( (s=fread(ihdr,1,12,infd)) ne 12)
   { printf("Cannot read boot header %d %d.\n",s,ferror(infd)); goto done; }

  if( swap(ihdr[0]) ne 0x12345678L )
   { printf("First word of file not magic number.\n"); goto done; }

  bootsize = swap(ihdr[2]);

  bootstrap = (UBYTE *) malloc((int) bootsize);
  if( bootstrap eq NULL )
   { printf("Cannot get image buffer.\n"); goto done; }

  if( (s=fread(bootstrap,1,(int)bootsize,infd)) ne bootsize)
   { printf("Image too small %d %d.\n",s,ferror(infd)); goto done; }

  fclose( infd );
  infd = (FILE *) NULL;
  return(1);

done:
  fclose( infd );
  infd = (FILE *) NULL; 
  return(0);	/* return failure code */
}

/**
*** Timeout() is called when any of the boot writes to the transputer fails.
*** It longjmps back to boot_transputer() above, which either recovers or
*** exits depending on what the user is doing.
**/

PRIVATE void timeout(when)
char *when;
{ printf("Timed out when sending %s", when);
  longjmp(failure_buf, 1);
}

/**
*** Send_boot() is responsible for sending all the bootstrap code to the
*** transputer. First I attempt to reset all the transputer hardware, which is
*** a very troublesome piece of code. Then I send the size of the bootstrap
*** program, followed by the bootstrap program itself. This program starts to
*** run on the transputer and on Meiko hardware the first thing it does is
*** clear all of the parity memory - Yukk. Then the program does an IN
*** instruction to receive the system image, and I send that. When the system
*** image has been loaded the kernel starts to run and expects some
*** configuration to come down its link, so I send that.
***
*** Next there is some low-level message interaction between the transputer and
*** the host, involving a byte-F0 message, which only NHG understands. In
*** server mode this involves calling server_helios(), and in debugging mode
*** it involves calling debug_helios() in module debug.c .
**/

PRIVATE void send_boot()
{ UBYTE *cbuf;
  WORD osize = isize;
  WORD len;
  PRIVATE void helios();

  resetlnk();
  xpreset();
   
  if (!xpwrbyte(bootsize))              /* bootstrap size */
   timeout("bootstrap size.\n");
  if (!xpwrdata(bootstrap,bootsize))    /* bootstrap */
   timeout("bootstrap code.\n");

  xpwrbyte(4L);

  cbuf = (UBYTE *)ibuf;
  while (osize>0)
   { len = osize;
     if (len > MAXCHUNK) len = MAXCHUNK;
     if (!xpwrdata(cbuf,len))		/* system image */
       timeout("system image.\n");
     osize -= len;
     cbuf  = cbuf + len;
   }

  send_conf();

  helios();
}

/**
*** NOTE : this information should be configurable
**/

PRIVATE void send_conf()
{ if (!xpwrint(24L))                                /* 6 words in conf vector */
   timeout("system configuration size.\n");
  xpwrint(64L);		                                /* size of port table */
  xpwrint(1L);                                          /* incarnation number */
  xpwrint(LoadBase);
  xpwrint(isize);
  xpwrint(1L);                                         /* just 1 link for now */
  if (!xpwrword(swap(0x00000240L)))                    /* link conf structure */
    timeout("system configuration.\n");
}

/**
*** The main job of this routine is to wait for the kernel to start up
*** sufficiently for it to need to know a port on my side of the link. This
*** involves the transputer sending a byte F0, followed by some more junk,
*** and I reply with junk plus a pseudo port for the IOproc device.
**/

PRIVATE void helios()
{	
	WORD iocport = 0;
	printf("Booted...\n");
	for(;;)
	{
		if( xprdrdy() )
		{
			WORD b;
			WORD a;
			b = xprdbyte();
			switch( (int) b )
			{
			case 2:
			{
				WORD h,d,r,f;
				WORD dsize;

				h = xprdint();
				d = xprdint();
				r = xprdint();
				f = xprdint();

				if( (dsize=(h & 0x0000ffffL)) != 0 )
				{	WORD ports[3];
					INT i;
					for (i=0;i<3;i++)
					{ ports[i]=xprdint();
/* printf("Port %ld = %lx ",i,ports[i]); */
/*				ports[i] = 0x8000007aL - i * 2; */
					}

					putchar('\n');
					initmsg(ports);
					return;
				}
				printf("Unexpected message received\n");
				break;
			}

			case 0xf0:
				  xprdbyte();
				  xprdbyte(); 
				  xprdbyte(); 

				  a=xprdint();
				  iocport=xprdint();

				  if ( ( a & 0x00ff0000L ) ne 0L )
				   { xpwrint (0xf0f0f0f0L);
				     xpwrint (0x00000100L);
				     xpwrint (0x8000AAAAL);
				   }
				for (a=0;a<10000;a++);
				break;

			default:
				printf("Unexpected byte %2lx\n",b);
				break;
			}
		}
	}
}

E 1
