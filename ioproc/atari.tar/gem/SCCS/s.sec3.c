h02766
s 00935/00000/00000
d D 2.1 88/10/26 18:43:38 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/************************************************************************/
/*									*/
/*				SEC3.C					*/
/*									*/
/************************************************************************/

/************************************************************************/
/*									*/
/* Contains all the workstation control routines			*/
/* which are in the GEM VDI manual Section 3 and needed by the		*/
/* screen driver.							*/
/* PJW/NC								*/
/*									*/
/************************************************************************/

#include "header.h"

/* FUNCTIONS IN THIS MODULE:						*/
/*									*/
/* FUNCTION	DESCRIPTION		NAME		MANUAL SECTION	*/
/*									*/
/*	 1:	Open workstation 	v_opnwk			3	*/
/*	 2:	Close workstation 	v_clswk			3	*/
/*	 3:	Clear workstation 	v_clrwk			3	*/
/*	 4:	Update workstation 	v_updwk			3	*/
/*	 100:	Open virtual screen					*/
/*		workstation	 	v_opnvwk		3	*/
/*	 101:	Close virtual screen					*/
/*		workstation	 	v_clsvwk		3	*/
/*	 129:	Set clipping rectangle 	vs_clip			3	*/
/*									*/

void v_opnwk()
/* Function 1: Open workstation	*/
{
	void clear_screen(void);
	void initvdi(void);
	WORD setup_ws(void);
	void init_default_line_patterns(void);
	WORD init_default_fill_patterns(void);
	void init_marker_info(void);

/* SHOULD load device driver: INTIN[0] says which one */
/* However, we assume the code is permanently core resident */

/* Initialise Virtual Device Interface package */
	initvdi();

/* Get storage space; initialise and get handle to it */
	if (!setup_ws()) return;	/* Failed */

/* Success: CONTRL[6] now contains the device handle */
/* Graphics mode and other defaults have now been set */

/* initialise the default line patterns */
	init_default_line_patterns();

/* initialise the default fill patterns */

	if (!init_default_fill_patterns()) {
		CONTRL[6] = 0;
		return;
	}

/* initialise marker patterns */
	init_marker_info();

/* Clear the screen */
	clear_screen();

} /* v_opnwk() */

void v_clswk()
/* Function 2: Close workstation */
/* DEVIATION */
/* Atari specification says that closing should prevent */
/* any further output to the device. This does not do that */
/* This removes all allocated memory used by gem */
{
	WORD temp0, temp1, temp3, temp5;
	void v_escape(void);
	void tidy_workstation(void);

/* NB/ memory allocated to FILL_PATTERN[1] only, rest are offsets into this */

	(void) free_memory((BYTE *) FILL_PATTERN[1]);

	(void) free_memory((BYTE *) CROSS_PATTERN[1]);

/* Save part of environment */
	temp0 = CONTRL[0];
	temp1 = CONTRL[1];
	temp3 = CONTRL[3];
	temp5 = CONTRL[5];

/* Go back to alpha mode */
	CONTRL[0] = 5;	/* Function 5= Escape */
	CONTRL[1] = 0;
	CONTRL[3] = 0;
	CONTRL[5] = 3;	/* enter alpha mode */
	v_escape();

/* Replace environment */
	CONTRL[0] = temp0;
	CONTRL[1] = temp1;
	CONTRL[3] = temp3;
	CONTRL[5] = temp5;

/* Do any system dependent tidying */
	tidy_workstation();

/* Mark as free and release the storage */
	WS_INUSE[CONTRL[6]] = 0;

	(void) free_memory((BYTE *) WS_INFO);

	(void) free_memory((BYTE *) tmpscanline);

/* Return control of the mouse to original controller */

/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_clswk() */

void v_clrwk()
/* Function 3: Clear workstation */
{
	void clear_screen(void);

	clear_screen();

	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_clrwk() */

void v_updwk()
/* Function 4: Update workstation */
{
/* Has no effect on screens */
	
/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_updwk() */

void v_opnvwk()
/* Function 100: Open virtual screen workstation */
{
	WORD setup_ws(void);

/* Default return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;

/* Get storage space; initialise and get handle to it */

	(void) setup_ws();

/* return whether successful or not */
/* CONTRL[6] contains handle (or 0 for fail) */

} /* v_opnvwk() */

void v_clsvwk()
/* Function 101: Close virtual screen workstation */
/* DEVIATION */
/* Atari specification says that closing should prevent */
/* any further output to the device. This does not do that */
{
	if (! WS_INUSE[CONTRL[6]]) {
		IOdebug("attempting to free non initialised workstation %d\n",
			CONTRL[6]);

	} else {
		(void) free_memory((BYTE *) WS_INFO->FILL_USER_PATTERN);

		if(free_memory((BYTE *) WS_INFO) ) {
			IOdebug("unable to free virtual workstation memory\n");
			IOdebug("for workstation %d (in use = %d)\n",
				CONTRL[6],WS_INUSE[CONTRL[6]]);
		}
	}

	WS_INUSE[CONTRL[6]] = 0;

/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_clsvwk() */

void vs_clip()
/* Function 129: Set clipping rectangle */
/* Assume do not update clip rectangle when disabling */
{
	WORD clip;
	WORD x1,x2,y1,y2;

	WS_INFO->CLIP_FLAG = clip = INTIN[0];

	if (clip) {
		/* Get the coordinates */

		x1 = MIN(PTSIN[0],PTSIN[2]);
		x2 = MAX(PTSIN[0],PTSIN[2]);
		y1 = MIN(PTSIN[1],PTSIN[3]);
		y2 = MAX(PTSIN[1],PTSIN[3]);

		/* clip to screen boundary */

		if (x1 < SCREEN_XLEFT)  x1 = SCREEN_XLEFT;
		if (x2 > SCREEN_XRIGHT) x2 = SCREEN_XRIGHT;
		if (y1 < SCREEN_YBOT)   y1 = SCREEN_YBOT;
		if (y2 > SCREEN_YTOP)   y2 = SCREEN_YTOP;

		/* and assign */

		WS_INFO->CLIP_XMIN = x1;
		WS_INFO->CLIP_YMIN = y1;
		WS_INFO->CLIP_XMAX = x2;
		WS_INFO->CLIP_YMAX = y2;
	}

	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* vs_clip() */

/************************************************************************/
/*									*/
/*			LOCAL UTILITIES					*/
/*									*/
/************************************************************************/

WORD setup_ws()
/* Initialise all workstation parameters */
{
	HANDLE		*wsptr;
	WORD		save_variable,x;
	WORD	*ptr;
	WORD		get_next_wsnum(void);
	void		v_enter_cur(void);
	void		vsl_type(void);
	void		vsf_style(void);
	void		default_clu(void);
	void		load_ws_values(void);

	/* See if there are any free handles */

	CONTRL[6] = get_next_wsnum();

	if (!CONTRL[6]) return(0);

	/* Try to create storage for the workstation */

	if ((wsptr = (HANDLE *)get_memory((UWORD) sizeof(HANDLE))
		) == (HANDLE *)NULL) {

		CONTRL[6] = 0;	/* failed to get space.. */
		return(0);
	}

	WS_INFO = wsptr;	/* Got a ws: point to its attributes */

	/* Space allocated successfully: initialise it with data provided */
	/* set up the Line Type and Line Mask */

	save_variable = INTIN[0];
	INTIN[0] = INTIN[1];

	vsl_type();

	INTIN[0] = save_variable;

	wsptr->LINE_COLOR_INDEX    = INTIN[2];
	wsptr->MARKER_TYPE         = INTIN[3];
	wsptr->MARKER_COLOR_INDEX  = INTIN[4];
	wsptr->MARKER_SET_HEIGHT   = MIN_MARKER_HEIGHT;
	wsptr->TEXT_FACE           = 2;
	wsptr->TEXT_COLOR_INDEX    = INTIN[6];
	wsptr->FILL_INTERIOR_STYLE = INTIN[7];
	wsptr->FILL_STYLE_INDEX    = INTIN[8];

	save_variable = INTIN[0];
	INTIN[0] = INTIN[8];

	vsf_style();

	INTIN[0] = save_variable;

	wsptr->FILL_COLOR_INDEX = INTIN[9];
	wsptr->NDC_TO_RC_FLAG   = INTIN[10];	/* Should be 2 */

	/* Load default color table */

	default_clu();

	/* Set graphics mode */

	CONTRL[0] = 5;	/* Function 5= Escape */
	CONTRL[1] = 0;
	CONTRL[3] = 0;
	CONTRL[5] = 3;	/* Set graphics mode = Exit from alpha mode */

	v_enter_cur();

	/* Other default values */

	wsptr->TEXT_CHAR_WIDTH  = 7;	/* Character width */
	wsptr->TEXT_CHAR_HEIGHT = 13;	/* Char height from baseline */
	wsptr->TEXT_CELL_WIDTH  = 8;	/* Character cell width */
	wsptr->TEXT_CELL_HEIGHT = 16;	/* Character cell height */
	wsptr->TEXT_ANGLE       = 0;	/* Character baseline rotation */
	wsptr->TEXT_ALIGN[0]    = 0;	/* Horizontally aligned left justified*/
	wsptr->TEXT_ALIGN[1]    = 0;	/* Vertically aligned to baseline*/
	wsptr->TEXT_EFFECT      = 0;	/* text effects */
	wsptr->LINE_WIDTH       = 1;	/* Single pixel line width */
	wsptr->MARKER_HEIGHT    = 16;	/* FINE TUNE */
	wsptr->LINE_END_STYLE[0] = 0;	/* Squared end style for lines */
	wsptr->LINE_END_STYLE[1] = 0;	/* Squared end style for lines */
	wsptr->WRITE_MODE       = 1; 	/* Replace mode */
	wsptr->FILL_OUTLINED    = 1;	/* Visible */	
	wsptr->LINE_USER_PATTERN = ~0;	/* Solid line */
	wsptr->A_ON             = 0;	/* Alpha cursor off */
	wsptr->CLIP_FLAG        = 0;	/* Clipping off */

	wsptr->FILL_USER_PATTERN = ptr = (WORD *)get_memory(
		PATTERN_SIZE_BYTES);

	if (ptr == (WORD *)NULL) {
		IOdebug("unable to get space for user fill pattern\n");
		WS_INUSE[CONTRL[6]] = 0;
		(void) free_memory((BYTE *)WS[CONTRL[6]]);
		CONTRL[6] = 0;
		return(0);
	}

	/* default user pattern - an atari logo */

	*ptr++ = 0x00000000;
	*ptr++ = 0x05A005A0;
	*ptr++ = 0x05A005A0;
	*ptr++ = 0x05A005A0;
	*ptr++ = 0x05A005A0;
	*ptr++ = 0x05A005A0;
	*ptr++ = 0x0DB00DB0;
	*ptr++ = 0x0DB00DB0;
	*ptr++ = 0x1DB81DB8;
	*ptr++ = 0x399C399C;
	*ptr++ = 0X399E399E;
	*ptr++ = 0X718E718E;
	*ptr++ = 0X718E718E;
	*ptr++ = 0X61866186;
	*ptr++ = 0X41824182;
	*ptr++ = 0X00000000;

	for(x = 16 ; x ; --x) {
		*ptr = *(ptr - 16);
		ptr++;
	}

	/* workstation parameters */

	load_ws_values();

	return(1);	/* Success */

} /* setup_ws() */

WORD get_next_wsnum()
/* return the number of a free workstation slot */
/* if none available, return zero */
{
	WORD i;

	for (i = 1 ; ((i<MAX_HANDLES) && (WS_INUSE[i])) ; i++);

	if (i >= MAX_HANDLES) return(0);	/* None available */

	WS_INUSE[i] = 1;	/* This one is free: mark it now in use */

	return(i);

} /* get_next_wsnum() */

void default_clu()
/* Load the default color table */
{
	WORD max,half_max,i;
	void set_clu(WORD,WORD,WORD,WORD);

	if (SCREEN.MODE != 0) {

		half_max = 255 >> 1;
		max      = 255;

		set_clu(0,max,max,max);		    	/* white */
		set_clu(1,0L,0L,0L);		    	/* black */
		set_clu(2,max,0L,0L);	    		/* red */
		set_clu(3,0L,max,0L);			/* green */
		set_clu(4,0L,0L,max);	    		/* blue */
		set_clu(5,0L,max,max);		    	/* cyan */
		set_clu(6,max,max,0L);			/* yellow */
		set_clu(7,max,0L,max);			/* magenta */
		set_clu(8,half_max,max,max);		/* light cyan */
		set_clu(9,0L,0L,0L);		    	/* black */
		set_clu(10,max,half_max,half_max);	/* light red */
		set_clu(11,half_max,max,half_max);	/* light green */
		set_clu(12,half_max,half_max,max);	/* light blue */
		set_clu(13,half_max,max,max);		/* light cyan */
		set_clu(14,max,max,half_max);		/* light yellow */
		set_clu(15,max,half_max,max);		/* light magenta */

		set_clu(255,0,0,0);
		set_clu(254,max,max,max);
		set_clu(253,0,max,max);
		set_clu(252,max,0,max);
		set_clu(251,max,max,0);
		set_clu(250,max,0,0);
		set_clu(249,0,0,max);
		set_clu(248,0,max,0);
		set_clu(247,0,0,0);
		set_clu(246,max,max,max);
		set_clu(245,0,half_max,half_max);
		set_clu(244,half_max,0,half_max);
		set_clu(243,half_max,half_max,0);
		set_clu(242,half_max,0,0);
		set_clu(241,0,0,half_max);
		set_clu(240,0,half_max,0);

	} else {

		max = 15;

		set_clu(0,max,max,max);

		for (i = 1; i < 14 ; i++) {
			set_clu(i,0,0,0);
		}

		for(i = 14; i < 15; i++) {
			set_clu(i,max,max,max);
		}

		set_clu(15,0,0,0);
	}

	set_clu(SCREEN.MAGIC,max,max,max);

} /* default_clu */

void init_default_line_patterns()
/* each line pattern is held as a 16 bit pattern so that the LINE_TYPE */
/* field (type WORD) in the HANDLE structure actually contains the */
/* current pattern; this improves efficiency when we need to make use */
/* of the pattern inside plot_line. */
/* This procedure initialises these patterns */
{
	LINE_PATTERNS[1] = 0xFFFF;	/* solid */
	LINE_PATTERNS[2] = 0xFFF0;	/* long dash */
	LINE_PATTERNS[3] = 0xE0E0;	/* dot */
	LINE_PATTERNS[4] = 0xFE38;	/* dash,dot */
	LINE_PATTERNS[5] = 0xFF00;	/* dash */
	LINE_PATTERNS[6] = 0xF198;	/* dash,dot,dot */
	LINE_PATTERNS[7] = 0xFFFF;	/* user-definable; solid by default */

} /* init_default_line_patterns() */

WORD init_default_fill_patterns()
/* each Fill pattern is held as a 32 by 32 bit pattern. This procedure */
/* initialises each of these patterns and initialises the array that */
/* indexes into them */
{
	WORD index;	/* used to index the fill pattern array */
	WORD *ptr;	/* used to access the fill pattern memory */
	WORD y;		/* a counter variable */

	index = 1;	/* the patterns are indexed from 1 */
	
	if ((FILL_PATTERN[index++] = ptr = (WORD *)get_memory((UWORD)
		N_DOTTED_PATTERNS * PATTERN_SIZE_BYTES))
		 == (WORD *)NULL) {
		return(0);
	}

	*ptr++ = 0x22222222L;
	*ptr++ = 0x00000000L;
	*ptr++ = 0x88888888L;
	*ptr++ = 0x00000000L;

	for (y=0; y<28; y++) {	
		*ptr = *(ptr-4);
		ptr++;
	}

/* next pattern 2 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0xAAAAAAAAL;
	*ptr++ = 0x00000000L;

	for (y=0; y<30; y++) {
		*ptr = *(ptr-2);
		ptr++;
	}

/* next pattern 3 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0x22222222L;	*ptr++ = 0x55555555L;	*ptr++ = 0x88888888L;
	*ptr++ = 0x55555555L;	*ptr++ = 0x22222222L;	*ptr++ = 0x55555555L;
	*ptr++ = 0x88888888L;	*ptr++ = 0x55555555L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next pattern 4 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0x55555555L;	*ptr++ = 0xAAAAAAAAL;
	for (y=0; y<30; y++) {
		*ptr = *(ptr-2);
		ptr++;
	}

/* next pattern 5 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0xDDDDDDDDL;	*ptr++ = 0xAAAAAAAAL;	*ptr++ = 0x77777777L;
	*ptr++ = 0xAAAAAAAAL;
	for (y=0; y<28; y++) {
		*ptr = *(ptr-4);
		ptr++;
	}

/* next pattern 6 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0xFFFFFFFFL;	*ptr++ = 0xAAAAAAAAL;

	for (y=0; y<30; y++) {
		*ptr = *(ptr-2);
		ptr++;
	}

/* next pattern 7 using our number system */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0xCCCCCCCCL;	*ptr++ = 0xCCCCCCCCL;
	*ptr++ = 0x33333333L;	*ptr++ = 0x33333333L;

	for (y=0; y<28; y++) {
		*ptr = *(ptr-4);
		ptr++;
	}

/* next pattern 8 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0xFFFFFFFFL;

	for (y=0; y<31; y++) {
		*ptr = *(ptr-1);
		ptr++;
	}

/* next pattern 9 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0xFFFFFFFFL;	*ptr++ = 0x80808080L;	*ptr++ = 0x80808080L;
	*ptr++ = 0x80808080L;	*ptr++ = 0xFFFFFFFFL;	*ptr++ = 0x08080808L;
	*ptr++ = 0x08080808L;	*ptr++ = 0x08080808L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next pattern 10 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0x40404040L;	*ptr++ = 0xA0A0A0A0L;	*ptr++ = 0x11111111L;
	*ptr++ = 0x0A0A0A0AL;	*ptr++ = 0x04040404L;	*ptr++ = 0x08080808L;
	*ptr++ = 0x10101010L;	*ptr++ = 0x20202020L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next pattern 11 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0x40404040L;	*ptr++ = 0xA0A0A0A0L;	*ptr++ = 0x00000000L;
	*ptr++ = 0x00000000L;	*ptr++ = 0x04040404L;	*ptr++ = 0x0A0A0A0AL;
	*ptr++ = 0x00000000L;	*ptr++ = 0x00000000L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next pattern 12 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0xAAAAAAAAL;	*ptr++ = 0x70707070L;	*ptr++ = 0x20202020L;
	*ptr++ = 0x20202020L;	*ptr++ = 0xAAAAAAAAL;	*ptr++ = 0x07070707L;
	*ptr++ = 0x02020202L;	*ptr++ = 0x02020202L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next pattern 13 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0x80808080L;	*ptr++ = 0x40404040L;	*ptr++ = 0x20202020L;
	*ptr++ = 0x00000000L;	*ptr++ = 0x02020202L;	*ptr++ = 0x04040404L;
	*ptr++ = 0x08080808L;	*ptr++ = 0x00000000L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next pattern 14 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0x60006000L;	*ptr++ = 0x63006300L;	*ptr++ = 0xC330C330L;
	*ptr++ = 0xCC30CC30L;	*ptr++ = 0x0C000C00L;	*ptr++ = 0x00600060L;
	*ptr++ = 0x06660666L;	*ptr++ = 0x06060606L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next pattern 15 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0x80008000L;	*ptr++ = 0x00000000L;	*ptr++ = 0x00800080L;
	*ptr++ = 0x00000000L;	*ptr++ = 0x00000000L;	*ptr++ = 0x00000000L;
	*ptr++ = 0x00000000L;	*ptr++ = 0x00000000L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next pattern 16 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0x82828282L;	*ptr++ = 0xC1C1C1C1L;	*ptr++ = 0xA0A0A0A0L;
	*ptr++ = 0x11111111L;	*ptr++ = 0x0A0A0A0AL;	*ptr++ = 0x1C1C1C1CL;
	*ptr++ = 0x28282828L;	*ptr++ = 0x44444444L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next pattern 17 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0xAAAAAAAAL;	*ptr++ = 0x00000000L;	*ptr++ = 0x88888888L;
	*ptr++ = 0x14141414L;	*ptr++ = 0x22222222L;	*ptr++ = 0x41414141L;
	*ptr++ = 0x88888888L;	*ptr++ = 0x00000000L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next pattern 18 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0xAAAAAAAAL;	*ptr++ = 0x00000000L;	*ptr++ = 0x80808080L;
	*ptr++ = 0x00000000L;	*ptr++ = 0x88888888L;	*ptr++ = 0x00000000L;
	*ptr++ = 0x80808080L;	*ptr++ = 0x00000000L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next pattern 19 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0x7CFE7CFEL;	*ptr++ = 0x86FE86FEL;	*ptr++ = 0x867C867CL;
	*ptr++ = 0xFE00FE00L;	*ptr++ = 0xFE7CFE7CL;	*ptr++ = 0xFE86FE86L;
	*ptr++ = 0x7C867C86L;	*ptr++ = 0x00FE00FEL;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next pattern 20 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0x80808080L;	*ptr++ = 0x80808080L;	*ptr++ = 0x41414141L;
	*ptr++ = 0x3E3E3E3EL;	*ptr++ = 0x08080808L;	*ptr++ = 0x08080808L;
	*ptr++ = 0x14141414L;	*ptr++ = 0xE3E3E3E3L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next pattern 21 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0xC0C0C0C0L;	*ptr++ = 0x303C303CL;	*ptr++ = 0x08080808L;
	*ptr++ = 0x04040404L;	*ptr++ = 0x04040404L;	*ptr++ = 0x0C0C0C0CL;
	*ptr++ = 0x12121212L;	*ptr++ = 0x21212121L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next pattern 22 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0xF0F0F0F0L;	*ptr++ = 0xF0F0F0F0L;	*ptr++ = 0xF0F0F0F0L;
	*ptr++ = 0xF0F0F0F0L;	*ptr++ = 0x0F0F0F0FL;	*ptr++ = 0x0F0F0F0FL;
	*ptr++ = 0x0F0F0F0FL;	*ptr++ = 0x0F0F0F0FL;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next pattern 23 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0x10101010L;	*ptr++ = 0x38383838L;	*ptr++ = 0x7C7C7C7CL;
	*ptr++ = 0xFFFFFFFFL;	*ptr++ = 0x7C7C7C7CL;	*ptr++ = 0x38383838L;
	*ptr++ = 0x10101010L;	*ptr++ = 0x10101010L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next pattern 24 */
	FILL_PATTERN[index++] = ptr;

	*ptr++ = 0xffffffffL;	*ptr++ = 0x88888888L;	*ptr++ = 0x44444444L;
	*ptr++ = 0x22222222L;	*ptr++ = 0xffffffffL;	*ptr++ = 0x22222222L;
	*ptr++ = 0x44444444L;	*ptr++ = 0x88888888L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}
		
	/****************************************************************/
	/*		Now the CROSS Patterns				*/
	/****************************************************************/
	
	index = 1;

	if ((CROSS_PATTERN[index++] = ptr = (WORD *)get_memory((UWORD)
		N_CROSS_PATTERNS * PATTERN_SIZE_BYTES)) == 
		(WORD *)NULL) {
			return(0);
	}

	*ptr++ = 0x80808080L;	*ptr++ = 0x01010101L;	*ptr++ = 0x02020202L;
	*ptr++ = 0x04040404L;	*ptr++ = 0x08080808L;	*ptr++ = 0x10101010L;
	*ptr++ = 0x20202020L;	*ptr++ = 0x40404040L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next Cross pattern 2 */
	CROSS_PATTERN[index++] = ptr;

	*ptr++ = 0xC0C0C0C0L;	*ptr++ = 0x81818181L;	*ptr++ = 0x03030303L;
	*ptr++ = 0x06060606L;	*ptr++ = 0x0C0C0C0CL;	*ptr++ = 0x18181818L;
	*ptr++ = 0x30303030L;	*ptr++ = 0x60606060L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next Cross pattern 3 */
	CROSS_PATTERN[index++] = ptr;

	*ptr++ = 0x80808080L;	*ptr++ = 0x41414141L;	*ptr++ = 0x22222222L;
	*ptr++ = 0x14141414L;	*ptr++ = 0x08080808L;	*ptr++ = 0x14141414L;
	*ptr++ = 0x22222222L;	*ptr++ = 0x41414141L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next Cross pattern 4 */
	CROSS_PATTERN[index++] = ptr;

	*ptr++ = 0x80808080L;

	for (y=0;y<31; y++) {
		*ptr = *(ptr-1);
		ptr++;
	}

/* next Cross pattern 5 */
	CROSS_PATTERN[index++] = ptr;

	*ptr++ = 0xFFFFFFFFL;	*ptr++ = 0x00000000L;	*ptr++ = 0x00000000L;
	*ptr++ = 0x00000000L;	*ptr++ = 0x00000000L;	*ptr++ = 0x00000000L;
	*ptr++ = 0x00000000L;	*ptr++ = 0x00000000L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next Cross pattern 6 */
	CROSS_PATTERN[index++] = ptr;

	*ptr++ = 0xFFFFFFFFL;	*ptr++ = 0x80808080L;	*ptr++ = 0x80808080L;
	*ptr++ = 0x80808080L;	*ptr++ = 0x80808080L;	*ptr++ = 0x80808080L;
	*ptr++ = 0x80808080L;	*ptr++ = 0x80808080L;

	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

/* next Cross pattern 7 */
	CROSS_PATTERN[index++] = ptr;

	*ptr++ = 0x00010001L;	*ptr++ = 0x00020002L;	*ptr++ = 0x00040004L;
	*ptr++ = 0x00080008L;	*ptr++ = 0x00100010L;	*ptr++ = 0x00200020L;
	*ptr++ = 0x00400040L;	*ptr++ = 0x00800080L;	*ptr++ = 0x01000100L;
	*ptr++ = 0x02000200L;	*ptr++ = 0x04000400L;	*ptr++ = 0x08000800L;
	*ptr++ = 0x10001000L;	*ptr++ = 0x20002000L;	*ptr++ = 0x40004000L;
	*ptr++ = 0x80008000L;

	for (y=0; y<16; y++) {
		*ptr = *(ptr-16);
		ptr++;
	}

/* next Cross pattern 8 */
	CROSS_PATTERN[index++] = ptr;

	*ptr++ = 0x80018001L;	*ptr++ = 0x00030003L;	*ptr++ = 0x00060006L;
	*ptr++ = 0x000C000CL;	*ptr++ = 0x00180018L;	*ptr++ = 0x00300030L;
	*ptr++ = 0x00600060L;	*ptr++ = 0x00C000C0L;	*ptr++ = 0x01800180L;
	*ptr++ = 0x03000300L;	*ptr++ = 0x06000600L;	*ptr++ = 0x0C000C00L;
	*ptr++ = 0x18001800L;	*ptr++ = 0x30003000L;	*ptr++ = 0x60006000L;
	*ptr++ = 0xC000C000L;

	for (y=0; y<16; y++) {
		*ptr = *(ptr-16);
		ptr++;
	}

/* next Cross pattern 9 */
	CROSS_PATTERN[index++] = ptr;

	*ptr++ = 0x80018001L;	*ptr++ = 0x40024002L;	*ptr++ = 0x20042004L;
	*ptr++ = 0x10081008L;	*ptr++ = 0x08100810L;	*ptr++ = 0x04200420L;
	*ptr++ = 0x02400240L;	*ptr++ = 0x01800180L;

	for (y=1; y<16; y+= 2) {
		*ptr = *(ptr-y);
		ptr++;
	}

	for (y=0; y<16; y++) {
		*ptr = *(ptr-16);
		ptr++;
	}

/* next Cross pattern 10 */
	CROSS_PATTERN[index++] = ptr;

	*ptr++ = 0x80008000L;

	for (y=0; y<31; y++) {
		*ptr = *(ptr-1);
		ptr++;
	}

/* next Cross pattern 11 */
	CROSS_PATTERN[index++] = ptr;

	*ptr++ = 0xFFFFFFFFL;
	*ptr++ = 0x00000000L;

	for (y=2; y<16; y++) {
		*ptr = *(ptr-1);
		ptr++;
	}

	*ptr++ = 0xFFFFFFFFL;

	for (y=1; y<16; y++) {
		*ptr = *(ptr-16);
		ptr++;
	}

/* next Cross pattern 12 */
	CROSS_PATTERN[index++] = ptr;

	*ptr++ = 0xFFFFFFFFL;	*ptr++ = 0xFFFFFFFFL;	*ptr++ = 0xC0C0C0C0L;

	for (y=3; y<8; y++) { 
		*ptr = *(ptr-1);
		ptr++;
	}
	for (y=0; y<24; y++) {
		*ptr = *(ptr-8);
		ptr++;
	}

	return (1);

} /* init_default_fill_patterns() */
E 1
