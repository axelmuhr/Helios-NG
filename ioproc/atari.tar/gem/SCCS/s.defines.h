h36568
s 00220/00000/00000
d D 2.1 88/10/26 18:42:53 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/************************************************************************/
/*									*/
/*				DEFINES.H				*/
/*									*/
/************************************************************************/

/************************************************************************/
/*									*/
/*			ATARI GRAPHICS LIBRARY	MACROS			*/
/*									*/
/************************************************************************/

#define VERSION		"VDI driver V1.00\n"

#define RPA(ptr)	(*(UBYTE *)(ptr))

#define RPO(ptr)	(*(UBYTE *)(ptr + SCREEN.MAP))

#define SPA(ptr,value)	(*(UBYTE *)(ptr) = (UBYTE)(value))
	
#define ATPO(addr)	((PIX_OFFSET) ((UWORD)(addr) - SCREEN.MAP))

#define FRR(l,r,lines)	(Fill_Rect_Region((l),(r),(lines)))

#define OFFSET(x,y)	(((WORD)(x)) + ((WORD)(y)) * SCREEN.STRIDE)

#define N_FRACT_BITS	16	/* floats have been removed from all */
				/* expressions. Instead, integral numerators */
				/* are scaled by 2**N_FRACT_BITS (shifted */
				/* left N_FRACT_BITS) before being divided, */
				/* this scale is then removed from the result*/
				/* by a shift right of N_FRACT_BITS */

#define N_F_B	8		/* smaller version of above */

#define MAX_POINTS	512	/* maximum number of points */
				/* for polyline, polymarker, filled area */

#define OPCODE		CONTRL[0]	/* opcode value */
#define PRIMITIVE_ID	CONTRL[5]	/* determines the GDP type */

#define WS_INFO		WS[CONTRL[6]] /* current WorkStation */
#define MAX_HANDLES	100

#define BACKGROUND_COLOUR	0	/* color index of background colour */

				/* PORTABILITY CHANGE */
#define MAPPED		1	/* 0 if no color table; non-zero otherwise */

/* Drawing parameters */
#define MAX_LINE_TYPES	  7	/* Number of linestyles supported */
#define MAX_MARKER_TYPES  6	/* Number of markers supported */
#define MIN_MARKER_HEIGHT 6	/* FINE TUNE */
#define MAX_MARKER_HEIGHT 50	/* FINE TUNE */
#define MAX_TEXT_FACES    1	/* Number of fonts supported */
#define MIN_TEXT_HEIGHT	  4	/* Smallest size of characters */
#define MAX_TEXT_HEIGHT	  26	/* Largest size of characters */
#define MAX_FILL_INTERIOR_STYLES	5	/* Number of fill patterns */

/* Mnemonics for the Line End Styles */
#define SQUARED		0
#define ARROW		1
#define ROUNDED		2

/* Mnemonics for the VDI Writing Modes */
#define REPLACE		1
#define TRANSPARENT	2
#define XOR		3
#define REV_TRANSPARENT 4

/* Mnemonics for VDI raster operations */
/* Two part names, such as NOT_AND, are parsed as NOT S AND D */
#define VDI_ZERO	0
#define VDI_AND		1
#define VDI_AND_NOT	2
#define VDI_REPLACE	3
#define VDI_NOT_AND	4
#define VDI_NOP		5
#define VDI_XOR		6
#define VDI_OR		7
#define VDI_NOR		8
#define VDI_XNOR	9
#define VDI_NOTD	10
#define VDI_OR_NOT	11
#define VDI_NOTS	12
#define VDI_NOT_OR	13
#define VDI_NAND	14
#define VDI_ONE		15
/* Perihelion extensions to VDI */
#define MAX_SD		16
#define MIN_SD		17
#define S_ADD_D		18
#define S_SUB_D		19
#define D_SUB_S		20

/* Conditions for the Colour RasterOp procedure */
#define  RAS_LEQ	0
#define  RAS_EQ		1
#define  RAS_GEQ	2
#define  RAS_NEQ	3
#define  RAS_NO_COND	4

/* Mask and pattern parameters */
#define NUM_MASK_BITS		1024	/* Number of bits in mask */
#define N_DOTTED_PATTERNS	24	/* The number of dotted patterns */
#define N_CROSS_PATTERNS	12	/* The number of cross-hatch patterns*/
#define PATTERN_SIZE_BYTES	32*32	/* Pattern size in bytes */

/* Number of bits per byte */
#define BYTE_SIZE	8

/* Printers points per inch */
#define POINTS_PER_INCH	72

/* Convert inches to microns */
/* Note that this is a float; it is not used however being commented out in */
/* depends.c */
#define MICRONS_TO_INCHES	25400.0

/* Error character used for out of range text values */
#define ERRORCHAR	63

/* Maps the Primitive ID to the correct function call */
#define BAR			1
#define ARC			2
#define PIE			3
#define CIRCLE			4
#define ELLIPSE			5
#define ELLIPTICAL_ARC		6
#define ELLIPTICAL_PIE		7
#define ROUNDED_RECTANGLE	8
#define FILLED_ROUND_RECTANGLE	9
#define JUSTIFIED_GRAPHICS_TEXT	10

/* Mnemonics for the Fill Interior Styles */
#define HOLLOW			0
#define SOLID			1
#define PATTERN			2
#define HATCH			3
#define USER_DEFINED_STYLE	4

/* standard macros */
#define ABS(x)		( (x) >=  0  ? (x) : -(x) )
#define MAX(x,y) 	( (x) >= (y) ? (x) : (y)  )
#define MIN(x,y)	( (x) >= (y) ? (y) : (x)  )

/* Macros for interrogating the Edge Data Structure, when */
/* scan-converting polygons */
#define Edge_Xvalue(ptr)	((ptr)->edge_xvalue)
#define Edge_Gradient(ptr)	((ptr)->edge_gradient)
#define Edge_Ymax(ptr)		((ptr)->edge_ymax)
#define Edge_Next(ptr)		((ptr)->edge_next)

/* Text effects */
#define BOLD		1
#define LIGHT		2
#define ITALIC		4
#define UNDERLINE	8
#define OUTLINE		16
#define SHADOW		32

/* Text alignments */
#define LEFT		0
#define CENTER		1
#define RIGHT		2

#define BASELINE	0
#define HALF_LINE	1
#define ASCENT_LINE	2
#define BOTTOM_LINE	3
#define DESCENT_LINE	4
#define TOP_LINE	5

/* screen limits */
#define SCREEN_XLEFT	0
#define SCREEN_XRIGHT	(SCREEN.WIDTH - 1)
#define SCREEN_YBOT	0
#define SCREEN_YTOP	(SCREEN.HEIGHT - 1)

/* directions used by RasterOp */

#define FORWD		1
#define BACKWD		0

/* defines used by the atari - transputer send / receive protocol */

#define DONE		0
#define OK		1
#define ERROR		255
#define RET_HANDLE	254
#define MOUSE_COORDS	200
#define BUF_SIZE	10240
#define NOT_SEND_MEM	0
#define SEND_MEM	1
#define TFORM		2

/* defines for starting the mouse */

#define MOUSE_X		320
#define MOUSE_Y		200
#define MOUSE_SCALE	3

/* defines for atari / transputer message FnRc's */

#define OOPS		0x00000000L
#define MEM_BACK	0x11111111L
#define PRINT		0x22222222L
#define SEND_FONT	0x33333333L
#define SEND_MFDB	0x44444444L
#define DATA_BACK	0x55555555L
#define ATARI_MESS	0x66666666L
#define SEND_BLOCK	0x77777777L

/* magic colour - guaranteed to be the same as colour 0 without */
/* having an index of 0 */

#define MAGIC_COLOUR0	6

#define MAGIC_COLOUR1	230

E 1
