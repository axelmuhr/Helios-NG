h06232
s 00236/00000/00000
d D 2.1 88/10/26 18:43:16 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
#include <stdio.h>
#include <osbind.h>
#define BUF_SIZ	1024

extern int	ans;

extern int	tmp,handle,
		fill_colour,
		fill_style,
		fill_perimeter,
		fill_interior,
		line_colour,
		line_start,
		line_end,
		line_width,
		line_type,
		write_mode;

extern int	intin[],intout[],contrl[];
extern int	pxyarray[],ptsin[],ptsout[];
extern char	in[];

int	clipping = 0,
	clipsx = 0,
	clipsy = 0,
	clipex = 0,
	clipey = 0;

void help()
{
	v_clrwk(handle);

	printf("Gem demonstation help menu ...\n");
	printf("\nType one letter for desired demo.\n");
	printf("A.. elliptical arc\n");
	printf("C.. contour filling\n");
	printf("E.. elliptical pie chart\n");
	printf("M.. plot varying size markers\n");
	printf("P.. pie slice\n");
	printf("a.. arc drawing\n");
	printf("b.. bar drawing\n");
	printf("c.. circle drawing\n");
	printf("e.. ellipse drawing\n");
	printf("f.. area fill\n");
	printf("h.. this help screen\n");
	printf("m.. mouse demo\n");
	printf("p.. filled pattern test\n");
	printf("r.. rounded (thin-line) box\n");
	printf("t.. text drawing\n");
	printf("\nv.. change the line and fill variables\n");
	printf("x.. set/unset clipping region\n");

	printf("\nq.. quit\n");

} /* help */

void vars()
{
	printf("Gem demonstration variable settings :-\n");
	printf("\n0. Line colour %d (%s)\n",line_colour,(line_colour) ?
		"foreground" : "background");
	printf("1. Line type %d\n",line_type);
	printf("2. Line width %d\n",line_width);
	printf("3. Line start %d (",line_start);
	switch(line_start) {
		case 0:		printf("square)\n");
				break;
		case 1:		printf("arrow)\n");
				break;
		case 2:		printf("rounded)\n");
				break;
	}
	printf("4. Line end %d (",line_end);
	switch(line_end) {
		case 0:		printf("square)\n");
				break;
		case 1:		printf("arrow)\n");
				break;
		case 2:		printf("rounded)\n");
				break;
	}

	printf("\n5. Fill colour %d\n",fill_colour);
	printf("6. Fill perimeter %d (%s)\n",fill_perimeter,(fill_perimeter) ?
		"shown" : "hidden");
	printf("7. Fill interior %d (",fill_interior);
	switch (fill_interior) {
		case 0:		printf("hollow)\n");
				break;
		case 1:		printf("colour filled)\n");
				break;
		case 2:		printf("pattern filled)\n");
				break;
		case 3:		printf("cross-hatched)\n");
				break;
		case 4:		printf("user defined pattern)\n");
				break;
	}
	printf("8. Fill style %d\n",fill_style);

	printf("\n9. write mode %d (",write_mode);
	switch (write_mode) {
		case 1:		printf("replace)\n");
				break;
		case 2:		printf("transparent) \n");
				break;
		case 3:		printf("xor)\n");
				break;
		case 4:		printf("reverse transparent)\n");
				break;
	}
	printf("\n-----------------------------------------\n");

	for(;;) {

		printf("\nWhich do you wish to change (0-9) (q to finish) ");
		fflush(stdout);

		ans = gemdos(0x1);

		printf("\n");

		switch (ans) {
		case '0':	printf("new line colour (0,1) ? ");
				line_colour = get(0,1);
				break;
		case '1':	printf("new line type (1 - 7) ? ");
				line_type = get(1,7);
				break;
		case '2':	printf("new line width (1 - 9) ? ");
				line_width = get(1,9);
				break;
		case '3':	printf("new line start (0 - 2) ? ");
				line_start = get(0,2);
				break;
		case '4':	printf("new line end (0 - 2) ? ");
				line_end = get(0,2);
				break;
		case '5':	printf("new fill colour (0,1) ? ");
				fill_colour = get(0,1);
				break;
		case '6':	printf("new fill perimeter (0,1) ? ");
				fill_perimeter = get(0,1);
				break;
		case '7':	printf("new fill interior (0 - 4) ? ");
				fill_interior = get(0,4);
				break;
		case '8':	printf("new fill style (1 - 24) ? ");
				fill_style = get(1,24);
				break;
		case '9':	printf("new write mode (1 - 4) ? ");
				write_mode = get(1,4);
				break;
		case 'q':	return;
		}
	}

} /* vars */

int get(min,max)
int min,max;
{
	int	val;

	val = min - 1;
	fflush(stdout);

	while (val < min || val > max) {
		in[0] = BUF_SIZ - 3;
		Cconrs(in);
		in[in[1]+2] = '\0';
		val = atoi(in+2);
	}

	return (val);

} /* get */

void clip()
{
	printf("Gem demonstration clip region\n");

	if (clipping) {
		printf("current clip region shown\n");

		pxyarray[0] = clipsx;
		pxyarray[1] = clipsy;
		pxyarray[2] = clipex;
		pxyarray[3] = clipey;

		tmp = vsf_color(handle,1);
		tmp = vsf_interior(handle,3);
		tmp = vsf_style(handle,1);
		tmp = vsf_perimeter(handle,1);
		tmp = vswr_mode(handle,2);

		v_bar(handle,pxyarray);
	} else {
		printf("clipping turned off\n");
	}

	printf("\n\nturn clipping %s ? (y/n) ",(clipping) ? "off" : "on");
	fflush(stdout);

	for (ans = ' ' ; ans != 'y' && ans != 'n' ; ans = Cconin());

	if (ans == 'y') clipping = ~clipping;

	if (clipping && ans == 'y') {
		printf("\n\nnew clip region ...\n");
		printf("starting x coordinate ? (currently %d) (0 - 639) ",
			clipsx);
		clipsx = get(0,639);

		printf("\nstarting y coordinate ? (currently %d) (0 - 398) ",
			clipsy);
		clipsy = get(0,398);

		printf("\nend x coordinate ? (currently %d) (0 - 639) ",
			clipex);
		clipex = get(0,639);

		printf("\nend y coordinate ? (currently %d) (0 - 398) ",
			clipey);
		clipey = get(0,398);
	}

	pxyarray[0] = clipsx;
	pxyarray[1] = clipsy;
	pxyarray[2] = clipex;
	pxyarray[3] = clipey;

	vs_clip(handle,clipping,pxyarray);

} /* clip */

E 1
