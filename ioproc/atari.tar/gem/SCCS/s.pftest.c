h53053
s 00353/00000/00000
d D 2.1 88/10/26 18:43:34 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
#include "helios.h"
#include "task.h"

#define NUM_6845_REG	16
#define NUM_MODES	4
#define MAP0		0x00000000L
#define MAP1		0x00200000L
#define MAP2		0x00400000L
#define MAP3		0x00600000L

WORD screen_base = MAP1;

extern void bytblt(WORD *,WORD *,WORD,WORD,WORD,WORD,WORD,WORD,WORD);

extern Task	*MyTask;

WORD p_mode[NUM_MODES] = { 0x00,0x20,0x40,0x60 };

WORD v_mode[NUM_MODES] = { 0x02,0x3C,0x36,0x11 };

WORD *pmode =   0x40000000;
WORD *vidmode = 0x40400000;

#define HITACHI		0
#define NEC_PL		1
#define NEC_XL		2

#define MODE0		0
#define MODE1_HITACHI	1
#define MODE1_NEC_PL	2
#define MODE1_NEC_XL	3
#define MODE2_NEC_PL	4
#define MODE2_NEC_XL	5
#define MODE3_NEC_PL	6
#define MODE3_NEC_XL	7

WORD crt[8][16] = { 
/* mode 0 */	{ 42,16,34,0x34,64, 2,60,61,0,15,0x2f,0xf,0x1f,0xe0,0,0 } ,
/* mode 1 */	{ 40,16,33,0x64,49,13,48,48,0,15,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* --"--  */	{ 40,16,37,0x64,49,13,48,48,0,15,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* --"--  */	{ 40,16,36,0x64,49,13,48,48,0,15,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* mode 2 */	{ 42,16,36,0x34,31, 9,30,31,0,15,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* --"--  */	{ 42,16,36,0x34,31, 9,30,31,0,15,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* mode 3 */	{ 50,16,40,0x35,62, 7,60,61,0, 7,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* --"--  */	{ 50,16,40,0x35,62, 7,60,61,0, 7,0x2f,0xf,0x3f,0xe0,0,0 } ,
		 };

WORD *vgaddr = 0x40200000;
WORD *vgreg  = 0x40200004;

void setup6845(index)
WORD index;
{
	register WORD i;

	for (i=0; i < NUM_6845_REG; i++) {

		*vgaddr = i;
		*vgreg  = crt[index][i];
	}
}

void setup_video(mode,monitor)
WORD mode;	/* screen mode 0 - 3 */
WORD monitor;	/* monitor supplied 0 - 2 */
{
	if (mode < 0 || mode >= NUM_MODES) return;

	*pmode   = p_mode[mode];
	*vidmode = v_mode[mode];

	switch (mode) {

		case 0:		setup6845(MODE0);
				break;

		case 1:	switch (monitor) {

				case HITACHI:	setup6845(MODE1_HITACHI);
						break;

				case NEC_PL:	setup6845(MODE1_NEC_PL);
						break;

				case NEC_XL:	setup6845(MODE1_NEC_XL);
						break;

				default:	/* error */
						break;
			}
			break;

		case 2:	switch (monitor) {

				case NEC_PL:	setup6845(MODE2_NEC_PL);
						break;

				case NEC_XL:	setup6845(MODE2_NEC_XL);
						break;

				default:	/* error */
						break;
			}
			break;

		case 3:	switch (monitor) {

				case NEC_PL:	setup6845(MODE3_NEC_PL);
						break;

				case NEC_XL:	setup6845(MODE3_NEC_XL);
						break;

				default:	/* error */
						break;
			}
			break;

		default: /*error */

			break;
	}
}

WORD *vd453wraddraddr = 0x40d00000;
WORD *vd453wrcoladdr  = 0x40d02000;

void set_colour(red,green,blue)
WORD red,green,blue;
{
	*vd453wrcoladdr = red;
	*vd453wrcoladdr = green;
	*vd453wrcoladdr = blue;
}
	
void setup_colour()
{
	WORD i,bias;

	*vd453wraddraddr = 0L;

	set_colour(0,0,0);

	bias = 147;

	for(i=1; i <= 36; i++) {

		set_colour(bias + i*3,0,0);
		set_colour(0,bias + i*3,0);
		set_colour(0,0,bias + i*3);
		set_colour(bias + i*3,bias + i*3,0);
		set_colour(bias + i*3,0,bias + i*3);
		set_colour(0,bias + i*3,bias + i*3);
		set_colour(bias + i*3,bias + i*3,bias + i*3);
	}

	set_colour(~0,0,0);
	set_colour(~0,~0,~0);
}	

static unsigned long next = 1;

WORD rand(void)
{
	next = next * 1103515245 + 12345;

	return ((WORD)((next >> 16)));
}

int main(void)
{
	void clear_screen2(void);
	void pattern_show(void);

	setup_video(1,NEC_XL);

	setup_colour();

	clear_screen2();

	pattern_show();
	
	return(1);
}

WORD *array = (WORD *)(MinInt + 1024);

void clear_screen2(void)
{
	WORD i,*ptr = array;
	
	for(i=0;i<256;i++) {
		*ptr++ = 0;
	}

	bytblt(array,(WORD *)screen_base,0,0,0,2048,768,1024,0);
}

#define min(a,b)	( (a) < (b) ? (a) : (b))

void pattblat(s_ptr,s_width,s_height,d_ptr,d_width,d_height,colour)
WORD s_ptr;	/* pointer to source of pattern */
WORD s_width;	/* source width in (pattern) pixels */
WORD s_height;	/* source height in lines */
WORD d_ptr;	/* destination (screen) pointer */
WORD d_width;	/* destrination width in pixels (bytes) */
WORD d_height;	/* destination height in lines */
UBYTE colour;	/* colour of set pixels in the pattern */
{
	UBYTE	*sptr,*dptr;
	WORD	height,width,patt,count,count2;
	UWORD	mask;

	/* copy pattern onto screen */

	width  = min(s_width,d_width);
	height = min(s_height,d_height);

	dptr = d_ptr;

	for(count = 0; count < height; count++) {
		mask = 0x80000000L;
		patt = *((WORD *)s_ptr);
		
		for(count2 = 0; count2 < width; count2++) {

			if (mask & patt) *((UBYTE *)(dptr)) = colour;
			else 	         *((UBYTE *)(dptr)) = 0;

			dptr++;
			mask >>= 1;
		}

		dptr  += 2048 - width;
		s_ptr += 4;		/* SOURCE STRIDE */
	}

	/* now copy pattern across screen */

	if (width < d_width) {
		WORD itterations,remainder;

		itterations = d_width / s_width - 1;

		sptr = d_ptr;

		for (count = 0; count < height; count++) {

			dptr = (unsigned char *)(sptr + s_width);

			bytblt(sptr,dptr,0,0,0,s_width,itterations,s_width,0);

			dptr += itterations * s_width;

			/* copy remainder of line */

			remainder = d_width - ((itterations + 1) * s_width);

			bytblt(sptr,dptr,0,0,0,0,1,remainder,0);

			sptr += 2048;
		}
	}
	
	/* now copy down rest of screen .... */

	if (height < d_height) {

		dptr = d_ptr + s_height * 2048;
		
		bytblt(d_ptr,dptr,0,0,2048,2048,d_height - s_height,d_width,0);
	}
}

WORD patt[][8] = {
	{ 0xAAAAAAAA,0x00000000 } ,
	{ 0x55555555,0xAAAAAAAA } ,
	{ 0xFFFFFFFF,0xAAAAAAAA } ,
	{ 0x88888888,0x44444444,0x22222222,0x11111111 } ,
	{ 0x22222222,0x00000000,0x88888888,0x00000000 } ,
	{ 0x22222222,0x55555555,0x88888888,0x55555555 } ,
	{ 0xDDDDDDDD,0xAAAAAAAA,0x77777777,0xAAAAAAAA } ,
	{ 0xCCCCCCCC,0xCCCCCCCC,0x33333333,0x33333333 } ,
	{ 0xFFFFFFFF,0x80808080,0x80808080,0x80808080 } ,
	{ 0x40404040,0xA0A0A0A0,0x00000000,0x00000000,
	  0x04040404,0x0A0A0A0A,0x00000000,0x00000000 } ,
	{ 0x40404040,0xA0A0A0A0,0x11111111,0x0A0A0A0A,
	  0x04040404,0x08080808,0x10101010,0x20202020 } ,
	{ 0x60006000,0x63006300,0xC330C330,0xCC30CC30,
	  0X0C000C00,0x00600060,0x06660666,0x06060606 } ,
	{ 0xff00ff00,0xff00ff00,0x00ff00ff,0x00ff00ff }
	};

void pattern_show(void)
{
	WORD dest;
	void pattblat(WORD,WORD,WORD,WORD,WORD,WORD,UBYTE);

#define COLOUR	255

	dest = 200 + 100 * 2048 + screen_base;

	pattblat((WORD)patt[0],32,2,dest,100,100,COLOUR);

	dest = 400 + 100 * 2048 + screen_base;

	pattblat((WORD)patt[1],32,2,dest,100,100,COLOUR);

	dest = 600 + 100 * 2048 + screen_base;

	pattblat((WORD)patt[2],32,2,dest,100,100,COLOUR);

	dest = 800 + 100 * 2048 + screen_base;

	pattblat((WORD)patt[3],32,4,dest,100,100,COLOUR);

	dest = 200 + 300 * 2048 + screen_base;

	pattblat((WORD)patt[4],32,4,dest,100,100,COLOUR);

	dest = 400 + 300 * 2048 + screen_base;

	pattblat((WORD)patt[5],32,4,dest,100,100,COLOUR);

	dest = 600 + 300 * 2048 + screen_base;

	pattblat((WORD)patt[6],32,4,dest,100,100,COLOUR);

	dest = 800 + 300 * 2048 + screen_base;

	pattblat((WORD)patt[7],32,4,dest,100,100,COLOUR);

	dest = 200 + 500 * 2048 + screen_base;

	pattblat((WORD)patt[8],32,4,dest,100,100,COLOUR);

	dest = 400 + 500 * 2048 + screen_base;

	pattblat((WORD)patt[9],32,8,dest,100,100,COLOUR);

	dest = 600 + 500 * 2048 + screen_base;

	pattblat((WORD)patt[10],16,8,dest,100,100,COLOUR);

	dest = 800 + 500 * 2048 + screen_base;

	pattblat((WORD)patt[11],16,4,dest,100,100,COLOUR);

	dest = 100 + 600 * 2048 + screen_base;

	pattblat((WORD)patt[12],32,4,dest,100,100,COLOUR);

}
E 1
