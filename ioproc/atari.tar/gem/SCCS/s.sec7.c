h63463
s 00193/00000/00000
d D 2.1 88/10/26 18:44:05 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/************************************************************************/
/*									*/
/*			SEC7.C						*/
/*									*/
/************************************************************************/

#include "header.h"

/* FUNCTIONS IN THIS MODULE:						*/
/*									*/
/*  FUNCTION	DESCRIPTION		NAME		MANUAL SECTION	*/
/*									*/
/*	 111:	Set mouse form		vsc_form		7	*/
/*	 122:	Show cursor 		v_show_c		7	*/
/*	 123:	Hide cursor 		v_hide_c		7	*/
/*           								*/

void vsc_form()
/* Function 111: Set mouse form */
/* Loads a graphics cursor pattern */
{
	WORD 		i,j;
	UWORD	mask;
	WORD		save,fg,bg;

/* Prevent mouse being displayed whilst updating form */

	save        = SCREEN.G_ON;
	SCREEN.G_ON = 0;

/* Load new pattern and mask */

/* Note we must put the patterns into the high word as transputer uses */
/* 32 bit masks whereas GEM uses 16 bit masks */
/* NB this version woks ibn modes 1 & 2 only */

	/* ensure colour zero is displayed */

	bg = INTIN[3];
	fg = INTIN[4];

	if (bg == 0) bg = SCREEN.MAGIC;
	if (fg == 0) fg = SCREEN.MAGIC;

	for(i = 0; i < 16; i++) {
		mask = 0x8000;
		for(j = 0; j < 16; j++) {

			if (mask & INTIN[5 + i]) {

				if (mask & INTIN[21 + i]) {

					SCREEN.G_CUR_COL[i][j] = fg;

				} else {

					SCREEN.G_CUR_COL[i][j] = bg;
				}

			} else {

				SCREEN.G_CUR_COL[i][j] = 0;
			}

			mask >>= 1;
		}
	}

	SCREEN.G_ON = save;

	/* Return values */
	
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* vsc_form() */

void v_show_c()
/* Function 122: Show cursor */
{
	WORD visible;
	void g_cursor_restore(void);

	visible = SCREEN.G_ON;	/* Remember current visibility */

	if (INTIN[0] != 0)		/* If not reset */
		visible++;		/* Increment the visibility */
	else				/* Reset to visible */
		visible = 1;		/* Set to visible */

	/* If cursor has just become visible, put it on screen */
	/* (otherwise it is either not visible or is on screen already) */

	if ((SCREEN.G_ON<=0) && (visible==1)) {
		SCREEN.G_ON = visible;
		g_cursor_restore();

	} else {
		SCREEN.G_ON = visible;
	}

	/* return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_show_c() */

void v_hide_c()
/* Function 123: Hide cursor */
{
	void g_cursor_save(void);

	if (SCREEN.G_ON > 0) { /* Currently visible */

		g_cursor_save();

		SCREEN.G_ON = 0;
	
	} else {		/* Currently invisible */
		--SCREEN.G_ON;	/* make it less visible still */
	}
	
	/* return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_hide_c() */

/************************************************************************/
/*									*/
/*			LOCAL UTILITIES					*/
/*									*/
/************************************************************************/

static WORD	oldx = MOUSE_X,
		oldy = MOUSE_Y;

void handler(x,y)
WORD x,y;
{
	void g_cursor_save(void);
	void g_cursor_restore(void);

	if (SCREEN.G_ON > 0) {

		g_cursor_save();

		oldx = x;

		oldy = y;

		g_cursor_restore();

	} else {

		oldx = x;

		oldy = y;
	}

} /* handler() */

void g_cursor_restore()
/* Put the graphics cursor back on the screen */
/* first saving the overwritten section of picture */
{
	/* first save contents of screen under cursor */

	bytblt(	(WORD *)(SCREEN.MAP + OFFSET(oldx,oldy)),
		(WORD *)(SCREEN.G_CUR_COPY),0,0,
		SCREEN.STRIDE,16,16,16,0);

	/* then display the cursor in transparent mode */

	bytblt(	(WORD *)SCREEN.G_CUR_COL,
		(WORD *)(SCREEN.MAP + OFFSET(oldx,oldy)),0,0,
		16,SCREEN.STRIDE,16,16,1);

} /* g_cursor_restore() */

void g_cursor_save()
/* Take the graphics cursor off the screen */
/* Do this by putting back the picture which was under it */
{
	/* put G_CUR_COPY back to (oldx,oldy) */

	bytblt(	(WORD *)SCREEN.G_CUR_COPY,
		(WORD *)(SCREEN.MAP + OFFSET(oldx,oldy)),0,0,
		16,SCREEN.STRIDE,16,16,0);

} /* g_cursor_save() */


E 1
