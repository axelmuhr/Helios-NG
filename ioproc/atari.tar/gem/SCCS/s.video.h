h27864
s 00050/00000/00000
d D 2.1 88/10/26 18:44:43 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/*****************************************************************

	Charity version for video 

	RGM 30/12/87	

******************************************************************/

#define NUM_MODES	4

#define MAP0	0x00000000
#define MAP1	0x00200000
#define MAP2	0x00400000
#define MAP3	0x00600000

/********************************************************************
		Video board addresses and values
*********************************************************************/

#define VMODE 0x42400000	/* Video mode register */

/* BT453 is Brooktree CLUT for modes 1 and 2 (8 bits / pixel) */

#define	C453WADDR 0x42D00000	/* BT453 write addresses */
#define	C453WDATA 0x42D02000	/* BT453 write colour data */
#define	C453RADDR 0x42500000	/* BT453 read addresses */
#define	C453RDATA 0x42502000	/* BT453 read colour data */

/* BT454 is Brooktree CLUT for mode 0 (4 bits / pixel) */

#define	C454WADDR 0x42580000	/* BT454 write addresses */
#define	C454WDATA 0x42582000	/* BT454 write colour data */

/**********************************************************************
		Magic numbers for monitors and modes
***********************************************************************/

#define HITACHI		0
#define NEC_PL		1
#define NEC_XL		2

#define MODE0		0
#define MODE1_HITACHI	1
#define MODE1_NEC_PL	2
#define MODE1_NEC_XL	3
#define MODE2_NEC_PL	4
#define MODE2_NEC_XL	5
#define MODE3_NEC_PL	6
#define MODE3_NEC_XL	7

E 1
