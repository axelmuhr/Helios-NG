h53016
s 00613/00000/00000
d D 2.1 88/10/26 18:44:01 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/************************************************************************/
/*									*/
/*				SEC6.C					*/
/*									*/
/************************************************************************/

#include "header.h"
#include "stextra.h"

/* FUNCTIONS IN THIS MODULE:						*/
/*									*/
/*  FUNCTION	DESCRIPTION		NAME		MANUAL SECTION	*/
/*									*/
/*	 109:	Copy raster, opaque 	vro-cpyfm		6	*/
/*	 110:	Transform form 		vr_trnfm		6	*/
/*	 121:	Copy raster,						*/
/*		transparent	 	vrt_cpyfm		6	*/
/*									*/

#define TABLE_SIZE	128

static WORD	*table[TABLE_SIZE][2];
static WORD	table_index = TABLE_SIZE - 1;	/* last used entry in table */

void vr_trnfm(void)
/* Function 110: Transform form */
/* UNFINISHED - screen to standard with too many screen planes */
/* NB/ standard form is xy-format rather than z-format */
/* NB/ Gem does not appear to define the order in which the planes should */
/*     be stored, so we store them least significant plane first.  This   */
/*     a monochrome image to be easily extracted from a standard form.    */
/* NB/ Gem does not define which planes should be chosen when less planes */
/*     are requested than the source depth.  We chose the least	          */
/*     significant planes.						  */
{
	WORD	x, y, z, i, index, step, length;
	UWORD	size;
	UBYTE	*tmp, *mem, *ptr, *start ,*planes[8];
	UBYTE	pixel, mask, insert, begin;
	MFDB	*src, *dest;
	void	sendm(WORD, UBYTE *, WORD);
	
	src  = (MFDB *)(*(WORD *)(CONTRL + 7));
	dest = (MFDB *)(*(WORD *)(CONTRL + 9));

	/* Return values */

	CONTRL[2] = 0;
	CONTRL[4] = 0;

	/* determin the kind of transform required */

	if ( IS_SPECIFIC(src) ) {

		/* convert a screen image into a gem standard image */

		if (src->planes > SCREEN.DEPTH) {

			IOdebug("cannot convert %d planes!\n",src->planes);
			(void) free_memory((BYTE *)src);
			(void) free_memory((BYTE *)dest);
			return;
		}

		/* locate the source memory in table */

		i = table_index;

		tmp = (UBYTE *)src->res1;

		if (table[i][1] != (WORD *)tmp) {

			do {
				--i;
				if (i < 0) i = TABLE_SIZE - 1;

			} while (i           != table_index &&
				 table[i][1] != (WORD *)tmp    );

			if (i == table_index) {
				IOdebug("could not find source address %lx\n",
					tmp);
				(void) free_memory((BYTE *)src);
				(void) free_memory((BYTE *)dest);
				return;
			}
		}

		tmp = (UBYTE *)table[i][0];

		/* get memory for converted image */
		/* this is needed because destination memory may be the */
		/* same as the source memory, and anyway, destination  */
		/* memory is not copied over */

		size = src->word_width * src->height *
			SCREEN.DEPTH * sizeof(short);

		mem = (UBYTE *)get_memory(size);

		if (mem == (UBYTE *)NULL) {
			IOdebug("unable to get memory for transformed image\n");
			(void) free_memory((BYTE *)src);
			(void) free_memory((BYTE *)dest);
			return;
		}

		/* zero the memory */

		ptr = mem;
		for (z = size; z ; --z) {
			*ptr++ = 0;
		}

		/* pretend memory is split up into planes */
		/* NB/ planes must be (16 bit) word aligned */

		step = src->word_width * src->height * sizeof(short);

		for (x = SCREEN.DEPTH - 1; x >= 0; --x) {

			planes[x] = mem + step * x;
		}

		/* now convert the memory */
		/* for each pixel in the source area put one bit in each */
		/* plane of destination memory */
		/* NB/ this routine works in modes 0 - 2 only */

		index  = 0;
		insert = 0x80;

		if (SCREEN.DEPTH == 4) {

			begin = 0x08;	/* low nibble */

		} else {

			begin = 0x80;	/* entire byte */
		}

		for (x = 0; x < src->height; x++ ) {

			for (y = 0; y < src->width; y++ ) {

				pixel = *(tmp + x * src->width + y);

				for (	mask = begin, z = SCREEN.DEPTH - 1;
					z >= 0;
					mask >>= 1, --z) {

					if (pixel & mask) {
						planes[z][index] |= insert;
					}
				}

				if (!(insert >>= 1)) {
					insert = 0x80;
					index++;
				}
			}
			if (insert != 0x80) {
				insert = 0x80;
				index++;
			}
		}

		/* should be finished now, so install result */	

		dest->res1 = (WORD)mem;
		dest->flag = ~src->flag;

		/* send the transformed image back to the atari */
		/* adjust length sent back to reflect number of */
		/* planes requested				*/

		length = step * src->planes;

		sendm(length,mem,MEM_BACK);

		/* release the memory afterwards */

		(void) free_memory((BYTE *)mem);

	} else {

		/* convert standard format to screen format */

		if (src->planes > SCREEN.DEPTH) {

			IOdebug("clipping to %d planes\n",SCREEN.DEPTH);
			src->planes = SCREEN.DEPTH;
		}

		/* get memory for converted image */
		/* this is needed because destination memory may be the */
		/* same as the source memory, and anyway, destination  */
		/* memory is not copied over */

		size = src->word_width * src->height * 8 * sizeof(short);

		mem = (UBYTE *)get_memory(size);

		if (mem == (UBYTE *)NULL) {
			IOdebug("cannot get memory for screen image\n");
			(void) free_memory((BYTE *)src);
			(void) free_memory((BYTE *)dest);
			return;
		}

		/* zero the memory */

		ptr = mem;
		for (z = size; z ; --z) {
			*ptr++ = 0;
		}

		tmp   = mem;
		start = (UBYTE *)src->addr;
		step  = src->word_width * src->height * sizeof(short);
		mask  = 0x80;

		/* now convert */

		for (y = 0; y < src->height; y++) {

			for(x = 0; x < src->width; x++) {

				/* extract a pixel */

				pixel = 0;

				for (z = src->planes - 1; z >= 0; --z) {

					pixel <<= 1;

					if ((*(start + step * z)) & mask) {
							pixel |= 0x1;
					}
				}

				if (pixel == SCREEN.MAGIC) ++pixel;

				*tmp++ = pixel;

				if (!(mask >>= 1)) {
					mask = 0x80;
					++start;
				}
			}

			if (mask != 0x80) {
				mask = 0x80;
				++start;
			}
		}

		/* should be finished now, so install result */	

		dest->flag = ~src->flag;

		if (++table_index >= TABLE_SIZE) table_index = 0;

		if (table[table_index][0]) {

			/* about to overwrite - so free */

			(void) free_memory((BYTE *)table[table_index][0]);
		}

		table[table_index][0] = (WORD *)mem;
		table[table_index][1] = (WORD *)dest->res1; /* atari address */
	}

	(void) free_memory((BYTE *)src);
	(void) free_memory((BYTE *)dest);

} /* vr_trnfm() */
	
WORD clip(startx,starty,endx,endy)
WORD	*startx,*starty,*endx,*endy;
/* clips as necessary, returns non-zero if outside clipping area */
{
	WORD	sx,sy,dx,dy;

	sx = *startx;
	sy = *starty;
	dx = *endx;
	dy = *endy;

	if (WS_INFO->CLIP_FLAG) {
		if (	sx > WS_INFO->CLIP_XMAX ||
			sy > WS_INFO->CLIP_YMAX ||
			dx < WS_INFO->CLIP_XMIN ||
			dy < WS_INFO->CLIP_YMIN ) {
			return (1);
		}

		if (sx < WS_INFO->CLIP_XMIN) sx = WS_INFO->CLIP_XMIN;
		if (sy < WS_INFO->CLIP_YMIN) sy = WS_INFO->CLIP_YMIN;
		if (dx > WS_INFO->CLIP_XMAX) dx = WS_INFO->CLIP_XMAX;
		if (dy > WS_INFO->CLIP_YMAX) dy = WS_INFO->CLIP_YMAX;

	} else {

		if (	sx > SCREEN_XRIGHT ||
			sy > SCREEN_YTOP   ||
			dx < SCREEN_XLEFT  ||
			dy < SCREEN_YBOT   ) {
				return(1);
		}

		if (sx < SCREEN_XLEFT)  sx = SCREEN_XLEFT;
		if (sy < SCREEN_YBOT)   sy = SCREEN_YBOT;
		if (dx > SCREEN_XRIGHT) dx = SCREEN_XRIGHT;
		if (dy > SCREEN_YTOP)   dy = SCREEN_YTOP;

	}

	*startx = sx;
	*starty = sy;
	*endx   = dx;
	*endy   = dy;

	return(0);

} /* clip() */

void vro_cpyfm()
/* Function 109: Copy raster, opaque */
/* UNFINISHED - does not copy off-screen images back to the atari */
{
	MFDB		*src, *dest;
	PIX_OFFSET	sptr, dptr;
	WORD		sx, sy, dx, dy, width, height, op;
	UBYTE		*tmp;
	void RasterOp(	WORD,PIX_OFFSET,WORD,
			WORD,WORD,PIX_OFFSET,WORD,
			WORD *,PIX_OFFSET);


	src  = (MFDB *)(*(WORD *)(CONTRL + 7));
	dest = (MFDB *)(*(WORD *)(CONTRL + 9));

	op   = INTIN[0];

	/* Return values */

	CONTRL[2] = 0;
	CONTRL[4] = 0;

	width  = ABS(PTSIN[0] - PTSIN[2]);
	height = ABS(PTSIN[1] - PTSIN[3]);

	/* test for device - device copy */

	if (src->res1 == 0 && dest->res1 == 0) {

		dx = MIN(PTSIN[4],PTSIN[6]);
		dy = MIN(PTSIN[5],PTSIN[7]);

		sx = dx + width;
		sy = dy + height;

		clip(&dx,&dy,&sx,&sy);

		width  = sx - dx + 1;
		height = sy - dy + 1;

		sx = MIN(PTSIN[0],PTSIN[2]);
		sy = MIN(PTSIN[1],PTSIN[3]);

		/* byte blat copy across screen */

		sptr = OFFSET(sx,sy);
		dptr = OFFSET(dx,dy);

		tmp = (UBYTE *)get_memory((UWORD)(width * height));

		if (tmp == (UBYTE *)NULL) {
			IOdebug("unable to get temporary memory for screen\n");
			return;
		}

		bytblt(	(WORD *)(sptr + SCREEN.MAP),(WORD *)tmp,0,0,
			SCREEN.STRIDE,width,height,width,0);

		switch(op) {

		case VDI_REPLACE:
			bytblt(	(WORD *)tmp,(WORD *)(dptr + SCREEN.MAP),0,0,
				width,SCREEN.STRIDE,height,width,0);
			break;

		default:
			RasterOp( op,ATPO(tmp),width,width,height,
				dptr,SCREEN.STRIDE,OPEN_MASK,0L);
			break;
		}

		(void) free_memory((BYTE *)tmp);

	} else if (src->res1 == 0) {
		/* screen to memory */

		width++;
		height++;

		/* first get your memory */

		tmp = (UBYTE *)get_memory((UWORD)(width * height));

		if (tmp == (UBYTE *)NULL) {
			IOdebug("unable to get off-screen memory\n");
			return;
		}

		/* then calculate starting coordinates */

		sx = MIN(PTSIN[0],PTSIN[2]);
		sy = MIN(PTSIN[1],PTSIN[3]);

		sptr = OFFSET(sx,sy);

		/* copy into off-screen memory */

		switch(op) {

		case VDI_REPLACE:
			bytblt(	(WORD *)(sptr + SCREEN.MAP),(WORD *)tmp,0,0,
				SCREEN.STRIDE,width,height,width,0);
			break;

		default:
			RasterOp( op,sptr,width,width,height,
				ATPO(tmp),SCREEN.STRIDE,OPEN_MASK,0L);
			break;
		}

		/* and store the address in the table */

		if (++table_index >= TABLE_SIZE) table_index = 0;

		if (table[table_index][0]) {

			/* about to overwrite - so free */

			(void) free_memory((BYTE *)table[table_index][0]);
		}

		table[table_index][0] = (WORD *)tmp;
		table[table_index][1] = (WORD *)dest->res1; /* atari address */

	} else {
		/* memory to screen */

		WORD i = table_index;

		width++;
		height++;

		/* locate pointer in table */

		tmp = (UBYTE *)src->res1;

		if (table[i][1] != (WORD *)tmp) {
			do {
				--i;
				if (i < 0) i = TABLE_SIZE - 1;
			} while (i          != table_index &&
				table[i][1] != (WORD *)tmp );

			if (i == table_index) {
				IOdebug("could not find source address %lx\n",
					tmp);

				(void) free_memory((BYTE *)src);
				(void) free_memory((BYTE *)dest);
				return;
			}
		}

		/* calculate the screen position */

		dx = MIN(PTSIN[4],PTSIN[6]);
		dy = MIN(PTSIN[5],PTSIN[7]);

		dptr = OFFSET(dx,dy);

		sptr = (PIX_OFFSET)table[i][0];

		/* and put onto the screen */

		switch(op) {

		case VDI_REPLACE:
			bytblt(	(WORD *)sptr,(WORD *)(dptr + SCREEN.MAP),0,0,
				width,SCREEN.STRIDE,height,width,0);
			break;

		default:
			RasterOp( op,ATPO(sptr),width,width,height,
				dptr,SCREEN.STRIDE,OPEN_MASK,0L);
			break;
		}

	}

	(void) free_memory((BYTE *)src);
	(void) free_memory((BYTE *)dest);

} /* vro_cpyfm() */

void vrt_cpyfm()
/* Function 121: Copy raster, transparent */
{
	WORD		dx,dy,dex,dey,width,height;
	MFDB		*src,*dest;
	PIX_OFFSET	dptr;
	UBYTE		*sptr;
	void RasterOp(	WORD,PIX_OFFSET,WORD,
			WORD,WORD,PIX_OFFSET,WORD,
			WORD *,PIX_OFFSET);

	/* Return values */

	CONTRL[2] = 0;
	CONTRL[4] = 0;

	src  = (MFDB *)(*(WORD *)(CONTRL + 7));
	dest = (MFDB *)(*(WORD *)(CONTRL + 9));

	if (dest->res1) {
		IOdebug("screen to memory not implemented yet!\n");
		IOdebug("dest->res1 = %lx, src->res1 = %lx\n",
			dest->res1,src->res1);
		IOdebug("sx,sy = %d,%d sex,sey = %d,%d\n",
			PTSIN[0],PTSIN[1],PTSIN[2],PTSIN[3]);
		IOdebug("dx,dy = %d,%d dex,dey = %d,%d\n",
			PTSIN[4],PTSIN[5],PTSIN[6],PTSIN[7]);

	} else if (src->planes != 1) {

		IOdebug("too many source planes %d\n",src->planes);

	} else {

		dx  = PTSIN[4];
		dy  = PTSIN[5];
		dex = PTSIN[6];
		dey = PTSIN[7];

		if ( !clip(&dx,&dy,&dex,&dey)) {

			sptr   = (UBYTE *)src->addr;

			sptr  += ((dy - PTSIN[5]) * src->width);

			sptr  += (dx - PTSIN[4]);

			dptr   = OFFSET(dx,dy) + SCREEN.MAP;

			width  = dex - dx + 1;
			height = dey - dy + 1;

			switch (INTIN[0]) {

			case REPLACE:	/* NB check the colour !! */
				bytblt(	(WORD *)sptr,(WORD *)dptr,0,0,
					src->width,SCREEN.STRIDE,
					height,width,0);
				break;

			case TRANSPARENT :	/* NB check the colour !! */

				bytblt(	(WORD *)sptr,(WORD *)dptr,0,0,
					src->width,SCREEN.STRIDE,
					height,width,1);
				break;

			case REV_TRANSPARENT :	/* NB check the colour !! */

				bytblt(	(WORD *)sptr,(WORD *)dptr,0,0,
					src->width,SCREEN.STRIDE,
					height,width,2);
				break;

			case XOR:

				RasterOp( VDI_NOTD,
					ATPO(sptr),src->width,
					width,height,
					ATPO(dptr),SCREEN.STRIDE,
					OPEN_MASK,0L);

				break;

			default:
				IOdebug("bad transparent mode %d\n",INTIN[0]);
				break;
			}
		}
	}

	if (src->addr)  (void)free_memory((BYTE *)src->addr);

	if (dest->addr) (void)free_memory((BYTE *)dest->addr);

	(void)free_memory((BYTE *)src);
	(void)free_memory((BYTE *)dest);

} /* vrt_cpyfm() */

E 1
