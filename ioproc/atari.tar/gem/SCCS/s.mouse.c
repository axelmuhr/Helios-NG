h26410
s 00173/00000/00000
d D 2.1 88/10/26 18:43:27 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/************************************************************************/
/*									*/
/*			  MOUSE.C					*/
/*									*/
/************************************************************************/

#ifdef ATARI_ST_HOST
#include "header.h"

static int	oldx = MOUSE_X,
		oldy = MOUSE_Y;

#define CLIP(val,max)\
((val) = (((val) < 0) ? (0) : (((val) > (max)) ? (max) : (val))))

static void show(oldx,oldy,newx,newy)
int	oldx,oldy,newx,newy;
/* Draw the mouse */
/* Seperate procedure to allow extra register variables */
{
	register char		 	*s_ptr;
	register WORD			*mask_ptr;
	register WORD			*col_ptr;
	register int			j;
	register unsigned BIG_WORD	copy;
	register unsigned WORD		mask,col;
	register WORD			i;
	register WORD			stride;

	stride   = SCREEN.STRIDE - 16;
	s_ptr    = (char *) OFFSET(oldx,oldy) + SCREEN.MAP;
	mask_ptr = SCREEN.G_CUR_COPY;

	for( i = 16; i ; --i) {

		copy = *mask_ptr++;

		for( j = 16; j ; --j) {
	
			SPA((PIX_OFFSET)s_ptr,copy & 1);

			copy >>= 1;
			s_ptr++;
			}

		s_ptr += stride;
	}

	stride   = SCREEN.STRIDE + 16;
	s_ptr    = (char *) OFFSET(newx,newy) + 15 + SCREEN.MAP;
	mask_ptr = SCREEN.G_CUR_PAT;
	col_ptr  = SCREEN.G_CUR_COL;

	for( i = 0; i < 16; i++) {

		mask = *mask_ptr++;
		col  = *col_ptr++;

		for( j = 16; j ; --j) {

			copy <<= 1;
			copy |= RPA((PIX_OFFSET)s_ptr);

			if (mask & 1) SPA((PIX_OFFSET)s_ptr,col & 1);
		
			--s_ptr;
			mask >>= 1;
			col  >>= 1;
		}
	
		SCREEN.G_CUR_COPY[ i ] = (WORD) copy;
		s_ptr += stride;
	}
}

void handler(x,y)
register int x,y;
{
#ifndef NC
	void show();
#else
	void show(WORD,WORD,WORD,WORD);
#endif
	if (!x && !y) return; 

	x += oldx;

	CLIP(x,SCREEN.WIDTH);

	y += oldy;

	CLIP(y,SCREEN.HEIGHT);

	if (WS_INFO->G_ON > 0) {
		show(oldx,oldy,x,y);
	}

	oldx = x;
	oldy = y;
}

void g_cursor_restore()
/* Put the graphics cursor back on the screen */
/* first saving the overwritten section of picture */
{
	register char		 	*s_ptr;
	register WORD			*mask_ptr;
	register WORD			*col_ptr;
	register WORD			j;
	register unsigned WORD		mask,col;
	register unsigned BIG_WORD	copy;
	register WORD			i;
	register WORD			stride;

	stride   = SCREEN.STRIDE + 16;
	s_ptr    = (char *) OFFSET(oldx,oldy) + 15;
	mask_ptr = SCREEN.G_CUR_PAT;
	col_ptr  = SCREEN.G_CUR_COL;

	for( i = 0; i < 16; i++) {

		mask = *mask_ptr++;
		col  = *col_ptr++;

		for( j = 16; j ; --j) {

			copy <<= 1;
			copy |= RPA((PIX_OFFSET)s_ptr);

			if (mask & 1) SPA((PIX_OFFSET)s_ptr,col & 1);
		
			--s_ptr;
			mask >>= 1;
			col  >>= 1;
		}

		SCREEN.G_CUR_COPY[ i ] = (WORD) copy;
		s_ptr += stride;
	}
}

void g_cursor_save()
/* Take the graphics cursor off the screen */
/* Do this by putting back the picture which was under it */
{
	register unsigned WORD	copy;
	register char		*s_ptr;
	register WORD		*copy_ptr;
	register WORD		j,i;
	register WORD		stride;

	stride   = SCREEN.STRIDE - 16;
	s_ptr    = (char *) OFFSET(oldx,oldy);
	copy_ptr = SCREEN.G_CUR_COPY;

	for( i = 16; i ; --i) {

		copy = *copy_ptr++;

		for( j = 16; j ; --j) {

			SPA((PIX_OFFSET)s_ptr,copy & 1);

			copy >>= 1;
			s_ptr++;
		}

		s_ptr += stride;
	}
}

#endif

E 1
