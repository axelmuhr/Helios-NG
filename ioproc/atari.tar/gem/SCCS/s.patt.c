h07746
s 00352/00000/00000
d D 2.1 88/10/26 18:43:31 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
#include "helios.h"
#include "task.h"

#define NUM_6845_REG	16
#define NUM_MODES	4
#define MAP0		0x00000000L
#define MAP1		0x00200000L
#define MAP2		0x00400000L
#define MAP3		0x00600000L

WORD screen_base = MAP1;

extern void bytblt(WORD *,WORD *,WORD,WORD,WORD,WORD,WORD,WORD,WORD);

extern Task	*MyTask;

WORD p_mode[NUM_MODES] = { 0x00,0x20,0x40,0x60 };

WORD v_mode[NUM_MODES] = { 0x13,0x3d,0x37,0x00 };

WORD *pmode =   0x40000000;
WORD *vidmode = 0x40400000;

#define HITACHI		0
#define NEC_PL		1
#define NEC_XL		2

#define MODE0		0
#define MODE1_HITACHI	1
#define MODE1_NEC_PL	2
#define MODE1_NEC_XL	3
#define MODE2_NEC_PL	4
#define MODE2_NEC_XL	5
#define MODE3_NEC_PL	6
#define MODE3_NEC_XL	7

WORD crt[8][16] = { 
/* mode 0 */	{ 42,16,34,0x34,64, 2,60,61,0,15,0x2f,0xf,0x1f,0xe0,0,0 } ,
/* mode 1 */	{ 40,16,33,0x64,49,13,48,48,0,15,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* --"--  */	{ 40,16,37,0x64,49,13,48,48,0,15,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* --"--  */	{ 40,16,36,0x64,49,13,48,48,0,15,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* mode 2 */	{ 42,16,36,0x34,31, 9,30,31,0,15,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* --"--  */	{ 42,16,36,0x34,31, 9,30,31,0,15,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* mode 3 */	{ 50,16,40,0x35,62, 7,60,61,0, 7,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* --"--  */	{ 50,16,40,0x35,62, 7,60,61,0, 7,0x2f,0xf,0x3f,0xe0,0,0 } ,
		 };

WORD *vgaddr = 0x40200000;
WORD *vgreg  = 0x40200004;

void setup6845(index)
WORD index;
{
	register WORD i;

	for (i=0; i < NUM_6845_REG; i++) {

		*vgaddr = i;
		*vgreg  = crt[index][i];
	}
}

void setup_video(mode,monitor)
WORD mode;	/* screen mode 0 - 3 */
WORD monitor;	/* monitor supplied 0 - 2 */
{
	if (mode < 0 || mode >= NUM_MODES) return;

	*pmode   = p_mode[mode];
	*vidmode = v_mode[mode];

	switch (mode) {

		case 0:		setup6845(MODE0);
				break;

		case 1:	switch (monitor) {

				case HITACHI:	setup6845(MODE1_HITACHI);
						break;

				case NEC_PL:	setup6845(MODE1_NEC_PL);
						break;

				case NEC_XL:	setup6845(MODE1_NEC_XL);
						break;

				default:	/* error */
						break;
			}
			break;

		case 2:	switch (monitor) {

				case NEC_PL:	setup6845(MODE2_NEC_PL);
						break;

				case NEC_XL:	setup6845(MODE2_NEC_XL);
						break;

				default:	/* error */
						break;
			}
			break;

		case 3:	switch (monitor) {

				case NEC_PL:	setup6845(MODE3_NEC_PL);
						break;

				case NEC_XL:	setup6845(MODE3_NEC_XL);
						break;

				default:	/* error */
						break;
			}
			break;

		default: /*error */

			break;
	}
}

WORD *vd453wraddraddr = 0x40d00000;
WORD *vd453wrcoladdr  = 0x40d02000;

void set_colour(red,green,blue)
WORD red,green,blue;
{
	*vd453wrcoladdr = red;
	*vd453wrcoladdr = green;
	*vd453wrcoladdr = blue;
}
	
void setup_colour()
{
	WORD i,bias;

	*vd453wraddraddr = 0L;

	set_colour(~0,~0,~0);

	bias = 147;

	for(i=1; i <= 36; i++) {

		set_colour(bias + i*3,0,0);
		set_colour(0,bias + i*3,0);
		set_colour(0,0,bias + i*3);
		set_colour(bias + i*3,bias + i*3,0);
		set_colour(bias + i*3,0,bias + i*3);
		set_colour(0,bias + i*3,bias + i*3);
		set_colour(bias + i*3,bias + i*3,bias + i*3);
	}

	set_colour(~0,0,0);
	set_colour(0,0,~0);
}	

static unsigned long next = 1;

WORD rand(void)
{
	next = next * 1103515245 + 12345;

	return ((WORD)((next >> 16)));
}

int main(void)
{
	void gen_box(void);
	void clear_screen2(void);
	void pattern_show(void);

	setup_video(1,NEC_XL);

	setup_colour();

	clear_screen2();
#ifdef NEVER
	gen_box();
#endif
	pattern_show();
	
	return(1);
}

WORD *array = (WORD *)(MinInt + 1024);
WORD colours[256];

void clear_screen2(void)
{
	WORD i,*ptr = array;
	
	for(i=0;i<256;i++) {
		colours[i] =   i;
		colours[i] <<= 8;
		colours[i] |=  i;
		colours[i] <<= 8;
		colours[i] |=  i;
		colours[i] <<= 8;
		colours[i] |=  i;
		*ptr++ = 0;
	}

	bytblt(array,(WORD *)screen_base,0,0,0,2048,768,1024,0);
}

void draw_box(WORD x,WORD y,WORD width,WORD height,WORD colour)
{
	WORD i,rgb;
	WORD ptr,*tmp;

	if (y + height > 767) return;
	if (x + width > 1023) return;

	width &= ~3;
	height &= ~3;

	rgb = colours[colour & 0xff];

	tmp = array;

	for(i=0; i <width/4; i++) *tmp++ = rgb;

	ptr = screen_base;

	ptr += 2048 * y + x;

	ptr += 3;

	ptr &= ~3;

	bytblt(array,(WORD *)ptr ,0,0,0,2048,height,width,0);
}

void gen_box(void)
/* put a square on the screen */
{
	WORD x,y;
	WORD width,height;
	WORD rand(void);
	void draw_box(WORD,WORD,WORD,WORD,WORD);

	for (;;) {

		x = rand() & 0x3ff;

		y = rand() % 768;

		width = (rand() & 0xff) + 70;
	
		height = (rand() & 0xff) + 70;

		draw_box(x, y, width, height, rand() & 0xff);
	}
}

#define min(a,b)	( (a) < (b) ? (a) : (b))

void pattblat(s_ptr,s_width,s_height,d_ptr,d_width,d_height,colour)
WORD s_ptr;	/* pointer to source of pattern */
WORD s_width;	/* source width in bytes */
WORD s_height;	/* source height in lines */
WORD d_ptr;	/* destination (screen) pointer */
WORD d_width;	/* destrination width in pixels (bytes) */
WORD d_height;	/* destination height in lines */
UBYTE colour;	/* colour of set pixels in the pattern */
{
	UBYTE	*sptr,dptr,count,count2;
	WORD	height,width,patt;
	UWORD	mask;

	/* copy pattern onto screen */

	width  = min(s_width,d_width);
	height = min(s_height,d_height);

	dptr = d_ptr;

	for(count = 0; count < height; count++) {
		mask = 0x80000000L;
		patt = *((WORD *)s_ptr);
		
		for(count2 = 0; count2 < width; count2++) {

			if (mask & patt) *((unsigned char *)(dptr)) = colour;
			else 	         *((unsigned char *)(dptr)) = 0;

			dptr++;
			mask >>= 1;
		}

		dptr += 2048 - width;
		s_ptr++;
	}

	/* now copy pattern across screen */

	if (width < d_width) {
		WORD itterations;

		itterations = d_width / s_width - 1;

		sptr = d_ptr;

		for (count = 0; count < height; count++) {

			dptr = (unsigned char *)(sptr + s_width);

			bytblt(sptr,dptr,0,0,0,s_width,itterations,s_width,0);

			dptr += itterations * s_width;

			/* copy remainder of line */

			bytblt(sptr,dptr,0,0,0,0,1,d_width % s_width,0);

			sptr += 2048;
		}
	}
	
	/* now copy down rest of screen .... */

	if (height < d_height) {

		dptr = d_ptr + s_height * 2048;
		
		bytblt(sptr,dptr,0,0,2048,2048,d_height - s_height,d_width,0);
	}
}

WORD patt[2][4] = {
	{ 0xf0f0f0f0,0x0f0f0f0f } ,
	{ 0x88888888,0x44444444,0x22222222,0x11111111 } 
	};

void pattern_show(void)
{
	WORD dest;
	void pattblat(WORD,WORD,WORD,WORD,WORD,WORD,UBYTE);

	dest = 200 + 100 * 2048 + screen_base;

	pattblat((WORD)patt[0],4,2,dest,100,100,254);
#ifdef NEVER
	dest = 500 + 700 * 2048 + screen_base;

	pattblat((WORD)patt[1],4,4,dest,200,300,253);
#endif
}
E 1
