h37799
s 01472/00000/00000
d D 2.1 88/10/26 18:44:28 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/************************************************************************/
/*									*/
/*				TEXT.C					*/
/*			ATARI GRAPHICS LIBRARY				*/
/*			TEXT OUTPUT FUNCTIONS  (Section 4)		*/
/*									*/
/************************************************************************/

/* FUNCTIONS IN THIS MODULE:						*/
/*									*/
/*  FUNCTION	DESCRIPTION		NAME		MANUAL SECTION	*/
/*	 8:	Text 			v_gtext			4	*/
/*	 11:	Generalised Drawing Primitive			4	*/
/*					v_justified			*/

#include <message.h>
#include <task.h>

#define NO_DEFINES

#include "header.h"
#include "stextra.h"

extern UBYTE block[BUF_SIZE];

FONT	*fonts[3];

BYTE	*text_array;

#define B0	0x00000000L
#define B1	0x80000000L
#define B2	0x40000000L
#define B3	0x20000000L
#define B4 	0x10000000L
#define B5	0x08000000L
#define B6	0x04000000L
#define B7	0x02000000L
#define B8	0x01000000L
#define B9	0x00800000L
#define B10	0x00400000L
#define B11	0x00200000L
#define B12	0x00100000L
#define B13	0x00080000L
#define B14	0x00040000L
#define B15	0x00020000L
#define B16	0x00010000L

extern	Task *MyTask;

WORD	inter_char_spacing = 0;

void v_gtext()
/* Writes graphics text to the display */
{
	void show_text(WORD);

	show_text(CONTRL[3] * WS_INFO->TEXT_CELL_WIDTH);

	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_gtext() */

void v_justified()
{
	WORD	i, j, k, space, insert, remove, inword, words = 0;
	WORD	interword, intraword, excess = 0, length;
	UBYTE	tmp[MAX_POINTS];
	void	show_text(WORD);
	WORD	is_alpha(UBYTE);

	interword = INTIN[0];
	intraword = INTIN[1];

	length    = PTSIN[2];

	/* Return values */
	CONTRL[2] = CONTRL[4] = 0;

	if (interword) {
		/* modify inter word spacing */

		/* determin amount of space to be inserted */

		space = length / WS_INFO->TEXT_CELL_WIDTH - (CONTRL[3] - 2);

		if (space != 0) {
			inword = words = 0;

			/* find out how many words there are in the string */

			for(i = 2; i < CONTRL[3]; i++) {

				tmp[i] = (UBYTE)(INTIN[i] & 0xff);

				if (!is_alpha(tmp[i])) {

					inword = 0;

				} else if (!inword) {

					inword = 1;
					words++;
				}
			}
		}

		if (words > 1) {

			if (space > 0) {

				if (intraword) {
					excess = length - (
						(CONTRL[3] - 2 + space) *
						WS_INFO->TEXT_CELL_WIDTH);
				}

				--words;

				inword = 1;

				for( j = i = 2; i < CONTRL[3]; i++) {

					INTIN[j++] = (WORD)(tmp[i]);

					if (is_alpha(tmp[i])) {

						inword = 1;

					} else if (inword) {

						inword = 0;
						insert = space / words;
						space -= insert;
						--words;
						for(k = insert; k ; --k) {
							INTIN[j++] = ' ';
						}
					}
				}

				CONTRL[3] = j;

			} else {
				/* must remove spaces from between words */

				--words;

				space = -space;

				inword = 1;

				for( j = i = 2; i < CONTRL[3]; i++) {

					INTIN[j++] = (WORD)(tmp[i]);

					if (is_alpha(tmp[i])) {

						inword = 1;

					} else if (inword) {

						inword = 0;
						remove = space / words;
						--words;
						for(	k = remove;
							k && !is_alpha(tmp[i]);
							 --k) {
								i++;
						}
						space -= remove - k;
						if (remove) {
							--j;
							--i;
						}
					}
				}

				/* Officially this ought to be calculated */
				/* even if intraword adjustment is not    */
				/* allowed, but the character spacing     */
				/* adjustment should be restricted to     */
				/* the ends of words.  This would mean    */
				/* a major rewriting of the text and      */
				/* justification routines, and also       */
				/* contravenes the spirit of restricting  */
				/* inter-character adjustment.            */
				if (intraword && space) {
					/* allow for unremoved space */
					excess = -space *
						WS_INFO->TEXT_CELL_WIDTH;
				}

				CONTRL[3] = j;
			}
		}
	}

	if (intraword) {
		/* set intraword spacing flag */
		if (interword) {

			inter_char_spacing = excess;

		} else {

			inter_char_spacing = length -
				(CONTRL[3] - 2) * WS_INFO->TEXT_CELL_WIDTH;
		}
	} else {

		inter_char_spacing = 0;
	}

	for (i = 2; i < CONTRL[3]; i++) {

		INTIN[i - 2] = INTIN[i];
	}

	CONTRL[3] -= 2;

	show_text(length);

} /* v_justified */


/******************************************************************************/
/*									      */
/*				Local Functions				      */
/*									      */
/******************************************************************************/

WORD is_alpha(UBYTE ch)
/* returns non zero iff ch is alpha-numeric */
{
	if (	             ch < 48  ||
		(ch > 57  && ch < 65) ||
		(ch > 90  && ch < 97) ||
		(ch > 122           )  ) {

			return(0);
	} else {
			return(~0);
	}

} /* is_alpha() */

void accept_fonts()
/* accept a font across the atari - transputer link */
{
	WORD 	i;
	MCB	mcb;
	WORD 	GetMsg(MCB *);
	void	receive_font(UBYTE *);
	void	sendm(WORD, UBYTE *, WORD);
	void	construct(FONT *);

	for (i = 0; i < 3; i++) {

		/* Indicate we want a font now */
		sendm(0,block,SEND_FONT);

		mcb.Data	= (BYTE *)block;
		mcb.MsgHdr.Dest = MyTask->Port;
		mcb.Timeout	= 20000000;

		while(GetMsg(&mcb) < 0) ;

		receive_font(block);
	}

	construct(fonts[2]);

} /* accept_fonts() */

void receive_font(UBYTE *start)
{
	FONT	*to;
	WORD 	number;
	WORD	i,j;
	UBYTE	*ptr,tmp;

	number = *start++;

	fonts[number] = (FONT *)get_memory((UWORD)sizeof(FONT));

	to = fonts[number];

	if (to == (FONT *)NULL) {
		IOdebug("\n\nunable to get memory for a font\n\n");
		return;
	}

	to->font_low_ade     = *start++;
	to->font_hi_ade      = *start++;
	to->font_top_dst     = *start++;
	to->font_ascent_dst  = *start++;
	to->font_half_dst    = *start++;
	to->font_descent_dst = *start++;
	to->font_bottom_dist = *start++;
	to->font_fatest      = *start++;
	to->font_thickening  = *start++;
	to->font_underline   = *start++;
	to->font_lightening  = *start++;
	to->font_lightening  <<= 8;
	to->font_lightening  |= *start++;
	to->font_width       = *start++;
	to->font_width       <<= 8;
	to->font_width       |= *start++;
	to->font_height      = *start++;

	/* now get char_offset table */

	number = to->font_hi_ade - to->font_low_ade + 1;

	to->font_char_off = (WORD *)get_memory(
		(UWORD)(number * sizeof(WORD)));

	if (to->font_char_off == (WORD *)NULL) {
		IOdebug("unable to get memory for character offset tablen\n");
		return;
	}

	ptr = (UBYTE *)(to->font_char_off);

	/* NB must swap bytes to allow for byte ordering */

	for(i = 0; i < number; i++) {		

		tmp    = *start++;
		*ptr++ = *start++;
		*ptr++ = tmp;
	}

	to->font_data = get_memory((UWORD)
		(to->font_width * to->font_height * sizeof(BYTE)));

	if (to->font_data == (BYTE *)NULL) {
		IOdebug("unable to get memory for font data\n");
		return;
	}

	ptr = (UBYTE *)(to->font_data);

	for(j = 0; j < to->font_height; j++) {

		for(i = 0; i < to->font_width; i++) {

			*ptr++ = *start++;
		}
	}

} /* receive_font() */ 

void construct(FONT *font)
/* construct a screen image version of the large font */
{
	WORD	ch,c_ptr,x,j,line;
	BYTE	*text,*m_ptr,fg;

	m_ptr = text = get_memory((UWORD)(256 * 16 * 8));

	if (text == (BYTE *)NULL) {
		IOdebug("construct unable to get memory\n");
		return;
	}

	fg = 1;

	for (ch = 0; ch < 256; ch++) {

		/* point to a characters information */

		c_ptr = *(font->font_char_off + ch / 2);

		if (ch & 1) c_ptr >>= 16;

		c_ptr &= 0xffff;

		c_ptr >>= 3;

		for (j = 0; j < 16; j++) {

			line = *(font->font_data + c_ptr);

			line &= 0xff;

			c_ptr +=font->font_width;

			/* now put this model into the array */

			for (x = 8; x ; --x) {
				if (line & 0x80) {
					*m_ptr++ = fg;
				} else {
					*m_ptr++ =  0;
				}
				line <<= 1;
			}
		}
	}

	text_array = text;

} /* construct() */
	
void rotate(UWORD *model,WORD *cheight,WORD *cwidth)
/* rotate the character in model */
{
	BYTE 	j,k;
	UWORD 	jmask,kmask,line;
	UWORD 	fig[32];
	
	switch(WS_INFO->TEXT_ANGLE) {

		default:	break;

		case 900: 	/* rotate north */

			line = ~((UWORD)0xffffffffL >> *cwidth);

			for(j = 0 ; j < 32 ; j++){
				fig[j] = ( model[j] & line );
				model[j] = 0x0L;
			}

			for(	j = 0 ,
				jmask = ((UWORD)0x80000000L);
				j < *cheight;
				j++ ,
				jmask >>= 1) {

				line = fig[j];

				if (!line) continue;

				for(	k = *cwidth - 1,
					kmask = ((UWORD)0x80000000L);
					k >= 0;
					--k ,
					kmask >>= 1) {
					if (line & kmask) model[k] |= jmask;
				}
			}

			j = *cwidth;
			*cwidth = *cheight;
			*cheight = j; 

			break;

		case 1800: 	/* rotate west */

			line = ~((UWORD)0xffffffffL >> *cwidth);

			for(j = 0 ; j < 32 ; j++){
				fig[j] = ( model[j] & line );
				model[j] = 0x0L;
			}

			for(	j = *cheight - 1 ;
				j >= 0;
				--j ) {

				line = fig[ *cheight - j - 1 ];

				if (!line) continue;

				for(	k = *cwidth ,
					kmask = ((UWORD)0x80000000L) ,
					jmask = ((UWORD)0x80000000L) >>
						(*cwidth - 1);
					k ;
					--k ,
					kmask >>= 1 ,
					jmask <<= 1) {
					if (line & kmask) model[ j ] |= jmask;
				}
			}
			break;

		case 2700: 	/* rotate south */

			line = ~((UWORD)0xffffffffL >> *cwidth);

			for(j = 0 ; j < 32 ; j++){
				fig[j] = ( model[j] & line );
				model[j] = 0x0L;
			}

			for(	j = *cheight - 1 ,
				jmask = ((UWORD)0x80000000L);
				j >= 0;
				--j ,
				jmask >>= 1) {

				line = fig[j];

				if (!line) continue;

				for(	k = 0 ,
					kmask = ((UWORD)0x80000000L);
					k < *cwidth;
					k++ ,
					kmask >>= 1) {
					if (line & kmask) model[k] |= jmask;
				}
			}

			j = *cwidth;
			*cwidth = *cheight;
			*cheight = j; 

			break;
	}

} /* rotate() */

void size(WORD *width,WORD *height)
/* Determine the size of the rectangle occupied by the text */
{
	*width = WS_INFO->TEXT_CELL_WIDTH * CONTRL[3];

	*height = WS_INFO->TEXT_CELL_HEIGHT;

	if (WS_INFO->TEXT_EFFECT & ITALIC) {
		*width += ((*height >> 1) - 1);
	}

	if (WS_INFO->TEXT_EFFECT & OUTLINE) {
		*height += 2;
		*width  += 2 * CONTRL[3];
	}

	if (WS_INFO->TEXT_ANGLE == 900 || WS_INFO->TEXT_ANGLE == 2700) {
		register WORD	tmp;

		tmp = *height;
		*height = *width;
		*width = tmp;
	}

} /* size() */

void show_text(WORD length)
/* length is the expected length of the text */
{
	WORD	xpos, ypos, width, height;
	WORD	i, j, k, count, extra, chars;
	WORD	top, bot, left, right;
	UBYTE	ch;
	WORD	ch_ptr, shift, dptr;
	WORD	char_width, font_width_in_bytes;
	WORD	fheight, cheight, xoff, yoff;
	UBYTE	*temp;
	UWORD	scanline;
	PIX_OFFSET	const_pix_offset;
	UWORD	m_ptr[36], *colour_array, model[36];
	UWORD	dup, mask, lightmask, tmp;
	FONT	*font;
	UWORD	*get_screen_lookalike(WORD);
	void	blkload(UWORD *,WORD,WORD);
	void	RasterOp( WORD,PIX_OFFSET,WORD,
			  WORD,WORD,PIX_OFFSET,WORD,
			  UWORD *,PIX_OFFSET);
	void 	rotate(UWORD *,WORD *,WORD *);
	void	size(WORD *,WORD *);
	WORD	clip(WORD *,WORD *,WORD *,WORD *);
	void	v_pline(void);

	/* Check that the font is available */

	if (	WS_INFO->TEXT_FACE < SCREEN.MINFONTNUM ||
		WS_INFO->TEXT_FACE > SCREEN.MAXFONTNUM ) return;

	/* Point to the font */

	font    = fonts[WS_INFO->TEXT_FACE];

	fheight = font->font_height;
	cheight = WS_INFO->TEXT_CELL_HEIGHT;

	/* Alignment point of text */

	{
		WORD	base;

		width  = WS_INFO->TEXT_CELL_WIDTH;
		height = WS_INFO->TEXT_CELL_HEIGHT;

		switch (WS_INFO->TEXT_ALIGN[1]) {

			case ASCENT_LINE:
				base = font->font_ascent_dst * height /
					font->font_height;
				break;

			case HALF_LINE:	
				base = font->font_half_dst * height /
					font->font_height;
/*				base = height / 2;		*/
				break;

			case BASELINE:

				base   = font->font_bottom_dist;
				if (width == 16) base += 1;
				if (height > 11) base -= 1;
				break;

			case DESCENT_LINE:	/* UNFINISHED */

				base = font->font_descent_dst * height /
					font->font_height;
				break;

			case BOTTOM_LINE:

				base = 0;
				break;

			case TOP_LINE:

				base = font->font_top_dst * height /
					font->font_height;
/*				base = height;		*/
				break;

			default:
				IOdebug("bad vertical alignment\n");
				break;
		}

		switch (WS_INFO->TEXT_ANGLE) {

			default:	xpos = PTSIN[0];
					ypos = PTSIN[1] + base;
					break;

			case 900:	xpos = PTSIN[0] - height + base + 1;
					ypos = PTSIN[1];
					break;
	
			case 1800:	xpos = PTSIN[0] - width;
					ypos = PTSIN[1] + height - base - 1;
					break;

			case 2700:	xpos = PTSIN[0] - base;
					ypos = PTSIN[1] + width;
					break;
		}
		/* now allow for horozontal alignement */

		switch (WS_INFO->TEXT_ALIGN[0]) {

		case LEFT:	break;

		case CENTER:	xpos -= length/2;
				break;

		case RIGHT:	xpos -= length;
				break;
		}
	}

#ifdef NEVER
	/* Allow for extra height if the characters are in outline mode */

	if (WS_INFO->TEXT_EFFECT & OUTLINE) {
		top -= 2;
	}
#endif

	/* Set all words to the current text color */
	/* we assume the widest character in the font is <= 32 */

	colour_array     = get_screen_lookalike(32);
	if (colour_array == (UWORD *)NULL) return;
	const_pix_offset = ATPO(colour_array);

	/* Put a background in for italic characters in REPLACE mode */
	/* and all characters in REV_TRANSPARENT mode */

	if (	( (WS_INFO->TEXT_EFFECT & ITALIC ) && 
		  (WS_INFO->WRITE_MODE == REPLACE)  ) ||
	     	WS_INFO->WRITE_MODE == REV_TRANSPARENT ) {

		WORD tmpx,tmpy,x,y;
		
		size(&tmpx,&tmpy);

		if (WS_INFO->WRITE_MODE == REPLACE) {
			blkload(colour_array,32,0);
		} else {
			blkload(colour_array,32,WS_INFO->TEXT_COLOR_INDEX);
		}
	
		if (WS_INFO->TEXT_ANGLE == 1800) {
			x = xpos + tmpy - tmpx;
			y = ypos - tmpy;
		} else if (WS_INFO->TEXT_ANGLE == 2700) {
			x = xpos;
			y = ypos - tmpx;
		} else {
			x = xpos;
			y = ypos - tmpy;
		}

		if (WS_INFO->WRITE_MODE == REV_TRANSPARENT &&
		    !(WS_INFO->TEXT_EFFECT & ITALIC)) {
			if (WS_INFO->TEXT_ANGLE == 900) {
				x = xpos - 1;
				y = ypos - tmpy;
			} else if (WS_INFO->TEXT_ANGLE == 1800) {
				x = xpos - tmpy - 1;
				y = ypos - tmpy + 1;
			} else if (WS_INFO->TEXT_ANGLE == 2700) {
				x = xpos;
				y = ypos - tmpy + tmpx + 1;
			}
		}

		tmpx = x + tmpx;
		tmpy = y + tmpy;

		(void) clip(&x,&y,&tmpx,&tmpy);

#ifdef NEVER
		if (WS_INFO->CLIP_FLAG) {

			if (y < WS_INFO->CLIP_YMIN)
				y = WS_INFO->CLIP_YMIN;
			
			if (tmpy > WS_INFO->CLIP_YMAX)
				tmpy = WS_INFO->CLIP_YMAX;

			if (x < WS_INFO->CLIP_XMIN)
				x = WS_INFO->CLIP_XMIN;

			if (tmpx > WS_INFO->CLIP_XMAX)
				tmpx = WS_INFO->CLIP_XMAX;
		
		} else {

			if (y < SCREEN_YBOT)		y = SCREEN_YBOT;

			if (tmpy > SCREEN_YTOP)		tmpy = SCREEN_YTOP;

			if (x < SCREEN_XLEFT)		x = SCREEN_XLEFT;

			if (tmpx > SCREEN_XRIGHT)	tmpx = SCREEN_XRIGHT;
		}
#endif

		RasterOp(	VDI_REPLACE,
				const_pix_offset,0,
				tmpx - x + 1,tmpy - y + 1,
				OFFSET(x,y),SCREEN.STRIDE,
				(UWORD *)OPEN_MASK,0);
	}

	/* now draw an underline if the text is italic */

	if ((WS_INFO->TEXT_EFFECT & ITALIC) &&
		(WS_INFO->TEXT_EFFECT & UNDERLINE)) {

			/* calculate length of line as if italic was not on */

			WS_INFO->TEXT_EFFECT &= ~ITALIC;

			size(&width,&height);

			WS_INFO->TEXT_EFFECT |= ITALIC;

			xpos = PTSIN[0];
			ypos = PTSIN[1];

			width  = xpos + width - 1;
			height = ypos;
			
			if (!clip(&xpos,&ypos,&width,&height)) {

				/* go ahead and draw */

				WORD	tmp_contrl,tmp_width,tmp_colour,
					tmp_type,tmp_style0,tmp_style1,
					tmp_mask;

				PTSIN[0] = xpos;
				PTSIN[1] = ypos;
				PTSIN[2] = width;
				PTSIN[3] = height;

				CONTRL[1]  = 2;
				tmp_contrl = CONTRL[3];
				CONTRL[3]  = 0;

				tmp_width  = WS_INFO->LINE_WIDTH;
				tmp_colour = WS_INFO->LINE_COLOR_INDEX;
				tmp_type   = WS_INFO->LINE_TYPE;
				tmp_style0 = WS_INFO->LINE_END_STYLE[0];
				tmp_style1 = WS_INFO->LINE_END_STYLE[1];
				tmp_mask   = WS_INFO->LINE_MASK;

				WS_INFO->LINE_WIDTH        = 1;
				WS_INFO->LINE_COLOR_INDEX  = WS_INFO->TEXT_COLOR_INDEX;
				WS_INFO->LINE_TYPE         = 1;
				WS_INFO->LINE_END_STYLE[0] = 0;
				WS_INFO->LINE_END_STYLE[1] = 0;
				WS_INFO->LINE_MASK         = LINE_PATTERNS[1];

				v_pline();

				WS_INFO->LINE_WIDTH        = tmp_width;
				WS_INFO->LINE_COLOR_INDEX  = tmp_colour;
				WS_INFO->LINE_TYPE         = tmp_type;
				WS_INFO->LINE_END_STYLE[0] = tmp_style0;
				WS_INFO->LINE_END_STYLE[1] = tmp_style1;
				WS_INFO->LINE_MASK         = tmp_mask;

				CONTRL[3] = tmp_contrl;
			}
	}

	/* Load with the appropriate foreground colour */
	/* Note that background has already been drawn for REV_TRANSPARENT */

	if (WS_INFO->WRITE_MODE == REV_TRANSPARENT) {
		blkload(colour_array,32,0);
	} else {
		blkload(colour_array,32,WS_INFO->TEXT_COLOR_INDEX);
	}

	/* font width is already in bytes */

	font_width_in_bytes = font->font_width;

	/* So for each character... */

	if (	  cheight == 16 		&& 
		  inter_char_spacing == 0       &&
		!(WS_INFO->TEXT_EFFECT) 	&&
		!(WS_INFO->TEXT_ANGLE)  	&&
		 (WS_INFO->TEXT_COLOR_INDEX == 1)) {

		for (i = 0; i < CONTRL[3]; i++) {

			xoff = yoff = 0;

			ch = INTIN[i] & 0xff;	/* extract the character */

			top   = ypos - 15;
			bot   = ypos;
			left  = xpos;
			right = xpos + 7;

			if (WS_INFO->CLIP_FLAG) {

				if (	top   > WS_INFO->CLIP_YMAX ||
					bot   <	WS_INFO->CLIP_YMIN ||
					left  > WS_INFO->CLIP_XMAX ||
					right < WS_INFO->CLIP_XMIN ) {

						xpos += 8;

						continue; /* do next char */
				}	

				if (top < WS_INFO->CLIP_YMIN) {
					yoff = WS_INFO->CLIP_YMIN - top;
					top  = WS_INFO->CLIP_YMIN;
				}
		
				if (bot > WS_INFO->CLIP_YMAX)
					bot = WS_INFO->CLIP_YMAX;

				if (left < WS_INFO->CLIP_XMIN) {
					xoff = WS_INFO->CLIP_XMIN - left;
					left = WS_INFO->CLIP_XMIN;
				}

				if (right > WS_INFO->CLIP_XMAX)
					right = WS_INFO->CLIP_XMAX;
			} else {

				if (	top   > SCREEN_YTOP ||
					bot   < SCREEN_YBOT ||
					left  > SCREEN_XRIGHT ||
					right < SCREEN_XLEFT ) {

						xpos += 8;

						continue; /* do next char */
				}

				if (top < SCREEN_YBOT) {
					yoff = SCREEN_YBOT - top;
					top  = SCREEN_YBOT;
				}

				if (bot > SCREEN_YTOP)
					bot = SCREEN_YTOP;

				if (left < SCREEN_XLEFT) {
					xoff = SCREEN_XLEFT - xoff;
					left = SCREEN_XLEFT;
				}

				if (right > SCREEN_XRIGHT)
					right = SCREEN_XRIGHT;
			}

			dptr = OFFSET(left,top) + SCREEN.MAP;

			bytblt( (WORD *)(text_array + ch * 8 * 16 + yoff * 8),
				(WORD *)dptr,xoff,0,8,SCREEN.STRIDE,
				bot - top + 1,right - left + 1,
				WS_INFO->WRITE_MODE - 1);

			xpos += 8;

		}
			(void) free_memory((BYTE *)colour_array);

			return;

	} /* end of fast text if */

	chars = CONTRL[3] - 1;

	for (i = 0; i < CONTRL[3]; i++) {

	/* Check character is valid: if not, force error character */
		ch = INTIN[i] & 0xff;	/* extract the character */
		if (ch < font->font_low_ade) ch = ERRORCHAR;
		if (ch > font->font_hi_ade)  ch = ERRORCHAR;

	/* point to start of first scan line of the character */

		j = ch - font->font_low_ade;

		ch_ptr = *(font->font_char_off + j / 2);

		if (j & 1) ch_ptr >>= 16;

		ch_ptr &= 0xffff;

	/* shift remains constant between scan-lines */
		shift = ch_ptr & 0x7;

	/* calculate the first byte offset */
		ch_ptr = ch_ptr >> 3;

		for (j = 0; j < fheight; j++) {

			temp = (UBYTE *)(font->font_data + ch_ptr);

		/* pull out the correct bits */
			scanline = ((WORD)(*temp) << 24) & 0xff000000L;
			scanline = scanline | (((WORD)(*(temp + 1)) << 16)
				& 0x00ff0000L);
			scanline = scanline | (((WORD)(*(temp + 2)) << 8) 
				& 0x0000ff00L);
			scanline = scanline | (((WORD)(*(temp + 3))) & 0x000000ffL);
			scanline= scanline << shift;

		/* move the scan line into our local array */
			mask = ~(0xffffffffL << (shift));
			m_ptr[j]= scanline | (((WORD)(*(temp+4)) >>
				(BYTE_SIZE - shift)) & mask);

		/* advance to next scan line */
			ch_ptr += font_width_in_bytes;
		}

	/* we have extracted the character from the font */

	/* now we must stretch it to fit the cell width */
	/* note we assume a font width of 8 */

		char_width = WS_INFO->TEXT_CELL_WIDTH;

		switch (char_width) {

			/* UNFINISHED - should be more compact */

			case 7:	for (j = 0; j < fheight; j++) {
					tmp = m_ptr[j];
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x0fffffffL;
					tmp      &= 0xf0000000L;
					m_ptr[j] |= tmp;
				}
				break;

			case 9:	for (j = 0; j < fheight; j++) {
					tmp = m_ptr[j];
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x07ffffffL;
					tmp      &= 0xf8000000L;
					m_ptr[j] |= tmp;
				}
				break;

			case 10: for (j =0; j < fheight; j++) {
					tmp = m_ptr[j];
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x01ffffffL;
					tmp      &= 0xfe000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x0fffffffL;
					tmp      &= 0xf0000000L;
					m_ptr[j] |= tmp;
				}
				break;

			case 11: for (j = 0; j < fheight; j++) {
					tmp = m_ptr[j];
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x01ffffffL;
					tmp      &= 0xfe000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x07ffffffL;
					tmp      &= 0xf8000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x1fffffffL;
					tmp      &= 0xe0000000L;
					m_ptr[j] |= tmp;
				}
				break;

			case 12: for (j = 0; j < fheight; j++) {
					tmp = m_ptr[j];
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x01ffffffL;
					tmp      &= 0xfe000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x07ffffffL;
					tmp      &= 0xf8000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x1fffffffL;
					tmp      &= 0xe0000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x7fffffffL;
					tmp      &= 0x80000000L;
					m_ptr[j] |= tmp;
				}
				break;

			case 13: for (j = 0; j < fheight; j++) {
					tmp = m_ptr[j];
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x00ffffffL;
					tmp      &= 0xff000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x07ffffffL;
					tmp      &= 0xf8000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x0fffffffL;
					tmp	 &= 0xf0000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x3fffffffL;
					tmp      &= 0xc0000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x7fffffffL;
					tmp      &= 0x80000000L;
					m_ptr[j] |= tmp;
				}
				break;

			case 15: for (j = 0; j < fheight; j++) {
					tmp = m_ptr[j];
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x01ffffffL;
					tmp      &= 0xfe000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x03ffffffL;
					tmp      &= 0xfc000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x07ffffffL;
					tmp      &= 0xf8000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x0fffffffL;
					tmp      &= 0xf0000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x1fffffffL;
					tmp      &= 0xe0000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x3fffffffL;
					tmp      &= 0xc0000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0xffffffffL;
					tmp      &= 0x00000000L;
					m_ptr[j] |= tmp;
				}
				break;

			case 16: for (j = 0; j < fheight; j++) {
					tmp = m_ptr[j];
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x00ffffffL;
					tmp      &= 0xff000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x01ffffffL;
					tmp      &= 0xfe000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x03ffffffL;
					tmp      &= 0xfc000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x07ffffffL;
					tmp      &= 0xf8000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x0fffffffL;
					tmp      &= 0xf0000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x1fffffffL;
					tmp      &= 0xe0000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x3fffffffL;
					tmp      &= 0xc0000000L;
					m_ptr[j] |= tmp;
					m_ptr[j] >>= 1;
					m_ptr[j] &= 0x7fffffffL;
					tmp      &= 0x80000000L;
					m_ptr[j] |= tmp;
				}
				break;
			default:	for (j = 0; j < fheight; j++) {
					m_ptr[j] &= 0xff000000L;
				} /* FINE TUNE - char width > 8 */
				break;
					/* UNFINISHED */
		}

	/* next we must grow or shrink it to fit the cell height */

	switch (cheight) {

			/* Deal with reductions in height first */

	case 4:		model[0] = m_ptr[0];
			model[1] = m_ptr[2];
			model[2] = m_ptr[3];
			model[3] = m_ptr[4];
			break;

	case 5:		model[0] = m_ptr[0];
			model[1] = m_ptr[1];
			model[2] = m_ptr[2];
			model[3] = m_ptr[3];
			model[4] = m_ptr[5];
			break;

	case 13:	model[0] = m_ptr[0];
			model[2] = m_ptr[2];
			model[3] = m_ptr[3];
			model[4] = m_ptr[4];
			model[5] = m_ptr[6];
			model[6] = m_ptr[7];
			model[7] = m_ptr[8];
			model[8] = m_ptr[9];
			model[9] = m_ptr[10];
			model[10] = m_ptr[12];
			model[11] = m_ptr[13];
			model[12] = m_ptr[14];
			model[13] = m_ptr[15];
			break;

	case 14:	model[0] = m_ptr[0];
			model[2] = m_ptr[2];
			model[3] = m_ptr[3];
			model[4] = m_ptr[4];
			model[5] = m_ptr[6];
			model[6] = m_ptr[7];
			model[7] = m_ptr[8];
			model[8] = m_ptr[9];
			model[9] = m_ptr[10];
			model[10] = m_ptr[11];
			model[11] = m_ptr[12];
			model[12] = m_ptr[13];
			model[13] = m_ptr[14];
			model[14] = m_ptr[15];
			break;

			/* Now deal with growth in height */

	default:	switch (cheight) {

			case 6:		dup = B0;
					break;
			case 7:		dup = B3;
					break;
			case 8:		dup = B0;
					break;
			case 9:		dup = B4;
					break;
			case 10:	dup = B5 | B8;
					break;
			case 11:	dup = B4 | B6 | B8;
					break;
			case 16:	if (char_width == 16) {
						dup = B0;
					} else {
						dup = B16;
					}
					break;
			case 17:	dup = B10 | B16;
					break;
			case 18:	dup = B3 | B8 | B16;
					break;
			case 19:	dup = B7 | B10 | B13 | B16;
					break;
			case 21:	dup = B3 | B6 | B9 | B12 | B15;
					break;
			case 22:	dup = B6 | B8 | B10 | B12 | B14 | B16;
					break;
			case 23:	dup = B2 | B4 | B6 | B8 | B10 | B12 |
					B14;
					break;
			case 24:	dup = B1 | B3 | B5 | B7 | B9 | B11 |
					B13 | B15;
					break;
			case 32:	dup = B1 | B2 | B3 | B4 | B5 | B6 | B7 |
					B8 | B9 | B10 | B11 | B12 | B13 | B14 |
					B15 | B16;
					break;
			default:	IOdebug("size error! =  %d\n",cheight);
					dup = B0;
					break;
			}

		k = 0;
		mask = ((UWORD)0x80000000L);

		for (j = 0; j < cheight; j++) {
			model[j] = m_ptr[k];
			if (!(mask & dup)) k++;
			mask >>= 1;
		}
		break;
				/* UNFINISHED */
	}

	/* now perform other special effects */

	if (WS_INFO->TEXT_EFFECT & BOLD) {
		lightmask = (UWORD)0xffffffffL;
		lightmask >>= char_width;

		for (j = 0; j < cheight; j++) {
			model[j] &= ~lightmask;
			model[j] |= (model[j] >> 1);
		}
	}
			
	if (WS_INFO->TEXT_EFFECT & ITALIC) {
		count = (cheight >> 1) - 1;
		char_width += count;

		mask = ((UWORD)0xffffffffL);
		mask >>= char_width;
		mask = ~mask;

		for ( j = 0; j < cheight; j++ ) {
			model[j] >>= count;
			model[j] &= mask;
			count -= (j & 0x1);
			mask <<= (j & 0x1);
		}
	}
	
	if (WS_INFO->TEXT_EFFECT & OUTLINE) {
		UWORD limit,*fig;

		fig = (UWORD *) get_memory(
			(UWORD)((cheight + 4) * sizeof(WORD)));
		if (fig == (UWORD *)NULL) {
			IOdebug("could not obtain outline memory\n");
			(void) free_memory((BYTE *)colour_array);
			return;
		}

		mask = ~((UWORD)0xffffffffL >> char_width);

		for (j = 0; j < cheight; j++) {
			fig[j+2] = model[j];
			fig[j+2] &= mask;
			fig[j+2] >>= 2;
			fig[j+2] = ~(fig[j+2]);
		}

		fig[0] = fig[1] = fig[cheight+2] = fig[cheight+3] = 0xffffffffL;

		/* remove any set pixels with all set neightbours */

		limit = ((UWORD)0xffffffffL) >> (char_width + 3);

		for (j = 1; j < cheight + 3; j++ ) {
			model[j-1] = (fig[j] << 1);
			for (mask = ((UWORD)0x40000000L);
			     mask > limit ;
			     mask >>= 1) {
				if (	(fig[j] & mask)          &&
					(fig[j] & (mask << 1))   &&
					(fig[j] & (mask >> 1))   &&
					(fig[j-1] & mask)        &&
					(fig[j-1] & (mask << 1)) &&
					(fig[j-1] & (mask >> 1)) &&
					(fig[j+1] & mask)        &&
					(fig[j+1] & (mask << 1)) &&
					(fig[j+1] & (mask >> 1))) {
						model[j-1] &= ~(mask << 1);
					}
			}
		}

		cheight += 2;
		char_width += 2;

		(void) free_memory((BYTE *)fig);
	}

	if (WS_INFO->TEXT_EFFECT & LIGHT) {
		lightmask = font->font_lightening;
		lightmask <<= 16;
		lightmask |= font->font_lightening;

		for ( j = 0; j < cheight; j++) {
			model[j] &= lightmask;
			lightmask = ~lightmask;
		}
	}

	/* Italic text in xor mode will overwrite the underline of previous */
	/* letters.  So the solution is to draw the underline before the    */
	/* the text has been drawn. */

	if ((WS_INFO->TEXT_EFFECT & UNDERLINE) &&
		!(WS_INFO->TEXT_EFFECT & ITALIC)) {
			model[cheight - font->font_underline] = 0xffffffffL;
	}

	/* deal with text rotation */

	rotate(model,&cheight,&char_width);

	top = ypos - cheight + 1;
	bot = ypos;

	/* Calculate left and right edge of the character */

	left  = xpos;
	right = xpos + char_width - 1;

	if (!clip(&left,&top,&right,&bot)) {

		/* Plot the character */
		/* First save the current write mode (see REPLACE) */

		tmp = WS_INFO->WRITE_MODE;

		switch (tmp) {

		case XOR:	/* Write in XOR mode */
			RasterOp(VDI_XOR,
				const_pix_offset,0,
				right - left + 1,(WORD) (bot-top+1),
				OFFSET(left,top),SCREEN.STRIDE,
				model,OFFSET(xpos,ypos-cheight+1));
			 break;

		case REPLACE:	/* If in italics force TRANSPARENT mode */
				if (WS_INFO->TEXT_EFFECT & ITALIC) {
					WS_INFO->WRITE_MODE = TRANSPARENT;
				}
		case REV_TRANSPARENT:	/* Plot as transparent */
		case TRANSPARENT:	/* Plot as normal */
			RasterOp(VDI_REPLACE,
 				const_pix_offset,0,
				right-left+1,(WORD) (bot-top+1),
				OFFSET(left,top),SCREEN.STRIDE,
				model,OFFSET(xpos,ypos-cheight+1));

			break;
		}

		/* Restore the write mode */

		WS_INFO->WRITE_MODE = tmp;
	}

	/* Update the x and y positions, ready for the next character */

	/* allow for inter character spacing */

	if (inter_char_spacing) {
		extra = inter_char_spacing / chars;
		inter_char_spacing -= extra;
		--chars;

	} else {
		extra = 0;
	}

	switch(WS_INFO->TEXT_ANGLE) {

		default:	xpos += char_width + extra;
				if (WS_INFO->TEXT_EFFECT & ITALIC) {
					xpos -= ((cheight >> 1) - 1);
				}
				break;

		case 900:	bot -= cheight + extra;
				ypos -= cheight + extra;
				if (WS_INFO->TEXT_EFFECT & ITALIC) {
					bot +=  ((char_width >> 1) - 1);
					ypos += ((char_width >> 1) - 1);
				}
				break;

		case 1800:	xpos -= char_width + extra;
				if (WS_INFO->TEXT_EFFECT & ITALIC) {
					xpos += ((cheight >> 1) - 1);
				}
				break;

		case 2700:	bot += cheight + extra;
				ypos += cheight + extra;
				if (WS_INFO->TEXT_EFFECT & ITALIC) {
					bot -=  ((char_width >> 1) - 1);
					ypos -= ((char_width >> 1) - 1);
				}
				break;
	}

	if (WS_INFO->TEXT_ANGLE != 0 && WS_INFO->TEXT_ANGLE != 1800) {
		j = cheight;
		cheight = char_width;
		char_width = j;
	}

	if (WS_INFO->TEXT_EFFECT & OUTLINE) {
		cheight -= 2;
		char_width -= 2;
	}

	}
	(void) free_memory((BYTE *)colour_array);

} /* show_text() */
E 1
