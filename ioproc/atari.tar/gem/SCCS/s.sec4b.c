h55880
s 01046/00000/00000
d D 2.1 88/10/26 18:43:52 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/************************************************************************/
/*									*/
/*				SEC4B.C					*/
/*									*/
/************************************************************************/

#include "header.h"

/* FUNCTIONS IN THIS MODULE:						*/
/*									*/
/*  FUNCTION	DESCRIPTION		NAME		MANUAL SECTION	*/
/*	 7:	Polymarker 		v_pmarker		4	*/
/*									*/

/************************************************************************/
/*									*/
/*	Contains routines:						*/
/*									*/
/*		init_marker_info()					*/
/*		draw_filled_polygon()					*/
/*		plot_arrow()						*/
/*		WORD our_sqrt(sq,dx,dy)					*/
/*		bdary_fill(seedx,seedy,bdarycol)			*/
/*									*/
/************************************************************************/

static WORD dot_mark_info[] = { 1, 1, 1, 
					1, 0, 0 };
static WORD plus_mark_info[] = { 6, 6, 2,
					2, 0, 3,  0, -3,
					2, 3, 0, -3,  0 };
#ifdef NEVER
static WORD asterisk_mark_info[] = { 6, 6,  2,
					4, -3, -3, -1, 0, 1, 0, 3,  3,
					4, -3,  3, -1, 0, 1, 0, 3, -3 };
static WORD asterisk_mark_info[] = { 6,8,3,
					4, -3, -3, -1, -1, 1, -1, 3, -3,
					4, -3,  3, -1,  1, 1,  1, 3,  3,
					2,  0, -4,  0,  4 };
#else
static WORD asterisk_mark_info[] = { 6, 6,  3,
					3, -2, -2,  0,  0,  2, -2,
					3, -2,  2,  0,  0,  2,  2,
					2,  0, -3,  0,  3 };
#endif
static WORD cross_mark_info[] = { 6, 6, 2,
					2, -3, -3, 3, 3,
					2, -3, 3, 3, -3 };
static WORD diamond_mark_info[] = { 6, 6, 1,
					5, 0, -3, 3, 0, 0, 3, -3, 0, 0, -3 };
static WORD square_mark_info[] = { 6, 6, 1,
					5, -3, -3, 3, -3, 3, 3, -3, 3, -3, -3};

void init_marker_info()
/* Each list describing a marker conatins the following values */
/* Height of bounding box; Width of bounding box */
/* Number of lines that represent the symbol */
/* and then for each of these lines the number of points in the line */
/* and the values of these points */
/* These points are given as offsets from the centre of the mark */
{
	MARK_INFO[0] = dot_mark_info;
	MARK_INFO[1] = plus_mark_info;
	MARK_INFO[2] = asterisk_mark_info;
	MARK_INFO[3] = square_mark_info;
	MARK_INFO[4] = cross_mark_info;
	MARK_INFO[5] = diamond_mark_info;

} /* init_marker_info() */

void v_pmarker()
/* plots the current marker symbol at the points defined in PTSIN */
/* Uses attributes: COLOUR, SCALE, MARKER_TYPE, WRITE_MODE */
{
#define MAX_VERTICES	9

	WORD 	save_line_type,save_line_colour,save_line_width;
	WORD 	save_line_mask,half_width,half_height;
	WORD 	*mark_info_ptr;
	WORD 	x_centre, y_centre;
	WORD 	i,j,k,num_lines,num_marks;
	WORD 	tmp_points[2 * MAX_VERTICES];
	WORD	scale,type;
	void 	v_pline(void);

	/* save some of the line attributes and set them up for PolyLine */
	save_line_width  = WS_INFO->LINE_WIDTH;
	save_line_type   = WS_INFO->LINE_TYPE;
	save_line_colour = WS_INFO->LINE_COLOR_INDEX;
	save_line_mask   = WS_INFO->LINE_MASK;

	WS_INFO->LINE_WIDTH       = 1; 		/* a thin line */
	WS_INFO->LINE_TYPE        = LINE_PATTERNS[1];  /* a solid line */
	WS_INFO->LINE_COLOR_INDEX = WS_INFO->MARKER_COLOR_INDEX;
	WS_INFO->LINE_MASK        = LINE_PATTERNS[1];

	/* copy the PTSIN values that will be overwritten by the */
	/* marker outlines */
	for (i = 0; i < 2 * MAX_VERTICES; i++)
		tmp_points[i] = PTSIN[i];

	type = WS_INFO->MARKER_TYPE - 1;

	/* half the marker height and width to improve clipping efficiency */
	half_height = ((UWORD)(WS_INFO->MARKER_HEIGHT + 1)) / 2;
	half_width = ((UWORD)(WS_INFO->MARKER_WIDTH + 1)) / 2;
	mark_info_ptr = MARK_INFO[type];

	/* Determine the scale between the size of the symbol as it */
	/* is defined and the desired size */
	scale = ( WS_INFO->MARKER_HEIGHT << N_F_B ) / *mark_info_ptr++;
	num_marks = CONTRL[1];

	/* Plot all the markers one by one */
	for (i = 0; i < num_marks * 2; i += 2) {
		if (i < 2 * MAX_VERTICES) {
			x_centre = tmp_points[i];
			y_centre = tmp_points[i+1];
		} else {
			x_centre = PTSIN[i];
			y_centre = PTSIN[i+1];
		}

		/* Trivial clipping against the Clip Region */
		if (WS_INFO->CLIP_FLAG) {
			if (	y_centre+half_height < WS_INFO->CLIP_YMIN ||
				y_centre-half_height > WS_INFO->CLIP_YMAX ||
				x_centre+half_width  < WS_INFO->CLIP_XMIN ||
				x_centre-half_width  > WS_INFO->CLIP_XMAX )
					/* nothing will be displayed so */
					continue;
		} else {
			if (	y_centre + half_height < SCREEN_YBOT  ||
				y_centre - half_height > SCREEN_YTOP  ||
				x_centre + half_width  < SCREEN_XLEFT ||
				x_centre - half_width  > SCREEN_XRIGHT )
					/* nothing will be displayed so */
					continue;
		}

		mark_info_ptr = &MARK_INFO[type][2];
		num_lines = *mark_info_ptr++;

		/* for each line in the symbol */
		for (j = 0; j < num_lines; j++ ) {
			/* initialise the number of points */
			CONTRL[1] = *mark_info_ptr++;

			for (k = 0; k < CONTRL[1] * 2; ) {
				PTSIN[k++] = x_centre +
				((scale * (*mark_info_ptr++)) >> N_F_B);
				PTSIN[k++] = y_centre +
				((scale * (*mark_info_ptr++)) >> N_F_B);
			}
			/* Call v_pline to draw this line of the symbol */

			v_pline();
		}
	}

	/* restore the line attributes */
	WS_INFO->LINE_WIDTH       = save_line_width;
	WS_INFO->LINE_TYPE        = save_line_type;
	WS_INFO->LINE_COLOR_INDEX = save_line_colour;
	WS_INFO->LINE_MASK        = save_line_mask;

	/* restore the other variables */
	CONTRL[1] = num_marks;
	CONTRL[2] = 0;
	CONTRL[4] = 0;
	for (i = 0; i < 2 * MAX_VERTICES; i++)
		PTSIN[i] = tmp_points[i];

}/* v_pmarker() */

static WORD plotting = 0;

void plot_arrow(WORD x_index, WORD nextxy)
/* does an arrow for a line end style */
/* the corrct Fill parameters will have already been set */
/* x_index is the index to the x-coordinate of the arrow head */
/*       therefore x_index + 1 points to the y-coordinate */
/* nextxy is the increment between this cordinate and the next line segment */
/* 	this is either 2 if the arrow head is at the beginning of */
/*	the polyline or -2 if at the end of the line segment */
{
	WORD	*xyptr, *temp_xyptr, npts, sav_pts[10];
	WORD	dx, dy, line_len, i;
	WORD	x_of_head, y_of_head, ht_x, ht_y, base_x, base_y;
	WORD	arrow_len, arrow_wid, sq_arrow_len, sq_line_len;
	WORD	our_sqrt(WORD);
	void 	draw_filled_polygon(void);

if (plotting) {
	return;
} else {
	plotting = 1;
}

	xyptr = PTSIN + x_index;
	
	/* calculate the arrow width and height as functions of line_width */
	/* line_widths of 1 give a default length of 8 */ /* FINE TUNE */
	arrow_len = (WS_INFO->LINE_WIDTH == 1) ? 8 : 3 *WS_INFO->LINE_WIDTH - 1;
	arrow_wid = arrow_len / 2;

	/* determine the next point on the polyline that will not be */
	/* obsured by the arrow head */
	temp_xyptr   = xyptr;
	x_of_head    = *xyptr;
	y_of_head    = *(xyptr + 1);
	sq_arrow_len = arrow_len * arrow_len;

	for (i = 1; i < CONTRL[1]; i++) {
		/* point to the next point along the polyline */
		temp_xyptr += nextxy;

		/* determine the x and y deltas */
		dx = x_of_head - *temp_xyptr;
		dy = y_of_head - *(temp_xyptr + 1);
		
		/* if the length of this vector is greater than the */
		/* arrow_len then we have determined the closest point */
		/* along the polyline that will not be obscured by */
		/* the arrow_head */

		sq_line_len = dx * dx + dy * dy;

		if (sq_line_len >= sq_arrow_len)
			break;
	}
	
	/* if the longest line segment in the polyline is not visible do not */
	/* draw an arrow_head */
	if (sq_line_len < sq_arrow_len) {
		return;
	}
		
	line_len = our_sqrt(sq_line_len);

	/* determine the values of the offsets in the x and y directions */
	/* These should really be performed using real arithmetic but for */
	/* the time being we will make do with integers scaled by */
	/* N_FRACT_BITS; note that arrow_len and arrow_wid are relatively */
	/* small so overflow should not occur */

	ht_x   = (((arrow_len * dx) << N_F_B) / line_len) >> N_F_B;
	ht_y   = (((arrow_len * dy) << N_F_B) / line_len) >> N_F_B;
	base_x = (((arrow_wid * dy) << N_F_B) / line_len) >> N_F_B;
	base_y = (((arrow_wid * dx) << N_F_B) / line_len) >> N_F_B;

	npts = CONTRL[1];
	for (i = 0; i < 6; i++ )
		sav_pts[i] = PTSIN[i];
		
	/* now build up the three points making up the boundary of the */
	/* arrow_head. */
	CONTRL[1] = 3;
	PTSIN[0] = x_of_head + base_x - ht_x;
	PTSIN[1] = y_of_head - base_y - ht_y;
	PTSIN[2] = x_of_head - base_x - ht_x;
	PTSIN[3] = y_of_head + base_y - ht_y;
	PTSIN[4] = x_of_head;
	PTSIN[5] = y_of_head;

	/* Note this procedure assumes the fill attributes have been set up */
	draw_filled_polygon();
	
	/* restore the saved points etc */
	CONTRL[1] = npts;
	for (i = 0; i < 6; i++ ) {
		PTSIN[i] = sav_pts[i];
	}
		
	/* adjust the end point and any points that have been skipped so */
	/* that they do not overwrite the arrow_head */
	*xyptr -= ht_x;
	*(xyptr+1) = *(xyptr+1) - ht_y;
	while ( (temp_xyptr -= nextxy) != xyptr) {
		*temp_xyptr = *xyptr;
		*(temp_xyptr+1) = *(xyptr+1);
	}

plotting = 0;

} /* plot_arrow() */

WORD our_sqrt(WORD sq)
/* returns a WORD approximation of the given sq */
/* This is a wonderful one-line C function .... */
{
	 WORD s,t;

	for(t = s = 1; t <= sq; t += s += 2);
	return((--s)/2);

} /* our_sqrt() */

static WORD fill_miny,fill_maxy;	/* Limits on a polygon to fill */

void draw_filled_polygon()
/* draw a filled polygon on the screen */
/* the polygon may or may not be closed before this is called */
/* sets the minimum and maximum y-values for this region */
{	
	WORD i,j,k,max_x,min_x;
	void scan_convert_polygon(void);
	void draw_poly_line(void);
	void fill_clip_horiz_line(WORD,WORD,WORD);

	/* determine the minimum and maximum y-values */
	fill_miny = fill_maxy = PTSIN[1];
	min_x = max_x = PTSIN[0];
	j = 3;
	for (i = CONTRL[1]; i > 1; --i) {
		k = PTSIN[j-1];
		     if (k < min_x) min_x = k;
		else if (k > max_x) max_x = k;

		k = PTSIN[j];
		j += 2;
		     if (k < fill_miny) fill_miny = k;
		else if (k > fill_maxy) fill_maxy = k;
	}

	if (WS_INFO->CLIP_FLAG) {
		/* do some trivial clipping against the Clip Region */
		if (	fill_miny > WS_INFO->CLIP_YMAX ||
			fill_maxy < WS_INFO->CLIP_YMIN ||
			min_x     > WS_INFO->CLIP_XMAX ||
			max_x     < WS_INFO->CLIP_XMIN  ) 
				return;
	} else {
		/* do some trivial clipping against the Screen Boundary */
		if (	fill_maxy < SCREEN_YBOT  ||
			fill_miny > SCREEN_YTOP  ||
			min_x     > SCREEN_XRIGHT ||
			max_x     < SCREEN_XLEFT   )
				return;
	}

	if (fill_miny == fill_maxy) {
		/* this test saves time and also prevents a bug in the    */
		/* scan convert algorithm - I have not yet found this bug */
		
		fill_clip_horiz_line(min_x,max_x,fill_miny);
		return;
	}
	
	/* now scan-convert the polygon onto the display */
	scan_convert_polygon();
	
	if (WS_INFO->FILL_OUTLINED) {
		/* if there is an area perimeter draw it with a thin */
		/* solid line with the same colour as the fill area  */
		/* NB must ensure that the perimeter is closed       */

		WORD save_line_type,save_line_colour,save_line_width;
		WORD save_line_mask,save_write_mode;
		WORD save_line_start,save_line_end;
		WORD npts;
		
		save_line_width  = WS_INFO->LINE_WIDTH;
		save_line_type   = WS_INFO->LINE_TYPE;
		save_line_colour = WS_INFO->LINE_COLOR_INDEX;
		save_line_mask   = WS_INFO->LINE_MASK;
		save_write_mode  = WS_INFO->WRITE_MODE;
		save_line_start  = WS_INFO->LINE_END_STYLE[0];
		save_line_end    = WS_INFO->LINE_END_STYLE[1];

		WS_INFO->LINE_WIDTH        = 1;
		WS_INFO->LINE_TYPE         = LINE_PATTERNS[1];
		WS_INFO->LINE_COLOR_INDEX  = WS_INFO->FILL_COLOR_INDEX;
		WS_INFO->LINE_MASK         = LINE_PATTERNS[1];
		WS_INFO->LINE_END_STYLE[0] = SQUARED;
		WS_INFO->LINE_END_STYLE[1] = SQUARED;
		WS_INFO->WRITE_MODE	   = REPLACE; /* IS THIS RIGHT ??? */

		/* ensure closure */

		npts = (CONTRL[1] - 1) * 2;

		if (	PTSIN[npts    ] != PTSIN[0] ||
			PTSIN[npts + 1] != PTSIN[1] ||
			npts < 2                    ) {

			npts += 2;
			PTSIN[npts    ] = PTSIN[0];
			PTSIN[npts + 1] = PTSIN[1];
			++CONTRL[1];
		}

		draw_poly_line();

		/* no need to reset CONTRL[1] as all the drawing is done */

		WS_INFO->LINE_WIDTH        = save_line_width;
		WS_INFO->LINE_TYPE         = save_line_type;
		WS_INFO->LINE_COLOR_INDEX  = save_line_colour;
		WS_INFO->LINE_MASK         = save_line_mask;
		WS_INFO->LINE_END_STYLE[0] = save_line_start;
		WS_INFO->LINE_END_STYLE[1] = save_line_end;
		WS_INFO->WRITE_MODE	   = save_write_mode;
	}
		
} /* draw_filled_polygon() */

void scan_convert_polygon()
/* scan-converts the polygon onto the display. This polygon may or */
/* may not be already closed */
/* Uses (*Fill_Rect_Region) to actually update the display, since */
/* this procedure takes care of all the fill attributes */
{	
	WORD		y;
	EDGE_RECORD 	**bucket;
	void		initialise_bucket_list(WORD,EDGE_RECORD **);
	void		makeactivelist(WORD,EDGE_RECORD **);
	void		scan_line(WORD,EDGE_RECORD **);
	void		sort_activelist(WORD,EDGE_RECORD **);

	/* create space for the bucket list */
	bucket = (EDGE_RECORD **) get_memory((UWORD)
		(fill_maxy-fill_miny+1)*sizeof(EDGE_RECORD *));
		
	if (bucket == (EDGE_RECORD **)NULL)
		return;

	/* initialise the bucket list and edge list */
	initialise_bucket_list(CONTRL[1],bucket);

	for (y = fill_miny; y <= fill_maxy; y++) {
		/* create the active list */
		makeactivelist(y,bucket);
		/* and scan-convert into the raster */
		scan_line(y,bucket);
		/* ensure the current active list is sorted */
		sort_activelist(y,bucket);
	}
	
	/* free the memory used by the bucket list */
	(void) free_memory((BYTE *) bucket);

} /* scan_convert_polygon() */

void sort_activelist(scany,bucket)
/* ensures the current active list is sorted and that any Line Segments */
/* that become unactive on the next scanline are removed from the list */
WORD scany;
EDGE_RECORD **bucket;
{
	EDGE_RECORD *left_ptr,*right_ptr,*temp_ptr,*prev_ptr;
	
	/* first get scany into the range used by bucket */
	scany = scany-fill_miny;
	if ((left_ptr = *(bucket+scany)) == (EDGE_RECORD *)NULL)
		/* the list is empty */
		return;
	
	/* first of all remove any at the beginning of the list that */
	/* are not active on the next scan-line */
	while (left_ptr != (EDGE_RECORD *)NULL && Edge_Ymax(left_ptr)==scany) {
		temp_ptr = left_ptr;
		left_ptr = Edge_Next(left_ptr);
		(void) free_memory((BYTE *) temp_ptr);
	}

	*(bucket+scany) = left_ptr;
	if (left_ptr == (EDGE_RECORD *)NULL)
		/* the list is now empty */
		return;

	right_ptr = Edge_Next(left_ptr);

	while (left_ptr != (EDGE_RECORD *)NULL) {
		while (right_ptr!= (EDGE_RECORD *)NULL &&
			Edge_Xvalue(right_ptr)>=Edge_Xvalue(left_ptr)) {
			/* they are in the correct order; check that the */
			/* right_ptr LS does not become inactive */
			if (Edge_Ymax(right_ptr)>scany) {
				left_ptr = right_ptr;
				right_ptr = Edge_Next(right_ptr);
			}
			else {
				/* remove right_ptr from the list */
				temp_ptr = right_ptr;
				right_ptr = Edge_Next(right_ptr);
				(void) free_memory((BYTE *) temp_ptr);
				Edge_Next(left_ptr) = right_ptr;
			}
		}
		/* now we have either gone off the list or have found */
		/* two records not in the right order */
		if (right_ptr == (EDGE_RECORD *)NULL)
			/* list is sorted and complete */
			return;
		/* otherwise delete right_ptr */
		Edge_Next(left_ptr) = Edge_Next(right_ptr);
		if (Edge_Ymax(right_ptr)>scany) {
			/* insertion sort right_ptr into correct position */
			prev_ptr = (EDGE_RECORD *)NULL;
			temp_ptr = *(bucket+scany);
			while (Edge_Xvalue(temp_ptr)<Edge_Xvalue(right_ptr)) {
				prev_ptr = temp_ptr;
				temp_ptr = Edge_Next(temp_ptr);
			}
			if (prev_ptr == (EDGE_RECORD *)NULL) {
				Edge_Next(right_ptr) = *(bucket+scany);
				*(bucket+scany) = right_ptr;
			}
			else {
				Edge_Next(prev_ptr) = right_ptr;
				Edge_Next(right_ptr) = temp_ptr;
			}
		}
		else
			/* remove right_ptr from the list */
			(void) free_memory((BYTE *) right_ptr);
		right_ptr = Edge_Next(left_ptr);
	}

} /* sort_active_list() */

void scan_line(scany,bucket)
/* scan_converts the current active list for scanline scany */
WORD scany;
EDGE_RECORD **bucket;
{
	EDGE_RECORD	*curr_active_ptr;
	UWORD		x1,x2;
	void		fill_clip_horiz_line(UWORD,UWORD,WORD);
	void		printactivelist(WORD,EDGE_RECORD **);

	/* start at the beginning of the list */
	curr_active_ptr = *(bucket+scany-fill_miny);
	
	while (curr_active_ptr != (EDGE_RECORD *)NULL) {
		x1 = (UWORD) Edge_Xvalue(curr_active_ptr) >> 
			N_F_B;
		Edge_Xvalue(curr_active_ptr) += Edge_Gradient(curr_active_ptr);
		curr_active_ptr = Edge_Next(curr_active_ptr);
		if (curr_active_ptr == (EDGE_RECORD *)NULL) {
			/* NOTE this small test may be taken out when */
			/* development is complete--only here for a debug */
			printactivelist(scany,bucket);
		}
		x2 = (UWORD) Edge_Xvalue(curr_active_ptr) >> 
			N_F_B;
		Edge_Xvalue(curr_active_ptr) += Edge_Gradient(curr_active_ptr);
		curr_active_ptr = Edge_Next(curr_active_ptr);

		fill_clip_horiz_line(x1,x2,scany);
	}

} /* scan_line() */

void makeactivelist(scany,bucket)
/* make the active list for the given scan-line */
/* merges the current active list with the new edges that start on this */
/* scan-line and removes any line segments that stop being active */
WORD scany;
EDGE_RECORD **bucket;
{
	EDGE_RECORD	*curr_active_ptr,*bucket_ptr,*prev_ptr;

	if (scany==fill_miny)
		curr_active_ptr = (EDGE_RECORD *)NULL;
	else
		curr_active_ptr = *(bucket+scany-1-fill_miny);
		
	/* first change scany into the range used by bucket */
	scany = scany-fill_miny;
	bucket_ptr = *(bucket+scany);
	prev_ptr = (EDGE_RECORD *)NULL;

	while (	curr_active_ptr != (EDGE_RECORD *)NULL &&
		bucket_ptr != (EDGE_RECORD *)NULL) {
		/* while both lists are not empty do:- */
		if (Edge_Xvalue(curr_active_ptr) < Edge_Xvalue(bucket_ptr)) {
			if (prev_ptr == (EDGE_RECORD *)NULL)
				*(bucket+scany) = curr_active_ptr;
			else
				Edge_Next(prev_ptr) = curr_active_ptr;
			prev_ptr = curr_active_ptr;
			curr_active_ptr = Edge_Next(curr_active_ptr);
		}
		else  {
			if (prev_ptr != (EDGE_RECORD *)NULL)
				Edge_Next(prev_ptr) = bucket_ptr;
			prev_ptr = bucket_ptr;
			bucket_ptr = Edge_Next(bucket_ptr);
		}
	}
	if (curr_active_ptr != (EDGE_RECORD *)NULL) {
		/* the current active list is not empty */
		if (prev_ptr == (EDGE_RECORD *)NULL)
			*(bucket+scany) = curr_active_ptr;
		else
			Edge_Next(prev_ptr) = curr_active_ptr;
	}
	else if (bucket_ptr != (EDGE_RECORD *)NULL) {
		/* the bucket list is not empty */
		if (prev_ptr != (EDGE_RECORD *)NULL)
			Edge_Next(prev_ptr) = bucket_ptr;
	}

} /* makeactivelist() */

void printactivelist(y,bucket)
WORD y;
EDGE_RECORD **bucket;
{
	EDGE_RECORD *ptr;

	ptr = *(bucket+y-fill_miny);
	if (ptr == (EDGE_RECORD *)NULL)
		IOdebug("The Active List on scan line %d is Empty\n",y);
	else
		IOdebug("The Active List on scan line %d is \n",y);

	while (ptr != (EDGE_RECORD *)NULL) {
		IOdebug("xv %ld gr %ld maxy %d\n",
			(unsigned)Edge_Xvalue(ptr) >> N_F_B,
			Edge_Gradient(ptr) >> N_F_B,
			(unsigned)Edge_Ymax(ptr) + fill_miny);
		ptr = Edge_Next(ptr);
	}

} /* printactivelist() */

static EDGE_RECORD *new_edge_record()
/* return a pointer to a new edge redcord */
{ 
	EDGE_RECORD	*edge_record_ptr;

	edge_record_ptr = (EDGE_RECORD *) get_memory((UWORD)
		sizeof(EDGE_RECORD));
	if (edge_record_ptr == (EDGE_RECORD *)NULL) {
		IOdebug("initialise_bucket_list::get_memory returns NULL\n");
		return (edge_record_ptr);
	}
	Edge_Next(edge_record_ptr) = (EDGE_RECORD *)NULL;
	return (edge_record_ptr);

} /* new_edge_record() */

void initialise_bucket_list(npts,bucket)
/* initialise the bucket list before scan-converting a polygon */
WORD npts;
EDGE_RECORD **bucket;
{
	WORD	y,line_start,line_end,last_vec;
	WORD 	x1,x2;
	WORD		y1,y2;
	EDGE_RECORD	*edge_record_ptr;
	void		degenerate_polygon(WORD);
	void		initialise_edge_record(EDGE_RECORD *,WORD,
				WORD,WORD,EDGE_RECORD **);

	/* determine whether or not the polygon is closed */
	if (PTSIN[0] == PTSIN[2*npts-2] && PTSIN[1] == PTSIN[2*npts-1])
		/* the remainder of this procedure assumes the polygon is */
		/* open, so remove the last point if the polygon is closed */
		--npts;
	
	for (y = fill_maxy-fill_miny; y >= 0; --y)
		*(bucket+y) = (EDGE_RECORD *)NULL;

	/* remove any horizontal lines from the beginning and the end of the */
	/* list of Line Segments. This makes it easier to test whether we */
	/* need to shorten the line segments at the join */
	line_start = 0;
	while (line_start < 2*npts-2 && 
				PTSIN[line_start+1] == PTSIN[line_start+3])
		line_start += 2;
	if (line_start == 2*npts-2) {
		/* we have the degenerate case consisting of only horizontal */
		/* line_segments */
		degenerate_polygon(npts);
		return;
	}

	if (PTSIN[1]!=PTSIN[2*npts-1])
		/* the last segment is not horizontal */
		line_end = 2*npts-2;
	else {
		/* the last segment is horizontal */
		line_end = 2*npts-4;
		while (line_end>line_start &&
			PTSIN[line_end+1] == PTSIN[line_end+3])
			line_end -= 2;
	}

	/* add the first LS to the list */
	edge_record_ptr = new_edge_record();
	x1 = PTSIN[line_start]; y1 = PTSIN[line_start+1];
	x2 = PTSIN[line_start+2]; y2 = PTSIN[line_start+3];
	Edge_Gradient(edge_record_ptr) = ((x2-x1) << N_F_B) / (y2-y1);
	if (y2 > y1) {
		if (PTSIN[line_end+1]<y1)
			/* must shorten the bottom edge */
			initialise_edge_record(edge_record_ptr,
			(x1 << N_F_B)+Edge_Gradient(edge_record_ptr),
					y2,y1+1,bucket);
		else
			initialise_edge_record(edge_record_ptr,
				x1 << N_F_B,
					y2,y1,bucket);
	} else {
		if (PTSIN[line_end+1]>y1)
			initialise_edge_record(edge_record_ptr,
				x2 << N_F_B,
					y1-1,y2,bucket);
		else
			initialise_edge_record(edge_record_ptr,
				x2 << N_F_B,y1,y2,bucket);
	}
	last_vec = PTSIN[line_start+1];	/* store the y-value of the last */
					/* non-horizontal vector */

	/* for each remaining edge of the polygon, bucket sort and */
	/* initialise the edge records */
	for (y = line_start+2; y <= line_end; y += 2) {
		x1 = PTSIN[y];
		y1 = PTSIN[y+1];
		if (y==2*npts-2) {
			/* the last segment, so pick up the first point */
			x2 = PTSIN[0]; y2 = PTSIN[1];
		} else {
			x2 = PTSIN[y+2]; y2 = PTSIN[y+3];
		}
		if (y1 != y2 ) {
			/* if the line is not horizontal */
			edge_record_ptr = new_edge_record();
			Edge_Gradient(edge_record_ptr) = ((x2-x1) << 
				N_F_B)/(y2-y1);
			if (y1 < y2) {
				if (last_vec < y1) {
					/* shorten the bottom of this */
					initialise_edge_record(edge_record_ptr,
					(x1 << N_F_B) + 
					Edge_Gradient(edge_record_ptr),
						y2,y1+1,bucket);
				} else {
					initialise_edge_record(edge_record_ptr,
						x1 << N_F_B,
						y2,y1,bucket);
				}
			} else {
				if (last_vec>y1) {
					/* must shorten this Line Segment */
					initialise_edge_record(edge_record_ptr,
						x2 << N_F_B,y1-1,
						y2,bucket);
				} else {
					initialise_edge_record(edge_record_ptr,
						x2 << N_F_B,y1,
						y2,bucket);
				}
			}
			last_vec = PTSIN[y+1];
		}
	}

} /* initialise_bucket_list() */

void initialise_edge_record(edge_record_ptr,xvalue,ymax,min_scany,bucket)
/* initialise the given edge record with the given values */
EDGE_RECORD *edge_record_ptr;
WORD xvalue;
WORD ymax,min_scany;
EDGE_RECORD **bucket;
{
	void add_to_bucket_list(WORD,EDGE_RECORD *,EDGE_RECORD **);

/* Add on halve the accuracy of the number of bits representing */
/* the fractional part to ensure the correct rounfing is performed */
/* inside scanline */

	Edge_Xvalue(edge_record_ptr) = xvalue + (1L << (N_F_B-1));

/* subtract fill_miny to make sort_activelist more efficient */
	Edge_Ymax(edge_record_ptr) = ymax - fill_miny;
	add_to_bucket_list(min_scany,edge_record_ptr,bucket);

} /* initialise_edge_record() */

void degenerate_polygon(npts)
/* the given polygon consists completely of horizontal lines */
/* by necessity this polygon must be closed */
WORD npts;
{
	WORD		xl,xr;
	WORD	ptno;
	PIX_OFFSET	left_ptr;

	xr = xl = PTSIN[0];
	/* determine the left and right x extremes */
	for (ptno = 2; ptno < 2*npts-4; ptno++)
		if (PTSIN[ptno] < xl)
			xl = PTSIN[ptno];
		else if (PTSIN[ptno]>xr)
			xr = PTSIN[ptno];
	/* and fill between these limits */
	left_ptr = OFFSET( xl, PTSIN[1]);
	FRR(left_ptr,left_ptr + xr - xl + 1,1);

} /* degenerate_polygons() */

void add_to_bucket_list(ystart,edge_ptr,bucket)
/*  insert this new edge record in the bucket list */
/* each bucket list is kept in increasing x-order */
WORD ystart;
EDGE_RECORD *edge_ptr,**bucket;
{
	EDGE_RECORD *next_edge_ptr,*prev_edge_ptr,**tmp_buck_ptr;

	tmp_buck_ptr  = bucket+ystart-fill_miny;
	next_edge_ptr = *(bucket+ystart-fill_miny);
	prev_edge_ptr = (EDGE_RECORD *)NULL;

	while (next_edge_ptr != (EDGE_RECORD *)NULL) {
		if (Edge_Xvalue(next_edge_ptr)<Edge_Xvalue(edge_ptr)) {
			/* go to the next edge */
			prev_edge_ptr = next_edge_ptr;
			next_edge_ptr = Edge_Next(next_edge_ptr);
		} else {
			/* insert this new edge before the edge pointed at */
			/* by next_edge_ptr */
			if (prev_edge_ptr == (EDGE_RECORD *)NULL)
				*tmp_buck_ptr = edge_ptr;
			else
				Edge_Next(prev_edge_ptr) = edge_ptr;
			Edge_Next(edge_ptr) = next_edge_ptr;
			return;
		}
	}
	/* this edge must be placed at the end of the list */
	if (prev_edge_ptr == (EDGE_RECORD *)NULL)
		*tmp_buck_ptr = edge_ptr;
	else
		Edge_Next(prev_edge_ptr) = edge_ptr;

} /* add_to_bucket_list() */

#define SCANLO	1
#define SCANHI	2

void bdary_fill(seedx,seedy,bdarycol)
/* performs a boundary fill from the given seed point */
/* to the boundary given by the colour bdarycol */
/* Note that this will loop infinitely if the colour we are filling */
/* with already exists inside the region */
/* this region is bounded by the Display Bounds and the Clip Region */
WORD seedx,seedy,bdarycol;
{
	PIX_OFFSET	slptr,srptr,pl,pr,py,xmin,xmax,rxend;
	PIX_OFFSET	regstart,regend;
	WORD	ninx,code;
	WORD	new_colour;
	WORD		initstack(void);
	WORD		push(PIX_OFFSET,PIX_OFFSET,PIX_OFFSET,WORD);
	WORD		pop(PIX_OFFSET *,PIX_OFFSET *,PIX_OFFSET *,WORD *);
	void		remove_stack(void);
  
  /* first check that the seed point is in the display surface */
  /* if it is not, then do not do any filling */
  /* The display coordinate system is deemed to go from 0 to WIDTH-1 */
  /* in the x-direction and from 0 to HEIGHT-1 in the y-direction */
  
	if (WS_INFO->CLIP_FLAG) {
		if (	seedx < WS_INFO->CLIP_XMIN ||
			seedx > WS_INFO->CLIP_XMAX ||
			seedy < WS_INFO->CLIP_YMIN ||
			seedy > WS_INFO->CLIP_YMAX )
				return;
	} else {
		if (	seedx < SCREEN_XLEFT  ||
			seedx > SCREEN_XRIGHT ||
			seedy < SCREEN_YBOT   ||
			seedy > SCREEN_YTOP   )
		/* the seed point is outside the Display Boundary */
				return;
	}

	if (!initstack())
		/* we cannot initialise the fill-stack */
		return;

	/* initialise some variables */
	/* a pointer to the seed point */
	srptr = slptr = OFFSET( seedx, seedy);
		/* py is the least address on the current scan-line */
	if (WS_INFO->CLIP_FLAG) {
		/* the region must be bounded by the Clip Region */
		py       = OFFSET(WS_INFO->CLIP_XMIN, seedy);
		regend   = OFFSET(WS_INFO->CLIP_XMIN,WS_INFO->CLIP_YMIN);
		regstart = OFFSET(WS_INFO->CLIP_XMIN,WS_INFO->CLIP_YMAX);
		/* the number of pixels on the scanline minus 1 */
		ninx     = WS_INFO->CLIP_XMAX - WS_INFO->CLIP_XMIN;
	} else {
		/* the region must be bounded by the Display Boundary */
		py       = OFFSET(SCREEN_XLEFT, seedy);
		regend   = OFFSET(SCREEN_XLEFT,SCREEN_YBOT);
		regstart = OFFSET(SCREEN_XLEFT,SCREEN_YTOP);
		/* the number of pixels on the scanline minus 1 */
		ninx     = SCREEN.WIDTH - 1;
	}
	
	new_colour = WS_INFO->FILL_COLOR_INDEX;
	if (bdarycol == RPO(slptr) && new_colour == RPO(slptr))
	/* the colour of the seed point is the same as the boundary colour */
	/* or the colour that we are filling with */
		return;

	/* find the span containing the seed point; fill it and then loop */
	/* until the stack is empty */
	while ( (slptr>=py) &&
		(RPO(slptr)!=bdarycol) &&
		(RPO(slptr)!=new_colour) )
			--slptr;
	slptr++;

	while ( (srptr<=py+ninx) &&
		(RPO(srptr)!=bdarycol) &&
		(RPO(srptr)!=new_colour))
			srptr++;

	FRR(slptr,srptr,1);

	if ( py != regstart )
		if (!push(slptr,srptr-1,py,SCANHI))
			return;
	if ( py != regend )
		if (!push(slptr,srptr-1,py,SCANLO))
			return;

	while (pop(&pl,&pr,&py,&code))
		switch (code) {
		case SCANLO: /* check the child BELOW this parent */
			slptr = pl-SCREEN.STRIDE;
			xmin = py-SCREEN.STRIDE; xmax = xmin+ninx;
			rxend = pr-SCREEN.STRIDE;
			if (RPO(slptr)!=bdarycol && RPO(slptr)!=new_colour)
			{	srptr = slptr + 1;
				do {
					--slptr;
				} while ( (slptr>=xmin) &&
					(RPO(slptr)!=bdarycol) &&
					(RPO(slptr)!=new_colour) );
				slptr++;
			}
			else srptr = slptr;

			while ( slptr <= rxend )
			{	while ((srptr <= xmax) && 
					(RPO(srptr) != bdarycol) &&
					(RPO(srptr) != new_colour) )
					srptr++;
				if (srptr!=slptr) {
					FRR(slptr,srptr,1);
					if ( xmin != regend )
					    if (!push(slptr,srptr-1,xmin,
							SCANLO))
						break;  /* stack is full */
					if ( xmin != regstart )
					{	if ( slptr < pl-SCREEN.STRIDE-1)
						if (!push(slptr,
							pl-SCREEN.STRIDE-2,
							xmin,SCANHI))
						break;
						if ( srptr > rxend+2 )
						{	if (!push(rxend+2,srptr-1,
							xmin,SCANHI))
							break;
						}
					}
				}

				/* Now skip all the pixels that are */
				/* the boundary colour or the new colour */
				slptr = srptr + 1;
				while ((slptr <= rxend) &&
					((RPO(slptr) == bdarycol) ||
					(RPO(slptr)  == new_colour)))
					slptr++;
				srptr=slptr+1;
			}
			break;

		case SCANHI: /* check the child ABOVE this parent */
			slptr = pl+SCREEN.STRIDE;
			xmin  = py+SCREEN.STRIDE; xmax = xmin+ninx;
			rxend = pr+SCREEN.STRIDE;
			if (RPO(slptr)!=bdarycol && RPO(slptr)!=new_colour)
			{	srptr = slptr+1;
				do {
					--slptr;
				} while ( (slptr >= xmin) &&
					(RPO(slptr) != bdarycol) &&
					(RPO(slptr) != new_colour) );
				slptr++;
			}
			else srptr = slptr;

			while ( slptr <= rxend )
			{	while ((srptr <= xmax) && 
					(RPO(srptr) != bdarycol) &&
					(RPO(srptr) != new_colour) )
					srptr++;
				if (srptr != slptr) {
					FRR(slptr,srptr,1);
					if ( xmin != regstart )
					    if (!push(slptr,srptr-1,xmin,
							SCANHI))
						break;  /* stack is full */
					if ( xmin != regend )
					{	if ( slptr < pl+SCREEN.STRIDE-1)
						if (!push(slptr,
							pl+SCREEN.STRIDE-2,
							xmin,SCANLO))
						break;
						if ( srptr>rxend+2 )
						{	if (!push(rxend + 2,
								srptr - 1,
							xmin,SCANLO))
							break;
						}
					}
				}

				/* Now skip all the pixels that are */
				/* the boundary colour or the new colour */
				slptr = srptr + 1;
				while ((slptr <= rxend) &&
					((RPO(slptr) == bdarycol) ||
					(RPO(slptr) == new_colour)) )
					slptr++;
				srptr = slptr + 1;
			}
			break;
	  }
	/* free any memory associated with the stack_frames */
	remove_stack();

} /* bdary_fill() */

E 1
