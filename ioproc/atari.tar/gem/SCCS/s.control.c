h02822
s 00085/00000/00000
d D 2.1 88/10/26 18:42:51 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
#include <stdarg.h>
#include <helios.h>
#include <queue.h>
#include <memory.h>
#include <message.h>
#include <codes.h>
#include <task.h>
#include <root.h>
#include <config.h>
#include <syslib.h>

#define New(_type)	(_type *)Malloc(sizeof(_type))

extern void trace(...);
extern void mark(void);

void debug(char *str, ... );
word NewTask(Program *prog,Port port,Port parent);

int main()
{
	LinkInfo *link;
	MCB txmcb;
	Port ports[3];
	Task *task = MyTask;
	word e;
	int i;

	Config *config = (Config *)MyTask -> Environ;
	RPTR *prog = config->LoadBase + IVecServers;

	ports[0] = NewPort();
	ports[1] = NewPort();
	ports[2] = NewPort();

	link = (Root->Links)[0];

	txmcb.MsgHdr.Dest = link->RemoteIOCPort;

	txmcb.MsgHdr.Reply = NullPort;
	txmcb.MsgHdr.DataSize = 12;
	txmcb.MsgHdr.ContSize = 0;
	txmcb.MsgHdr.Flags = MsgHdr_Flags_preserve;
	txmcb.MsgHdr.FnRc = 0x11111111;
	txmcb.Timeout = 1000000;
	txmcb.Data = (byte *)(&ports);

	PutMsg(&txmcb);

	i = 0;
	while( *prog )
	{
		NewTask((Program *)RTOA(*prog),ports[i++],link->RemoteIOCPort);
		prog++;
	}
}

word NewTask(Program *prog,Port port,Port parent)
{
	word e 		 = Err_Null;
	Task *task 	 = New(Task);

	if ( task == Null(Task) ) 
	{
		e = EC_Error+SS_ProcMan+EG_NoMemory+EO_Task;
		goto Fail;
	}

	task->Program	 = prog;
	InitPool(&task->MemPool);
	task->Port	 = port;
	task->Parent	 = parent;
	task->IOCPort	 = NullPort;
	task->Environ	 = NULL;
	task->ExceptCode = (VoidFnPtr)NULL;
	task->ExceptData = Null(word);

	if( ( e = TaskInit(task) ) != Err_Null ) goto Fail;

	return Err_Null;
Fail:
	if( task != Null(Task) ) Free((void *)task);
	return e;
}

E 1
