h56691
s 00052/00000/00000
d D 2.1 88/10/26 18:42:45 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/*****************************************************************

	Charity registers

	RGM 30/12/87

*****************************************************************/

#define NUM_VREGS 9		/* Number of video registers */
#define VREG_BASE 0x40000040	/* Base of video registers */

/* !! N/A !! means that this register has not been implemented on 
   charity1 */

#define	MC_REG 0x40000000	/* Master control */
#define	EA_REG 0x40000004	/* Event line address */
#define	TS_REG 0x40000008	/* Test (leave alone!) */

#define	HT_REG 0x40000040
#define	HD_REG 0x40000044
#define	HS_REG 0x40000048
#define HW_REG 0x4000004C

#define VT_REG 0x40000050
#define VD_REG 0x40000054
#define VS_REG 0x40000058
#define VW_REG 0x4000005C
#define VC_REG 0x40000060

#define BC_REG 0x40000080	/* Blit control */
#define TC_REG 0x40000084	/* Test control */
#define PA_REG 0x40000088	/* Pixel alignment */
#define CA_REG 0x4000008c	/* Count direction */

#define DT_REG 0x40000090	/* Destination total */
#define DB_REG 0x40000094	/* Destination base address */
#define DW_REG 0x40000098	/* Destination width */
#define DS_REG 0x4000009c	/* Destination stride */

#define SB_REG 0x400000a0	/* Source base address */
#define SS_REG 0x400000a4	/* Source stride */
#define ML_REG 0x400000a8	/* Mask line start !! N/A !! */
#define MB_REG 0x400000ac	/* Mask bit start  !! N/A !! */

#define PC_REG 0x400000b0	/* Pipe control */
#define CD_REG 0x400000b4	/* Colour data     !! N/A !! */
#define TV_REG 0x400000b8	/* Test values */
#define SD_REG 0x400000bc	/* Source data */
#define MD_REG 0x40000020	/* Mask data       !! N/A !! */
#define DD_REG 0x40000024	/* Destination data */

/*****************************************************************/
E 1
