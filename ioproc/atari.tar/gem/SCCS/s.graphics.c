h20641
s 00243/00000/00000
d D 2.1 88/10/26 18:43:09 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
#include <stdio.h>

extern int	tmp,handle,
		fill_colour,
		fill_style,
		fill_perimeter,
		fill_interior,
		line_colour,
		line_start,
		line_end,
		line_width,
		line_type,
		write_mode;

extern int	intin[],intout[],contrl[];
extern int	pxyarray[],ptsin[],ptsout[];
extern char	in[];

void pattern()
{
	int style,index;

	printf("pattern filled rounded rectangles ... \n");

	tmp = vsf_color(handle,fill_colour);
	tmp = vswr_mode(handle,write_mode);
	tmp = vsf_perimeter(handle,fill_perimeter);

	for (style = 0; style <= 3; style++) {

		tmp = vsf_interior(handle,style);

		for (index = 1; index < 25; index++) {

			tmp = vsf_style(handle,index);

			pxyarray[0] = index * 20 + 5;
			pxyarray[1] = style * 80 + 19;
			pxyarray[2] = index * 20 + 20;
			pxyarray[3] = style * 80 + 80;

			v_rfbox(handle,pxyarray);
		}
	}

} /* pattern */

void area_fill()
{
	printf("filled polygon .... \n");

	tmp = vswr_mode(handle,write_mode);
	tmp = vsf_interior(handle,fill_interior);
	tmp = vsf_style(handle,fill_style);
	tmp = vsf_color(handle,fill_colour);

	pxyarray[0] = 100;
	pxyarray[1] = 100;
	pxyarray[2] = 300;
	pxyarray[3] = 100;
	pxyarray[4] = 200;
	pxyarray[5] = 300;
	pxyarray[6] = 100;
	pxyarray[7] = 100;

	v_fillarea(handle,4,pxyarray);

} /* area_fill */

contour_fill()
{
	char	ans;
	int	colour;

	printf("poly line + contour fill .... \n");

	printf("\nBoundary fill (b) or Seed fill (s) ? ");
	fflush(stdout);

	ans = gemdos(0x1);
	if (ans == 'b' || ans == 'B') colour = 1;
	else		colour = -1;

	tmp = vsl_color(handle,line_colour);
	tmp = vswr_mode(handle,write_mode);
	tmp = vsl_type(handle,line_type);
	tmp = vsl_width(handle,line_width);
	tmp = vsl_ends(handle,line_start,line_end);
	tmp = vsf_color(handle,fill_colour);
	tmp = vsf_interior(handle,fill_interior);
	tmp = vsf_style(handle,fill_style);

	pxyarray[0] = 150;
	pxyarray[1] = 150;
	pxyarray[2] = 300;
	pxyarray[3] = 150;
	pxyarray[4] = 300;
	pxyarray[5] = 300;
	pxyarray[6] = 150;
	pxyarray[7] = 300;
	pxyarray[8] = 150;
	pxyarray[9] = 150;

	v_pline(handle, 5, pxyarray);

	v_contourfill(handle,200,200,colour);

} /* contour_fill */

void bar()
{
	printf("filled bar ...\n");
	
	tmp = vsf_color(handle,fill_colour);
	tmp = vsf_interior(handle,fill_interior);
	tmp = vswr_mode(handle,write_mode);
	tmp = vsf_style(handle,fill_style);
	tmp = vsf_perimeter(handle,fill_perimeter);

	pxyarray[0] = 150;
	pxyarray[1] = 200;
	pxyarray[2] = 430;
	pxyarray[3] = 300;

	v_bar(handle,pxyarray);

} /* bar */

void arc()
{
	printf("arc drawing ... \n");

	tmp = vsl_color(handle,line_colour);
	tmp = vsl_type(handle,line_type);
	tmp = vswr_mode(handle,write_mode);
	tmp = vsl_width(handle,line_width);
	tmp = vsl_ends(handle,line_start,line_end);

	v_arc(handle,200,200,150,0,2700);

} /* arc */

void pie()
{
	printf("pie slice drawing ... \n");

	tmp = vsf_color(handle,fill_colour);
	tmp = vsf_interior(handle,fill_interior);
	tmp = vswr_mode(handle,write_mode);
	tmp = vsf_style(handle,fill_style);
	tmp = vsf_perimeter(handle,fill_perimeter);

	v_pieslice(handle,200,200,150,0,2700);

} /* pie */

void circle()
{
	printf("circle drawing ... \n");

	tmp = vsf_color(handle,fill_colour);
	tmp = vsf_interior(handle,fill_interior);
	tmp = vswr_mode(handle,write_mode);
	tmp = vsf_style(handle,fill_style);
	tmp = vsf_perimeter(handle,fill_perimeter);
	
	for (tmp = 20; tmp < 300; tmp +=40) {
		v_circle(handle,10+2*tmp,200,tmp);
	}

} /* circle */

void ellarc()
{
	printf("elliptical arc drawing ... \n");

	tmp = vsl_color(handle,line_colour);
	tmp = vsl_type(handle,line_type);
	tmp = vswr_mode(handle,write_mode);
	tmp = vsl_width(handle,line_width);
	tmp = vsl_ends(handle,line_start,line_end);

	v_ellarc(handle,200,200,150,100,0,2700);

} /* ellarc */

void ellpie()
{
	printf("elliptical pie slice drawing ... \n");

	tmp = vsf_color(handle,fill_colour);
	tmp = vsf_interior(handle,fill_interior);
	tmp = vswr_mode(handle,write_mode);
	tmp = vsf_style(handle,fill_style);
	tmp = vsf_perimeter(handle,fill_perimeter);

	v_ellpie(handle,400,200,150,100,0,2700);

} /* ellpie */

void ellipse()
{
	printf("ellipse drawing ... \n");

	tmp = vsf_color(handle,fill_colour);
	tmp = vsf_interior(handle,fill_interior);
	tmp = vswr_mode(handle,write_mode);
	tmp = vsf_style(handle,fill_style);
	tmp = vsf_perimeter(handle,fill_perimeter);

/*	v_ellipse(handle,200,200,150,100); */
	v_ellipse(handle,200,200,15,10);

} /* ellipse */

void roundbox()
{
	printf("rounded box drawing ... \n");

	pxyarray[0] = 150;
	pxyarray[1] = 100;
	pxyarray[2] = 450;
	pxyarray[3] = 350;

	tmp = vsf_interior(handle,fill_interior);
	tmp = vsf_style(handle,fill_style);
	tmp = vswr_mode(handle,2);

	vr_recfl(handle,pxyarray);

	tmp = vsl_color(handle,line_colour);
	tmp = vsl_type(handle,line_type);
	tmp = vswr_mode(handle,write_mode);
	tmp = vsl_width(handle,line_width);

	pxyarray[0] = 200;
	pxyarray[1] = 130;
	pxyarray[2] = 400;
	pxyarray[3] = 300;

	v_rbox(handle,pxyarray);

} /* roundbox */
E 1
