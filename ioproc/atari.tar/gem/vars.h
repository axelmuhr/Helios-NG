/*************************************************************************/
/*									*/
/*			VARS.H						*/
/*									*/
/************************************************************************/

/************************************************************************/
/*									*/
/* Contains all the static globals needed by the Atari graphics library */
/*									*/
/************************************************************************/

/*		VIRTUAL DEVICE INTERFACE			*/

#ifdef Top_Level

#define EXTERN
WORD CLU_PRESENT = MAPPED;

#else

#define EXTERN extern
extern WORD CLU_PRESENT;

#endif

EXTERN HANDLE 	*WS[ MAX_HANDLES ];	/* Array of pointers to workstation */

EXTERN WORD	CONTRL[ MAX_POINTS ];
EXTERN WORD	INTIN[  MAX_POINTS ];
EXTERN WORD	PTSIN[  MAX_POINTS ];
EXTERN WORD	PTSOUT[ MAX_POINTS ];
EXTERN WORD	INTOUT[ MAX_POINTS ];


/*		WORKSTATION					*/

EXTERN WORD WS_INUSE[MAX_HANDLES];	/* Booleans identifying valid */
				/* workstation records */
EXTERN WORD CLU[256][2][3];	/* Color table */
				/* One entry per color index */
				/* Red, Green and Blue components */
				/* in device and in VDI form */

EXTERN SCREEN_PARAMS SCREEN;

EXTERN WORD OPEN_MASK[32];	/* Mask pattern, to be set to all 1 */
			/* Used to get the effect of mask disabled */

EXTERN WORD LINE_PATTERNS[8];  /* Contains bit patterns representing the line */
			/* types that are available. Should be indexed */
			/* by MAX_LINE_TYPES, but C arrays go from 0 */

EXTERN WORD *CROSS_PATTERN[13];/* Pointers to the bit patterns representing the */
			/* cross hatch patterns. Should be indexed by */
			/* N_CROSS_PATTERNS  but C arrays go from 0 */

EXTERN WORD *FILL_PATTERN[25]; /* Pointers to the bit patterns representing the */
			/* dotted fill patterns. Should be indexed by */
			/* N_FILL_PATTERNS but C arrays go from 0 */

EXTERN WORD *MARK_INFO[6];	/* Pointers to the points representing the symbols */

/* These are the procedures used to access the display */
/* These procedures are initialised to the correct procedures for each */
/* screen variant.We do not need to test on screen variant within any */
/* procedure that uses these procedures--they will automatically call */
/* the correct one */

/*	Fill_Rect_Region(ptr_left,ptr_right,height)			  */
/*						fill a rectangular region */
/*						using the fill attributes */

extern void Fill_Rect_Region(PIX_OFFSET,PIX_OFFSET,WORD);

/*	OTHER GLOBALS NOT DEFINED BY ATARI NOMENCLATURE	*/

EXTERN WORD curx , cury;		/* Current drawing position */

/* Temporary storage for one scanline */

EXTERN WORD	*tmpscanline;

EXTERN PIX_OFFSET	const_tmpscanline;	/* PIX_OFFSET of above array */

/* commom external functions */

extern void bytblt(WORD *,WORD *,WORD,WORD,WORD,WORD,WORD,WORD,WORD);
extern BYTE *get_memory(UWORD);
extern WORD free_memory(BYTE *);
extern WORD printf(BYTE *,...);
