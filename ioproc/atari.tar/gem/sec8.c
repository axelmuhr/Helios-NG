/************************************************************************/
/*									*/
/*				SEC8.C					*/
/*									*/
/************************************************************************/

/************************************************************************/
/*									*/
/* Contains all the "inquire" routines for modes, indices and styles 	*/
/* which are in the GEM VDI manual Section 8 and needed by the		*/
/* screen driver.							*/
/* PJW									*/
/*									*/
/************************************************************************/

#include "header.h"

/* FUNCTIONS IN THIS MODULE:						*/
/*									*/
/*  FUNCTION	DESCRIPTION		NAME		MANUAL SECTION	*/
/*									*/
/*	 26:	Inquire color						*/
/*		representation	 	vq_color		8	*/
/*	 35:	Inquire current						*/
/*		polyline attributes 	vql_attributes		8	*/
/*	 36:	Inquire current						*/
/*		polymarker attributes 	vqm_attributes		8	*/
/*	 37:	Inquire current fill					*/
/*		area attributes 	vqf_attributes		8	*/
/*	 38:	Inquire current graphic					*/
/*		text attributes 	vqt_attributes		8	*/
/*	 102:	Extended inquire 	vq_extnd		8	*/
/*	 116:	Inquire text extent 	vqt_extent		8	*/
/*	 117:	Inquire character					*/
/*		cell width	 	vqt_width		8	*/
/*	 130:	Inquire face name					*/
/*		and index	 	vqt_name		8	*/
/*	 131:	Inquire current						*/
/*		face information	vq_fontinfo		8	*/
/*           								*/

void vq_color()
/* Function 26: Inquire color representation */
{
	WORD index;

	index = INTIN[0];

	/* Validate index */
	INTOUT[0] = -1;

	CONTRL[4] = 1;
	CONTRL[2] = 0;

	if ( SCREEN.MODE != 0 && index < 256 && index >= 0) {

		INTOUT[0] = index;
	
		if (INTIN[1]) {	/* Realised values are required */
		
			INTOUT[1] = CLU[index][1][0] * 1000 / 255;
			INTOUT[2] = CLU[index][1][1] * 1000 / 255;
			INTOUT[3] = CLU[index][1][2] * 1000 / 255;

		} else {	/* Requested values are required */

			INTOUT[1] = CLU[index][0][0];	/* red */
			INTOUT[2] = CLU[index][0][1];	/* green */
			INTOUT[3] = CLU[index][0][2];	/* blue */
		}
		
		CONTRL[2] = 0;
		CONTRL[4] = 4;
	}

	if ( SCREEN.MODE == 0 && index < 16 && index >= 0) {

		INTOUT[0] = index;
	
		if (INTIN[1]) {	/* Realised values are required */
		
			INTOUT[1] = CLU[index][1][0] * 1000 / 15;
			INTOUT[2] = CLU[index][1][1] * 1000 / 15;
			INTOUT[3] = CLU[index][1][2] * 1000 / 15;

		} else	{	/* Requested values are required */

			INTOUT[1] = CLU[index][0][0];	/* red */
			INTOUT[2] = CLU[index][0][1];	/* green */
			INTOUT[3] = CLU[index][0][2];	/* blue */
		}
		
		CONTRL[2] = 0;
		CONTRL[4] = 4;
	}

} /* vq_color() */

void vql_attributes()
/* Function 35: Inquire current polyline attributes */
{
	WORD i;

/* determine the line type; the LINE_TYPE field contains a copy of the */
/* actual pattern to improve efficiency inside 'plot_line', so we must */
/* determine the index value by comparing against the line pattern styles */

	for (i = 1; i <= MAX_LINE_TYPES; i++)
		if (WS_INFO->LINE_TYPE == LINE_PATTERNS[i]) {
			INTOUT[0] = i;
			break;
		}

	INTOUT[1] = WS_INFO->LINE_COLOR_INDEX;
	INTOUT[2] = WS_INFO->WRITE_MODE;
	INTOUT[3] = WS_INFO->LINE_END_STYLE[0];	/* start point */
	INTOUT[4] = WS_INFO->LINE_END_STYLE[1];	/* end point */
	PTSOUT[0] = WS_INFO->LINE_WIDTH;

	PTSOUT[1] = 0;
	CONTRL[2] = 1;
	CONTRL[4] = 5;

} /* vql_attributes() */

void vqm_attributes()
/* Function 36: Inquire current polymarker attributes */
{
	INTOUT[0] = WS_INFO->MARKER_TYPE;
	INTOUT[1] = WS_INFO->MARKER_COLOR_INDEX;
	INTOUT[2] = WS_INFO->WRITE_MODE;

	PTSOUT[0] = WS_INFO->MARKER_WIDTH;
	PTSOUT[1] = WS_INFO->MARKER_HEIGHT;

	CONTRL[2] = 1;
	CONTRL[4] = 3;

} /* vqm_attributes() */

void vqf_attributes()
/* Function 37: Inquire current polymarker attributes */
{
	INTOUT[0] = WS_INFO->FILL_INTERIOR_STYLE;

	if (WS_INFO->FILL_MASK == WS_INFO->FILL_USER_PATTERN) {
		INTOUT[0] = USER_DEFINED_STYLE;
	}

	INTOUT[1] = WS_INFO->FILL_COLOR_INDEX;
	INTOUT[2] = WS_INFO->FILL_STYLE_INDEX;
	INTOUT[3] = WS_INFO->WRITE_MODE;
	INTOUT[4] = WS_INFO->FILL_OUTLINED;

	CONTRL[2] = 0;
	CONTRL[4] = 5;

} /* vqf_attributes() */

void vqt_attributes()
/* Function 38: Inquire current graphic text attributes */
{
	INTOUT[0] = 1;
	INTOUT[1] = WS_INFO->TEXT_COLOR_INDEX;
	INTOUT[2] = WS_INFO->TEXT_ANGLE;
	INTOUT[3] = WS_INFO->TEXT_ALIGN[0]; /* horizontal alignment */
	INTOUT[4] = WS_INFO->TEXT_ALIGN[1]; /* vertical alignment */
	INTOUT[5] = WS_INFO->WRITE_MODE - 1;

	PTSOUT[0] = WS_INFO->TEXT_CHAR_WIDTH;	/* Character width */
	PTSOUT[1] = WS_INFO->TEXT_CHAR_HEIGHT;	/* Char height from baseline */
	PTSOUT[2] = WS_INFO->TEXT_CELL_WIDTH;	/* Character cell width */
	PTSOUT[3] = WS_INFO->TEXT_CELL_HEIGHT;	/* Character cell height */

	CONTRL[2] = 2;
	CONTRL[4] = 6;

} /* vqt_attributes() */

void vq_extnd()
/* Function 102: Extended inquire */
{
	WORD i;
	void load_ws_values(void);

	if (INTIN[0] == 0) {	/* Return the standard set */
		load_ws_values();	
		return;
	}
	
	/* Return the extended set */
	INTOUT[0] =  4;	/* Screen type */
	INTOUT[1] =  1;	/* Number of background colors */
	INTOUT[2] =  31;/* Text effects */
	INTOUT[3] =  0;	/* No scaling */
	INTOUT[4] =  SCREEN.DEPTH;	/* Number of planes */
	INTOUT[5] =  1;	/* Color look-up table supported */
	INTOUT[6] =  1000;/* RasterOps/sec *//* FINE TUNE */
	INTOUT[7] =  1;	/* Contour fill capable */
	INTOUT[8] =  1;	/* Character rotation= 90 degree only */
	INTOUT[9] =  4;	/* Number of writing modes */
	INTOUT[10] = 2;	/* Input mode = sample */
	INTOUT[11] = 1;	/* Text alignment capable */
	INTOUT[12] = 0;	/* Device cannot ink */
	INTOUT[13] = 0;	/* Cannot rubberband */
	INTOUT[14] = MAX_POINTS / 2;	/* Polyline/marker filled area limit */
	INTOUT[15] = MAX_POINTS / 2;	/* Unbounded size to INTIN */
	INTOUT[16] = 2;	/* Number of mouse keys */
	INTOUT[17] = 0;	/* Styles for wide lines are not supported */
	INTOUT[18] = 0;	/* Writing modes for wide lines */

	/* Not used, but must be zero */
	for (i = 19; i <= 44; i++) INTOUT[i] = 0;
	for (i = 0;  i <= 11; i++) PTSOUT[i] = 0;

	CONTRL[2] = 6;
	CONTRL[4] = 45;

} /* vq_extend() */

void vqt_extent()
/* Function 116: Inquire text extent */
/* UNFINISHED */
{
	WORD width,height;

	width     = CONTRL[3] * WS_INFO->TEXT_CELL_WIDTH;
	height    = WS_INFO->TEXT_CELL_HEIGHT;

	PTSOUT[0] = PTSOUT[1] = 0;

	PTSOUT[2] = width - 1;
	PTSOUT[3] = 0;

	PTSOUT[4] = width - 1;
	PTSOUT[5] = height - 1;

	PTSOUT[6] = 0;
	PTSOUT[7] = height - 1;

	CONTRL[2] = 4;
	CONTRL[4] = 0;

} /* vqt_extent() */

void vqt_width()
/* Function 117: Inquire character cell width */
{
/* UNFINISHED: need to know what left and right char alignment deltas are */
/* See Manual page 8-18 */
/* FINE TUNE: currently assumes a fixed size cell */
	INTOUT[0] = INTIN[0];	/* Pass ADE value back */
	PTSOUT[0] = WS_INFO->TEXT_CELL_WIDTH;
	PTSOUT[1] = 0;
	PTSOUT[2] = 1;
	PTSOUT[3] = 0;
	PTSOUT[4] = 1;
	PTSOUT[5] = 0;

	CONTRL[2] = 3;
	CONTRL[4] = 1;

} /* vqt_width() */

void vqt_name()
/* Function 130: Inquire face name and index */
/* UNFINISHED */
/* Need to know what ADE is */
/* See Manual page 8-19 */
{
	return;

} /* vqt_name() */

void vq_fontinfo()
/* Function 131: Inquire current face information */
/* UNFINISHED */
/* Need to know what ADE is */
/* See Manual page 8-21 */
{
	return;

} /* vqt_fontinfo() */
