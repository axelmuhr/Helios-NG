/************************************************************************/
/*									*/
/*				SEC9.C					*/
/*									*/
/************************************************************************/

#include "header.h"

/* FUNCTIONS IN THIS MODULE:						*/
/*									*/
/*  FUNCTION	DESCRIPTION		NAME		MANUAL SECTION	*/
/*									*/
/*	 5:	Escape 			v_escape		9	*/
/*									*/
/* Escapes are:								*/
/*									*/
/* Esc 1:	Inquire addressable alpha character cells		*/
/* Esc 2:	Exit alpha mode						*/
/* Esc 3:	Enter alpha mode					*/
/* Esc 4:	Alpha cursor up						*/
/* Esc 5:	Alpha cursor down					*/
/* Esc 6:	Alpha cursor right					*/
/* Esc 7:	Alpha cursor left					*/
/* Esc 8:	Home alpha cursor					*/
/* Esc 9:	Erase to end of screen					*/
/* Esc 10:	Erase to end of alpha text line				*/
/* Esc 11:	Direct alpha cursor address				*/
/* Esc 12:	Output cursor addressable alpha text			*/
/* Esc 15:	Inquire current alpha cursor address			*/
/* Esc 18:	Place graphic cursor at location			*/
/* Esc 19:	Remove last graphic cursor				*/
/*									*/

void v_escape()
/* Function 5: various escapes */
{
	void vq_chcells(void);
	void v_exit_cur(void);
	void v_enter_cur(void);
	void v_curup(void);
	void v_curdown(void);
	void v_curright(void);
	void v_curleft(void);
	void v_curhome(void);
	void v_eeos(void);
	void v_eeol(void);
	void vs_curaddress(void);
	void v_curtext(void);
	void vq_curaddress(void);
	void v_dspcur(void);
	void v_rmcur(void);

	switch( CONTRL[5] )
		{
		case 1:  vq_chcells();		break;
		case 2:  v_exit_cur();		break;
		case 3:  v_enter_cur();		break;
		case 4:  v_curup();		break;
		case 5:  v_curdown();		break;
		case 6:  v_curright();		break;
		case 7:  v_curleft();		break;
		case 8:  v_curhome();		break;
		case 9:  v_eeos();		break;
		case 10: v_eeol();		break;
		case 11: vs_curaddress();	break;
		case 12: v_curtext();		break;
		case 15: vq_curaddress();	break;
		case 18: v_dspcur();		break;
		case 19: v_rmcur();		break;
		default:;	
	}	

} /* v_escape() */

void vq_chcells()
/* Esc 1: Inquire addressable alpha character cells */
{
	/* Number of addressable character rows */
	INTOUT[0] = SCREEN.CHAR_ROWS;

	/* Number of addressable character columns */
	INTOUT[1] = SCREEN.CHAR_COLS;
	
	/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 2;	

} /* vq_chcells() */

void v_exit_cur()
/* Esc 2: Exit alpha mode */
{
/* This implementation does not distinguish between graphics mode */
/* and alpha mode, other than by the presence of the alpha cursor */
	
	/* Alpha cursor disable */
	WS_INFO->A_ON = 0;
	
	/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;	

} /* v_exit_cur() */

void v_enter_cur()
/* Esc 3: Enter alpha mode */
{
/* This implementation does not distinguish between graphics mode */
/* and alpha mode, other than by the presence of the alpha cursor */
/* and the setting of the alpha mode flag */	
#ifdef NEVER
	void RasterOp(	WORD,PIX_OFFSET,WORD,
			WORD,WORD,PIX_OFFSET,WORD,
			WORD *,PIX_OFFSET);
#endif

	/* Initialise cursor's position to top left */
	WS_INFO->A_CURSOR_X = 1;
	WS_INFO->A_CURSOR_Y = 1;

/* Put cursor on the screen */
#ifdef NEVER
	RasterOp(VDI_XOR,
		0L,SCREEN.WIDTH,
		SCREEN.WIDTH,SCREEN.HEIGHT,
		0L,SCREEN.WIDTH,
		(WORD *) SCREEN.G_CUR_PAT,0L);
#endif

	/* Alpha cursor enable */
	WS_INFO->A_ON = 1;
	
	/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;	

} /* v_enter_cur() */

void v_curup()
/* Esc 4: Alpha cursor up */
{
	/* Move alpha cursor up, unless already at top */
	void move_a_cursor(HANDLE *,WORD,WORD);

	move_a_cursor(WS_INFO,WS_INFO->A_CURSOR_X,WS_INFO->A_CURSOR_Y - 1);

	/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;	

} /* v_curup() */

void v_curdown()
/* Esc 5: Alpha cursor down */
{
	/* Move cursor down, unless already at bottom */
	void move_a_cursor(HANDLE *,WORD,WORD);

	move_a_cursor(WS_INFO,WS_INFO->A_CURSOR_X,WS_INFO->A_CURSOR_Y + 1);

	/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;	

} /* v_curdown() */

void v_curright()
/* Esc 6: Alpha cursor right */
{
	/* Move cursor right, unless already at right margin */
	void move_a_cursor(HANDLE *,WORD,WORD);

	move_a_cursor(WS_INFO,WS_INFO->A_CURSOR_X + 1,WS_INFO->A_CURSOR_Y);

	/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;	

} /* v_curright() */

void v_curleft()
/* Esc 7: Alpha cursor left */
{
	/* Move cursor left, unless already at left margin */
	void move_a_cursor(HANDLE *,WORD,WORD);

	move_a_cursor(WS_INFO,WS_INFO->A_CURSOR_X - 1,WS_INFO->A_CURSOR_Y);

	/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;	

} /* v_curleft() */

void v_curhome()
/* Esc 8: Home alpha cursor */
{
	void move_a_cursor(HANDLE *,WORD,WORD);

	move_a_cursor(WS_INFO,1,1);

	/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;	

} /* v_curhome() */

void v_eeos() 
/* Esc 9: Erase to end of screen */
/* Atari do not define what happens if not in alpha mode */
/* We assume only permitted if in alpha mode */
{
	WORD gsavex, gsavey;
	WORD y;
	void move_a_cursor(HANDLE *,WORD,WORD);
	void v_eeol(void);

	/* Check we are in alpha mode */
	if (!WS_INFO->A_ON) return;

	/* Erase to end of current line */
	/* All input values should be correct, except for the function number */
	CONTRL[5 ]= 10;	/* Make function number be that of v_eeol() */
	v_eeol();
	
	/* Save current alpha cursor position */
	gsavex = SCREEN.G_CURSOR_X;
	gsavey = SCREEN.G_CURSOR_Y;
	
	/* Now move cursor down successive lines, clearing as we go */
	for (y = gsavey + 1; y <= SCREEN.CHAR_ROWS; y++) {
		move_a_cursor(WS_INFO,0,y);
		v_eeol();
	}
	
	/* Replace cursor to its original position */
	move_a_cursor(WS_INFO,gsavex,gsavey);

	/* Restore the environment */
	CONTRL[5] = 9;

	/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_eeos() */

void v_eeol()
/* Esc 10: Erase to end of alpha text line */
{
	void RasterOp(	WORD,PIX_OFFSET,WORD,
			WORD,WORD,PIX_OFFSET,WORD,
			WORD *,PIX_OFFSET);
	PIX_OFFSET celloffset(WORD,WORD);

	RasterOp(	VDI_ZERO,
			celloffset(SCREEN.G_CURSOR_X,SCREEN.G_CURSOR_Y),
			SCREEN.STRIDE,
			(SCREEN.CHAR_COLS - WS_INFO->A_CURSOR_X)*
						WS_INFO->TEXT_CELL_WIDTH,
			WS_INFO->TEXT_CELL_HEIGHT,
			celloffset(SCREEN.G_CURSOR_X,SCREEN.G_CURSOR_Y),
			SCREEN.STRIDE,
			OPEN_MASK,0L);

} /* v_eeol() */

void vs_curaddress()
/* Esc 11: Direct alpha cursor address */
{
	void move_a_cursor(HANDLE *,WORD,WORD);

	/* Move to required position */
	move_a_cursor(WS_INFO,INTIN[1],INTIN[0]);

	/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;	

} /* vs_curaddress() */

void v_curtext()
/* Esc 12: Output cursor addressable alpha text */
/* UNFINISHED */
{
	return;

} /* v_curtext() */

void vq_curaddress()
/* Esc 15: Inquire current alpha cursor address */
{
	/* Return values */
	INTOUT[0] = WS_INFO->A_CURSOR_Y;	/* Row number */
	INTOUT[1] = WS_INFO->A_CURSOR_X;	/* Column number */
		
	CONTRL[2] = 0;
	CONTRL[4] = 2;

} /* vq_curaddress() */

void v_dspcur()
/* Esc 18: Place graphic cursor at location */
{
	void plot_g_cursor(WORD,WORD);

	/* Place at required position */
	plot_g_cursor(PTSIN[0],PTSIN[1]);	/* Plot the cursor */

	/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;	

} /* v_dspcur() */

void v_rmcur()
/* Esc 19: Remove last graphic cursor */
{
	void plot_g_cursor(WORD,WORD);

	/* Unplot the graphics cursor */	
	plot_g_cursor(SCREEN.G_CURSOR_X,SCREEN.G_CURSOR_Y);

	/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;	

} /* v_rmcur() */

/************************************************************************/
/*									*/
/*			LOCAL UTILITIES					*/
/*									*/
/************************************************************************/

void move_a_cursor(HANDLE *WSPTR,WORD A_CUR_X,WORD A_CUR_Y)
/* Updates the globals defining the alpha cursor */
/* If the alpha cursor is enabled it will be removed from its */
/* old position and moved to the new one */
{
	void a_cursor_comp(WORD,WORD);

	/* Clamp to within the screen */
	if (A_CUR_X < 1) 		 A_CUR_X = 1;
	if (A_CUR_Y < 1) 		 A_CUR_Y = 1;
	if (A_CUR_X >= SCREEN.CHAR_COLS) A_CUR_X = SCREEN.CHAR_COLS;
	if (A_CUR_Y >= SCREEN.CHAR_ROWS) A_CUR_Y = SCREEN.CHAR_ROWS;
		
	/* Remove alpha cursor from current position */
	if (WSPTR->A_ON) a_cursor_comp(WSPTR->A_CURSOR_X,WSPTR->A_CURSOR_Y);

	/* Update its position */
	WSPTR->A_CURSOR_X = A_CUR_X;
	WSPTR->A_CURSOR_Y = A_CUR_Y;
	
	/* Redraw alpha cursor at new position */
	if (WSPTR->A_ON) a_cursor_comp(A_CUR_X,A_CUR_Y);

} /* move_a_cursor() */

void plot_g_cursor(WORD G_CUR_X,WORD G_CUR_Y)
/* XOR the graphics cursor at named position */
{
	void g_cursor_comp(WORD,WORD);

	/* Clamp to within the screen */
	if (G_CUR_X < 0) 	      G_CUR_X = 0;
	if (G_CUR_Y < 0) 	      G_CUR_Y = 0;
	if (G_CUR_X >= SCREEN.WIDTH)  G_CUR_X = SCREEN.WIDTH - 1;
	if (G_CUR_Y >= SCREEN.HEIGHT) G_CUR_Y = SCREEN.HEIGHT - 1;
	
	/* Update */
	SCREEN.G_CURSOR_X = G_CUR_X;
	SCREEN.G_CURSOR_Y = G_CUR_Y;

/* The graphics cursor is now XORed at the indicated position */
/* If already there, this will erase the cursor; */
/* otherwise it shows it */
	g_cursor_comp(G_CUR_X,G_CUR_Y);

} /* plot_g_cursor() */
