/************************************************************************/
/*									*/
/*				SEC4A.C					*/
/*			ATARI GRAPHICS LIBRARY				*/
/*			OUTPUT FUNCTIONS  (Section 4)			*/
/*									*/
/************************************************************************/

#define Top_Level
#include "header.h"

/* FUNCTIONS IN THIS MODULE:						*/
/*									*/
/*  FUNCTION	DESCRIPTION		NAME		MANUAL SECTION	*/
/*	 9:	Filled area 		v_fillarea		4	*/
/*	 10:	Cell array 		v_cellarray		4	*/
/*	 11:	Generalised Drawing Primitive			4	*/
/*					v_bar				*/
/*					v_arc				*/
/*					v_pieslice			*/
/*					v_circle			*/
/*					v_ellipse			*/
/*					v_ellarc			*/
/*					v_ellpie			*/
/*					v_rbox				*/
/*					v_rfbox				*/
/*	 103:	Contour fill 		v_contourfill		4	*/
/*	 114:	Fill rectangle	 	vr_recfl		4	*/
/*									*/

/* plot_line		uses the LINE attributes */
/* plot_marker		uses color, scale, type and writing mode */
/* wide_line		uses the LINE attributes */
/* are the only procedures that actually update the screen */

/************************************************************************/
/*									*/
/*			Static Drawing Variables			*/
/*			used by this module				*/
/*									*/
/************************************************************************/

static WORD xc,yc;			/* The cente of an arc */
static WORD xrad,yrad;			/* The radii of an arc */
static WORD beg_angle,end_angle;	/* The start, end angles of an arc */
static WORD delta_angle;		/* The angle difference */
static WORD n_steps;		/* The number of steps for the arc */
static WORD xend_line,yend_line;	/* The cds of the line to display */

#define MAX_ARC_CT	60		/* number of segments per arc */
					/* NOTE should be a multiple of 4 */
					/* each seg represents */
					/* (3600/10)/MAX_ARC_CT degrees */

#define TRUE	1
#define FALSE	0

#define Pattern_Offset_Start	((UWORD)0x8000)

/* Two tables are used to represent the cos and sin functions */
/* Arcs/circles are drawn as polylines where a complete circle */
/* is represented by MAX_ARC_CT line segments. Thus the angle subtended */
/* by each line sgement is (3600/10)/MAX_ARC_CT degrees. Each of these */
/* tables contains the sin/cos of all the such angles in the first octant */
/* For example when MAX_ARC_CT is 60 each line segment represents 6 degrees */
/* and so there should be 16 = 90/6 + 1 entries in these tables representing */
/* the angles 0,6,12,.....,90 */
/* Each of these values is also scaled by 2**N_FRACT_BITS so that */
/* expressions may be calculated using LONG arithmetic. The result of each */
/* expression is then shifted by N_FRACT_BITS to remove the scaling */

static WORD cos_table[] = {
	0x10000L, 0xfe99L, 0xfa68L, 0xf378L, 0xe9deL, 0xddb4L, 0xcf1cL,
	0xbe3fL, 0xab4cL, 0x9679L, 0x8000L, 0x6820L, 0x4f1cL, 0x353aL,
	0x1ac2L, 0x0L 
};

static WORD sin_table[] = {
	0x0L, 0x1ac2L, 0x353aL, 0x4f1cL, 0x6820L, 0x8000L, 0x9679L,
	0xab4cL, 0xbe3fL, 0xcf1cL, 0xddb4L, 0xe9deL, 0xf378L, 0xfa68L,
	0xfe99L, 0x10000L
};

#define NBYTES_PER_INTEGER	4

/* some values and parameters for the Fill Routines */
#define SCANLO	1
#define SCANHI	2
#define MAX_FILL_STACK_FRAMES	5	/* the maximum number of fill stack */
					/* frames */
#define MAX_FILL_STACK_RECORDS	1024	/* the maximum number of fill stack */
					/* records within each frame */

static struct FILL_STACK_RECORD	*fill_stack[MAX_FILL_STACK_FRAMES];
static struct FILL_STACK_RECORD	*fill_ptr;
static WORD current_stack_frame;		/* index to the current stack_frame */
static WORD number_stacked;		/* number of Fill Records */

void v_pline()
/* Zero length lines are shown as points */
/* Will not show a single coordinate pair */
/* Uses attributes: COLOUR, LINE_TYPE, LINE_WIDTH, END_STYLE, WRITE_MODE */
{
	void draw_poly_line(void);

	/* initialise the pattern to start at the first bit */

	WS_INFO->LINE_PATTERN_OFFSET = Pattern_Offset_Start;
	
	draw_poly_line();

	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_pline() */

void v_fillarea()
/* fills a complex polygon */
/* uses the fill area color, interior style, writing mode, style index */
{
	WORD	index;
	void	draw_filled_polygon(void);

	index = CONTRL[1] * 2 - 2;
	if (	PTSIN[index    ] != PTSIN[0] &&
		PTSIN[index + 1] != PTSIN[1]) {
			PTSIN[index + 2] =  PTSIN[0];
			PTSIN[index + 3] =  PTSIN[1];
			CONTRL[1]++;
	}

	draw_filled_polygon();

	CONTRL[1] = (index + 2) / 2;
		
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_fillarea() */

void v_cellarray()
/* draws a rectangular array of blocks of color */
{	
	WORD *tmp_storage;
	WORD old_row,y_counter;
	WORD npixels,nrows;		/* aidth,height of each area */
	WORD xleft,ybot,xright,ytop;
	WORD row_error,row_constant,init_cell_constant,init_cell_start;
	PIX_OFFSET left_ptr;
	PIX_OFFSET pix_offset_to_tmp_storage;
	void 	init_cell_memory(WORD *,WORD,WORD,WORD,WORD);
	void 	RasterOp(WORD,PIX_OFFSET,WORD,
			WORD,WORD,PIX_OFFSET,WORD,
			WORD *,PIX_OFFSET);
	WORD 	clip_rectangle(WORD *,WORD *,WORD *,WORD *);
	WORD	*get_screen_lookalike(WORD);

	xleft =  PTSIN[0]; ybot = PTSIN[1];
	xright = PTSIN[2]; ytop = PTSIN[3];
	
	if (!clip_rectangle(&xleft,&ybot,&xright,&ytop))
		return;

	/* point to the lower left corner */
	left_ptr = OFFSET(xleft,ybot);
	
	/* number of pixels to update across the screen */
	npixels = xright - xleft + 1;
	
	/* temporary storage for each scan-line */
	tmp_storage = get_screen_lookalike((WORD) npixels);
	if (tmp_storage == (WORD *)NULL)
		return;
		
	/* the pixel offset to this storage, which is a constant */
	pix_offset_to_tmp_storage = ATPO(tmp_storage);
	
	/* the row_constant is the colour increment per scan-line */
	/* arithmetic is performed using LONGs so scale by 2**N_FRACT_BITS */
	row_constant = (CONTRL[9] << N_FRACT_BITS) /
		(PTSIN[3] - PTSIN[1] + 1);
	
	/* the row_error counts  the colour error on each scan-line */
	/* determine the row_error on the first scan-line to be updated */
	row_error = (ybot - PTSIN[1]) * row_constant;

	/* initialise the old colour row index */
	/* to start at the first row in the colour array that will be */
	/* visible */
	old_row = row_error >> N_FRACT_BITS;

	/* initialise the temporary storage with the first set of colours */
	init_cell_constant = (CONTRL[8] << N_FRACT_BITS) / 
			(PTSIN[2] - PTSIN[0] + 1);
	init_cell_start = (xleft - PTSIN[0]) * init_cell_constant;
	init_cell_memory(tmp_storage,old_row * CONTRL[7],
			npixels,init_cell_constant,init_cell_start);

	nrows = 1;
	for (y_counter = ybot; y_counter <= ytop; y_counter++) {
		if ( (row_error >> N_FRACT_BITS) != old_row) {
			/* RasterOp a number of rows onto the display */
			RasterOp(VDI_REPLACE,
				pix_offset_to_tmp_storage,0,
				xright-xleft+1,nrows,
				left_ptr,SCREEN.STRIDE,
				OPEN_MASK,0L);
			/* initialise a new array containing a new list */
			/* of source colours */
			old_row++;		/* new colour index */
			init_cell_memory(tmp_storage,
					old_row * CONTRL[7],
				npixels,init_cell_constant,init_cell_start);
			nrows = 0;
		}
		nrows++;
		row_error += row_constant;
		left_ptr -= SCREEN.STRIDE;
	}
	
	(void) free_memory((BYTE *) tmp_storage);
	/* the output variables */
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_cellarray() */

void init_cell_memory(p_o_t_s,color_index,npixels,cell_constant,col_error)
/* initialises the given storage with the correct colours for cellarray */
/* The required memory has been allocated and has a pointer as given */
/* Since this memory will be used by RasterOp it must be similar to the */
/* current screen format and so has been allocated by get_screen_lookalike. */
/* This memory may then be initialised by SPA. Note now that SPA takes a ptr. */
/* The colour array is given by the global INTIN, and color_index */
/* is the index to the first colour within this array to be used for this row*/
/* color_index indicates the first colour in this array to map to this row */
/* Because of possible clipping we must initialise the colour error term */
/* to col_error; the conastant between each pixel along the scan-line is */
/* given by cell_constant */
WORD *p_o_t_s;
WORD color_index;
WORD npixels;
WORD  cell_constant,col_error;
{
	WORD old_column,pixel_ctr;
	
	/* initialise the colour_column value */
	old_column = col_error >> N_FRACT_BITS;

	/* update the colour index to the fisrt colour that will */
	/* be visible */
	color_index += old_column;

	/* set the first pixel */
	SPA(p_o_t_s,(WORD) INTIN[color_index]);
	p_o_t_s++;

	/* for each remaining pixel, test the error variable and see */
	/* whether a new colour is to be selected */
	for (pixel_ctr = 1; pixel_ctr<npixels; pixel_ctr++) {
		if ((col_error >> N_FRACT_BITS)!= old_column) {
			old_column++;
			color_index++;
		}
		col_error += cell_constant;
		SPA(p_o_t_s,(WORD) INTIN[color_index]);
		p_o_t_s++;
	}

} /* init_cell_memory() */

void v_contourfill()
/* fills to a boundary or a colour */
{
	void seed_fill(WORD,WORD);
	void bdary_fill(WORD,WORD,WORD);

	if (INTIN[0]<0)
		/* fill from the given seed point */
		seed_fill(PTSIN[0],PTSIN[1]);
	else
		/* fill to the given boundary colour */
		bdary_fill(PTSIN[0],PTSIN[1],INTIN[0]);

	/* initialise the output variables */
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_contourfill() */

void vr_recfl()
/* fills a rectangular area with a pattern */
/* Uses all fill area attributes except outline */
{
	WORD xleft,ybot,xright,ytop;
	WORD clip_rectangle(WORD *,WORD *,WORD *,WORD *);

	if (PTSIN[0] < PTSIN[2]) {
		xleft  = PTSIN[0];
		xright = PTSIN[2];
	} else {
		xleft  = PTSIN[2];
		xright = PTSIN[0];
	}

	if (PTSIN[1] > PTSIN[3]) {
		ybot = PTSIN[1];
		ytop = PTSIN[3];
	} else {
		ybot = PTSIN[3];
		ytop = PTSIN[1];
	}

	if (!clip_rectangle(&xleft,&ybot,&xright,&ytop))
		return;

	FRR(OFFSET(xleft,ytop),OFFSET(xright+1,ytop),ybot-ytop+1);

	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* vr_recfl() */

WORD clip_rectangle(xleft,ybot,xright,ytop)
/* Clips the given rectangle against the Clip region and the Screen */
/* returns 0 if none of the region will be displayed; otherwise returns 1 */
/* Note that when the Clip Region is set it would be more efficient to */
/* intersect it with the screen coordinates */
/* The cds specifying the rectangle use the orientation as the user looks at */
/* the display; that is (xleft,ybot) is the lower left corner and */
/* (xright,ytop) is the upper right corner as we look at the screen */
WORD *xleft,*ybot,*xright,*ytop;
{
	if (WS_INFO->CLIP_FLAG) {
		/* Test against current clip region */

		if (	*ybot   < WS_INFO->CLIP_YMIN ||
			*ytop   > WS_INFO->CLIP_YMAX ||
			*xleft  > WS_INFO->CLIP_XMAX ||
			*xright < WS_INFO->CLIP_XMIN )
				return(0);

		if (*xleft  < WS_INFO->CLIP_XMIN) *xleft  = WS_INFO->CLIP_XMIN;
		if (*xright > WS_INFO->CLIP_XMAX) *xright = WS_INFO->CLIP_XMAX;
		if (*ytop   < WS_INFO->CLIP_YMIN) *ytop   = WS_INFO->CLIP_YMIN;
		if (*ybot   > WS_INFO->CLIP_YMAX) *ybot   = WS_INFO->CLIP_YMAX;
	
	 } else {
		/* Test against the Screen */
		if (	*xleft  > SCREEN_XRIGHT ||
			*xright < SCREEN_XLEFT  ||
			*ybot   < SCREEN_YBOT   ||
			*ytop   > SCREEN_YTOP   )
				return (0);
				
		if (*xleft  < SCREEN_XLEFT) 	*xleft  = SCREEN_XLEFT;
		if (*xright > SCREEN_XRIGHT) 	*xright = SCREEN_XRIGHT;
		if (*ybot   > SCREEN_YTOP)	*ybot   = SCREEN_YTOP;
		if (*ytop   < SCREEN_YBOT) 	*ytop   = SCREEN_YBOT;
	}

	/* some of the rectangle is visible */	
	return(1);

} /* clip_rectangle() */

void v_bar()
/* Uses fill area atributes */
/* FILL, INTERIOR STYLE, STYLE INDEX, WRITING MODE, COLOUR, PERIMETER STYLE */
{
	void vr_recfl(void);
	void v_pline(void);

	vr_recfl();

	if (WS_INFO->FILL_OUTLINED) {
		WORD save_line_type,save_line_colour,save_line_width;
		WORD save_line_mask;
		
		save_line_width = WS_INFO->LINE_WIDTH;
		WS_INFO->LINE_WIDTH = 1;  /* a thin line */
		save_line_type = WS_INFO->LINE_TYPE;
		WS_INFO->LINE_TYPE = LINE_PATTERNS[1];  /* a solid line */
		save_line_colour = WS_INFO->LINE_COLOR_INDEX;
		WS_INFO->LINE_COLOR_INDEX = WS_INFO->FILL_COLOR_INDEX;
		save_line_mask = WS_INFO->LINE_MASK;
		WS_INFO->LINE_MASK = LINE_PATTERNS[1];

		/* now do the outline of the bar */

		PTSIN[9] = PTSIN[1];
		PTSIN[8] = PTSIN[0];
		PTSIN[7] = PTSIN[3];
		PTSIN[6] = PTSIN[0];
		PTSIN[5] = PTSIN[3];
		PTSIN[4] = PTSIN[2];
		PTSIN[3] = PTSIN[1];
		PTSIN[2] = PTSIN[2];
		PTSIN[1] = PTSIN[1];
		PTSIN[0] = PTSIN[0];

		CONTRL[1] = 5;

		v_pline();

		WS_INFO->LINE_WIDTH = save_line_width;
		WS_INFO->LINE_TYPE = save_line_type;
		WS_INFO->LINE_COLOR_INDEX = save_line_colour;
		WS_INFO->LINE_MASK = save_line_mask;

		CONTRL[1] = 2;
	}
		
	/* Return values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_bar() */

void v_arc()
/* uses line attributes and calls draw_screen_arc to do the plotting */
/* COLOR, LINETYPE, WRITING MODE, WIDTH, END STYLES */
{
	void draw_screen_arc(void);

	beg_angle   = INTIN[0];
	end_angle   = INTIN[1];
	delta_angle = end_angle - beg_angle;

	if ( delta_angle < 0 ) delta_angle += 3600;

	n_steps     = (delta_angle*MAX_ARC_CT)/ 3600;
	if (n_steps == 0) return;

	xc   = PTSIN[0];
	yc   = PTSIN[1];
	xrad = PTSIN[6];
	yrad = xrad;

	draw_screen_arc();

	CONTRL[1] = 4;

	/* Return Values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_arc() */

void v_pieslice()
/* uses fill area attributes */
/* INTERIOR STYLE, WRITING MODE, FILL STYLE, FILL COLOR, PERIMETER STYLE */
{
	void v_arc(void);

	/* call v_arc() since the pie is filled within draw_screen_arc() */

	v_arc();

} /* v_pieslice() */
	
void v_circle()
/* uses fill area attributes */
/* INTERIOR STYLE, WRITING MODE, FILL STYLE, FILL COLOR, PERIMETER STYLE */
{
	void draw_screen_circle(void);

	xc   = PTSIN[0];
	yc   = PTSIN[1];
	xrad = PTSIN[4];
	yrad = xrad;

	draw_screen_circle();

	CONTRL[1] = 3;	/* this is corrupted inside draw_screen_circle */

	/* Return Values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_circle() */

void v_ellarc()
/* Uses line attributes */
/* COLOR, LINETYPE, WRITING MODE, WIDTH, END STYLES */
{
	void draw_screen_arc(void);

	beg_angle   = INTIN[0];
	end_angle   = INTIN[1];
	delta_angle = end_angle - beg_angle;

	if (delta_angle < 0) delta_angle += 3600;

	n_steps = (delta_angle*MAX_ARC_CT)/ 3600;
	if (n_steps == 0)return;

	xc   = PTSIN[0];
	yc   = PTSIN[1];
	xrad = PTSIN[2];
	yrad = PTSIN[3];
	
	draw_screen_arc();

	CONTRL[1] = 2;

	/* Return Values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_ellarc() */

void v_ellpie()
/* Uses fill area atributes */
/* FILL, INTERIOR STYLE, STYLE INDEX, WRITING MODE, COLOUR, PERIMETER STYLE */
{
	void v_ellarc(void);

	/* call v_ellarc since the pie is filled within draw_screen_arc() */
	v_ellarc();

	/* Return Values are set up in v_ellarc */

} /* v_ellpie() */

void v_ellipse()
/* draw an ellipse. uses the circle routine with unequal */
/* xrad and yrad values */
{
	void draw_screen_circle(void);

	xc   = PTSIN[0];
	yc   = PTSIN[1];
	xrad = PTSIN[2];
	yrad = PTSIN[3];
	
	draw_screen_circle();

	CONTRL[1] = 2;
	
	/* Return Values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_ellipse() */

void v_rbox()
/* Uses line attributes */
/* COLOR, LINETYPE, WRITING MODE, WIDTH, END STYLES */
{
	WORD	x1,y1,x2,y2;
	WORD 	rdeltax,rdeltay,i,j;
	WORD 	xl,yb,xr,yt;	/* as we look at the screen */
	WORD 	sin_scaled(WORD);
	WORD 	cos_scaled(WORD);
	void 	v_pline(void);
	void 	draw_filled_polygon(void);

/* The number of Line Segments representing the curvature at the corner */
#define N_CORNER_PTS	5

	x1 = PTSIN[0];
	y1 = PTSIN[1];
	x2 = PTSIN[2];
	y2 = PTSIN[3];

	if (x2 > x1) {
		rdeltax = (x2 - x1) >> 1;
		xl = x1; xr = x2;
	} else {
		rdeltax = (x1 - x2) >> 1;
		xl = x2; xr = x1;
	}

	if (y2 > y1) {
		rdeltay = (y2 - y1) >> 1;
		yb = y1; yt = y2;
	} else {
		rdeltay = (y1 - y2) >> 1;
		yb = y2; yt = y1;
	}

	/* initialise the x-radius for the corners */
	xrad = SCREEN.WIDTH >> 6;
	if (xrad > rdeltax)
		xrad = rdeltax;

	yrad = xrad;
	if (yrad > rdeltay)
		yrad = rdeltay;

	/* now determine the points on the circular quadrant at each corner */
	/* the magic numbers allow 5 segments to represent each corner */
	/* that is at angles 0, 180, 360, 540, 720 and 900 */
	/* Note that a change in MAX_ARC_CT may require these to be changed */

	j = 0;
	PTSIN[j++] = 0; PTSIN[j++] = yrad;
	PTSIN[j++] = cos_scaled(720/MAX_ARC_CT);
	PTSIN[j++] = sin_scaled(720/MAX_ARC_CT);
	PTSIN[j++] = cos_scaled(540/MAX_ARC_CT);
	PTSIN[j++] = sin_scaled(540/MAX_ARC_CT);
	PTSIN[j++] = cos_scaled(360/MAX_ARC_CT);
	PTSIN[j++] = sin_scaled(360/MAX_ARC_CT);
	PTSIN[j++] = cos_scaled(180/MAX_ARC_CT);
	PTSIN[j++] = sin_scaled(180/MAX_ARC_CT);
	PTSIN[j++] = xrad;
	PTSIN[j++] = 0;

	/* determine the complete path around the rectangle */
	xc = xr - xrad;
	yc = yb + yrad;

	/* the bottom right corner */
	for (i = N_CORNER_PTS<<1; i >= 0; i -= 2) {
		PTSIN[j++] = xc + PTSIN[i];
		PTSIN[j++] = yc - PTSIN[i+1];
	}

	xc = xl + xrad;
	/* the bottom left corner */

	for (i = 0; i <= N_CORNER_PTS<<1; i += 2) {
		PTSIN[j++] = xc - PTSIN[i];
		PTSIN[j++] = yc - PTSIN[i+1];
	}

	yc = yt - yrad;
	/* the top left corner */

	for (i = N_CORNER_PTS<<1; i >= 0; i -= 2) {
		PTSIN[j++] = xc - PTSIN[i];
		PTSIN[j++] = yc + PTSIN[i+1];
	}

	j = 0;
	xc = xr - xrad;
	/* the top right corner */

	for (i = 0; i <= N_CORNER_PTS<<1; i += 2) {
		PTSIN[j++] = xc + PTSIN[i];
		PTSIN[j++] = yc + PTSIN[i+1];
	}

	/* close up the rectangular box */
	j = (N_CORNER_PTS+1) << 3;
	PTSIN[j++] = PTSIN[0];
	PTSIN[j] = PTSIN[1];
	
	/* the line or fill atrributes are taken care of inside the */
	/* relevant plotting procedure */
	CONTRL[1] = ((N_CORNER_PTS+1) << 2) + 1;
	if (PRIMITIVE_ID == ROUNDED_RECTANGLE)
		v_pline();
	else if (PRIMITIVE_ID == FILLED_ROUND_RECTANGLE)
		draw_filled_polygon();
	else
		IOdebug("v_rbox::illegal primitive ID %d\n",PRIMITIVE_ID);
		
	/* Return Values */
	CONTRL[2] = 0;
	CONTRL[4] = 0;

} /* v_rbox() */

void v_rfbox()
/* Uses fill area atributes */
/* FILL, INTERIOR STYLE, STYLE INDEX, WRITING MODE, COLOUR, PERIMETER STYLE */
{
	void v_rbox(void);

	/* call v_rbox() since draw_filled_polygon is called to fill the box */
	v_rbox();
	/* this procedure also sets up the return values */

} /* v_rfbox() */


/************************  LOCAL UTILITIES  ***************************/

/* sets the current user position to (xin,yin) */
#define abs_move(x,y)	{ curx = (x); cury = (y); }

void draw_screen_circle()
/* draw a circle/ellipse on the screen. uses a trignometric method to */
/* calculate the line segments around the circumference, and uses 4-way */
/* symmetry for efficiency. */
/* Calls v_pline to actually draw the circle/ellipse. */
/* This ensures that the relevant */
/* line type/style etc is used to update the screen */
/* the globals xc,yc,xrad,yrad must have been initialised */
{
	WORD 	quad2,quad4;
	WORD	x_temp,y_temp;
	WORD 	j,theta,delta_theta;
	void	calc_pts(WORD,WORD);
	void	draw_filled_polygon(void);
	
	/* first do some trivial clipping against the Clip Region */
	if (WS_INFO->CLIP_FLAG) {
		if (((yc+yrad) < WS_INFO->CLIP_YMIN) ||
				((yc-yrad) > WS_INFO->CLIP_YMAX))
			return;
		if (((xc+xrad) < WS_INFO->CLIP_XMIN) ||
				((xc-xrad) > WS_INFO->CLIP_XMAX))
			return;
	} else {
	/* do some trivial clipping against the screen boundary */
		if (((yc+yrad) < SCREEN_YBOT) || ((yc-yrad) > SCREEN_YTOP))
			return;
		if (((xc+xrad) < SCREEN_XLEFT) || ((xc-xrad) > SCREEN_XRIGHT))
			return;
	}

	/* first calculate the four NWSE end points */
	j = 0;
	PTSIN[j] = xc + xrad; PTSIN[j+1] = yc;
	j = MAX_ARC_CT;
	PTSIN[j] = xc - xrad; PTSIN[j+1] = yc;
	j = MAX_ARC_CT >> 1;
	PTSIN[j] = xc; PTSIN[j+1] = yc - yrad;
	j += MAX_ARC_CT;
	PTSIN[j] = xc; PTSIN[j+1] = yc + yrad;
	/* close the circumference */
	j = MAX_ARC_CT << 1;
	PTSIN[j] = PTSIN[0]; PTSIN[j+1] = PTSIN[1];

	/* calculate the offsets between the line segment indices between */
	/* each of the quadrants */

	quad2 = MAX_ARC_CT;
	quad4 = MAX_ARC_CT << 1;

	/* now calculate the line segments in between */
	/* calculate them in only one quadrant and use 4-way symmetry */
	theta = 0;
	delta_theta = 3600 / MAX_ARC_CT;
	for (j = 2; j < MAX_ARC_CT >> 1; j += 2) {
		theta += delta_theta;
		calc_pts(j,theta);
		x_temp = PTSIN[j] - xc;
		y_temp = yc - PTSIN[j+1];
		PTSIN[quad2-j] = xc - x_temp; PTSIN[quad2-j+1] = yc - y_temp;
		PTSIN[j+quad2] = xc - x_temp; PTSIN[j+quad2+1] = yc + y_temp;
		PTSIN[quad4-j] = xc + x_temp; PTSIN[quad4-j+1] = yc + y_temp;
	}

	/* call draw_filled_polygon to display the circle */
	CONTRL[1] = MAX_ARC_CT + 1;
	draw_filled_polygon();
	
} /* draw_screen_circle() */

void draw_screen_arc()
/* draw an arc on the screen */
/* uses the globals xc,yc,xrad,yrad,delta_angle,beg_angle,end_angle */
/* n_steps. */
/* called by v_arc, v_pieslice, v_ellarc, v_ellpie */
/* uses either plot_line or draw_filled_polygon to update the display */
/* clipping is performed inside plot_line or draw_filled_polygon */
/* storage is allocated and freed in case the application PTSIN array */
/* is not large enough. */
{
	WORD 	i,j;
	WORD 	angle_const,angle;
	void 	calc_pts(WORD,WORD);
	void 	draw_filled_polygon(void);
	void 	v_pline(void);
	
	if (WS_INFO->CLIP_FLAG) {
		if (	(yc+yrad) < WS_INFO->CLIP_YMIN ||
			(yc-yrad) > WS_INFO->CLIP_YMAX ||
			(xc+xrad) < WS_INFO->CLIP_XMIN ||
			(xc-xrad) > WS_INFO->CLIP_XMAX )
				return;
	} else {
	/* trivial clipping against the screen boundary */
		if (	(yc+yrad) < SCREEN_YBOT || 
			(yc-yrad) > SCREEN_YTOP ||
			(xc+xrad) < SCREEN_XLEFT || 
			(xc-xrad) > SCREEN_XRIGHT )
				return;
	}

	/* calculate the points around the arc/circumference */
	angle = beg_angle;
	angle_const = 3600 / MAX_ARC_CT;
	i = j = 0;

	calc_pts(j,angle);

	for (i = 0; i < n_steps; i++) {
		j += 2;
		angle += angle_const;
		calc_pts(j,angle);
	}

	/* now call the appropriate function to draw the primitive */
	if (PRIMITIVE_ID == PIE || PRIMITIVE_ID == ELLIPTICAL_PIE) {
		/* close the perimeter of the primitive */
		j += 2;
		/* line to the centre */
		PTSIN[j++] = xc; PTSIN[j++] = yc;
		/* line to the start of the arc */
		PTSIN[j++] = PTSIN[0]; PTSIN[j++] = PTSIN[1];
		CONTRL[1] = n_steps + 3;
		draw_filled_polygon();
	} else {
		CONTRL[1] = n_steps+1;
		v_pline();
	}
	
} /* draw_screen_arc() */

void calc_pts(ptno,angle)
/* calculates the points on the arc at the given angle */
/* uses tables for the sin and cos values at selected points */
/* these tables contain the sin and cos values in the first octant */
/* the values in these tables are scaled by 2**N_FRACT_BITS */
WORD ptno;
WORD angle;
{
	 WORD index;
	WORD cos_scaled(WORD);
	WORD sin_scaled(WORD);

	if (angle <= 900) {
		index = angle / MAX_ARC_CT;
		PTSIN[ptno] = xc + cos_scaled(index);
		PTSIN[ptno+1] = yc - sin_scaled(index);

	} else if (angle<=1800) {
		index = (1800-angle) / MAX_ARC_CT;
		PTSIN[ptno] = xc - cos_scaled(index);
		PTSIN[ptno+1] = yc - sin_scaled(index);

	} else if (angle<=2700) {
		index = (angle-1800) / MAX_ARC_CT;
		PTSIN[ptno] = xc - cos_scaled(index);
		PTSIN[ptno+1] = yc + sin_scaled(index);

	} else {
		index = (3600-angle) / MAX_ARC_CT;
		PTSIN[ptno] = xc + cos_scaled(index);
		PTSIN[ptno+1] = yc + sin_scaled(index);
	}

} /* calc_pts() */

WORD cos_scaled(WORD index)
/* returns xrad*cos(theta) where index is the index into the cos table */
/* for the required angle theta */
/* Note that all arithmetic is performed as LONGS; each value in the trig */
/* tables has been scaled by 2**N_FRACT_BITS and so we must shift the result */
/* by this number to remove this scaling */
{
	UWORD temp_res = cos_table[index] * xrad;

	if (temp_res & ( 1L << (N_FRACT_BITS-1))) {
		return ((WORD) ((temp_res >> N_FRACT_BITS) + 1));
	} else {
		return ((WORD) (temp_res >> N_FRACT_BITS));
	}

} /* cos_scaled() */

WORD sin_scaled(WORD index)
/* returns yrad*sin(theta) where index is the index into the sin table */
/* for the required angle theta */
/* Note that all arithmetic is performed as LONGS; each value in the trig */
/* tables has been scaled by 2**N_FRACT_BITS and so we must shift the result */
/* by this number to remove this scaling */
{
	 UWORD temp_res = sin_table[index] * yrad;

	if (temp_res & ( 1L << (N_FRACT_BITS-1))) {
		return ((WORD) ((temp_res >> N_FRACT_BITS) + 1));
	} else {
		return ((WORD) (temp_res >> N_FRACT_BITS));
	}

} /* sin_scaled() */

void draw_poly_line()
/* draws the given polyline */
/* uses plot_line to actually update the display */
{
	WORD i,j;
	void plot_line(WORD,WORD);
	void wide_poly_line(void);
	void plot_arrow(WORD,WORD);
	
	switch (WS_INFO->LINE_WIDTH) {
		case 1:

		if (CONTRL[1] == 1) {

			abs_move(PTSIN[0],PTSIN[1]);
			plot_line(PTSIN[0],PTSIN[1]);

		} else {

			if (WS_INFO->LINE_END_STYLE[0] == ARROW) {
				plot_arrow(0,2);
			}

			if (WS_INFO->LINE_END_STYLE[1] == ARROW) {
				plot_arrow(CONTRL[1] * 2 - 2,-2);
			}

			abs_move(PTSIN[0],PTSIN[1]);
			for (j = 2, i = CONTRL[1]; i > 1; --i, j += 2) {
				plot_line(PTSIN[j],PTSIN[j + 1]);
			}
		}
		break;
	default:
		/* a wide line must be drawn */
		wide_poly_line();
	}

} /* draw_poly_line() */

void SLP_Replace(UBYTE *ptr, WORD fg, WORD plot)
{
	if (plot) *ptr = fg;
	else      *ptr = BACKGROUND_COLOUR;

} /* SLP_Replace() */

void SLP_Transparent(UBYTE *ptr, WORD fg, WORD plot)
{
	if (plot) *ptr = fg;

} /* SLP_Transparent() */

void SLP_Xor(UBYTE *ptr, WORD fg, WORD plot)
{
	fg = fg;

	if (plot) *ptr = ~(*ptr);

} /* SLP_Xor() */

void SLP_RevTransparent(UBYTE *ptr, WORD fg, WORD plot)
{
	if (!plot) *ptr = fg;

} /* SLP_RevTransparent() */

void plot_line(WORD xin,WORD yin)
/* Plots a line from (curx,cury) to (xin,yin) in the current colour */
/* Uses Bresenham's incremental technique */
/* For speed, each octant is separately coded */
/* Updates current position to xin,yin */
/* the pattern offset is not changed so that when drawing a polyline, */
/* the pattern remains connected around vertices */
/* a call to abs_move() must be used to reset the pattern offset */
{  
	WORD 	d,dx,dy,inc1,inc2,counter,octant;
	WORD	mask,offset,fg,stride;
	UBYTE	*p;
	WORD 	clip_line(WORD);
	void	(*SLP)(UBYTE *,WORD,WORD);

	xend_line = xin;
	yend_line = yin;

	if (WS_INFO->CLIP_FLAG) {
		/* The line must be clipped */
		if (!clip_line(1)) {
			curx = xin; cury = yin;	
			/* none of this line must be displayed */
			return;
		}
		/* otherwise the section of the line that must be displayed */
		/* is given by (curx,cury) (xend_line,yend_line) */
	} else {
		/* else clip to the screen boundary */
		if (!clip_line(0)) {
			curx = xin; cury = yin;
			return;
		}
	}

	/* set up local variables */

	fg   = WS_INFO->LINE_COLOR_INDEX;
	if (fg == SCREEN.MAGIC) fg++;

	mask   = WS_INFO->LINE_MASK;
	offset = WS_INFO->LINE_PATTERN_OFFSET;
	stride = SCREEN.STRIDE;

	switch(WS_INFO->WRITE_MODE) {

		case REPLACE:		SLP = SLP_Replace;
					break;
		case TRANSPARENT:	SLP = SLP_Transparent;
					break;
		case XOR:		SLP = SLP_Xor;
					break;
		case REV_TRANSPARENT:	SLP = SLP_RevTransparent;
					break;
		default:		IOdebug("SLP error!\n");
					return;
	}

	/* point to the start of the line to be drawn */
	p = (UBYTE *)SCREEN.MAP + OFFSET(curx,cury);

	/* Is it a horizontal or vertical special case?! */

	if (yend_line == cury ) {

		counter = xend_line-curx;
		inc1	= 1;

	if (counter<0)	{
		counter=-counter;
		inc1=-inc1;
			}

		(*SLP)(p,fg,mask & offset);
		if (!(offset >>= 1)) offset = Pattern_Offset_Start;
 
		while (counter--) {
			p+=inc1;         /* x increment */
			(*SLP)(p,fg,mask & offset);
			if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		}
	WS_INFO->LINE_PATTERN_OFFSET = offset;

		goto endofline;
				}


	if (xend_line == curx ) {

		counter = yend_line-cury;
		inc1	= stride;

		if (counter<0)	{
		counter=-counter;
		inc1=-inc1;
				}

		(*SLP)(p,fg,mask & offset);
		if (!(offset >>= 1)) offset = Pattern_Offset_Start;
 
		while (counter--) {
			p+=inc1;         /* Y increment */
			(*SLP)(p,fg,mask & offset);
			if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		}

		goto	endofline;

				}




	/* Now decide which octant */
	if (yend_line > cury ) {
		dy = yend_line - cury;
		octant = 1;
	} else {
		dy = cury - yend_line;
		octant = 0;
	}

	if (xend_line < curx ) {
		octant += 2;
		dx = curx - xend_line;
	} else {
		dx = xend_line - curx;
	}

	if (ABS(xend_line - curx) < ABS(yend_line - cury)) octant += 4;
#ifdef NEVER
	if (((xend_line >= curx) ? xend_line - curx : curx - xend_line)-
	((yend_line >= cury) ? yend_line - cury : cury - yend_line) < 0 )
		octant += 4;
#endif

	switch (octant) {
	case 0:  /* OCTANT 0 */
		inc1    = dy + dy;
		d       = inc1 - dx;
		inc2    = inc1 - (dx + dx);
		counter = dx;
		(*SLP)(p,fg,mask & offset);
		if (!(offset >>= 1)) offset = Pattern_Offset_Start;
 
		while (counter--) {
			p++;         /* x increment */
			if (d < 0 ) {
				d += inc1;
			} else {
				p -= stride;  /* y increment */
				d += inc2;
			}
			(*SLP)(p,fg,mask & offset);
			if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		}
		break;

    case 1:  /* OCTANT 7 */
		inc1    = dy + dy;
		d       = inc1 - dx;
		inc2    = inc1 - (dx + dx);
		(*SLP)(p,fg,mask & offset);
		if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		counter = dx;
		while (counter--) {
			p++;         /* xtemp increment */
			if (d < 0 ) d += inc1;
			else {
				p += stride;  /* y decrement */
				d += inc2;
			}
			(*SLP)(p,fg,mask & offset);
			if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		}
		break;

    case 2:  /* OCTANT 3 */
		inc1    = dy + dy;
		d       = inc1 - dx;
		inc2    = inc1 - (dx + dx);
		(*SLP)(p,fg,mask & offset);
		if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		counter = dx;
		while (counter--) {
			--p;   /* x decrement */
			if (d <= 0) d+=inc1;
			else {
				p -= stride;  /* y increment */
				d += inc2;
			}
			(*SLP)(p,fg,mask & offset);
			if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		}
		break;

    case 3:  /* OCTANT 4 */
		inc1    = dy + dy;
		d       = inc1 - dx;
		inc2    = inc1 - (dx + dx);
		(*SLP)(p,fg,mask & offset);
		if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		counter = dx;
		while (counter--) {
			--p;   /* xtemp decrement */
			if (d <= 0) d+=inc1;
			else {
				p += stride;  /* ytemp decrement */
				d += inc2;
		 	}
			(*SLP)(p,fg,mask & offset);
			if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		}
		break;

    case 4:  /* OCTANT 1 */
		inc1    = dx + dx;
		d       = inc1 - dy;
		inc2    = inc1 - (dy + dy);
		(*SLP)(p,fg,mask & offset);
		if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		counter = dy;
		while (counter--) {
			p -= stride;   /* ytemp increment */
			if (d < 0) d += inc1;
			else {
				p++;		/* x increment */
				d += inc2;
		 	}
			(*SLP)(p,fg,mask & offset);
			if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		}
		break;

    case 5:  /* OCTANT 6 */
		inc1    = dx + dx;
		d       = inc1 - dy;
		inc2    = inc1 - (dy + dy);
		(*SLP)(p,fg,mask & offset);
		if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		counter = dy;
		while (counter--) {
			p += stride;  /* ytemp decrement */
			if (d < 0) d += inc1;
			else {
				p++;		/* x increment */
				d += inc2;
			}
			(*SLP)(p,fg,mask & offset);
			if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		}
		break;

    case 6:  /* OCTANT 2 */
		inc1    = dx + dx;
		d       = inc1 - dy;
		inc2    = inc1 - (dy + dy);
		(*SLP)(p,fg,mask & offset);
		if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		counter = dy;
		while (counter--) {
			p -= stride;   /* y increment */
			if (d <= 0) d += inc1;
			else {
				--p;     /* x decrement */
				d += inc2;
			}
			(*SLP)(p,fg,mask & offset);
			if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		}
		break;

    case 7:  /* OCTANT 5 */
		inc1    = dx + dx;
		d       = inc1 - dy;
		inc2    = inc1 - (dy + dy);
		(*SLP)(p,fg,mask & offset);
		if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		counter = dy;
		while (counter--) {
			p += stride;  /* ytemp decrement */
			if (d <= 0 ) d += inc1; 
			else {
				--p;		/* x decrement */
				d += inc2;
		 	}
			(*SLP)(p,fg,mask & offset);
			if (!(offset >>= 1)) offset = Pattern_Offset_Start;
		}
		break;
	}

endofline:

	/* save offset */

	WS_INFO->LINE_PATTERN_OFFSET = offset;

	/* Update current position */
	curx = xin; cury = yin;

} /* plot_line() */

WORD code(x,y,xl,yb,xr,yt)
/* codes the given point against the given clipping region */
WORD x,y;
WORD xl,yb,xr,yt;
{
	WORD clip_flag = 0;
	
	     if (x < xl) clip_flag =  1;
	else if (x > xr) clip_flag =  2;

	     if (y < yb) clip_flag += 4;
	else if (y > yt) clip_flag += 8;

	return (clip_flag);

} /* code() */

WORD clip_line(WORD region)
/* clips the line given by (curx,cury) to (xend_line,yend_line)         */
/* to the current Clip Region or the Screen Boundary                    */
/* Region is 1  if we need to clip to the Clip Region                   */
/*	     0  if we need to clip to the Screen Boundary               */
/* Screen boundary is assumed to have cds (SCREEN_XLEFT,SCREEN_YBOT) to */
/*                                        (SCREEN_XRIGHT,SCREEN_YTOP)   */
/* Returns TRUE if some of the line is on the display; otherwise        */
/* returns FALSE                                                        */
{
	WORD	*x,*y,start_clipflag,end_clipflag,temp_clip_flag;
	WORD	deltax,deltay;
	WORD	clipxleft,clipybot,clipxright,clipytop;
	WORD	code(WORD,WORD,WORD,WORD,WORD,WORD);

	if (region) {
		/* to the current Clip region */
		clipxleft  = WS_INFO->CLIP_XMIN;
		clipybot   = WS_INFO->CLIP_YMIN;
		clipxright = WS_INFO->CLIP_XMAX;
		clipytop   = WS_INFO->CLIP_YMAX;
	} else {
		/* to the Screen Boundary */
		clipxleft  = SCREEN_XLEFT;
		clipybot   = SCREEN_YBOT;
		clipxright = SCREEN_XRIGHT;
		clipytop   = SCREEN_YTOP;
	}

	start_clipflag = code(	curx,cury,
				clipxleft,clipybot,clipxright,clipytop);

	end_clipflag   = code(	xend_line,yend_line,
				clipxleft,clipybot,clipxright,clipytop);

	while (start_clipflag || end_clipflag) {

		if (start_clipflag & end_clipflag) {
			/* the line will not be displayed, so return FALSE */
			return (FALSE);
		}

		if (start_clipflag) {
			temp_clip_flag = start_clipflag;
			x = &curx;
			y = &cury;

		} else {
			temp_clip_flag = end_clipflag;
			x = &xend_line;
			y = &yend_line;
		}

		deltax = xend_line - curx;
		deltay = yend_line - cury;

		if (temp_clip_flag & 1)	{	/* left boundary */

			*y = cury + ((((deltay * (clipxleft-curx)) << N_F_B) /
					deltax) >> N_F_B);
			*x = clipxleft;

		} else if (temp_clip_flag & 2) {	/* right boundary */

			*y = cury + ((((deltay * (clipxright-curx)) << N_F_B) /
					deltax) >> N_F_B);
			*x = clipxright;

		} else if (temp_clip_flag & 4) {	/* top boundary */

			*x = curx + ((((deltax * (clipybot-cury)) << N_F_B) /
					deltay) >> N_F_B);
			*y = clipybot;
		
		} else if (temp_clip_flag & 8) {	/* bottom boundary */

			*x = curx + ((((deltax * (clipytop-cury)) << N_F_B) /
					deltay) >> N_F_B);
			*y = clipytop;
		}

		start_clipflag = code(	curx,cury,
				clipxleft,clipybot,clipxright,clipytop);

		end_clipflag   = code(	xend_line,yend_line,
				clipxleft,clipybot,clipxright,clipytop);
	}

	return (TRUE);

} /* clip_line() */

void seed_fill(WORD seedx,WORD seedy)
/* performs a seed fill from the given seed point */
/* this region is bounded by the Display Bounds */
{
	PIX_OFFSET	slptr,srptr,pl,pr,py,xmin,xmax,rxend;
	PIX_OFFSET 	regstart,regend;
	WORD 	ninx,code;
	WORD 	old_colour;
	void 		dec_ptr(PIX_OFFSET *,PIX_OFFSET,WORD);
	void 		inc_ptr(PIX_OFFSET *,PIX_OFFSET,WORD);
	WORD 		initstack(void);
	WORD		push(PIX_OFFSET,PIX_OFFSET,PIX_OFFSET,WORD);
	WORD		pop(PIX_OFFSET *,PIX_OFFSET *,PIX_OFFSET *,WORD *);
	void		remove_stack(void);
  
  /* first check that the seed point is in the display surface */
  /* if it is not, then do not do any filling */
  /* The display coordinate system is deemed to go from 0 to WIDTH-1 */
  /* in the x-direction and from 0 to HEIGHT-1 in the y-direction */
  
	if (WS_INFO->CLIP_FLAG) {
		if (	seedx < WS_INFO->CLIP_XMIN ||
			seedx > WS_INFO->CLIP_XMAX ||
			seedy < WS_INFO->CLIP_YMIN ||
			seedy > WS_INFO->CLIP_YMAX )
				return;
	} else {
		if (	seedx<SCREEN_XLEFT    ||
			seedx > SCREEN_XRIGHT ||
			seedy < SCREEN_YBOT   ||
			seedy > SCREEN_YTOP   )
		/* the seed point is outside the Display Boundary */
				return;
	}

	if (!initstack())
		/* we cannot initialise the fill-stack */
		return;

	/* initialise some variables */
	/* a pointer to the seed point */
	srptr = slptr = OFFSET( seedx, seedy);
		/* determine the colour we are filling over */
	old_colour = RPO(slptr);
		/* py is the least address on the current scan-line */
	if (WS_INFO->CLIP_FLAG) {
		/* the region must be bounded by the Clip Region */
		py       = OFFSET(WS_INFO->CLIP_XMIN, seedy);
		regend   = OFFSET(WS_INFO->CLIP_XMIN,WS_INFO->CLIP_YMIN);
		regstart = OFFSET(WS_INFO->CLIP_XMIN,WS_INFO->CLIP_YMAX);

		/* the number of pixels on the scanline minus 1 */
		ninx = WS_INFO->CLIP_XMAX - WS_INFO->CLIP_XMIN;

	} else {

		/* the region must be bounded by the Display Boundary */
		py       = OFFSET(SCREEN_XLEFT, seedy);
		regend   = OFFSET(SCREEN_XLEFT,SCREEN_YBOT);
		regstart = OFFSET(SCREEN_XLEFT,SCREEN_YTOP);

		/* the number of pixels on the scanline minus 1 */
		ninx = SCREEN.WIDTH - 1;
	}
	
	if (old_colour == WS_INFO->FILL_COLOR_INDEX)
	/* the new colour is the same as the old colour so return */
		return;
		
	/* find the span containing the seed point; fill it and then loop */
	/* until the stack is empty */
	dec_ptr(&slptr,py,old_colour);
	inc_ptr(&srptr,py+ninx,old_colour);
	FRR(slptr,srptr,1);
	if ( py != regstart )
		if (!push(slptr,srptr-1,py,SCANHI))
			return;
	if ( py != regend )
		if (!push(slptr,srptr-1,py,SCANLO))
			return;

	while (pop(&pl,&pr,&py,&code))
		switch (code) {
		case SCANLO: /* check the child BELOW this parent */
			slptr = pl - SCREEN.STRIDE;
			xmin  = py - SCREEN.STRIDE; xmax = xmin+ninx;
			rxend = pr - SCREEN.STRIDE;
			if ( RPO(slptr) == old_colour ) {
				srptr = slptr+1;
				dec_ptr(&slptr,xmin,old_colour);
			}
			else srptr = slptr;

			while ( slptr <= rxend )
			{	inc_ptr(&srptr,xmax,old_colour);
				if (srptr != slptr) {
					FRR(slptr,srptr,1);
					if ( xmin != regend )
					    if (!push(slptr,srptr-1,xmin,
							SCANLO))
						break;  /* stack is full */
					if ( xmin != regstart )
					{	if (slptr < pl-SCREEN.STRIDE -1)
						if (!push(slptr,
							pl - SCREEN.STRIDE - 2,
							xmin,SCANHI))
						break;
						if ( srptr > rxend + 2 )
						{	if (!push(rxend+2,
							srptr - 1,
							xmin,SCANHI))
							break;
						}
					}
				}

				/* Now skip all the pixels that are */
				/* not the seed colour */
				slptr = srptr + 1;
				while ((slptr <= rxend) &&
					(RPO(slptr) != old_colour))
					slptr++;
				srptr = slptr + 1;
			}
			break;

		case SCANHI: /* check the child ABOVE this parent */
			slptr = pl + SCREEN.STRIDE;
			xmin  = py + SCREEN.STRIDE;
			xmax  = xmin+ninx;
			rxend = pr + SCREEN.STRIDE;
			if ( RPO(slptr) == old_colour )
			{	srptr = slptr + 1;
				dec_ptr(&slptr,xmin,old_colour);
			}
			else srptr = slptr;

			while ( slptr<=rxend )
			{	inc_ptr(&srptr,xmax,old_colour);
				if (srptr!=slptr) {
					FRR(slptr,srptr,1);
					if ( xmin != regstart )
					    if (!push(slptr,srptr - 1,xmin,
							SCANHI))
						break;  /* stack is full */
					if ( xmin != regend )
					{	if ( slptr<pl+SCREEN.STRIDE-1 )
						if (!push(slptr,
							pl + SCREEN.STRIDE - 2,
							xmin,SCANLO))
						break;
						if ( srptr>rxend+2 )
						{	if (!push(rxend+2,srptr-1,
							xmin,SCANLO))
							break;
						}
					}
				}

				/* Now skip all the pixels that are */
				/* not the seed colour */
				slptr = srptr + 1;
				while ((slptr <= rxend) &&
					(RPO(slptr) != old_colour))
					slptr++;
				srptr = slptr + 1;
			}
			break;
	  }
	/* free any memory associated with the stack_frames */
	remove_stack();

} /* seed_fill() */

void dec_ptr(start_ptr,end_ptr,the_colour)
/* decrement the start ptr until either we reach the end_ptr or it points */
/* to the first pixel that has not the value the_colour. At th end */
/* start_ptr points to the last pixel tested that has the value the_colour */
/* or it has the value end_ptr */
PIX_OFFSET *start_ptr,end_ptr;
WORD the_colour;
{
	PIX_OFFSET tmp_ptr = *start_ptr;
			/* remove one level of */
			/* indirection for efficiency */

	/* we assume that start_ptr already points to a pixel that */
	/* has value the_colour */
	do {
		--tmp_ptr;
	}	while (tmp_ptr>=end_ptr && RPO(tmp_ptr) == the_colour);

		*start_ptr = ++tmp_ptr;

} /* dec_ptr() */

void inc_ptr(start_ptr,end_ptr,the_colour)
/* increment the start ptr until either we reach the end_ptr or it points */
/* to the first pixel that has not the value the_colour. At the end */
/* start_ptr points to the right most pixel that has the value */
/* the_colour or it has the value end_ptr */
PIX_OFFSET *start_ptr,end_ptr;
WORD the_colour;
{
	PIX_OFFSET tmp_ptr = *start_ptr;
				/* remove one level of */
				/* indirection for efficiency*/
	while (tmp_ptr <= end_ptr && RPO(tmp_ptr) == the_colour)
		tmp_ptr++;

	*start_ptr = tmp_ptr;

} /* inc_ptr */

WORD initstack()
/* initialise the stack for the filling routines */
/* an array of stack frames is used, space for each array being alloacted */
/* only when needed. This ensures that the stack never overflows assuming */
/* that no memory restrictions apply for malloc */
{
	current_stack_frame = 0;
	fill_stack[current_stack_frame] = (struct FILL_STACK_RECORD *)
		get_memory((UWORD)( MAX_FILL_STACK_RECORDS *
			sizeof(struct FILL_STACK_RECORD)));
	if (fill_stack[current_stack_frame] != 
		(struct FILL_STACK_RECORD *)NULL) {
		/* initialise the variables that access this structure */
		number_stacked = -1;
		fill_ptr = fill_stack[current_stack_frame];
		return (TRUE);
	}
	else
		/* we cannot allocate even one fill_stack_frame */
		return (FALSE);

} /* initstack() */

void remove_stack()
/* frees all the stack frames that have been used in the last fill command */
/* this is not performed as each stack frame is emptied since this would */
/* produce an unwanted number of malloc/free calls */
{
	WORD stack_frame;

	for (stack_frame = 0; stack_frame<MAX_FILL_STACK_FRAMES; stack_frame++)
		if (fill_stack[stack_frame] != 
			(struct FILL_STACK_RECORD *)NULL) {
			(void) free_memory((BYTE *) fill_stack[stack_frame]);
			fill_stack[stack_frame] = 
				(struct FILL_STACK_RECORD *)NULL;
		}

} /* remove_stack() */

WORD pop(ptr_to_left,ptr_to_right,ptr_to_parent,ptr_to_direct)
/* pops information of the stack */
PIX_OFFSET *ptr_to_left,*ptr_to_right,*ptr_to_parent;
WORD *ptr_to_direct;
{
	if (number_stacked==-1) {
		if (current_stack_frame==0)
			/* the stack is empty */
			return (FALSE);
		number_stacked = MAX_FILL_STACK_RECORDS-1;
		current_stack_frame--;
		fill_ptr = fill_stack[current_stack_frame] + MAX_FILL_STACK_RECORDS;
	}

	--number_stacked;
	--fill_ptr;

	*ptr_to_left = fill_ptr->left;
	*ptr_to_right = fill_ptr->right;
	*ptr_to_parent = fill_ptr->parent;	
	*ptr_to_direct = fill_ptr->direction;
	
	return (TRUE);

} /* pop() */

WORD push(left_ptr,right_ptr,parent_y,direct)
/* push the given values onto the fill stack */
/* checks whether there is room in the current stack frame; if not, a */
/* new stack frame is allocated. Returns FALSE if the values are not */
/* stacked; returns TRUE if they are stacked */
/* the left_ptr and right_ptr point to the inclusive range of values */
/* defining the current span, parent_y is a pointer to the left most */
/* pixle on this scan line and direct is the direction that we next need */
/* to search in */
PIX_OFFSET left_ptr,right_ptr,parent_y;
WORD direct;
{
	if (number_stacked!=MAX_FILL_STACK_RECORDS-1) {
		number_stacked++;
		fill_ptr->left = left_ptr;
		fill_ptr->right = right_ptr;
		fill_ptr->parent = parent_y;
		fill_ptr->direction = direct;
		fill_ptr++;
		return (TRUE);
	} else 
	if (current_stack_frame!=MAX_FILL_STACK_FRAMES - 1) {
		current_stack_frame++;
		if (fill_stack[current_stack_frame] == 
			(FILL_STACK_RECORD *)NULL) {
			/* this is the first time that this stack_frame */
			/* has needed to be used for this fill, so allocate */
			/* some space */
			fill_stack[current_stack_frame] =
				(FILL_STACK_RECORD *)
				get_memory((UWORD)
					MAX_FILL_STACK_RECORDS *
					sizeof(FILL_STACK_RECORD));
			if (fill_stack[current_stack_frame] != 
				(FILL_STACK_RECORD *)NULL) {
				number_stacked = -1;
				fill_ptr = fill_stack[current_stack_frame];
				return(push(left_ptr,right_ptr,parent_y,
						direct));
			} else	{
				/* cannot allocate another stack frame */
				--current_stack_frame;
				return (FALSE);
			}
		} else { /* this stack_frame was needed previously so we can */
			/* reuse its space */
			number_stacked = -1;
			fill_ptr = fill_stack[current_stack_frame];
			return(push(left_ptr,right_ptr,parent_y,direct));
		}
	} else {
		/* cannot allocate another stack frame */
		return (FALSE);
	}

} /* push() */

void wide_poly_line()
/* draws a wide polyline. Line end styles are determined by the current Ws */
/* handle. Uses Fill_Rect_Region to update the display hence the Fill */
/* parameters within the current WS handle are updated and replaced */
{
	WORD	*circle_pixels;
	WORD	i,j,npts;
        WORD 	x1,y1,x2,y2,sav_pts[8];
	WORD	x_delta,y_delta;
	WORD	x_off,y_off;
	WORD	save_fill_colour,save_fill_interior_style;
	WORD	save_fill_outlined;
	WORD	*save_fill_mask;
	WORD 	*set_up_circle(void);
	void 	plot_circle(WORD,WORD,WORD *);
	void 	plot_arrow(WORD,WORD);
	void 	calculate_offsets(WORD,WORD,
			WORD *,WORD *,WORD *);
	void 	draw_filled_polygon(void);
	
	npts = CONTRL[1];
	
	/* first set up the circumference information for the desired */
	/* line thickness */
	circle_pixels = set_up_circle();
	if (circle_pixels == (WORD *)NULL) {
		/* error inside set_up_circle */
		return;
	}

	/* save the current fill parameters that need to be changed */
	save_fill_colour         = WS_INFO->FILL_COLOR_INDEX;
	save_fill_interior_style = WS_INFO->FILL_INTERIOR_STYLE;
	save_fill_outlined       = WS_INFO->FILL_OUTLINED;
	save_fill_mask           = WS_INFO->FILL_MASK;

	/* initialise them to the relevant values */
	WS_INFO->FILL_COLOR_INDEX    = WS_INFO->LINE_COLOR_INDEX;
	WS_INFO->FILL_INTERIOR_STYLE = SOLID;
	WS_INFO->FILL_OUTLINED       = FALSE;
	WS_INFO->FILL_MASK           = OPEN_MASK;

	/* output the end points; these must be done in one go since */
	/* we need to update the list of points in the polyline in the */
	/* case of arrow-headed lines. */
	switch (WS_INFO->LINE_END_STYLE[0]) {
		case ROUNDED :
			plot_circle(PTSIN[0],PTSIN[1],circle_pixels);
			break;
		case ARROW :
			plot_arrow(0,2);
			break;
		case SQUARED:
			/* do nothing */
			break;
	}

	switch (WS_INFO->LINE_END_STYLE[1]) {
		case ROUNDED :
			plot_circle(PTSIN[npts*2-2],PTSIN[npts*2-1],
				circle_pixels);
			break;
		case ARROW :
			plot_arrow(npts*2-2,-2);
			break;
		case SQUARED:
			/* do nothing */
			break;
	}

	/* save the first 8 points since these are overwritten within */
	/* the procedure */
	for (i = 0; i < 8; i++) sav_pts[i] = PTSIN[i];
	
	/* since there will be many calls to draw_filled_polygon */
	/* initialise this value only once */
	CONTRL[1] = 4;
	j  = 2;
	x1 = PTSIN[0];
	y1 = PTSIN[1];

	for (i = 1; i < npts; i++) {
		/* determine the end coordinates */
		if (j<8) {
			x2 = sav_pts[j++];
			y2 = sav_pts[j++];
		} else {
			x2 = PTSIN[j++];
			y2 = PTSIN[j++];
		}

		x_delta = x2 - x1;
		y_delta = y2 - y1;
		
		/* ignore lines of zero length */
		if (x_delta == 0 && y_delta == 0) {
			continue;
		}

		/* calculate the offsets that include the line thickness */
		/* horizontal or vertical are simple */
		if (x_delta == 0) {
			x_off = *circle_pixels;
			y_off = 0;
		} else {
			if (y_delta == 0) {
				x_off = 0;
				y_off = *circle_pixels;
			} else {
				/* neither horizontal nor vertical so must */
				/* calculate the offsets */
				calculate_offsets(x_delta,y_delta,&x_off,&y_off,
					circle_pixels);
			}
		}

		/* produce the coordinates of the closed polygon */
		/* around the Bresenham region */
		PTSIN[0] = x1 + x_off; PTSIN[1] = y1 - y_off;
		PTSIN[2] = x1 - x_off; PTSIN[3] = y1 + y_off;
		PTSIN[4] = x2 - x_off; PTSIN[5] = y2 + y_off;
		PTSIN[6] = x2 + x_off; PTSIN[7] = y2 - y_off;
		draw_filled_polygon();

		if (i < npts-1)
			/* if in the middle of the line draw a circle */

			plot_circle(x2,y2,circle_pixels);

		/* this end coordinate is the next starting coordinate */
		x1 = x2;
		y1 = y2;
	} 
	
	/* return the saved points for the application */
	for (i = 0; i < 8; i++) 
		PTSIN[i] = sav_pts[i];
		
	/* free the memory associated with the circumference pixels */
	if (circle_pixels != (WORD *)NULL)
		(void) free_memory((BYTE *) circle_pixels);
		
	/* Return the Fill parameters to their previous state */
	WS_INFO->FILL_COLOR_INDEX    = save_fill_colour;
	WS_INFO->FILL_INTERIOR_STYLE = save_fill_interior_style;	
	WS_INFO->FILL_OUTLINED       = save_fill_outlined;
	WS_INFO->FILL_MASK           = save_fill_mask;
	
	CONTRL[1] = npts;

} /* wide_poly_line() */

WORD *set_up_circle()
/* uses a mid_point technique to calculate the pixels on the circumference */
/* of a circle. These are placed in memory that is allocated in this */
/* procedure */
{
	WORD x_value,y_value,error,*tmp_circle,index,tmp_value;
	
	/* allocate the memory for the integers */
	tmp_circle = (WORD *) get_memory((UWORD)
		((WS_INFO->LINE_WIDTH + 1) * NBYTES_PER_INTEGER));
	if (tmp_circle == (WORD *)NULL)
		/* error when allocating the memory */
		return (tmp_circle);
		
	/* otherwise calculate the pixels on the circumference */
	/* on y=y_centre the pixel is determined by the thickness */
	/* halved */

	*tmp_circle = WS_INFO->LINE_WIDTH / 2;	

	/* start at octant 0 and use a mid-point algorithm to determine */
	/* the pixels on the circumference of the first octant */

	x_value = *tmp_circle;
	y_value = 0;
	error   = 5 - 4 * x_value;
	
	while (x_value > y_value) {
		y_value++;
		if (error < 0) {
			/* choose the same x pixel as the previous line */
			error += 4 + 8 * y_value;
		} else {
			/* choose the inner x pixel */
			--x_value;
			error += 4 - 8 * x_value + 8 * y_value;
		}
		*(tmp_circle + y_value) = x_value;
	}

	/* now determine the pixels in the second octant */
	index = 0;
	for (y_value = *tmp_circle; y_value > x_value; --y_value) {
		tmp_value = *(tmp_circle + index);
		while (*(tmp_circle + index) == tmp_value)
			index++;
		*(tmp_circle + y_value) = index - 1;
	}
	
	/* return a pointer to the temporary storage */
	return (tmp_circle);

} /* set_up_circle() */

void plot_circle(x,y,pixel_offsets)
/* Plot the circle at x,y. The offsets to the Pixels on the circumference */
/* are passed by the structure pixel_offsets. The radius is given by the */
/* Line_Width field of WS_INFO. These circles join up wide lines and also */
/* yield rounded line end styles */
WORD x,y;
WORD *pixel_offsets;
{
	WORD	npixels;
	WORD	y_value;
	WORD	radius = *pixel_offsets;
	WORD	xleft,ybot,xright,ytop;
	void	fill_clip_horiz_line(WORD,WORD,WORD);
	
	xleft  = x - radius;
	xright = x + radius;
	ytop   = y - radius;
	ybot   = y + radius;

	if (WS_INFO->CLIP_FLAG) {
		/* do simple clipping first */
		if (	xleft  > WS_INFO->CLIP_XMAX ||
			xright < WS_INFO->CLIP_XMIN ||
			ytop   > WS_INFO->CLIP_YMAX ||
			ybot   < WS_INFO->CLIP_YMIN  )
			/* completely outside the Clip Region */
				return;
	} else {
		if (	xleft > SCREEN_XRIGHT ||
			xright < SCREEN_XLEFT ||
			ytop > SCREEN_YTOP    ||
			ybot < SCREEN_YBOT    )
			/* completely outside the Screen Region */
				return;
	}
	
	/* when here Clipping is either not on or the circle is */
	/* completely within the Clip Region */

	/* do the centre line first */

	fill_clip_horiz_line(xleft,xright,y);
	
	/* now for each of the remaining scanlines fill from the left */
	/* most pixel to the right most pixel */
	/* This is an important procedure for speeding up. Could be */
	/* performed by initialising some memory and clipping and */
	/* calling RasterOp directly */ 

	for (y_value = 1; y_value <= *pixel_offsets; y_value++ ) {
		npixels = *(pixel_offsets+y_value);
		fill_clip_horiz_line((x-npixels),(x+npixels),y-y_value);
		fill_clip_horiz_line((x-npixels),(x+npixels),y+y_value);
	}

} /* plot_circle() */

void calculate_offsets(delta_x,delta_y,x_off,y_off,pix_on_cirf)
/* for the line from (0,0) to (deltax,deltay) calculate the offsets */
/* representing the rectangular region between the brush ends. Note */
/* the pixels on the circumference have already been determined and are */
/* given by 'pix_on_cirf' */
WORD delta_x,delta_y,*x_off,*y_off,*pix_on_cirf;
{
	WORD quad,min_val,xmin,ymin,u,v,new_magnitude;
	WORD xinfirst,yinfirst;
	void quad_xform(WORD,WORD,WORD,WORD *,WORD *);
	
	/* mirror transform into the first octant */
	if (delta_x >= 0)
		quad = (delta_y >= 0 ? 1 : 4);
	else
		quad = (delta_y >= 0 ? 2 : 3);

	quad_xform(quad,delta_x,delta_y,&xinfirst,&yinfirst);
	
	/* now traverse the pixels around the circumference of the circle */
	/* using the information in 'pix_on_cirf' to obtain the point (u,v) */
	/* that minimises (u*xinfirst-v*yinfirst); in case of a tie choose */
	/* the point which minimizes (u - v). This is then the point closest */
	/* to the given line in the first quadrant */

	xmin    = u = *pix_on_cirf;
	ymin    = v = 0;
	min_val = u*xinfirst - v*yinfirst;
	min_val = ABS(min_val);

	while (1) {
		/* go to the next pixel on the circumference */
		if (v == *pix_on_cirf) {
			/* the top row of the circle */
			if (u==1) break; /* have tested all the pixels */
			else --u;	/* move in one pixel */

		} else {	/* not processing the top row */

			if (*(pix_on_cirf+v+1) >= u-1) {
				/* move up one scan_line */
				v++;
				u = *(pix_on_cirf+v);

			} else	/* move back along this scan_line */
				--u;
		}
		
		/* Check for a new minimum, same minimum or finished */
		new_magnitude = ABS(u*xinfirst - v*yinfirst);

		if ((new_magnitude < min_val) ||
			( (new_magnitude == min_val) &&
				(ABS(xmin - ymin) > ABS(u - v)) ) )
		{	/* have a new point */
			min_val = new_magnitude;
			xmin    = u;
			ymin    = v;
		}
		else
			/* have gone 'past ' the minimum so break */
			break;
	}
	
	/* now transform the solution into the required quadrant */
	quad_xform(quad,xmin,ymin,x_off,y_off);

} /* calculate_offsets() */

void quad_xform(q,xin,yin,xout,yout)
/* transform the input cds into cds in the first quadrant */
WORD q,xin,yin,*xout,*yout;
{
	switch (q) {
		case 1:
			*xout = xin; *yout = yin;
			break;
		case 2:
			*xout = -xin; *yout = yin;
			break;
		case 3:
			*xout = -xin; *yout = -yin;
			break;
		case 4:
			*xout = xin; *yout = -yin;
	}

} /* quad_xform() */

void fill_clip_horiz_line(x1,x2,y)
/* fills a clipped horizontal line from (x1,y) to (x2,y) */
/* we must first clip against a Clip Region and then against the */
/* Screen Boundary */
WORD x1,x2;
WORD y;
{
	WORD npixels;
	PIX_OFFSET left_ptr;
	
	if (WS_INFO->CLIP_FLAG) {
		if (	x1 > WS_INFO->CLIP_XMAX ||
			x2 < WS_INFO->CLIP_XMIN ||
			y  < WS_INFO->CLIP_YMIN ||
			y  > WS_INFO->CLIP_YMAX )
				return;
		if (x1 < WS_INFO->CLIP_XMIN) x1 = WS_INFO->CLIP_XMIN;
		if (x2 > WS_INFO->CLIP_XMAX) x2 = WS_INFO->CLIP_XMAX;

	} else {
		/* Clip against the Screen Boundary */
		if (	x1 > SCREEN_XRIGHT ||
			x2 < SCREEN_XLEFT  ||
			y  < SCREEN_YBOT   ||
			y  > SCREEN_YTOP   )
				return;
		if (x1 < SCREEN_XLEFT)  x1 = SCREEN_XLEFT;
		if (x2 > SCREEN_XRIGHT) x2 = SCREEN_XRIGHT;
	}

	left_ptr = OFFSET(x1,y);
	npixels  = x2 - x1 + 1;

	FRR(left_ptr,left_ptr+npixels,1);

} /* fill_clip_horiz_line() */

