/************************************************************************/
/*									*/
/*				FONT.C					*/
/*									*/
/************************************************************************/

#include <message.h>
#include <task.h>

#define NO_DEFINES

#include "header.h"
#include "stextra.h"

extern UBYTE block[BUF_SIZE];

FONT	*fonts[3];

BYTE *text_array;

void receive_font(UBYTE *start)
{
	FONT	*to;
	WORD 	number;
	WORD	i,j;
	UBYTE	*ptr,tmp;

	number = *start++;

	fonts[number] = (FONT *)get_memory((UWORD)sizeof(FONT));

	to = fonts[number];

	if (to == (FONT *)NULL) {
		printf("\n\nunable to get memory for a font\n\n");
		return;
	}

	to->font_low_ade     = *start++;
	to->font_hi_ade      = *start++;
	to->font_bottom_dist = *start++;
	to->font_fatest      = *start++;
	to->font_thickening  = *start++;
	to->font_underline   = *start++;
	to->font_lightening  = *start++;
	to->font_lightening  <<= 8;
	to->font_lightening  |= *start++;
	to->font_width       = *start++;
	to->font_width       <<= 8;
	to->font_width       |= *start++;
	to->font_height      = *start++;

	/* now get char_offset table */

	number = to->font_hi_ade - to->font_low_ade + 1;

	to->font_char_off = (WORD *)get_memory(
		(UWORD)(number * sizeof(WORD)));

	if (to->font_char_off == (WORD *)NULL) {
		printf("unable to get memory for character offset tablen\n");
		return;
	}

	ptr = (UBYTE *)(to->font_char_off);

	/* NB must swap bytes to allow for byte ordering */

	for(i = 0; i < number; i++) {		

		tmp    = *start++;
		*ptr++ = *start++;
		*ptr++ = tmp;
	}

	to->font_data = get_memory((UWORD)
		(to->font_width * to->font_height * sizeof(BYTE)));

	if (to->font_data == (BYTE *)NULL) {
		printf("unable to get memory for font data\n");
		return;
	}

	ptr = (UBYTE *)(to->font_data);

	for(j = 0; j < to->font_height; j++) {

		for(i = 0; i < to->font_width; i++) {

			*ptr++ = *start++;
		}
	}

} /* receive_font() */ 

void construct(FONT *font)
/* construct a screen image version of the large font */
{
	WORD	ch,c_ptr,x,j,line;
	BYTE	*text,*m_ptr,fg;

	m_ptr = text = get_memory((UWORD)(256 * 16 * 8));

	if (text == (BYTE *)NULL) {
		printf("construct unable to get memory\n");
		return;
	}

	fg = ~0;

	for (ch = 0; ch < 256; ch++) {

		/* point to a characters information */

		c_ptr = *(font->font_char_off + ch / 2);

		if (ch & 1) c_ptr >>= 16;

		c_ptr &= 0xffff;

		c_ptr >>= 3;

		for (j = 0; j < 16; j++) {

			line = *(font->font_data + c_ptr);

			line &= 0xff;

			c_ptr +=font->font_width;

			/* now put this model into the array */

			for (x = 8; x ; --x) {
				if (line & 0x80) {
					*m_ptr++ = fg;
				} else {
					*m_ptr++ =  0;
				}
				line <<= 1;
			}
		}
	}

	text_array = text;

} /* construct() */
	
extern Task *MyTask;

void accept_fonts()
/* accept a font across the atari - transputer link */
{
	WORD 	i;
	MCB	mcb;
	WORD 	GetMsg(MCB *);
	void	receive_font(UBYTE *);
	void	sendm(WORD, UBYTE *, WORD);
	void	construct(FONT *);

	for (i = 0; i < 3; i++) {

		/* Indicate we want a font now */
		sendm(0,block,SEND_FONT);

		mcb.Data	= (BYTE *)block;
		mcb.MsgHdr.Dest = MyTask->Port;
		mcb.Timeout	= 20000000;

		while(GetMsg(&mcb)) ;

		receive_font(block);
	}

	construct(fonts[2]);

} /* accept_fonts() */

