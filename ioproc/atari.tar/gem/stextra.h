		/* ATARI / TRANSPUTER header */

#ifndef NC
extern linea0();	/* () Initialize */
extern linea1();	/* () Put pixel */
extern linea2();	/* () Get pixel */
extern linea4();	/* () Draw horizontal line */
extern lineae();	/* () Copy raster form */

/*
 * Calling linea0() fetchs the following structure from
 * the system and stores it in external memory.
 */

struct linea_init {
	/* Early versions of TOS do not implement all possible functions */
	WORD		li_d0;		/* 0 if old system bugs persist */
	struct la_data	*li_a0;		/* pointer to linea data structure */
	struct la_font	**li_a1;	/* system font vector */
	WORD		(*li_a2)();	/* linea function vector */
};

extern struct linea_init la_init;

/*
 * The system data structure implements graphics.
 * This is not well documented.
 */

struct la_data {
	SHORT	ld_vplanes;	/* Number of video planes: 1, 2, or 4 */
	SHORT	ld_vwrap;	/* Number of bytes/video line */
	SHORT	*ld_contrl;	/* Pointer to CONTRL array */
	SHORT	*ld_intin;	/* Pointer to INTIN array */
	SHORT	*ld_ptsin;	/* Pointer to PTSIN array */
	SHORT	*ld_intout;	/* Pointer to INTOUT array */
	SHORT	*ld_ptsout;	/* Pointer to PTSOUT array */
	SHORT	ld_colbit[4];	/* Color bit-plane[i] value */
	SHORT	ld_lstlin;	/* -1 */
	SHORT	ld_lnmask;	/* Line-style mask */
	SHORT	ld_wmode;	/* Writing mode 0:replace, 1:transparent,
				   2:exclusive OR, 3:inverse transparent */
	SHORT	ld_x1;		/* X1 coordinate */
	SHORT	ld_y1;		/* Y1 coordinate */
	SHORT	ld_x2;		/* X2 coordinate */
	SHORT	ld_y2;		/* Y2 coordinate */
	SHORT	*ld_patptr;	/* Fill pattern pointer */
	SHORT	ld_patmsk;	/* Fill pattern mask */
	SHORT	ld_mfill;	/* Multi-plane fill flag */
	SHORT	ld_clip;	/* Clipping flag */
	SHORT	ld_xmincl;	/* Minimum X clipping value */
	SHORT	ld_ymincl;	/* Minimum Y clipping value */
	SHORT	ld_xmaxcl;	/* Maximum X clipping value */
	SHORT	ld_ymaxcl;	/* Maximum Y clipping value */
	SHORT	ld_xdda;	/* Accumulator for textblt dda */
	SHORT	ld_ddainc;	/* Fixed point scale factor */
	SHORT	ld_scaldir;	/* Scale direction flag */
	SHORT	ld_mono;	/* Current font is monospaced */
	SHORT	ld_srcx;	/* X coord of character in font */
	SHORT	ld_srcy;	/* Y coord of character in font */
	SHORT	ld_dstx;	/* X coord of character on screen */
	SHORT	ld_dsty;	/* Y coord of character on screen */
	SHORT	ld_delx;	/* Width of character */
	SHORT	ld_dely;	/* Height of character */
	SHORT	*ld_fbase;	/* Pointer to start of font form */
	SHORT	ld_fwidth;	/* Width of font form */
	SHORT	ld_style;	/* Textblt special effects flags */
	SHORT	ld_litemsk;	/* Lightening mask */
	SHORT	ld_skewmsk;	/* Skewing mask */
	SHORT	ld_weight;	/* Thickening factor */
	SHORT	ld_roff;	/* Skew offset above baseline */
	SHORT	ld_loff;	/* Skew offset below baseline */
	SHORT	ld_scale;	/* Scaling flag */
	SHORT	ld_chup;	/* Character rotation vector */
	SHORT	ld_textfg;	/* Text foreground color */
	SHORT	*ld_scrtchp;	/* Text special effects buffer */
	SHORT	ld_scrpt2;	/* Offset to scaling buffer from above */
	SHORT	ld_textbg;	/* Text background color */
	SHORT	ld_copytran;	/* Copy raster form type flag */
	SHORT	(*ld_seedabort)();	/* Seedfill end detect function */
};

/*
 * Memory Form Definition Block
 */

typedef struct MFDB {
	BYTE	*addr;		/* address of memory block */
	SHORT	width;		/* width of block in points */
	SHORT	height;		/* height of block in points */
	SHORT	word_width;	/* width of block in words */
	SHORT	flag;		/* raster format flag */
	SHORT	planes;		/* Number of raster planes */
	SHORT	res1;		/* reserved */
	SHORT	res2;		/* reserved */
	SHORT	res3;		/* reserved */
} MFDB;

/*
 * Font header. Taken from GEM VDI Programmers Guide G-2
 */

typedef struct la_font {
	SHORT	font_id;		/* Face identifier */
	SHORT	font_size;		/* Font size in points */
	BYTE	font_name[32];		/* Face name */
	SHORT	font_low_ade;		/* Lowest ASCII value in face */
	SHORT	font_hi_ade;		/* Highest ASCII value in face */
					/* Distance from char baseline */
	SHORT	font_top_dst;		/* Top line distance */
	SHORT	font_ascent_dst;	/* Ascent line distance */
	SHORT	font_half_dst;		/* Half line distance */
	SHORT	font_descent_dst; 	/* Descent line distance */
	SHORT	font_bottom_dist; 	/* Bottom line distance */
	SHORT	font_fatest;		/* Width of widest char in font */
	SHORT	font_fat_cell;		/* Width of widest char cell in font */
	SHORT	font_left_off;		/* Left offset */
	SHORT	font_right_off;		/* Right offset */
	SHORT	font_thickening; 	/* No. of pixles to widen chars */
	SHORT	font_underline;		/* Width in pixles of underline */
	SHORT	font_lightening; 	/* Mask used to drop pixles out */
	SHORT	font_skewing;		/* Mask used to determine skewing */
	unsigned default_font:1; 	/* Set if default system font */
	unsigned horiz_ofset:1;		/* Use horizontal offset tables */
	unsigned byte_swap:1;		/* Byte swap flag */
	unsigned mono_space:1;		/* Monospaced font */
	SHORT	*font_horiz_off; 	/* Pointer to horizontal offset table */
	SHORT	*font_char_off;		/* Pointer to char offset table */
	BYTE	*font_data;		/* Pointer to font data */
	SHORT	font_width;		/* Font width */
	SHORT	font_height;		/* Font height */
	BYTE	*font_next;		/* Pointer to next font */
} FONT;

#else

typedef struct la_font {
	WORD	font_id;		/* Face identifier */
	WORD	font_size;		/* Font size in points */
	BYTE	font_name[32];		/* Face name */
	WORD	font_low_ade;		/* Lowest ASCII value in face */
	WORD	font_hi_ade;		/* Highest ASCII value in face */
					/* Distance from char baseline */
	WORD	font_top_dst;		/* Top line distance */
	WORD	font_ascent_dst;	/* Ascent line distance */
	WORD	font_half_dst;		/* Half line distance */
	WORD	font_descent_dst; 	/* Descent line distance */
	WORD	font_bottom_dist; 	/* Bottom line distance */
	WORD	font_fatest;		/* Width of widest char in font */
	WORD	font_fat_cell;		/* Width of widest char cell in font */
	WORD	font_left_off;		/* Left offset */
	WORD	font_right_off;		/* Right offset */
	WORD	font_thickening; 	/* No. of pixles to widen chars */
	WORD	font_underline;		/* Width in pixles of underline */
	WORD	font_lightening; 	/* Mask used to drop pixles out */
	WORD	font_skewing;		/* Mask used to determine skewing */
	unsigned default_font:1; 	/* Set if default system font */
	unsigned horiz_ofset:1;		/* Use horizontal offset tables */
	unsigned byte_swap:1;		/* Byte swap flag */
	unsigned mono_space:1;		/* Monospaced font */
	WORD	*font_horiz_off; 	/* Pointer to horizontal offset table */
	WORD	*font_char_off;		/* Pointer to char offset table */
	BYTE	*font_data;		/* Pointer to font data */
	WORD	font_width;		/* Font width */
	WORD	font_height;		/* Font height */
	BYTE	*font_next;		/* Pointer to next font */
} FONT;

typedef struct MFDB {
	BYTE	*addr;		/* address of memory block */
	WORD	width;		/* width of block in points */
	WORD	height;		/* height of block in points */
	WORD	word_width;	/* width of block in (16 bit) words */
	WORD	flag;		/* raster format flag */
	WORD	planes;		/* Number of raster planes */
	WORD	res1;		/* reserved */
	WORD	res2;		/* reserved */
	WORD	res3;		/* reserved */
} MFDB;

#endif

#define IS_STANDARD(p)	((p)->flag)
#define IS_SPECIFIC(p)	(!((p)->flag))

#define STANDARD	~0
#define SPECIFIC	0
