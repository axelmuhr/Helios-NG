/************************************************************************/
/*									*/
/*				TRANS.C					*/
/*									*/
/************************************************************************/

/* Transputer side of vdi.c */

#include <message.h>
#include <task.h>
#include <root.h>
#include <link.h>
#include <codes.h>

#define NO_DEFINES

#include "header.h"
#include "stextra.h"

#define extend(x)	(((x) & 0x8000) ? ((x) | 0xffff0000) : (x))

UBYTE block[BUF_SIZE];

WORD unpack(array)
UBYTE *array;
/* Receive a message and unpack it into suitable arrays */
/* Returns non zero if the v_clswk() message was received */
{
	WORD	j,x,y,tmp;
	void 	gem(void);
	void 	handler(WORD,WORD);

	if (*array == 0) {
		IOdebug("received zero opcode !!\n");
		IOdebug("last opcode received was %d\n",CONTRL[0]);
		return (0);
	}

	CONTRL[0] = *array++;

	if (OPCODE == MOUSE_COORDS) {

		x =   *array++;
		x <<= 8;
		x |=  *array++;

		y =   *array++;
		y <<= 8;
		y |=  *array;

		handler(x,y);

		return(0);
	}

	CONTRL[1] = *array++;
	CONTRL[3] = *array++;
	CONTRL[6] = *array++;

	switch (OPCODE) {

		case 11:	/* get sub-code */
			CONTRL[5] = *array++;
			break;

		case 10:	/* get extra control information */
			CONTRL[7] = *array++;
			CONTRL[8] = *array++;
			CONTRL[9] = *array++;
			CONTRL[10] = *array++;
			break;

		case 1:		/* get screen mode */
			SCREEN.MODE = *array++;
			break;

		default:	/* no extras */
			break;
	}

	for (j = CONTRL[3]; j ; ) {
		tmp        =   *array++;
		tmp        <<= 8;
		tmp        |=  *array++;
		INTIN[--j] =   extend(tmp);
	}

	for (j = 0; j < CONTRL[1] * 2;) {
		tmp        =   *array++;
		tmp        <<= 8;
		tmp        |=  *array++;
		PTSIN[j++] =   extend(tmp);
		tmp        =   *array++;
		tmp        <<= 8;
		tmp        |=  *array++;
		PTSIN[j++] =   extend(tmp);
	}

	gem();

	if (OPCODE != 2) return (0);
	else		 return (1);

} /* unpack() */

void transmit(type)
WORD type;
{
	UBYTE	fine[2];
	WORD	j;
	UBYTE	*array = block;
	void	sendm(WORD, UBYTE *, WORD);

	fine[0] = fine[1] = 0;

	switch(type) {

		case OK:	/* send a default message */

			sendm(2,fine,0x12345678);
			break;

		case RET_HANDLE: /* Insert handle */

			*array++ = RET_HANDLE;
			*array++ = CONTRL[6];
			/* and fall through */

		default:	/* Insert info */

			*array++ = CONTRL[4];
			*array++ = CONTRL[2];
	
			for( j = CONTRL[4] ; j ; ) {
				*array++ = INTOUT[--j] >> 8;
				*array++ = INTOUT[j];
			}
	
			for( j = 0; j < CONTRL[2] * 2 ; j++ ) {
				*array++ = PTSOUT[j] >> 8;
				*array++ = PTSOUT[j++];
				*array++ = PTSOUT[j] >> 8;
				*array++ = PTSOUT[j];
			}

			sendm(array - block,block,DATA_BACK);
			break;
	}

} /* transmit() */

extern WORD	inter_char_spacing;

void gem()
{
	void v_opnwk(void);
	void v_clswk(void);
	void v_clrwk(void);
	void v_updwk(void);
	void v_escape(void);
	void v_pline(void);
	void v_pmarker(void);
	void v_gtext(void);
	void v_fillarea(void);
	void v_bar(void);
	void v_arc(void);
	void v_pieslice(void);
	void v_circle(void);
	void v_ellipse(void);
	void v_ellarc(void);
	void v_ellpie(void);
	void v_rbox(void);
	void v_rfbox(void);
	void v_justified(void);
	void vst_height(void);
	void vst_rotation(void);
	void vs_color(void);
	void vsl_type(void);
	void vsl_width(void);
	void vsl_color(void);
	void vsm_type(void);
	void vsm_height(void);
	void vsm_color(void);
	void vst_font(void);
	void vst_color(void);
	void vsf_interior(void);
	void vsf_style(void);
	void vsf_color(void);
	void vq_color(void);
	void vswr_mode(void);
	void vql_attributes(void);
	void vqm_attributes(void);
	void vqf_attributes(void);
	void vst_alignment(void);
	void v_opnvwk(void);
	void v_clsvwk(void);
	void vq_extnd(void);
	void v_contourfill(void);
	void vsf_perimeter(void);
	void vst_effects(void);
	void vst_point(void);
	void vsl_ends(void);
	void vsc_form(void);
	void vsf_udpat(void);
	void vsl_udsty(void);
	void vr_recfl(void);
	void v_show_c(void);
	void v_hide_c(void);
	void vs_clip(void);
	void vrt_cpyfm(void);
	void vro_cpyfm(void);
	void vr_trnfm(void);
	MFDB *accept_MFDB(WORD,WORD);
	void accept_fonts(void);

	switch (OPCODE)
		{
		case 1:		/* Open workstation */
				v_opnwk();
				IOdebug(VERSION);
				IOdebug("(C) 1987 Perihelion Software\n");
				accept_fonts();
				transmit(RET_HANDLE);
				return;
				
		case 2:		/* Close workstation */
				v_clswk();
				break;
				
		case 3:		/* Clear workstation */
				v_clrwk();
				break;
		
		case 4:		/* Update workstation */
				v_updwk();
				break;
		
		case 5:		/* Escape */
				v_escape();
				break;

		case 6:		/* Polyline */
				v_pline();
				break;

		case 7:		/* Polymarker */
				v_pmarker();
				break;
		
		case 8:		/* Text */
				inter_char_spacing = 0;
				v_gtext();
				break;
		
		case 9:		/* Filled area */
				v_fillarea();
				break;
		
		case 11:	/* Generalised Drawing Primitive */
				switch ( PRIMITIVE_ID ) {
				case BAR:
					v_bar();
					break;
				case ARC:
					v_arc();
					break;
				case PIE:
					v_pieslice();
					break;
				case CIRCLE:
					v_circle();
					break;
				case ELLIPSE:
					v_ellipse();
					break;
				case ELLIPTICAL_ARC:
					v_ellarc();
					break;
				case ELLIPTICAL_PIE:
					v_ellpie();
					break;
				case ROUNDED_RECTANGLE:
					v_rbox();
					break;
				case FILLED_ROUND_RECTANGLE:
					v_rfbox();
					break;
				case JUSTIFIED_GRAPHICS_TEXT:
					v_justified();
					break;
				default:
					IOdebug("bad graphics primative\n");
					break;
				}
				break;
		
		case 12:	/* Set BYTEacter height absolute mode */
				vst_height();
				break;

		case 13:	/* Set BYTEacter baseline vector */
				vst_rotation();
				break;

		case 14:	/* Set color representation */
				vs_color(); break;
		
		case 15:	/* Set polyline linetype */
				vsl_type(); break;

		case 16:	/* Set polyline width */
				vsl_width(); break;				

		case 17:	/* Set polyline color index */
				vsl_color(); break;
		
		case 18:	/* Set polymarker type */
				vsm_type(); break;

		case 19:	/* Set polymarker height */
				vsm_height();
				break;
				
		case 20:	/* Set polymarker color index */
				vsm_color();
				break;
		
		case 21:	/* Set text face */
				vst_font();
				break;
		
		case 22:	/* set text color index */
				vst_color();
				break;
		
		case 23:	/* Set fill interior style */
				vsf_interior();
				break;
		
		case 24:	/* Set fill style index */
				vsf_style();
				break;
		
		case 25:	/* Set fill color index */
				vsf_color();
				break;
		
		case 26:	/* Inquire color representation */
				vq_color();
				break;
				
		case 32:	/* Set writing mode */
				vswr_mode();
				break;
		
		case 35:	/* Inquire current polyline attributes */
				vql_attributes();
				break;
				
		case 36:	/* Inquire current polymarker attributes */
				vqm_attributes();
				break;
				
		case 37:	/* Inquire current fill area attributes */
				vqf_attributes();
				break;

		case 39:	/* Set graphics text alignment */
				vst_alignment();
				break;

		case 100:	/* Open virtual screen workstation */
				v_opnvwk();
				transmit(RET_HANDLE);
				return;
		
		case 101:	/* Close virtual screen workstation */
				v_clsvwk();
				break;

		case 102:	/* Extended inquire function */
				vq_extnd();
				break;
		
		case 103:	/* Contour fill */
				v_contourfill();
				break;
		
		case 104:	/* Set fill perimeter visibility */
				vsf_perimeter();
				break;
		
		case 106:	/* Set graphic text special effects */
				vst_effects();
				break;

		case 107:	/* Set character cell height, points mode */
				vst_point();
				break;
		
		case 108:	/* Set polyline and styles */
				vsl_ends();
				break;

		case 109:	/* copy raster opaque */

				CONTRL[7] = (WORD)accept_MFDB(NOT_SEND_MEM,0);
				CONTRL[9] = (WORD)accept_MFDB(NOT_SEND_MEM,0);

				vro_cpyfm();
				break;

		case 110:	/* transform form */

				CONTRL[7] = (WORD)accept_MFDB(SEND_MEM,0);
				CONTRL[9] = (WORD)accept_MFDB(NOT_SEND_MEM,0);

				vr_trnfm();
				break;

		case 111:	/* Set mouse form */
				vsc_form();
				break;

		case 112:	/* Set user-defined fill pattern */
				vsf_udpat();
				break;

		case 113:	/* Set user-defined linestyle pattern */
				vsl_udsty();
				break;

		case 114:	/* Fill rectangle */
				vr_recfl();
				break;

		case 121:	/* copy raster, transparent */

				CONTRL[7] = (WORD)accept_MFDB(TFORM,INTIN[1]);
				CONTRL[9] = (WORD)accept_MFDB(NOT_SEND_MEM,0);

				vrt_cpyfm();
				break;

		case 122:	/* Show cursor */
				v_show_c();
				break;
		
		case 123:	/* Hide cursor */
				v_hide_c();
				break;
		
		case 129:	/* Set clipping rectangle */
				vs_clip();
				break;

		default:	/* UNDEFINED */
				IOdebug("UNDEFINED: %d\n",OPCODE);
				CONTRL[2] = CONTRL[4] = 0;
				break;
		}

	transmit(DONE); /* indicate we handled it OK */
	return;	

} /* gem() */

extern Task	*MyTask;

int main()
{
	WORD	 done = 0;
	MCB	 mcb;
	WORD 	 GetMsg(MCB *);
	WORD	 unpack(UBYTE *);
        Carrier  *carrier = AllocFast(3000,&MyTask->MemPool);

	if( carrier == NULL ) exit(0);

	while (!done) {
		mcb.Data	= (BYTE *)block;
		mcb.MsgHdr.Dest	= MyTask->Port;
		mcb.Timeout	= 20000000;

		while (GetMsg(&mcb) < 0);

		done = accelerate(carrier,unpack,4,block);
	}

} /* main() */

WORD swap(UBYTE *data)
/* return a byte swapped WORD from a UBYTE pointer */
{
	WORD res;

	res =   *data++;
	res <<= 8;
	res |=  *data;

	return(res);

} /* swap() */

MFDB *receive_MFDB(UBYTE *array, WORD colour, WORD accept)
/* unpack an MFDB from array */
/* accept defines how to accept memory */
/* colour is used to expand monochrome images */
{
	WORD	x, y, z, width, addr;
	UWORD	size;
	MFDB	*to;
	UBYTE	*ptr, form;
	UBYTE	*get_memory(UWORD);
	WORD	swap(UBYTE *);

	/* get an MFDB */

	to = (MFDB *)get_memory((UWORD)sizeof(MFDB));

	if (to == (MFDB *)NULL) {
		IOdebug("no memory to create an MFDB\n\n");
		return ((MFDB *)NULL);
	}

	addr =   *array++;
	addr <<= 8;
	addr |=  *array++;
	addr <<= 8;
	addr |=  *array++;
	addr <<= 8;
	addr |=  *array++;

	to->width      = swap(array + 0);
	to->height     = swap(array + 2);
	to->word_width = swap(array + 4);
	to->flag       = swap(array + 6);
	to->planes     = swap(array + 8);
	to->res1       = swap(array + 10);
	to->res2       = swap(array + 12);
	to->res3       = swap(array + 14);

	to->res1 = addr;

	array += 16;

	if (*array++ == SEND_MEM) {

		switch(accept) {

		case TFORM: /* transparent memory image is to come .... */

			width = to->width / 8 + 1;

			to->addr = (BYTE *)get_memory((UWORD)
			(width * to->height * to->planes * 8));

			if (to->addr == (BYTE *)NULL) {
				IOdebug("cannot get icon image memory\n");
				return ((MFDB *)NULL);
			}

			ptr = (UBYTE *)(to->addr);

			if (colour == 0) colour = SCREEN.MAGIC;

			for(x = to->height * to->planes ; x ; --x) {

				for(y = width; y; --y) {
					form = *array++;

					for(z = 8; z; --z) {
						if (form & 0x80) {
							*ptr++ = colour;
						} else {
							*ptr++ = 0;
						}
						form <<= 1;
					}
				}
			}
			break;

		case SEND_MEM:	/* standard form image comming in */

			size = to->word_width * to->height *
				SCREEN.DEPTH * sizeof(short);

			to->addr = (BYTE *)get_memory(size);

			if (to->addr == (BYTE *)NULL) {
				IOdebug("cannot get solid image memory\n");
				return ((MFDB *)NULL);
			}

			ptr = (UBYTE *)(to->addr);

			for(x = size; x ; --x) {

				*ptr++ = *array++;
			}

			break;

		case NOT_SEND_MEM:
		default:
			IOdebug("unexpected memory sent !!\n");
			break;

		}
	} else {
		to->addr = 0;

		if (accept == TFORM ||
			(accept == SEND_MEM && IS_STANDARD(to))) {

			IOdebug("no memory sent - even tho some was expected\n");
		}
	}

	return (to);

} /* receive_MFDB() */

void sendm(WORD len, UBYTE *buffer, WORD FnRc)
/* send a message to the atari */
{
	MCB mcb;
	WORD PutMsg(MCB *);

	mcb.MsgHdr.DataSize	= len;
	mcb.MsgHdr.ContSize	= 0;
	mcb.MsgHdr.Flags	= MsgHdr_Flags_preserve;
	mcb.MsgHdr.Dest		= (Root->Links[0])->RemoteIOCPort;
	mcb.MsgHdr.Reply	= NullPort;
	mcb.MsgHdr.FnRc		= FnRc;
	mcb.Data		= (BYTE *)buffer;
	mcb.Timeout		= 20000000L;

	FnRc = PutMsg(&mcb);

	if (FnRc) IOdebug("bad PutMsg (%lx)\n",FnRc);

} /* sendm() */

MFDB *accept_MFDB(WORD accept, WORD colour)
/* colour is the foreground colour for icons */
/* accept is true if a memory image can be accepted */
/* accepts an MFDB across the atari - transputer link */
/* returns a pointer to the created MFDB */
{
	MCB	mcb;
	WORD 	GetMsg(MCB *);
	MFDB	*receive_MFDB(UBYTE *, WORD, WORD);
	void	sendm(WORD, UBYTE *, WORD);

	/* Indicate we want an MFDB now */
	sendm(0,block,SEND_MFDB);

	mcb.Data	= (BYTE *)block;
	mcb.MsgHdr.Dest = MyTask->Port;
	mcb.Timeout	= 20000000;

	while(GetMsg(&mcb) < 0) ;

	return( receive_MFDB(block,colour,accept) );

} /* accept_MFDB() */


