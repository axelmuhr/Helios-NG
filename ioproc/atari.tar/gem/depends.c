/************************************************************************/
/*									*/
/*				DEPENDS.C				*/
/*									*/
/************************************************************************/

#include "header.h"
#include "video.h"
#include "charity.h"

/************************************************************************/
/*									*/
/*		Contains system dependent routines			*/
/*									*/
/* These will usually all have to be rewritten to port the software	*/
/*									*/
/************************************************************************/

/* Contains functions:							*/
/*									*/
/*	void	 load_ws_values()					*/
/*	void	 a_cursor_comp()					*/
/*	BYTE	 *get_memory()						*/
/*	WORD	 free_memory()						*/
/*	void	 set_clu()						*/
/*	void	 pattblat()						*/
/*	void	 Fill_Rect_Region()					*/
/*	void	 RasterOp()						*/
/*	void	 initvdi()						*/
/*	void	 tidy_workstation()					*/
/*	WORD	 points_to_pixels()					*/
/*	WORD	 xyoffset()						*/
/*	void	 ColorOp()						*/
/*									*/

/* memory management structures and variables */
#ifdef NEVER

#define MEM_START	(MinInt + 0x40000)
#define MEM_SIZE	0x00300000

BYTE	*memory = (BYTE *)MEM_START;

static	WORD	space = MEM_SIZE,	/* free space left */
			next  = 0;		/* offset to free space */

#endif

void IOdebug(char *, ... );

#define NUM_6845_REG	16

/* ABAQ video setup data */

#ifdef PAL

/* These values for the old PAL boards. */

WORD p_mode[NUM_MODES] = { 0x00,0x20,0x40,0x60 };

WORD v_mode[NUM_MODES] = { 0x02,0x3c,0x36,0x11 };

WORD *pmode   = (WORD *)0x40000000;
WORD *vidmode = (WORD *)0x40400000;


WORD crt[8][16] = { 
/* mode 0 */	{ 42,16,34,0x34,64, 2,60,61,0,15,0x2f,0xf,0x1f,0xe0,0,0 } ,
/* mode 1 */	{ 40,16,33,0x64,49,13,48,48,0,15,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* --"--  */	{ 40,16,37,0x64,49,13,48,48,0,15,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* --"--  */	{ 40,16,36,0x64,49,13,48,48,0,15,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* mode 2 */	{ 42,16,36,0x34,31, 9,30,31,0,15,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* --"--  */	{ 42,16,36,0x34,31, 9,30,31,0,15,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* mode 3 */	{ 50,16,40,0x35,62, 7,60,61,0, 7,0x2f,0xf,0x3f,0xe0,0,0 } ,
/* --"--  */	{ 50,16,40,0x35,62, 7,60,61,0, 7,0x2f,0xf,0x3f,0xe0,0,0 } ,
		 };

WORD *vgaddr = (WORD *)0x40200000;
WORD *vgreg  = (WORD *)0x40200004;

void setup6845(index)
WORD index;
{
	WORD i;

	for (i = 0; i < NUM_6845_REG; i++) {

		*vgaddr = i;
		*vgreg  = crt[index][i];
	}

} /* setup6845() */

void setup_video(mode,monitor)
WORD mode;	/* screen mode 0 - 3 */
WORD monitor;	/* monitor supplied 0 - 2 */
{
	if (mode < 0 || mode >= NUM_MODES) return;

	*pmode   = p_mode[mode];
	*vidmode = v_mode[mode];

	switch (mode) {

		case 0:		setup6845(MODE0);
				break;

		case 1:	switch (monitor) {

				case HITACHI:	setup6845(MODE1_HITACHI);
						break;

				case NEC_PL:	setup6845(MODE1_NEC_PL);
						break;

				case NEC_XL:	setup6845(MODE1_NEC_XL);
						break;

			default:	/* error */
						break;
			}
			break;

		case 2:	switch (monitor) {

				case NEC_PL:	setup6845(MODE2_NEC_PL);
						break;

				case NEC_XL:	setup6845(MODE2_NEC_XL);
						break;

				default:	/* error */
						break;
			}
			break;

		case 3:	switch (monitor) {

				case NEC_PL:	setup6845(MODE3_NEC_PL);
						break;

				case NEC_XL:	setup6845(MODE3_NEC_XL);
						break;

				default:	/* error */
						break;
			}
			break;

		default: /*error */

			break;
	}

} /* setup_video() */

#else

  /* Setup for charity 1 */

WORD v_mode[NUM_MODES] = { 0x02,0x3C,0x36,0x11 }; /* CLUT enables */


/* Numbers for modes 1, 2, and 3 have been tweaked to work with the Hitachi
and NEC Multisync Plus.  Mode 0 works with the Hitachi */

WORD crt[8][9] =  { 

/* Most modes work ok, mode 1 definitely works, mode 0 might not be right!
cos I need to get my hands on a monitor that I can use to check things */

/* mode 0 */    { 208,158,160,16,1100,958,1000,4,3} ,		/* Hitachi */
/* mode 1 */	{ 352,254,284,21,810,766,774,4,3} ,		/* Hitachi */
/* mode 1 */	{ 352,254,284,21,896,766,864,4,3} ,		/* NEC pl */
/* mode 1 */	{ 320,254,268,21,797,766,774,4,3} ,		/* NEC xl */
/* mode 2 */	{ 210,158,180,20,505,480,488,3,0} ,		/* NEC pl */
/* mode 2 */	{ 210,158,176,20,544,478,500,3,0} ,		/* NEC xl */
/* mode 3 */	{ 800,511,640,80,503,478,488,3,0xFD008005} ,	/* NEC pl */
/* mode 3 */	{ 800,511,640,80,503,478,488,3,0xFD008005} ,	/* NEC xl */

		 };

/* Pokes the CRTC with the 9 values that provide timings required to keep
a video screen intact */
 
void setupvreg(index)
WORD index;
{
WORD i; 
WORD *x = (WORD *)VREG_BASE;

	for (i=0; i <= NUM_VREGS; i++) {

		*x++  =  crt[index][i];
	}
}

/* This is called from the Open Workstation bit of GEM */

void setup_video(mode,monitor)
WORD mode;	/* screen mode 0 - 3 */
WORD monitor;	/* monitor supplied 0 - 2 */
{	WORD *px;

	if (mode < 0 || mode >= NUM_MODES) return;

	switch (mode) {

		case 0:		setupvreg(MODE0);
				break;

		case 1:	switch (monitor) {

				case HITACHI:	setupvreg(MODE1_HITACHI);
						break;
				case NEC_PL:	setupvreg(MODE1_NEC_PL);
						break;
				case NEC_XL:	setupvreg(MODE1_NEC_XL);
						break;
				default:	/* error */
						break;
			}
			break;

		case 2:	switch (monitor) {

				case NEC_PL:	setupvreg(MODE2_NEC_PL);
						break;
				case NEC_XL:	setupvreg(MODE2_NEC_XL);
						break;
				default:	/* error */
						break;
			}
			break;

		case 3:	switch (monitor) {

				case NEC_PL:	setupvreg(MODE3_NEC_PL);
						break;
				case NEC_XL:	setupvreg(MODE3_NEC_XL);
						break;
				default:	/* error */
						break;
			}
			break;

		default: /*error */

			break;
	}
	px = (WORD *)MC_REG;
	*px = 4;		/* Enable video */
        px = (WORD*)VMODE;
        *px = v_mode[mode]; 	/* Enable the CLUT */


}
#endif

void load_ws_values()
/* Returns assorted workstation parameters */
{
	CONTRL[2]  = 6;
	CONTRL[4]  = 45;
	INTOUT[0]  = SCREEN.WIDTH - 1;	/* Width in pixels */
	INTOUT[1]  = SCREEN.HEIGHT - 1;	/* Height in pixels */
	INTOUT[2]  = 0;			/* Screen not capable of precise scaling */
	/* Width in microns (10^-6 metres) of 1 pixel */
	INTOUT[3]  = 372;		/*SCREEN.PIX_SIZE/MICRONS_TO_INCHES;*/
	/* Height in microns (10^-6 metres) of 1 pixel */
	INTOUT[4]  = 372;		/*SCREEN.PIX_SIZE/MICRONS_TO_INCHES;*/
	INTOUT[5]  = 3;			/* FINE TUNE: number of character heights*/
	INTOUT[6]  = MAX_LINE_TYPES;	/* Number of linetypes */
	INTOUT[7]  = 0;			/* FINE TUNE: number of linewidths */
	INTOUT[8]  = MAX_MARKER_TYPES;	/* Number of marker types */
	INTOUT[9]  = 8;			/* Number of marker sizes */
	INTOUT[10] = 1;			/* Number of faces supported */
	INTOUT[11] = N_DOTTED_PATTERNS;	/* Number of patterns: hollow,fill,hatch */
	INTOUT[12] = N_CROSS_PATTERNS;	/* Number of hatch styles */

	switch (SCREEN.DEPTH)
		{
		default:
		case 1:		INTOUT[13] =  2; break;
#ifdef NEVER
		case 4:		INTOUT[13] = 16; break;
#else
		case 4:		INTOUT[13] = 2; break;
#endif
		case 8:		INTOUT[13] = 256; break;
		case 32:	INTOUT[13] = 0x01000000L; break;
	}

/* Generalised Drawing Primitives */
	INTOUT[14] = 10; /* Number of GDPs supported */
	INTOUT[15] = 1;	 /* Bar */
	INTOUT[16] = 2;	 /* Arc */
	INTOUT[17] = 3;	 /* Pie slice */
	INTOUT[18] = 4;	 /* Circle */
	INTOUT[19] = 5;	 /* Ellipse */
	INTOUT[20] = 6;	 /* Elliptical arc */
	INTOUT[21] = 7;	 /* Elliptical pie */
	INTOUT[22] = 8;	 /* Rounded rectangle */
	INTOUT[23] = 9;	 /* Filled rounded rectangle */
	INTOUT[24] = 10; /* Justified graphics text */

/* GDP Attribute Set */
	INTOUT[25] = 3;	/* Fill area attributes apply */
	INTOUT[26] = 0;	/* Line attributes apply */
	INTOUT[27] = 3;	/* Fill area attributes apply */
	INTOUT[28] = 3;	/* Fill area attributes apply */
	INTOUT[29] = 3;	/* Fill area attributes apply */
	INTOUT[30] = 0;	/* Line attributes apply */
	INTOUT[31] = 3;	/* Fill area attributes apply */
	INTOUT[32] = 0;	/* Line attributes apply */
	INTOUT[33] = 3;	/* Fill area attributes apply */
	INTOUT[34] = 2;	/* Text attributes apply */

/* Assorted attributes */
	if (SCREEN.MODE != 0) {
		INTOUT[35] = 1; /* Color supported */
	} else {
		INTOUT[35] = 0;	/* Color not supported */
	}

	INTOUT[36] = 1;	/* But only in 90 deg lots */
	INTOUT[37] = 1;	/* Fill area supported */
	INTOUT[38] = 0;	/* Cell array operations supported */
	INTOUT[39] = 0; /* Number of colors in palette */
	INTOUT[40] = 2;	/* Locator devices: keyboard and others (mouse) */
	INTOUT[41] = 1;	/* Valuator device: keyboard only */
	INTOUT[42] = 1;	/* Choice device: function key set only */
	INTOUT[43] = 1;	/* String device: keyboard only */
	INTOUT[44] = 2;	/* Workstation type: input/output */
	PTSOUT[0]  = MIN_TEXT_HEIGHT + 1;	/* Minimum character width */
	PTSOUT[1]  = MIN_TEXT_HEIGHT;	/* Minimum character height */
	PTSOUT[2]  = 7;		/* Maximum character width */
	PTSOUT[3]  = 13;	/* Maximum character height */
	PTSOUT[4]  = 1;		/* Minimum line width */
	PTSOUT[5]  = 0;		/* 0 */
	PTSOUT[6]  = 40;	/* Maximum line width */
	PTSOUT[7]  = 0;		/* 0 */
	PTSOUT[8]  = 15;	/* Minimum marker width */
	PTSOUT[9]  = 11;	/* Minimum marker height */
	PTSOUT[10] = 120;	/* Maximum marker width */
	PTSOUT[11] = 88;	/* Maximum marker height */

} /* load_ws_values() */

BYTE *get_memory(UWORD num_bytes)
/* Allocate num_bytes of memory, starting on a word boundary */
{
#ifdef NEVER

	/* This is not a very sophisticated algorithm */

	num_bytes += 2 * sizeof(WORD);

	/* round up to nearest WORD boundary */

	num_bytes += 3;
	num_bytes &= ~3L;

	if (num_bytes > space) {
		IOdebug("out of memory! (needed %ld)\n",num_bytes);
		return(NULL);
	}

	*((WORD *)(memory + next)) = num_bytes;
	*((WORD *)(memory + next + sizeof(WORD))) = 0;

	space -= num_bytes;
	
	next += num_bytes;

	return (memory + next - num_bytes + 2 * sizeof(WORD));
#else
	BYTE *Malloc(WORD);

	return (Malloc(num_bytes));
#endif
} /* get_memory() */	

WORD free_memory(ptr)
/* Free the memory starting at ptr */
/* Returns non-zero value on failure */
BYTE *ptr;
{
#ifdef NEVER
	WORD	bytes;
	WORD	*block;
	void	printf(BYTE *,...);

	/* we assume that if the pointer is in range then it is valid */

	if (ptr < memory || ptr > memory + next) {
		printf("ptr (%lx) vs memory (%lx) and memory + next (%lx)\n",
			ptr,memory,memory + next);
		return(1);
	}

	ptr -= 2 * sizeof(WORD);
	
	block = (WORD *)(ptr);

	bytes = *block;

	if ((WORD)ptr - (WORD)memory + bytes == next) {
		
		/* release the space held by this block.  Note this space */
		/* may include space from blocks below it that may have   */
		/* been coalesced into it */

		bytes += *(block + 1);

		next  -= bytes;
		space += bytes;
	
	} else {
		/* increase the size of the block above this one to include */
		/* this block aswell */

		/* mark this block as unused */

		*(block) = -(*(block));

		/* point to next block */

		block = (WORD *)(ptr + bytes);

		/* continue until a non-unused block is found */

		while (*(block) < 0) {
			block = (WORD *)((BYTE *)block - *(block));
		}

		/* now increment this block's excess count */

		*(block + 1) += bytes;
		*(block + 1) += *((WORD *)(ptr + sizeof(WORD)));
	}
	return(0);
#else
	WORD Free(BYTE *);

	return (Free(ptr));
#endif
} /* free_memory() */


/****************************************************************/
/*                                                              */
/*		The Graphics Procedures                         */
/*                                                              */
/****************************************************************/

void a_cursor_comp(x,y)
/* Toggle the alpha cursor at cell location x,y */
WORD x,y;
{
	/* XORS the cell, subject to the alpha cursor as a mask */
	void RasterOp(	WORD,PIX_OFFSET,WORD,
			WORD,WORD,PIX_OFFSET,WORD,
			WORD *,PIX_OFFSET);

	RasterOp(	VDI_XOR,
			OFFSET(x,y),32,
			32,32,
			OFFSET(x,y),SCREEN.STRIDE,
			SCREEN.G_CUR_PAT,OFFSET(x,y));

} /* a_cursor_comp() */

void g_cursor_comp(WORD x,WORD y)
/* Toggle the graphics cursor at location x,y */
/* If already there, this will erase the cursor; */
/* otherwise it shows it */
{
	void RasterOp(	WORD,PIX_OFFSET,WORD,
			WORD,WORD,PIX_OFFSET,WORD,
			WORD *,PIX_OFFSET);

	RasterOp(	VDI_XOR,
		OFFSET(x,y),32,
		32,32,
		OFFSET(x,y),SCREEN.STRIDE,
		SCREEN.G_CUR_PAT,OFFSET(x,y));

} /* g_cursor_comp() */

void set_clu(index,red,green,blue)
/* Loads the given color components into the color table entry 'index' */
/* The components are expressed in VDI abstract units */
WORD 	 index;
WORD red,green,blue;
{
	WORD *vdwraddraddr;
	WORD *vdwrcoladdr;

	if (SCREEN.MODE == 0) {

#ifdef PAL
		vdwraddraddr = (WORD *)0x40580000;
		vdwrcoladdr  = (WORD *)0x40582000;
#else
		vdwraddraddr = (WORD *)C454WADDR;
		vdwrcoladdr  = (WORD *)C454WDATA;
#endif

		index &= 0xf;

	} else {

#ifdef PAL
		vdwraddraddr = (WORD *)0x40d00000;
		vdwrcoladdr  = (WORD *)0x40d02000;
#else
		vdwraddraddr = (WORD *)C453WADDR;
		vdwrcoladdr  = (WORD *)C453WDATA;
#endif

		index &= 0xff;
	}

	/* Store the VDI versions */
	CLU[index][0][0] = red;
	CLU[index][0][1] = green;
	CLU[index][0][2] = blue;

	/* Calculate the hardware equivalents */
	
	/* Store the hardware versions */
	CLU[index][1][0] = red;
	CLU[index][1][1] = green;
	CLU[index][1][2] = blue;
	
	/* Load into the hardware */

	switch (SCREEN.MODE) {
		case 0:		/* PERIHELION MODE 0 */
		case 1:		/* PERIHELION MODE 1 */
		case 2:		/* PERIHELION MODE 2 */

			*vdwraddraddr = index;
			*vdwrcoladdr  = red;
			*vdwrcoladdr  = green;
			*vdwrcoladdr  = blue;
			break;		

		case 3:		/* PERIHELION MODE 3 */
			IOdebug("set_clu: unused mode 3\n");
			break;
		default:	/* Illegal Mode of Operation */
			IOdebug("set_clu: illegal screen mode ?\n");
			break;
	}

} /* set_clu() */

UWORD	*mem;

WORD		old_s_ptr = ~0;		/* NB not static so sec5.c can alter */
static UBYTE	old_colour = ~0;

void pattblat(s_ptr,s_width,s_height,d_ptr,d_width,d_height,colour,mode)
WORD s_ptr;	/* pointer to source of pattern */
WORD s_width;	/* source width in (pattern) pixels */
WORD s_height;	/* source height in lines */
WORD d_ptr;	/* destination (screen) pointer */
WORD d_width;	/* destrination width in pixels (bytes) */
WORD d_height;	/* destination height in lines */
UBYTE colour;	/* colour of set pixels in the pattern */
WORD  mode;	/* write mode, 0 = opaque, 1 = transparent */
/* NB works in modes 0 - 2 only */
{
	UBYTE	*sptr,*dptr;
	WORD	patt,count,count2;
	WORD 	itterations,remainder;
	UWORD	mask;

	if (s_ptr != old_s_ptr || old_colour != colour) {

		old_s_ptr  = s_ptr;
		old_colour = colour;

		/* copy pattern into buffer */

		dptr = (UBYTE *)mem;

		for(count = 0; count < s_height; count++) {
			mask = 1;
			patt = *((WORD *)s_ptr);

			for(count2 = 0; count2 < s_width; count2++) {
	
				if (mask & patt) *((UBYTE *)(dptr)) = colour;
				else		 *((UBYTE *)(dptr)) = 0;
	
				dptr++;
				mask <<= 1;
			}

			dptr  += SCREEN.WIDTH - s_width;
			s_ptr += sizeof(WORD);
		}

		/* now copy pattern across buffer */

		itterations = (SCREEN.WIDTH / s_width) - 1;

		remainder   = SCREEN.WIDTH % s_width;

		sptr = (UBYTE *)mem;

		for (count = 0; count < s_height; count++) {

			dptr = (UBYTE *)(sptr + s_width);

			bytblt((WORD *)sptr,(WORD *)dptr,0,0,
				0,s_width,itterations,s_width,0);

			dptr += itterations * s_width;

			/* copy remainder of line */

			bytblt((WORD *)sptr,(WORD *)dptr,0,0,0,0,1,remainder,0);

			sptr += SCREEN.WIDTH;
		}

		/* now duplicate pattern in buffer */

		dptr = (UBYTE *)mem;

		dptr += (32 * SCREEN.WIDTH);

		bytblt((WORD *)mem,(WORD *)dptr,0,0,SCREEN.WIDTH,SCREEN.WIDTH,
			32,SCREEN.WIDTH,0);
	}

	/* calculate offsets into buffer */

	sptr = (UBYTE *)mem;

	sptr += SCREEN.WIDTH * (((d_ptr - SCREEN.MAP) / SCREEN.STRIDE) & 0x1f);

	sptr += (((d_ptr - SCREEN.MAP) % SCREEN.STRIDE) % SCREEN.WIDTH);

	/* now copy onto screen .... */

	for(count = d_height / s_height; count; --count) {
		bytblt((WORD *)sptr,(WORD *)d_ptr,0,0,SCREEN.WIDTH,
			SCREEN.STRIDE,s_height,d_width,mode);
		d_ptr += s_height * SCREEN.STRIDE;
	}

	/* copy remaining lines */

	bytblt((WORD *)sptr,(WORD*)d_ptr,0,0,SCREEN.WIDTH,SCREEN.STRIDE,
		d_height % s_height,d_width,mode);

} /* pattblat() */

void clear_screen()
/* Sets entire screen memory to background color, index 0 */
{
	WORD array[512],i,j;

	for(i = 512 ; i ;) array[--i] = 0;

	bytblt(array,(WORD *)SCREEN.MAP,0,0,0,SCREEN.STRIDE,
		SCREEN.HEIGHT,SCREEN.WIDTH,0);

	/* since screen has been cleared, so should the cursor's background */

	for (i = 0; i < 16; i++) {
		for(j = 0; j < 16; j++) {
			SCREEN.G_CUR_COPY[i][j] = 0;
		}
	}

} /* clear_screen() */

void Fill_Rect_Region(p_left,p_right,reg_height)
/* Fill a rectangular region using all the current  attributes except */
/* OUTLINE */
/* p_left    	the address of the top-left most pixel */
/* p_right   	the address of the top-right most pixel plus one */
/* 		that is pixels from p_left to p_right-1 inclusive will be set */
/* reg_height	height of the rectangular region */

PIX_OFFSET	p_left,p_right;
WORD 		reg_height;
{
	WORD		x,y,fg;
	PIX_OFFSET	dptr;
	void blkload(WORD *,WORD,WORD);

	if (reg_height < 1) return;

	switch (WS_INFO->WRITE_MODE) {
	case REPLACE:
		switch (WS_INFO->FILL_INTERIOR_STYLE) {
		case SOLID:
			blkload((WORD *)(p_left + SCREEN.MAP),
				p_right - p_left,WS_INFO->FILL_COLOR_INDEX);

			bytblt( (WORD *)(p_left + SCREEN.MAP),
				(WORD *)(p_left + SCREEN.MAP + SCREEN.STRIDE)
				,0,0,0,SCREEN.STRIDE,
				reg_height - 1,p_right - p_left,0);
			break;
			
		case HOLLOW:
			blkload((WORD *)tmpscanline,
				p_right - p_left,BACKGROUND_COLOUR);

			bytblt( (WORD *)tmpscanline,
				(WORD *)(p_left + SCREEN.MAP),0,0,
				0,SCREEN.STRIDE,reg_height,p_right - p_left,0);
			break;

		case PATTERN:
		case HATCH:
			pattblat((WORD)WS_INFO->FILL_MASK,32,32,
				(p_left + SCREEN.MAP),(p_right - p_left),
				reg_height,WS_INFO->FILL_COLOR_INDEX,0);
			break;

		default:	IOdebug("replace unmatched switch (%d)\n",
					WS_INFO->FILL_INTERIOR_STYLE);
				break;
		}
		break;

	case TRANSPARENT:
			fg = WS_INFO->FILL_COLOR_INDEX;

			if (fg == 0) fg = SCREEN.MAGIC;

		switch (WS_INFO->FILL_INTERIOR_STYLE) {
		case SOLID:
			blkload((WORD *)(p_left + SCREEN.MAP)
				,p_right - p_left,fg);

			bytblt( (WORD *)(p_left + SCREEN.MAP),
				(WORD *)(p_left + SCREEN.MAP + SCREEN.STRIDE)
				,0,0,0,SCREEN.STRIDE,
				reg_height - 1,p_right - p_left,1);
			break;
			
		case HOLLOW:
			blkload((WORD *)tmpscanline,p_right - p_left,
				BACKGROUND_COLOUR);

			bytblt(	(WORD *)tmpscanline,
				(WORD *)(p_left + SCREEN.MAP),0,0,
				0,SCREEN.STRIDE,reg_height,p_right - p_left,1);
			break;

		case PATTERN:
		case HATCH:
			pattblat((WORD)WS_INFO->FILL_MASK,32,32,
				(p_left + SCREEN.MAP),(p_right - p_left),
				reg_height,fg,1);
			break;

		default:	IOdebug("transparent unmatched switch\n");
				break;
			}
		break;
	case XOR:
		if (WS_INFO->FILL_INTERIOR_STYLE != HOLLOW) {

			dptr = p_left + SCREEN.MAP;

			for(y = reg_height ; y ; --y) {
				for(x = p_right - p_left; x ; --x) {
					SPA(dptr,~(RPA(dptr)));
					dptr++;
				}
				dptr += SCREEN.STRIDE - (p_right - p_left);
			}
		}
		break;

	case REV_TRANSPARENT:
		switch (WS_INFO->FILL_INTERIOR_STYLE) {
		case SOLID:
			blkload((WORD *)(p_left + SCREEN.MAP),
				p_right - p_left,WS_INFO->FILL_COLOR_INDEX);

			bytblt( (WORD *)(p_left + SCREEN.MAP),
				(WORD *)(p_left + SCREEN.MAP + SCREEN.STRIDE)
				,0,0,0,SCREEN.STRIDE,
				reg_height - 1,p_right - p_left,2);
			break;
			
		case HOLLOW:
			blkload(tmpscanline,p_right - p_left,BACKGROUND_COLOUR);

			bytblt(	(WORD *)tmpscanline,
				(WORD *)(p_left + SCREEN.MAP),0,0,
				0,SCREEN.STRIDE,reg_height,p_right - p_left,2);
			break;

		case PATTERN:
		case HATCH:
				fg = WS_INFO->FILL_COLOR_INDEX;

				if (fg == 0) fg = SCREEN.MAGIC;

				pattblat((WORD)WS_INFO->FILL_MASK,32,32,
					(p_left + SCREEN.MAP),
					(p_right - p_left),
					reg_height,fg,2);
				break;

		default:	IOdebug("rev-trans unmatched switch\n");
				break;
		}

	default:	IOdebug("unmatched switch\n");
			break;
	}

} /* Fill_Rect_Region() */


void RasterOp(	op, s_ptr,s_stride, s_width, s_height,
		d_ptr, d_stride, m_ptr, m_origin)
		
/* Generalised color raster operation */
/* Assumes screen memory origin is at top left */
/* Assumes a pixel is a char and that all pointers are char* */
		
WORD op;		/* Primary operation to be performed */

PIX_OFFSET s_ptr;	/* Memory offset of first (top left) source pixel */
WORD s_stride;		/* Source stride, in pixels */
WORD s_width;		/* Width, in pixels, of source raster */
WORD s_height;		/* Height, in pixels, of source raster */

PIX_OFFSET d_ptr;	/* Memory offset of first (top left) dest. pixel */
WORD d_stride;		/* Destination stride, in pixels */

WORD *m_ptr;		/* Memory location of 32 bit by 32 bit mask pattern */
PIX_OFFSET m_origin;	/* Memory location of the mask pattern tile origin */
			/* NOTE: to disable mask, use an all-1 pattern */

{
	WORD	   y;
	
/* Validate arguments */
	if (s_width  <= 0) return;
	if (s_height <= 0) return;
	if (s_stride <  0) return;
	if (d_stride <  0) return;

	/* Go forwards, moving down left-hand edge */
	
	for (y = s_height; y; --y)
		{
				
/* Moves a horizontal span of pixels, subject to source and destination */
/* conditions and mask */		

{
	UWORD mask_bigword;
	WORD dest = d_ptr;
	WORD dptr;
	WORD sptr = s_ptr + SCREEN.MAP;

	WORD i;
	WORD y_offset,x_offset;

/* Only test mask bits if necessary */
	if (m_ptr != OPEN_MASK) {
	/* we must initialise the y_offset and x_offset values */
	/* the y_offset indicates the relevant WORD in the mask */
	/* and the x_offset indicates the relevant BIT in this WORD */
		if (dest >= m_origin) {
			y_offset = ((((WORD)dest) - (WORD)m_origin) /
				SCREEN.STRIDE) & 0x1f;
			x_offset = 31 - (((((WORD)dest) - (WORD)m_origin) %
				SCREEN.STRIDE) & 0x1f);
		} else {
			y_offset = 31 - (((((WORD)m_origin) - (WORD)dest) /
				SCREEN.STRIDE) & 0x1f);
			x_offset = 31 - (((((WORD)m_origin) - (WORD)dest) %
				SCREEN.STRIDE) & 0x1f);
		}

		mask_bigword = *(m_ptr + y_offset);

	/* NOTE that the bit offset is updated in the for loop BEFORE */
	/* being tested so it must be set one bit to the left/right of */
	/* the first bit that needs to be tested */
		x_offset++;
	}
	
/* for each pixel on the span test the maskbyte and then test the */
/* source and destination bytes and do the update if one is necessary */
	for (i = 0; i < s_width; i++) {
	
		if (m_ptr != OPEN_MASK) {
	/* first update the offset for the bit in this WORD */
			x_offset--;
			x_offset &= 0x1f;

	/* a mask is defined so we must test the appropriate bit */
			if (!( ( mask_bigword >> x_offset) & 1)) {
				if (WS_INFO->WRITE_MODE == REPLACE) {
					SPA(dest+SCREEN.MAP,0L);
				}
			/* the bit is zero so do-not test the source and */
			/* destination pixels */
				goto nextbyte;
			}

	/* else the bit was a one and so we must test the source and */
	/* destination values */
		}


/* Source, Destination and Mask all say go ahead and perform the op */

		dptr = dest + SCREEN.MAP;

		switch (op) {

		case VDI_ZERO:		SPA(dptr,0L); break;
		case VDI_AND:		SPA(dptr,RPA(sptr) & RPA(dptr));
					break;
		case VDI_AND_NOT:	SPA(dptr,RPA(sptr) & ~RPA(dptr));
					break;
		case VDI_REPLACE:	SPA(dptr,RPA(sptr));
					break;
		case VDI_NOT_AND:	SPA(dptr,~RPA(sptr) & RPA(dptr));
					break;
		case VDI_NOP:		break;
		case VDI_XOR:		SPA(dptr,RPA(sptr) ^ RPA(dptr));
					break;
		case VDI_OR:		SPA(dptr,RPA(sptr) | RPA(dptr));
					break;
		case VDI_NOR:		SPA(dptr,~(RPA(sptr) | RPA(dptr)));
					break;
		case VDI_XNOR:		SPA(dptr,~(RPA(sptr) ^ RPA(dptr)));
					break;
		case VDI_NOTD:		SPA(dptr,~RPA(dptr));
					break;
		case VDI_OR_NOT:	SPA(dptr,RPA(sptr) | ~RPA(dptr));
					break;
		case VDI_NOTS:		SPA(dptr,~RPA(sptr));
					break;
		case VDI_NOT_OR:	SPA(dptr,~RPA(sptr) | RPA(dptr));
					break;
		case VDI_NAND:		SPA(dptr,~(RPA(sptr) & RPA(dptr)));
					break;
		case VDI_ONE:		SPA(dptr,0xFFFFFFFFL); break;
			
		}
/* increment the source and destination pointers to the next byte */
	nextbyte:
		sptr ++;
		dest ++;
	}

}

		d_ptr += d_stride;			
		s_ptr += s_stride;
		}

} /* RasterOp() */


void initvdi()
/* Called once at load time to set up the library */
{
	WORD	i,j;
	WORD	*get_screen_lookalike(WORD);
	void	setup_video(WORD,WORD);

	/* Initialise look-up-table present boolean */
	CLU_PRESENT = MAPPED;

	/* Set up screen data accordingly */

	setup_video(SCREEN.MODE,NEC_XL);

	switch (SCREEN.MODE) {
		case 0:		/* Perihelion Mode 0 */
			SCREEN.WIDTH  = 1280;
			SCREEN.HEIGHT = 960;
			SCREEN.DEPTH  = 4;
			SCREEN.STRIDE = 2048;
			SCREEN.MAP    = 0x00000000L;
			SCREEN.MAGIC  = MAGIC_COLOUR0;

			break;
		
		case 1:		/* Perihelion Mode 1 */
			SCREEN.WIDTH  = 1024;
			SCREEN.HEIGHT = 768;
			SCREEN.DEPTH  = 8;
			SCREEN.STRIDE = 2048;
			SCREEN.MAP    = 0x00200000L;
			SCREEN.MAGIC  = MAGIC_COLOUR1;

			break;
			
		case 2:		/* Perihelion Mode 2 */
			SCREEN.WIDTH  = 640;
			SCREEN.HEIGHT = 480;
			SCREEN.DEPTH  = 8;
			SCREEN.STRIDE = 2048;
			SCREEN.MAP    = 0x00400000L;
			SCREEN.MAGIC  = MAGIC_COLOUR1;

			break;
		
		case 3:		/* Perihelion Mode 3 */
			SCREEN.WIDTH  = 512;
			SCREEN.HEIGHT = 480;
			SCREEN.DEPTH  = 32;
			SCREEN.STRIDE = 2048;
			SCREEN.MAP    = 0x00600000L;
			SCREEN.MAGIC  = MAGIC_COLOUR1;
			
			break;
		}

	SCREEN.MINFONTNUM = 0;
	SCREEN.MAXFONTNUM = 2;

	/* Load default graphics cursor pattern */
	for(i = 0; i < 16; i++) {
		SCREEN.G_CUR_PAT[i]  = 0xFFFF;
		OPEN_MASK[i]         = 0xFFFFFFFFL;
		OPEN_MASK[i+16]      = 0xFFFFFFFFL;
		for(j = 0; j < 16; j++) {
			SCREEN.G_CUR_COL[i][j]  = 0xFF;
			SCREEN.G_CUR_COPY[i][j] = 0;
		}
	}

	/* set up mouse */

	SCREEN.G_CURSOR_X = MOUSE_X;
	SCREEN.G_CURSOR_Y = MOUSE_Y;
	SCREEN.G_ON = 0;

	/* Initialise all workstations to not-in-use */
	for (i = 0; i < MAX_HANDLES; i++) WS_INUSE[i]= 0;

	/* Initialise pointer to tmpscanline */

	tmpscanline = get_screen_lookalike((WORD)SCREEN.WIDTH);

	const_tmpscanline = ATPO(tmpscanline);

	/* Get memory for screen pattern buffer */

	mem = (UWORD *) get_memory((UWORD)
		(64 * SCREEN.WIDTH * sizeof(BYTE)));

} /* initvdi() */

void tidy_workstation()
/* tidy up any memory etc relevant to this workstation */
{
	/* first do any actions necessary for every type of workstation */

	(void) free_memory((BYTE *)mem);

	/* now do any specific actions for this workstation type */
		
	switch (SCREEN.MODE)
		{
		case 0:		/* Perihelion Mode 0 */
				break;
			
		case 1:		/* Perihelion Mode 1 */
				break;
			
		case 2:		/* Perihelion Mode 2 */
				break;
			
		case 3:		/* Perihelion Mode 3 */
				break;
	}

} /* tidy_workstation() */

WORD points_to_pixels(point_size)
/* transforms the given point size to a number of pixels */
WORD point_size;
{
	return ( (WORD) ( (point_size << N_FRACT_BITS) /
		(72*SCREEN.PIX_SIZE) >> N_FRACT_BITS) >> N_FRACT_BITS);

} /* points_to_pixels() */

WORD celloffset(WORD x,WORD y)
{
/* UNFINISHED */
	x = y = 0;
} /* celloffset() */

void blkload(store,numpixels,value)
/* does a block load of numpixels with a colour value into the storage */
/* this storage must be similar to the current screen variant since the */
/* memory is being initialised for a call to RasterOp which uses the SPA */
/* and RPA procedures */
WORD *store;
WORD numpixels;
WORD value;
{
	BYTE *addr = (BYTE *)store;

	switch (SCREEN.MODE)
		{
		case 0:		/* Perihelion Mode 0 */

		case 1:		/* Perihelion Mode 1 */
		case 2:		/* Perihelion Mode 2 */
				for(; numpixels; --numpixels)
					*addr++ = value;
				break;
				
		case 3:		/* Perihelion Mode 3 */
				break;
	}

} /* blkload() */

WORD *get_screen_lookalike(nvalues)
/* allocates storage for nvalues */
/* This memory will be similar to the current screen variant so that */
/* this memory may be passed over to the RasterOp and used as if it was */
/* the screen. Usually this memory will then be initialised by a call to */
/* blkload. It returns a WORD * so that all screen variants are */
/* aligned--this is the coarsest alignment needed for all variants */
WORD nvalues;
{
	switch (SCREEN.MODE)
		{
		case 0:		/* Perihelion Mode 0 */
		case 1:		/* Perihelion Mode 1 */
		case 2:		/* Perihelion Mode 2 */
			return ((WORD *) get_memory((UWORD)
				((nvalues + 3) * sizeof(BYTE))));
			break;
			
		case 3:		/* Perihelion Mode 3 */
			return ((WORD *) get_memory((UWORD)
				nvalues * sizeof(WORD)));
			break;
		default:
			break;
	}

} /* get_screen_lookalike() */

#ifdef NEVER
void ColorOp(	dt,db,dw,ds,sm,em,ic,
		sb,ss,al,sp,
		men,ml,ms,mb,mi,mx,
		op,comp,
		v1,v2,v3,v4)

/* GENERAL PERIHELION COLOR RASTER OPERATION */
/* FINE TUNE: This version handles nibble operations only */
/* and assumes ordinary 32 bit memory */
/* Can be improved by using Perihelion memory maps */
/* but is then not portable, even to the Atari ST */
		

/* Destination operands */
		
/* FINE TUNE */
/* dt should eventually be a WORD */
WORD dt;		/* Number of words (32 bits) to be transferred */
			/* including partial words at start and end of line */
WORD *db;		/* Destination start address */
WORD dw;		/* Width of area in words */
WORD ds;		/* Destination stride: difference between address of */
			/* last element of one line and address of */
			/* first element of next */
UBYTE sm;		/* Start mask */
UBYTE em;		/* End mask */
UBYTE ic;		/* Increment control- lowest 6 bits */

/* Source operands */
WORD *sb;		/* Source base address */
WORD ss;		/* Source stride: difference between address of */
			/* last element of one line and address of */
			/* first element of next */
UBYTE al;	/* Alignment- lowest 5 bits */
UBYTE sp;	/* Pipeline control */

/* Mask operands */
UBYTE men;	/* Mask enable boolean */
WORD ml;		/* Mask line base address */
UBYTE ms;	/* Mask start line- lowest 5 bits */
UBYTE mb;	/* Mask start bit offset- lowest 3 bits */
UBYTE mi;	/* Mask increment */
UBYTE mx;	/* Mask mux boolean. 1=>8 bits; 0=>4 bits */

/* Values for testing */
UBYTE op;	/* Four pairs of bits (GTE,INV), one pair per test */
UBYTE comp;	/* Four pairs of bits, one pair per comparator */
UBYTE v1;	/* First test value */
UBYTE v2;	/* Second test value */
UBYTE v3;	/* Third test value */
UBYTE v4;	/* Fourth test value */

/* Planar mask */
/* FINE TUNE */
/* Not available yet */

{
	WORD i;			/* Main loop counter */
	UBYTE s_nib;	/* Current source nibble */
	UBYTE d_nib;	/* Current destination nibble */
	WORD n_count;		/* Total number of nibble transfers */
	WORD l_count;		/* Number of nibble transfers per line */
	WORD dv_incr, sv_incr;	/* Dest and source vertical increments */
	WORD h_incr;		/* Horizontal increment */
	UBYTE	 j;		/* Minor loop counter */
	WORD test;			/* The test we are doing */
	UBYTE	 op1,op2,op3,op4;	/* The operations for each of the tests */
	UBYTE d_nib_count;	/* Number of nibbles in current word */
	UBYTE s_nib_count;	/* Number of nibbles in start mask   */
	UBYTE e_nib_count;	/* Number of nibbles in end mask     */

/* Calculate how many nibbles to transfer */
	s_nib_count= 0; e_nib_count= 0;

/* First count the source nibbles covered by the start mask */
	for (j=1; j!=0; j= j << 1)	/* Keep going until 1 shifts off left end */
		if (sm & j) s_nib_count++;
	d_nib_count= s_nib_count;	/* Number of nibbles in current word */
		
/* Now count the source nibbles covered by the end mask */
	for (j=1; j!=0; j= j << 1)	/* Keep going until 1 shifts off left end */
		if (em & j) e_nib_count++;
	
/* Number of nibbles to be transferred */
	l_count= 8*dw - (8 - s_nib_count) - (8 - e_nib_count);	/* ...per line */
	n_count= l_count*(dt/dw);				/* ...in total */

/* Forwards or backwards? */
	switch((WORD) (ic & 0x3))	/* Low bits: horizontal increment control */
		{
		case 0:
		case 3:		/* No operation: add zero */
				h_incr= 0;
				break;
		
		case 1:		/* Subtract one: moving right to left */
				h_incr= -1;
				sb= sb + dw - 1;	/* start at right margin */
				db= db + dw - 1;	/* start at right margin */
				break;

		case 2:		/* Add one */
				h_incr= 1;
				break;	
	}
	
	switch((WORD) (ic & 0xC))	/* High bits: vertical increment control */
		{
		case 0:		/* Add stride */
				dv_incr= ds;
				sv_incr= ss;
				break;
				
		case 4:		/* Add (stride + 1) */
				dv_incr= ds + 1;
				sv_incr= ss + 1;
				break;
				
		case 8:		/* Subtract (stride + 1 ): moving bottom to top */
				dv_incr= -(ds + 1);
				sv_incr= -(ss + 1);
				sb= sb + (dt/dw) - 1;	/* start at bottom edge */
				db= db + (dt/dw) - 1;	/* start at bottom edge */
				break;
			
		case 12:	/* Subtract stride: moving bottom to top */
				dv_incr= -ds;
				sv_incr= -ss;
				sb= sb + (dt/dw) - 1;	/* start at bottom edge */
				db= db + (dt/dw) - 1;	/* start at bottom edge */
				break;
	}
	
		
/* Of we go with the main loop */
	for (i=0; i<n_count; i++)
		{
		/* FINE TUNE  */
		/* Mask not yet available in hardware, so we ignore that for now */
			
		/* See if pixels are available- perform four tests */

		/* Get destination nibble */
		if (!d_nib_count)
			{	/* Move to next word of memory */
			db++;
			d_nib_count= 4;
		}
		d_nib= (UBYTE) (( (*db) >> (--d_nib_count)) & 0xF);
		
		/* Get source nibble */
		if (!s_nib_count)
			{	/* Move to next word of memory */
			sb++;
			s_nib_count= 4;
		}
		s_nib= (UBYTE) (( (*sb) >> (--s_nib_count)) & 0xF);

		test= (WORD) (comp & 0x3);	/* Which value to compare with? */
		switch (test)
			{
			case 0:	op1= v1; break;
			case 1:	op1= v2; break;
			case 2:	/* Should not happen */
			case 3:	op1= d_nib; break;
		}

		test= (WORD) ((comp>>2) & 0x3);	/* Which value to compare with? */
		switch (test)
			{
			case 0:	op2= v1; break;
			case 1:	op2= v2; break;
			case 2:
			case 3:	op2= d_nib; break;
		}

		test= (WORD) ((comp>>4) & 0x3);	/* Which value to compare with? */
		switch (test)
			{
			case 0:	op3= v1; break;
			case 1:	op3= v2; break;
			case 2:
			case 3:	op3= d_nib; break;
		}

		test= (WORD) ((comp>>6) & 0x3);	/* Which value to compare with? */
		switch (test)
			{
			case 0:	op4= v1; break;
			case 1:	op4= v2; break;
			case 2:
			case 3:	op4= d_nib; break;
		}
	
	/* First test */
		test= (WORD) (op & 0x3);
		switch (test)
			{
			case 0:	if (s_nib<=op1) break;
				else goto newnibble;
				
			case 1:	if (s_nib>op1) break;
				else goto newnibble;
				
			case 2:	if (s_nib>=op1) break;
				else goto newnibble;
				
			case 3:	if (s_nib<op1) break;
				else goto newnibble;
		}	
	/* First test succeeds */
		
	
	/* Second test */
		test= (WORD) ((op>>2) & 0x2);
		switch (test)
			{
			case 0:	if (s_nib<=op2) break;
				else goto newnibble;
				
			case 1:	if (s_nib>op2) break;
				else goto newnibble;
				
			case 2:	if (s_nib>=op2) break;
				else goto newnibble;
				
			case 3:	if (s_nib<op2) break;
				else goto newnibble;
		}	
	/* Second test succeeds */
		
	
	/* Third test */
		test= (WORD) ((op>>4) & 0x3);	/* Low four bits */
		switch (test)
			{
			case 0:	if (d_nib<=op3) break;
				else goto newnibble;
				
			case 1:	if (d_nib>op3) break;
				else goto newnibble;
				
			case 2:	if (d_nib>=op3) break;
				else goto newnibble;
			
			case 3:	if (d_nib<op3) break;
				else goto newnibble;
		}	
	/* Third test succeeds */
		
	
	/* Fourth test */
		test= (WORD) ((op>>6) & 0x3);	/* Low four bits */
		switch (test)
			{
			case 0:	if (d_nib<=op4) break;
				else goto newnibble;
				
			case 1:	if (d_nib>op4) break;
				else goto newnibble;
				
			case 2:	if (d_nib>=op4) break;
				else goto newnibble;
				
			case 3:	if (d_nib<op4) break;
				else goto newnibble;
		}	
	/* Fourth test succeeds */
		
	/* Source, Destination and Mask all say go ahead and perform the op */
		
/* UNFINISHED */
/*	SPA(d_ptr,(WORD) s_nib);*/

		newnibble: /* a comment */;
	}

}
#endif
