void IOdebug(char *str, int a, int b, int c, int d)
{ STdebug(str, a, b, c, d);
}

