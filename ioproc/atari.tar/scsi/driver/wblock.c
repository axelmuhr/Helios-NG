/* write a specific disk block */

#include <stdio.h>
#include <osbind.h>
#include <bios.h>

main(argc, argv)
int argc;
char **argv;

{
	int	i;
	long	ret;
	char	buffer[512];
	int 	rwflag =1;
	int 	number = 1;
	int	block =0, pattern =0, dev = 2;

	if ( argc < 2 )
		{
		fprintf(stderr,"Wblock syntax: wblock <blockno.> [<dev>][<data>]\n");
		return;
		}


	sscanf(argv[1],"%d",&block);
	

	if ( argc > 2 )
		{sscanf(argv[2],"%d",&dev);}

	if ( argc > 3 )
		{sscanf(argv[3],"%x",&pattern);}

	
	for (i=0; i<512; i++)
		{buffer[i] = (char)pattern;}

	printf("About to write dev %d block %d %d sectors \n",dev,block,number);

	ret = Rwabs(rwflag, &buffer[0], number, block, dev);

	fprintf(stderr,"returned %x\n",ret);
	
	return;
}
