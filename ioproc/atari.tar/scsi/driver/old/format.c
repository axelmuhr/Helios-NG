#include <stdio.h>

#define	BUF_SIZE	1024
#define DEVICE		0

extern void send_comand();

typedef long	BIG_WORD;
typedef int	WORD;
typedef char	BYTE;

typedef struct {
	BIG_WORD	first;
	BYTE		second;
	BYTE		device_id;
	BIG_WORD	third;
	BIG_WORD	fourth;
	BIG_WORD	fifth;
	BIG_WORD	sixth;
	BIG_WORD	seventh;
	BYTE		*cmd;
	BYTE		*data;
	BYTE		*status;
	} CCB;

#define BIT_SHIFT	0

BYTE	cmd[6];
BYTE	data[BUF_SIZE] = {0,0,0,8,0,0,0,0,0,0,2,0,1,3,14,4,3,14,BIT_SHIFT,1,0,
			0};
BYTE	status[1];
CCB	ccb;

void init()
{
	ccb.first = -1L;
	ccb.second = 0;
	ccb.device_id = DEVICE;
	ccb.third = 0L;
	ccb.fourth = 0L;
	ccb.fifth = 0L;
	ccb.sixth = 6L;
	ccb.seventh = 7L;
	ccb.cmd = cmd;
	ccb.data = data;
	ccb.status = status;

	cmd[0] = 0x15;	/* mode_select */
	cmd[1] = 0x0;
	cmd[2] = 0x0;
	cmd[3] = 0x0;
	cmd[4] = 0x18;
	cmd[5] = 0x0;

	send_comnd(&ccb);

	get_comnd(&ccb);

} /* init */
void format()
{
	cmd[0] = 0x04;	/* format */
	cmd[1] = 0x0;
	cmd[2] = 0x0;
	cmd[3] = 0x0;
	cmd[4] = 0x0;
	cmd[5] = 0x0;

	send_comnd(&ccb);

	get_comnd(&ccb);

} /* format */

main(argc,argv)
char **argv;
{
	init();

	format();

} /* main */
