
        		SCSI DRIVER FUNCTIONAL SPECIFICATION
			====================================

	27/7/87 C.G


1.0	INTRODUCTION:

  The existing Atari ST SASI driver will be modified to support the SCSI. This
SCSI driver will be provided in addition to the existing SASI driver so that 
both SCSI and SASI drives can be supported at the same time.


  A single interface to floppy,SASI HD,and SCSI HD are provided. These will be
initialised to support logical drives A-Z. Drives A and B are always floppies,
drives C-n are SASI HDs(hard disks), and drives n-Z are SCSI HDs. When the 
new hard disk driver is run from the auto folder, it will call the installer in 
the SASI HD driver and then the SCSI HD driver. These will install all disks 
and logical partitions thereof. When the GEM desktop appears the SCSI partitio-
-ns will appear as normal logical units.



  The whole disk driver will be provided as a single program which is run from 
the AUTO folder at bootup. It will patch the filesystem vectors; hdv_bpb, 
hdv_rw and hdv_mediach to intercept all disk requests. All subsequent disk 
requests will be redirected either to the floppy dirver, or to the SASI driver
, or to the SCSI driver.


  The disk driver can therefore be subdivided into four logical subsections:

	1] Main entry point - Initialise disk system and return to TOS
                              (must stay rsident).

	2] Floppy driver    - This will usually be the floppy driver resident
                              in the BIOS ROM. It may at a later date be 
			      enhanced and become RAM resident.

	3] SASI HD driver   - Existing SASI HD driver.

	4] SCSI HD driver   - SCSI driver. Currently only supports Hard disks
			      ,may be modified in future to support other 
			      devices. An NCR5380 SCSI host/adaptor driver
                              is also provided.


  The NCR5380 host/adaptor driver behaves as an intelligent initiator supporting
Disconnect/Reselect with multiple logical units (see d5380.ms).


  The Atari HDX utility already exists to format and partition SASI suported 
hard disks. An additional utility will be provided to format and partition the 
SCSI suported hard disks.



