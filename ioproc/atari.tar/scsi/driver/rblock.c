/* read a specific disk block */

#include "c:\include\stdio.h"
#include "c:\include\osbind.h"
#include "c:\include\bios.h"
#include "c:\include\ctype.h"

main(argc, argv)
int argc;
char **argv;

{
	int	duff;
	int	i,inner;
	long	ret;
	char    buffer[512];
	int 	rwflag =0;
	int 	number = 1;
	int	block =0, dev = 2;

	if ( argc < 2 )
		{
		fprintf(stderr,"Rblock syntax: rblock <blockno.> [<dev>][<no.>]\n");
		return;
		}


	block = atoi(argv[1]);
	

	if ( argc > 2 )
		{ dev = atoi(argv[2]);}

	if ( argc > 3 )
		{ number = atoi(argv[3]);}

	printf("About to read dev %d block %d %d sectors \n",dev,block,number);
	printf("\n...Any key to continue -");
	duff = getchar();

	ret = Rwabs(rwflag, &buffer[0], number, block, dev);

	if ( ret != 0 )
		{fprintf(stderr,"\nreturned %x\n",ret);return;}
	
	i=0;
	while(i<512)
		{
		for (inner=i; inner< i+16; inner ++)
			{ char c = buffer[inner];
			  printf("%x%x ",(c>>4)&0xf,(c&0xf));
			}

		printf("  ");

		for (inner=0; inner< 16; inner++)
			{
			if ( isascii(buffer[i]) ) 
				{printf("%c",buffer[i++]);}
			else {printf(".");i++;}
			}
		printf("\n");
		}
		
	printf("\n...Any key to continue -");
	duff = getchar();
	
	return;
}
