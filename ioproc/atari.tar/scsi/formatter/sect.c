/* sect.c */
/* $Header: sect.c,v 1.1 86/05/29 12:16:43 dyer Exp $ */

#include "defs.h"
#include "part.h"


#define	ZBUFSIZ	0x4000
#define	ZCOUNT	(ZBUFSIZ/0x200)


/*
 * Logical-to-dev+partition mapping table.
 */
int nlogdevs;			/* # logical devices */
LOGMAP logmap[MAXLOGDEVS];
int livedevs[MAXPHYSDEVS];	/* 1: device is alive */


/*
 * Rebuild logical-to-physical mapping
 * by reading and interpreting the root
 * blocks for all physical devs.
 *
 */
rescan()
{
    int dev;
    char buf[512];
    int partno;
    PART partinfo[NPARTS];

    /* disable all logical and physical devs */
    for (dev = 0; dev < MAXLOGDEVS; ++dev)
	logmap[dev].lm_physdev = -1;

    /*
     * Scan all physical devs
     * and pick up partition structures.
     */
    nlogdevs = 0;
    for (dev = 0; dev < MAXPHYSDEVS; ++dev)
    {
	if (!livedevs[dev])
		continue;
	getroot(dev, buf);
	gpart(buf, &partinfo[0]);
	for (partno = 0; partno < NPARTS; ++partno)
	    if (partinfo[partno].p_flg & P_EXISTS &&
		partinfo[partno].p_siz != (SECTOR)0)
	    {
		if (nlogdevs >= MAXLOGDEVS)
		{
		    err("[3][Too many logical devices][OK]");
		    return ERROR;
		}
		logmap[nlogdevs].lm_physdev = dev;
		logmap[nlogdevs].lm_partno = partno;
		logmap[nlogdevs].lm_start = partinfo[partno].p_st;
		logmap[nlogdevs].lm_siz = partinfo[partno].p_siz;
		++nlogdevs;
	    }
    }

    return OK;
}


/*
 * Map block on logical device to
 * block on physical device;
 * return ERROR if the logical device
 * doesn't exist.
 */
log2phys(adev, ablk)
int *adev;
SECTOR *ablk;
{
    int dev;

    dev = *adev;
    if (dev >= 0 && dev < MAXPHYSDEVS)
	return OK;

    dev = toupper(dev);
    if (dev >= 'C' && dev <= 'P')
    {
	dev -= 'C';
	if (logmap[dev].lm_physdev < 0)
	    return err("[3][Invalid logical device][CANCEL]");
	if (*ablk > logmap[dev].lm_siz)
	    return err("[3][Logical sector out of range][CANCEL]");
	*adev = logmap[dev].lm_physdev;
	*ablk = logmap[dev].lm_start + *ablk;
	return OK;
    }

    return ERROR;
}


/*
 * Get dev's root block.
 *
 */
getroot(dev, buf)
int dev;
char *buf;
{
    return rdsect(dev, buf, (SECTOR)0);
}


/*
 * Put dev's root block.
 *
 */
putroot(dev, buf)
int dev;
char *buf;
{
    return wrsect(dev, buf, (SECTOR)0);
}


/*
 * Read sector from dev.
 *
 */
rdsect(dev, buf, sect)
int dev;
char *buf;
SECTOR sect;
{
	int v;

	if (log2phys(&dev, &sect) < 0)
		return(repscsi("LOG2PHYS", 0x02ff));

	v = xread(sect, 1, buf, (WORD)dev);
	if (v && ((v >> 8) != SCSI_CHECK || (v & 0xff)))
		return(repscsi("READ", v));
	return(OK);
}


/*
 * Write sector to dev.
 *
 */
wrsect(dev, buf, sect)
int dev;
char *buf;
SECTOR sect;
{
    int v;

    if (log2phys(&dev, &sect) < 0)
	return(repscsi("LOG2PHYS", 0x02ff));

	v = xwrite(sect, 1, buf, (WORD)dev);
	if (v && ((v >> 8) != SCSI_CHECK || (v & 0xff)))
		return(repscsi("WRITE", v));
	return(OK);
}


/*
 * Zero range of sectors on dev.
 *
 */
zerosect(dev, start, count)
int dev;
SECTOR start;
WORD count;
{
    char zbuf[ZBUFSIZ];
    int i, v;

    if (log2phys(&dev, &start) < 0)
		return(repscsi("LOG2PHYS", 0x02ff));

    for (i = 0; i < ZBUFSIZ; ++i)
	zbuf[i] = 0;

    while (count)
    {
	i = ZCOUNT;
	if (count < i)
		i = count;
	if ((v = xwrite(start, i, zbuf, dev)) && ((v >> 8) != SCSI_CHECK || (v & 0xff)))
	    break;
	start += i;
	count -= i;
    }
	if (v && ((v >> 8) != SCSI_CHECK || (v & 0xff)))
		return(repscsi("WRITE", v));
	return(OK);
}
