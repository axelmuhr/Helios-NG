/* assist.c */
/* $Header: assist.c,v 1.1 86/05/29 12:18:29 dyer Exp $ */

/*
 * markbad()
 * zero()
 *
 */

#include "defs.h"
#include "part.h"

extern int rebootp;


#define	MAXBADSECTS	128		/* max# of bad sectors */
#define	MBUFSIZ		32		/* #blocks in read buffer */


/*
 * Mark bad sectors on the logical dev
 *
 */
markbad(ldev)
int ldev;
{
    WORD ndirs, fatsiz, w;
    long nsects;
    SECTOR fat0, fat1, data;
    char bs[512];
    int nbad;
    BOOT *boot;
    SECTOR badbuf[MAXBADSECTS];

    /*
     * Read boot sector and extract volume information.
     */
    if (rdsect(ldev, bs, (SECTOR)0) < 0) return ERROR;
    boot = (BOOT *)bs;
    gw((WORD *)&boot->b_ndirs[0], &ndirs);
    gw((WORD *)&boot->b_spf[0], &fatsiz);
    gw((WORD *)&boot->b_res[0], &w);
    fat0 = (SECTOR)w;
    gw((WORD *)&boot->b_nsects[0], &w);
    nsects = (SECTOR)w;

    fat1 = fat0 + fatsiz;
    data = fat1 + fatsiz + (nsects / (512 / 32));

    nbad = readrange(ldev, data, nsects, badbuf);
    if (nbad > MAXBADSECTS)
	form_alert(1, "[1][Drive has more than 128 bad|\
sectors -- try reformatting.][Cancel]");
    else if (nbad > 0)
	fixbadcls(ldev, data, fat0, fat1, nbad, badbuf);
}


/*
 * Read range of sectors,
 * record bad ones in the vector (up to MAXBADSECTS),
 * return number of bad ones.
 *
 */
readrange(dev, start, end, badbuf)
int dev;
SECTOR start;
SECTOR end;
SECTOR *badbuf;
{
    long count, cnt, physect;
    int nbad = 0;
	int v;
    SECTOR sect;
    char buf[MBUFSIZ*512];

    count = (long)(end - start);
    physect = start;
    sect = start;
    if (log2phys(&dev, &physect) != OK)
	return ERROR;

    /*
     * Read lots of sectors, 32 sectors at a time;
     * if an error happens, then probe individual sectors
     * in the lump of 32 that failed.
     */
    while (count)
    {
	cnt = count;
	if (cnt > MBUFSIZ) cnt = MBUFSIZ;
	if (nbad > MAXBADSECTS) break;

	if ((v = xread(physect, (WORD)cnt, buf, (WORD)dev)) && ((v >> 8) != SCSI_CHECK || (v & 0xff)))
	{
		repscsi("READ * 32", v);
	    while (cnt)			/* got error, so find which block */
	    {
		if (xread(physect, (WORD)1, buf, (WORD)dev))
		    if (nbad < MAXBADSECTS)
			badbuf[nbad++] = sect;
			else ++nbad;
		--cnt;
		++physect;
		++sect;
	    }
	} else {
	    physect += cnt;
	    sect += cnt;
	    count -= cnt;
	}
    }

    return nbad;
}


/*
 * Fixup bad sector entries in the FATs;
 * suboptimal, since a FAT sector is read and two are
 * written for EACH bad sector, even if there is
 * more than one bad entry in a given FAT sector.
 *
 * This "never happens", so who cares?
 *
 */
fixbadcls(ldev, data, fat0, fat1, nbad, badbuf)
int ldev;
SECTOR data, fat0, fat1;
int nbad;
SECTOR *badbuf;
{
    long clno, sno, wno;
    int i, v;
    WORD buf[256];

    for (i = 0; i < nbad; ++i)
    {
	clno = *badbuf / 2;
	sno = clno / 256L;
	wno = clno & 0xffL;

	if ((v = xread(sno + fat0, (WORD)1, buf, ldev)) && ((v >> 8) != SCSI_CHECK || (v & 0xff)))
	{
		repscsi("READ", v);
	    break;
	}

	buf[wno] = 0xf0ff;		/* 0xfff0 in 8086-land */

	if ((v = xwrite(sno + fat0, (WORD)1, buf, ldev)) && (v = xwrite(sno + fat1, (WORD)1, buf, ldev)) && ((v >> 8) != SCSI_CHECK || (v & 0xff)))
	{
		repscsi("WRITE", v);
	    break;
	}
    }
}


/*
 * Zero logical dev
 *
 */
zero(dev)
int dev;
{
    WORD ndirs, fatsiz;
    char bs[512];
    BOOT *boot;

    if (rdsect(dev, bs, (SECTOR)0) < 0)
	return ERROR;

    /*
     * Zero file system's FAT and DIR sectors.
     */
    boot = (BOOT *)bs;
    gw((WORD *)&boot->b_ndirs[0], &ndirs);
    gw((WORD *)&boot->b_spf[0], &fatsiz);
    zerosect(dev,
	     (SECTOR)1,
	     fatsiz*2 + ndirs/16);
    rebootp = 1;
    rescan();
}
