/* defs.h */
/* $Header: defs.h,v 1.1 86/05/29 12:23:48 dyer Exp $ */

#define	Super(x)	gemdos(0x20,x)
#define	WCAPFILE	"SCSICAP"	/* name of winnie-cap file */
#define	ERROR		(-1)
#define	OK		0
#define MAXPHYSDEVS	2		/* max #devs on DMA bus */
#define	MAXLOGDEVS	14		/* max # logical devices */
#define	NPARTS		4		/* #partitions in root block */

#define	NULL	0L
#define	LONG	long
#define	WORD	unsigned short int
#define	BYTE	char

#define	SECTOR	LONG

extern long gemdos();

#define	SCSI_OK		0x00
#define	SCSI_CHECK	0x02
#define	SCSI_BUSY	0x08
#define	SCSI_GOOD	0x10
#define	SCSI_CONFLICT	0x18
