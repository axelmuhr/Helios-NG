/* fmt.c */
/* $Header: fmt.c,v 1.1 86/05/29 12:15:16 dyer Exp $ */

#include "defs.h"
#include "part.h"

/* WINCAP FILE CHANGED TO SCSICAP - PAB 14/10/88 */

extern char sbuf[];
extern int livedevs[MAXPHYSDEVS];

/*
 * These constants are used in a heuristic that determines
 * if the format parameter information in the boot sector
 * is intact.  (See fmtpok()).
 */
#define	MAXCYLS		4096		/* max number of cylinders */
#define	MINCYLS		100		/* minimum number of cylinders */
#define	MAXHEADS	16		/* max number of heads */
#define	MINHEADS	2		/* minimum number of heads */
#define	MAXLZ		16		/* max landing zone value */
#define	MAXRT		2		/* max step-rate code */

/* error returns for Conner CP340 */
char *cp340_err[] = {
	"no additional sense data",
	"no index",
	"no seek complete",
	"write fault",
	"not ready",
	"not selected",
	"no track zero",
	"multiple drives selected",
	"LU communication failure",
	"track following error",
	"error 0A",
	"error 0B",
	"error 0C",
	"error 0D",
	"error 0E",
	"error 0F",
	"ECC error",
	"recovered read error",
	"null addr mark in ID",
	"null addr mark in data",
	"no record found",
	"seek error",
	"sync mark error",
	"recovered read data",
	"recovered read error",
	"defect list error",
	"parameter overrun",
	"error 1B",
	"primary defect list error",
	"compare error",
	"recovered ID",
	"error 1F",
	"illegal command opcode",
	"invalid LBN",
	"illegal function code",
	"error 23",
	"illegal field in CDP",
	"invalid LUN",
	"error 26",
	"invalid field in parameters",
	"media changed",
	"power-on or bus reset",
	"mode select parameter change",
	"error 2B",
	"error 2C",
	"error 2D",
	"error 2E",
	"error 2F",
	"incompatible cartridge",
	"medium format corrupt",
	"no defect spare location",
	"error 33",
	"error 34",
	"error 35",
	"error 36",
	"error 37",
	"error 38",
	"error 39",
	"error 3A",
	"error 3B",
	"error 3C",
	"error 3D",
	"error 3E",
	"error 3F",
	"RAM failure",
	"ECC diagnostic",
	"power diagnostic",
	"message request invalid",
	"internal error",
	"select or reselect failed",
	"successful s/w reset",
	"SCSI interface faulty",
	"internally detected error",
	"inappropriate or illegal message",
	"unknown error"
};
/* error returns for Adaptec ACB4070  */
char *acb4070_err[] = {
	"no error",
	"no index/sector",
	"no seek complete",
	"write fault",
	"drive not ready",
	"error 05",
	"no track zero",
	"error 07",
	"error 08",
	"error 09",
	"error 0A",
	"error 0B",
	"error 0C",
	"error 0D",
	"error 0E",
	"error 0F",
	"ID CRC error",
	"Uncorrectable data error",
	"ID address mark unfound",
	"error 13",
	"Record not found",
	"Seek error",
	"error 16",
	"error 17",
	"Data check in no retry mode",
	"ECC error during verify",
	"Interleave error",
	"error 1B",
	"Unformatted or bad format",
	"error 1D",
	"error 1E",
	"error 1F",
	"Illegal command",
	"Illegal block address",
	"error 22",
	"Volume overflow",
	"Bad arg.",
	"Invalid LUN",
	"error 26",
	"error 27",
	"Cartridge changed",
	"error 29",
	"error 2A",
	"error 2B",
	"Error count overflow",
	"error 2D",
	"error 2E",
	"error 2F",
	"unknown error"
};
char **scsi_err	= acb4070_err;		/* default error texts */
/*
 * These are the default format parameters;
 * they are for a 20Mb Mitsubishi drive.
 *
 * However, these parameters will be discarded at run time
 * in favour of the data from WINCAP.
 */
HINFO deffmt = {
	0x264,		/* 306 cylinders */
	4,		/* 4 heads */
	0x265,		/* no reduced write-current cylinder */
	0x265,		/* no write precomp cylinder */
	4,		/* landing zone position = 4 */
	2,		/* use buffered seeks */
	1,		/* interleave = 1 */
	17,		/* 17 sectors per track */
	0		/* generic size */
};


/*
 * Extract format parameters from a root
 * sector image.  Returns OK if the parameters
 * appear to be intact.
 *
 */
gfmtparm(image, fmtparm)
char *image;
HINFO *fmtparm;
{
    register HINFO *rinfo;

    rinfo = &((RSECT *)(image + 0x200 - sizeof(RSECT)))->hd_info;

    fmtparm->hi_cc = rinfo->hi_cc;
    fmtparm->hi_dhc = rinfo->hi_dhc;
    fmtparm->hi_rwcc = rinfo->hi_rwcc;
    fmtparm->hi_wpc = rinfo->hi_wpc;
    fmtparm->hi_lz = rinfo->hi_lz;
    fmtparm->hi_rt = rinfo->hi_rt;
    fmtparm->hi_in = rinfo->hi_in;
    fmtparm->hi_spt = rinfo->hi_spt;
    fmtparm->hi_gensize = 0;

    return fmtpok(fmtparm);
}


/*
 * Set format parameters in a
 * root sector image.
 *
 */
sfmtparm(image, fmtparm)
char *image;
HINFO *fmtparm;
{
    register HINFO *rinfo;
    register long siz;

    rinfo = &((RSECT *)(image + 0x200 - sizeof(RSECT)))->hd_info;

    rinfo->hi_cc = fmtparm->hi_cc;
    rinfo->hi_dhc = fmtparm->hi_dhc;
    rinfo->hi_rwcc = fmtparm->hi_rwcc;
    rinfo->hi_wpc = fmtparm->hi_wpc;
    rinfo->hi_lz = fmtparm->hi_lz;
    rinfo->hi_rt = fmtparm->hi_rt;
    rinfo->hi_in = fmtparm->hi_in;
    rinfo->hi_spt = fmtparm->hi_spt;

    /*
     * Compute total disk size
     * = <#cyls> * <#heads> * <#sectors/track>
     */
    ((RSECT *)(image + 0x200 - sizeof(RSECT)))->hd_siz =
    	(long)fmtparm->hi_cc *
	(long)fmtparm->hi_dhc *
	(long)fmtparm->hi_spt;
}


/*
 * Determine if format parameters are good;
 * return OK if they appear to be,
 * ERROR if they don't appear to be.
 *
 */
fmtpok(fmtparm)
HINFO *fmtparm;
{
    if (fmtparm->hi_cc > MAXCYLS ||
	fmtparm->hi_cc < MINCYLS ||
	fmtparm->hi_dhc > MAXHEADS ||
	fmtparm->hi_dhc < MINHEADS ||
	fmtparm->hi_lz > MAXLZ ||
	fmtparm->hi_rt > MAXRT)
	    return ERROR;

    return OK;
}


/*
 * Setup default format parameters in hinfo;
 * (REAL C compilers do this with a structure assignment...)
 *
 */
fdefault(hinfop)
HINFO *hinfop;
{
    hinfop->hi_cc = deffmt.hi_cc;
    hinfop->hi_dhc = deffmt.hi_dhc;
    hinfop->hi_rwcc = deffmt.hi_rwcc;
    hinfop->hi_wpc = deffmt.hi_wpc;
    hinfop->hi_lz = deffmt.hi_lz;
    hinfop->hi_rt = deffmt.hi_rt;
    hinfop->hi_in = deffmt.hi_in;
    hinfop->hi_spt = deffmt.hi_spt;
    hinfop->hi_gensize = deffmt.hi_gensize;
}


/*
 * Return format parameters in `hinfo', based on
 * the format parameter name `fpnam'.
 *
 * return 0 on OK,
 * -1 on [CANCEL].
 *
 */
gfparm(hinfop, fpnam)
HINFO *hinfop;
char *fpnam;
{
    long num;

    if (wgetent(fpnam, NULL) == ERROR)
	return errs("[3][No such disk format as|", fpnam, "][OK]");

    fdefault(hinfop);
    if (wgetnum("cy", &num) == OK) hinfop->hi_cc = (int)num;
    if (wgetnum("hd", &num) == OK) hinfop->hi_dhc = (char)num;
    if (wgetnum("rw", &num) == OK) hinfop->hi_rwcc = (int)num;
    if (wgetnum("wp", &num) == OK) hinfop->hi_wpc = (int)num;
    if (wgetnum("lz", &num) == OK) hinfop->hi_lz = (char)num;
    if (wgetnum("rt", &num) == OK) hinfop->hi_rt = (char)num;
    if (wgetnum("in", &num) == OK) hinfop->hi_in = (char)num;
    if (wgetnum("sp", &num) == OK) hinfop->hi_spt = (char)num;
    if (wgetnum("gs", &num) == OK) hinfop->hi_gensize = num;
    return 0;
}
extern getcmd();
extern sendcmd();

#define	BUF_SIZE	1024

typedef struct {
	long	qptr;
	char	rqstatus;
	char	device_id;
	long	curcmdptr;
	long	curdataptr;
	long	curstatptr;
	long	cmdlen;
	long	datalen;
	char	*cmd;
	char	*data;
	char	*status;
} CCB;

#define BIT_SHIFT	0

char cmd[6];
char data[BUF_SIZE];
char status[3];
CCB ccb;

int maxerrno = 0x2f;				/* ditto */

char sensebuf[18];

mode_select(dev, h, w)
int dev;
HINFO *h;
int w;
{
	long blocks, cyls, blksz, ostack;
	int v;
	cyls = h->hi_cc;
	blocks = h->hi_cc * h->hi_dhc * h->hi_spt;	/* cyls * heads * secs/trk */
	blksz = 512;
	ccbinit(dev);
	maxerrno = 0x49;		/* max error no */
	scsi_err = cp340_err;		/* error texts */

	if (h->hi_gensize != 0) /* if generic scsi has been set use drive defaults */
		return 0;	/* otherwise setup disk controler with params */

/* For drives without on-board controllers that understand their stats:	 */
/* send mode_select with params as set in SCSICAP */
/* i.e. if ADAPTEC controller used with ST506 drive */

		maxerrno = 0x2f;		/* max error no */
		scsi_err = acb4070_err;		/* error texts */
		cmd[1] = dev << 5;		/* lun */
		ccb.datalen = cmd[4] = 24;	/* 4 header, 8 blk desc, 12 drive parameters */
		ccb.datalen = cmd[4] = 22;	/* 4 header, 8 blk desc, 10 drive parameters */
		data[5] = 0;
		data[6] = 0;
		data[7] = 0;
		data[12] = 2;			/* list format = hard-sector fixed drv */
		data[12] = 1;			/* list format = soft-sector fixed drv */
		data[13] = cyls >> 8;
		data[14] = cyls & 0xff;		/* cylinders */
		data[15] = h->hi_dhc;		/* heads */
		data[16] = (cyls + 1) >> 8;
		data[17] = (cyls + 1) & 0xff;	/* reduced wr current cyl */
		data[18] = (cyls + 1) >> 8;
		data[19] = (cyls + 1) & 0xff;	/* wr precomp cyl */
		data[20] = h->hi_lz;		/* landing zone */
		data[20] = 0;			/* default inner trk */
		data[21] = h->hi_rt;		/* step pulse o/p rate code */
		data[21] = 0;			/* 3ms step pulse o/p rate code */
/*		data[22] = 0x0c;		fixed hardsectored */
/*		data[23] = h->hi_spt;		secs per track */
		/* ACB4070 */
		
	ostack = Super(NULL);
	cmd[0] = 0x15;	/* mode_select */
	cmd[2] = 0x0;
	cmd[3] = 0x0;
	cmd[5] = 0x0;	/* ctrl byte */
	data[0] = 0;
	data[1] = 0;	/* medium type = fixed hard disk */
	data[2] = 0;
	data[3] = 8;	/* blk descriptor length */
	data[4] = 0;	/* density code */
	data[8] = 0;
	data[9] = blksz >> 16;
	data[10] = (blksz >> 8) & 0xff;
	data[11] = blksz & 0xff;
	status[0] = 0xff;
	sendcmd(&ccb);
	getcmd(&ccb);
	if (status[0] == 0x02)
		v = rqsense(dev);
	else
		v = status[0] << 8;
	Super(ostack);
	return(v);
}

format(dev, intrlv)
int dev;
int intrlv;
{
	long ostack;
	int v;
	ostack = Super(NULL);
	ccbinit(dev);
	cmd[0] = 0x04;
	cmd[1] = dev << 5;		/* lun no defectlist */
	cmd[2] = 0x0;			/* default 6C byte pattern */
	cmd[3] = intrlv >> 8;
	cmd[4] = intrlv & 0xff;
	cmd[5] = 0x0;			/* ctrl byte */
	status[0] = 0xff;
	sendcmd(&ccb);
	getcmd(&ccb);
	if (status[0] == 0x02)
		v = rqsense(dev);
	else
		v = status[0] << 8;
	Super(ostack);
	return(v);
}
rqsense(dev)
int dev;
{	char code;
	ccbinit(dev);
	cmd[0] = 0x03;		/* request_sense */
	cmd[1] = dev << 5;	/* lun */
	cmd[2] = 0;
	cmd[3] = 0;
	cmd[4] = sizeof(sensebuf);	/* allocation length 0 = 4 */
	cmd[5] = 0;			/* ctrl byte */
	ccb.data = sensebuf;
	ccb.datalen = sizeof(sensebuf);
	sendcmd(&ccb);
	getcmd(&ccb);
	code = sensebuf[0] & 0x7f;
	if (code == 0x70)		/* Extended sense */
	{ /* Check for Recovered Error which is not really an error at all */
	  int sensekey = sensebuf[2] & 0x0f;
	  if ( sensekey <= 1 )
		   return(0);
	  return((sensebuf[12] & 0xff) | 0x0200);
	}
	return 	(code | 0x0200);
}

xread(sect, n, buf, dev)
long sect;
int n;
char buf[];
int dev;
{
	long ostack;
	int v;
/*	qrep("READ", dev, sect, n);
*/	ostack = Super(NULL);
	ccbinit(dev);
 	ccb.data = buf;
	ccb.datalen = 512 * n;
	cmd[0] = 0x08;	/* read */
	cmd[1] = (dev << 5) | (sect >> 16);	/* LBA msb */
	cmd[2] = (sect >> 8) & 0xff;
	cmd[3] = sect & 0xff;
	cmd[4] = n;	/* blocks */
	cmd[5] = 0x0;	/* ctrl byte */
	status[0] = 0xff;
	sendcmd(&ccb);
	getcmd(&ccb);
	if (status[0] == 0x02)
		v = rqsense(dev);
	else
		v = status[0] << 8;
	Super(ostack);
	return(v);
}
xwrite(sect, n, buf, dev)
long sect;
int n;
char buf[];
int dev;
{
	long ostack;
	int v;
/*	qrep("WRITE", dev, sect, n);
*/	ostack = Super(NULL);
	ccbinit(dev);
 	ccb.data = buf;
	ccb.datalen = 512 * n;
	cmd[0] = 0x0a;	/* write */
	cmd[1] = (dev << 5) | (sect >> 16);	/* LBA msb */
	cmd[2] = (sect >> 8) & 0xff;
	cmd[3] = sect & 0xff;
	cmd[4] = n;	/* blocks */
	cmd[5] = 0x0;	/* ctrl byte */
	status[0] = 0xff;
	sendcmd(&ccb);
	getcmd(&ccb);
	if (status[0] == 0x02)
		v = rqsense(dev);
	else
		v = status[0] << 8;
	Super(ostack);
	return(v);
}
i_scsi()
{
	int dev, v;
	long ostack;
	ostack = Super(NULL);
	init_controller();
	Super(ostack);

	for (dev = 0; dev < MAXPHYSDEVS; dev++) {
		livedevs[dev] = 0;

		/* Allow the device to settle down after RESET.
		   This will also take care of the initial "Unit Reset" err */
		for (;;)
		{ v = testrdy(dev);
	  	  if ( (v >> 8) != SCSI_BUSY ) break;
	  	}

		v = rezero(dev);	/* Attempt to zero the drive */
		if (!(v && ((v >> 8) != SCSI_CHECK || (v & 0xff))))
		/* Looks like a good drive - just make sure */
		{	v = testrdy(dev);
			if (v && ((v >> 8) != SCSI_CHECK || (v & 0xff)))
				repscsi("TEST READY", v);
			else
				livedevs[dev] = 1;
		}
	}
}
rezero(dev)
int dev;
{
	long ostack;
	int v;
	ostack = Super(NULL);
	ccbinit(dev);
	cmd[0] = 0x01;		/* rezero unit */
	cmd[1] = dev << 5;	/* lun */
	cmd[2] = 0;
	cmd[3] = 0;
	cmd[4] = 0;
	cmd[5] = 0;		/* ctrl byte */
	status[0] = 0xff;
	sendcmd(&ccb);
	getcmd(&ccb);
	if (status[0] == 0x02)
		v = rqsense(dev);
	else
		v = status[0] << 8;
	Super(ostack);
	return(v);
}
testrdy(dev)
int dev;
{
	long ostack;
	int v;
	ostack = Super(NULL);
	ccbinit(dev);
	cmd[0] = 0x00;		/* test unit ready */
	cmd[1] = dev << 5;	/* lun */
	cmd[2] = 0;
	cmd[3] = 0;
	cmd[4] = 0;
	cmd[5] = 0;		/* ctrl byte */
	status[0] = 0xff;
	sendcmd(&ccb);
	getcmd(&ccb);
	if (status[0] == 0x02)
		v = rqsense(dev);
	else
		v = status[0] << 8;
	Super(ostack);
	return(v);
}
ccbinit(dev)
int dev;
{
	ccb.qptr = -1L;
	ccb.rqstatus = 0;
	ccb.curcmdptr = 0L;
	ccb.curdataptr = 0L;
	ccb.curstatptr = 0L;
	ccb.cmdlen = 6L;
	ccb.datalen = 0;
	ccb.cmd = cmd;
	ccb.status = status;
	ccb.data = data;
	ccb.device_id = dev;
}
rep_err(s, v)
char s[];
int v;
{
	char sbuf[100];
	strcpy(sbuf, "[3][");
	strcat(sbuf, s);
	strcat(sbuf, ": ");
	if (v > maxerrno)
		v = maxerrno + 1;
	strcat(sbuf, scsi_err[v]);
	strcat(sbuf, "][abort]");
	form_alert(0, sbuf);
}
repscsi(s, v)
char s[];
int v;
{
	switch(v >> 8) {
	case SCSI_CHECK:
		rep_err(s, v & 0xff);
		break;
	case SCSI_BUSY:
		rep_stat(s, "busy error");
		break;
	case SCSI_GOOD:
		rep_stat(s, "intermediate result");
		break;
	case SCSI_CONFLICT:
		rep_stat(s, "conflict error");
		break;
	default:
		qrep(s, 0, 0, v);
		break;
	}
	return(ERROR);
}
rep_stat(s, t)
char s[];
char t[];
{
	char sbuf[100];
	strcpy(sbuf, "[3][");
	strcat(sbuf, s);
	strcat(sbuf, ": ");
	strcat(sbuf, t);
	strcat(sbuf, "][abort]");
	form_alert(0, sbuf);
}
qrep(s, dev, sect, n)
char s[];
int dev;
SECTOR sect;
int n;
{
	char sbuf[200];
	char t[20];
	strcpy(sbuf, "[3][DOING ");
	strcat(sbuf, s);
	strcat(sbuf, "|DEV=");
	sconv(t, (long)dev);
	strcat(sbuf, t);
	strcat(sbuf, "|SECT=");
	sconv(t, (long)sect);
	strcat(sbuf, t);
	strcat(sbuf, "|COUNT=");
	sconv(t, (long)n);
	strcat(sbuf, t);
	strcat(sbuf, "][abort]");
	form_alert(0, sbuf);
}
sconv(s, n)
char *s;
long n;
{
	char t[20];
	long div = 1000000000L;
	char *p = t;
	n &= 0x7fffffffL;
	while (div) {
		*p = '0';
		while (n >= div) {
			(*p)++;
			n -= div;
		}
		div /= 10;
		p++;
	}
	*p = 0;
	p = t;
	while (*p == '0' && *(p+1))
		p++;
	strcpy(s, p);
}
