/* resource file indicies for SCSIFMT */

#define MENUBAR  0	/* menu tree */
#define MNDESK   3	/* TITLE in tree MENUBAR */
#define MNFILE   4	/* TITLE in tree MENUBAR */
#define MNDISK   5	/* TITLE in tree MENUBAR */
#define DEABOUT  8	/* STRING in tree MENUBAR */
#define FIQUIT   17	/* STRING in tree MENUBAR */
#define DIFORM   19	/* STRING in tree MENUBAR */
#define DIPART   20	/* STRING in tree MENUBAR */

#define ABOUT    1	/* form/dialog */
#define ABOK     3	/* BUTTON in tree ABOUT */

#define PHYSDEV  2	/* form/dialog */
#define UNIT0    1	/* BUTTON in tree PHYSDEV */
#define UNIT1    2	/* BUTTON in tree PHYSDEV */
#define UNIT2    3	/* BUTTON in tree PHYSDEV */
#define UNIT3    4	/* BUTTON in tree PHYSDEV */
#define UNIT4    5	/* BUTTON in tree PHYSDEV */
#define UNIT5    6	/* BUTTON in tree PHYSDEV */
#define UNIT6    7	/* BUTTON in tree PHYSDEV */
#define UNIT7    8	/* BUTTON in tree PHYSDEV */
#define PHYSOK   9	/* BUTTON in tree PHYSDEV */
#define PHYSCN   10	/* BUTTON in tree PHYSDEV */

#define LOGDEV   3	/* form/dialog */
#define CCOLON   1	/* BUTTON in tree LOGDEV */
#define DCOLON   2	/* BUTTON in tree LOGDEV */
#define ECOLON   4	/* BUTTON in tree LOGDEV */
#define FCOLON   5	/* BUTTON in tree LOGDEV */
#define GCOLON   6	/* BUTTON in tree LOGDEV */
#define HCOLON   7	/* BUTTON in tree LOGDEV */
#define ICOLON   8	/* BUTTON in tree LOGDEV */
#define JCOLON   9	/* BUTTON in tree LOGDEV */
#define KCOLON   10	/* BUTTON in tree LOGDEV */
#define LCOLON   11	/* BUTTON in tree LOGDEV */
#define MCOLON   12	/* BUTTON in tree LOGDEV */
#define NCOLON   13	/* BUTTON in tree LOGDEV */
#define OCOLON   14	/* BUTTON in tree LOGDEV */
#define PCOLON   15	/* BUTTON in tree LOGDEV */
#define LOGOK    16	/* BUTTON in tree LOGDEV */
#define LOGCN    17	/* BUTTON in tree LOGDEV */

#define PICKPART 4	/* form/dialog */
#define PPART15  1	/* BUTTON in tree PICKPART */
#define PPART0   3	/* BUTTON in tree PICKPART */
#define PPOK     4	/* BUTTON in tree PICKPART */
#define PPCN     5	/* BUTTON in tree PICKPART */
#define PPART1   6	/* BUTTON in tree PICKPART */
#define PPART2   7	/* BUTTON in tree PICKPART */
#define PPART3   8	/* BUTTON in tree PICKPART */
#define PPART4   9	/* BUTTON in tree PICKPART */
#define PPART5   10	/* BUTTON in tree PICKPART */
#define PPART6   11	/* BUTTON in tree PICKPART */
#define PPART7   12	/* BUTTON in tree PICKPART */
#define PPART8   13	/* BUTTON in tree PICKPART */
#define PPART9   14	/* BUTTON in tree PICKPART */
#define PPART10  15	/* BUTTON in tree PICKPART */
#define PPART11  16	/* BUTTON in tree PICKPART */
#define PPART12  17	/* BUTTON in tree PICKPART */
#define PPART13  18	/* BUTTON in tree PICKPART */
#define PPART14  19	/* BUTTON in tree PICKPART */
#define PPEDIT   20	/* BUTTON in tree PICKPART */

#define ZWARNING 5	/* form/dialog */
#define ZWCN     1	/* BUTTON in tree ZWARNING */
#define ZWOK     5	/* BUTTON in tree ZWARNING */

#define FMTPART  6	/* form/dialog */
#define PFMT15   1	/* BUTTON in tree FMTPART */
#define PFMT0    3	/* BUTTON in tree FMTPART */
#define PFOK     4	/* BUTTON in tree FMTPART */
#define PFCN     5	/* BUTTON in tree FMTPART */
#define PFMT1    6	/* BUTTON in tree FMTPART */
#define PFMT2    7	/* BUTTON in tree FMTPART */
#define PFMT3    8	/* BUTTON in tree FMTPART */
#define PFMT4    9	/* BUTTON in tree FMTPART */
#define PFMT5    10	/* BUTTON in tree FMTPART */
#define PFMT6    11	/* BUTTON in tree FMTPART */
#define PFMT7    12	/* BUTTON in tree FMTPART */
#define PFMT8    13	/* BUTTON in tree FMTPART */
#define PFMT9    14	/* BUTTON in tree FMTPART */
#define PFMT10   15	/* BUTTON in tree FMTPART */
#define PFMT11   16	/* BUTTON in tree FMTPART */
#define PFMT12   17	/* BUTTON in tree FMTPART */
#define PFMT13   18	/* BUTTON in tree FMTPART */
#define PFMT14   19	/* BUTTON in tree FMTPART */

#define FWARNING 7	/* form/dialog */
#define FWARNCN  1	/* BUTTON in tree FWARNING */
#define FWARNOK  4	/* BUTTON in tree FWARNING */

#define PWARNING 8	/* form/dialog */
#define PWARNCN  1	/* BUTTON in tree PWARNING */
#define PWARNOK  4	/* BUTTON in tree PWARNING */

#define PARTPNL  9	/* form/dialog */
#define EP0SIZE  2	/* BUTTON in tree PARTPNL */
#define EP0DN    3	/* BOXCHAR in tree PARTPNL */
#define EP0UP    4	/* BOXCHAR in tree PARTPNL */
#define EPLEFT   5	/* BUTTON in tree PARTPNL */
#define EP1SIZE  6	/* BUTTON in tree PARTPNL */
#define EP1DN    7	/* BOXCHAR in tree PARTPNL */
#define EP1UP    8	/* BOXCHAR in tree PARTPNL */
#define EP2SIZE  9	/* BUTTON in tree PARTPNL */
#define EP2DN    10	/* BOXCHAR in tree PARTPNL */
#define EP2UP    11	/* BOXCHAR in tree PARTPNL */
#define EP3SIZE  12	/* BUTTON in tree PARTPNL */
#define EP3DN    13	/* BOXCHAR in tree PARTPNL */
#define EP3UP    14	/* BOXCHAR in tree PARTPNL */
#define EPMENU   15	/* BUTTON in tree PARTPNL */
#define EPRESET  16	/* BUTTON in tree PARTPNL */
#define EPCN     17	/* BUTTON in tree PARTPNL */
#define EPOK     18	/* BUTTON in tree PARTPNL */

