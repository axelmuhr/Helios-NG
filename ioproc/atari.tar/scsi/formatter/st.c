/* st.c */
/* $Header: st.c,v 1.1 86/05/29 12:12:43 dyer Exp $ */

/*
 * ST specific code
 * and error handling.
 *
 */
#include "defs.h"
#include "part.h"

extern char sbuf[];


/*
 * Throw up an alert box
 * with the given text.
 *
 */
err(s)
char *s;
{
    form_alert(3, s);
    return ERROR;
}


/*
 * Error, concatenate the three strings
 * and throw up an alert box.
 *
 */
errs(s1, s2, s3)
char *s1, *s2, *s3;
{
    strcpy(sbuf, s1);
    strcat(sbuf, s2);
    strcat(sbuf, s3);
    return err(sbuf);
}
