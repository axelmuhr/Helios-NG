/* epart.c */
/* $Header: epart.c,v 1.1 86/05/29 12:12:04 dyer Exp $ */

/*
 * Partition editing and picking.
 *
 */
#include "scsifmt.h"
#include "defs.h"
#include "part.h"
#include "\asm68\obdefs.h"
#include "\asm68\define.h"
#include "\asm68\gemdefs.h"
#include "\asm68\portab.h"
#include "\asm68\osbind.h"


#define	MEGABYTE	2048L		/* 1Mb worth of blocks */


extern long maxpsiz;
extern int wdesk;
extern int hdesk;
extern char partnames[];


/*
 * Global variables these routines communicate with
 *
 */
static PART *pinfo;		/* -> partition block */
static long disksiz;		/* size of disk in blocks */
static WORD formw, formh;
static WORD lx, ly, sx, sy;
static ok2draw;			/* 0: don't draw PARTPNL boxes */


/*
 * Figure out partition information;
 *    return OK if xpinfo[] is filled-in,
 *	     ERROR on [CANCEL] or something.
 *
 */
figpart(dev, xpinfo)
int dev;
PART *xpinfo;
{
    char bs[512];

    pinfo = xpinfo;

    /*
     * Get partition information from disk's root block.
     */
    if (getroot(dev, bs) < 0)
	return err("[3][Root Sector Read Error][CANCEL]");
    gpart(bs, pinfo);
    disksiz = ((RSECT *)(bs + 0x200 - sizeof(RSECT)))->hd_siz;
	for (;;) {
		switch (partpnl()) {
		case EPMENU:			/* chose from menu */
			switch (partmenu()) {
			case PPOK:
				return(OK);	/* [OK] */
			case PPCN:
				return(ERROR);	/* [CANCEL] */
			case PPEDIT:
				break;		/* continue and edit */
			default:
				return(ERROR);	/* [CANCEL] */
			}
			break;
		case EPCN:
			return(ERROR);	/* [CANCEL] */
		case EPOK:
			return(OK);	/* [OK] */
		default:
			return(ERROR);	/* [CANCEL] */
		}
	}
}


int objup[] = {EP0UP, EP1UP, EP2UP, EP3UP };
int objdn[] = {EP0DN, EP1DN, EP2DN, EP3DN };
int objsiz[] = {EP0SIZE, EP1SIZE, EP2SIZE, EP3SIZE };
char *sizstr[5] = {"999.9Mb", "999.9Mb", "999.9Mb", "999.9Mb", "999.9Mb"};


/*
 * Handle PARTPNL partition edit panel;
 *   Return EPMENU if the luser wants the menu again;
 *	    EPCN if the luser CANCEL'ed
 *	    EPOK if the luser wants to use the partition
 *
 */
partpnl()
{
    int i, but;
    OBJECT *p;
    int xrun = 1;
    PART savpart[4];
    char *s, *d;

    ok2draw = 0;
    if (rsrc_gaddr(0, PARTPNL, &p) == 0)
	return corrupt();

    /* save starting parameters */
    s = (char *)pinfo;
    d = (char *)savpart;
    for (i = sizeof(PART) * 4; i--;)
	*d++ = *s++;

    /*
     * Compute box position
     * (and clipping rectangle)
     */
    formw = p[0].ob_width;
    formh = p[0].ob_height;
    sx = wdesk / 2;
    sy = hdesk / 2;
    lx = (wdesk - formw) / 2;
    ly = (hdesk - formh) / 2;
    p[0].ob_x = lx;				/* set form's location */
    p[0].ob_y = ly;

    form_dial(0, sx, sy, 0, 0, lx, ly, formw, formh);	/* draw boxes */
    form_dial(1, sx, sy, 0, 0, lx, ly, formw, formh);

    /*
     * Set form for first display, then throw it up.
     */
    p[EPOK].ob_state = NORMAL;
    p[EPCN].ob_state = NORMAL;
    p[EPMENU].ob_state = NORMAL;
    for (i = -1; i < 4; ++i)
	epadj(0L, i, p);
    objc_draw(p, 0, MAX_DEPTH, 0, 0, wdesk, hdesk);

    /*
     * Edit the thing;
     * canonical event-driven switch().
     */
    ++ok2draw;
    while (xrun) switch ((but = form_do(p, -1)))
    {
	case EPMENU:
	case EPCN:
	case EPOK:	xrun = 0;			/* return */
			break;

	case EPRESET:	d = (char *)pinfo;
			s = (char *)savpart;
			for (i = sizeof(PART) * 4; i--;)
			    *d++ = *s++;
			for (i = -1; i < 4; ++i)
			    epadj(0L, i, p);
			objc_change(p, EPRESET, MAX_DEPTH,
				    0, 0, wdesk, hdesk,
				    NORMAL, 1);
			break;

	case EP0SIZE:	eptoggle(0, p);		break;
	case EP0UP:	epadj(MEGABYTE, 0, p);	break;
	case EP0DN:	epadj(-MEGABYTE, 0, p);	break;

	case EP1SIZE:	eptoggle(1, p);		break;
	case EP1UP:	epadj(MEGABYTE, 1, p);	break;
	case EP1DN:	epadj(-MEGABYTE, 1, p);	break;

	case EP2SIZE:	eptoggle(2, p);		break;
	case EP2UP:	epadj(MEGABYTE, 2, p);	break;
	case EP2DN:	epadj(-MEGABYTE, 2, p);	break;

	case EP3SIZE:	eptoggle(3, p);		break;
	case EP3UP:	epadj(MEGABYTE, 3, p);	break;
	case EP3DN:	epadj(-MEGABYTE, 3, p);	break;
    }


    /*
     * Draw shrinking box and cleanup the screen;
     * return thing that caused our exit.
     */
    form_dial(2, sx, sy, 0, 0, lx, ly, formw, formh);
    form_dial(3, sx, sy, 0, 0, lx-3, ly-3, formw+4, formh+4);

    return but;
}


/*
 * Toggle partition in/out of existence.
 *
 */
eptoggle(n, p)
int n;
OBJECT *p;
{
    /*
     * Toggle existance flag,
     * enforce minimum partition size.
     */
    if (((pinfo[n].p_flg ^= P_EXISTS) & P_EXISTS) && !pinfo[n].p_siz)
	epadj(MEGABYTE, n, p);
        else epadj(0L, n, p);

    epadj(0L, -1, p);			/* update #left field */
}


/*
 * Adjust partition `pno' size by `amt';
 * if `pno' is -1, just recompute and update disk space left indicator.
 *
 * A partition of size zero is disabled.
 *
 */
epadj(amt, pno, p)
long amt;
int pno;
OBJECT *p;
{
    int i;
    long siz;
    long totsiz = 0;

    if (pno < 0) goto fixleft;

    for (i = 0; i < 4; ++i)			/* compute total used */
	if (pinfo[i].p_flg & P_EXISTS)
	    totsiz += pinfo[i].p_siz;

    /*
     * If total partition size exceeds the disk's
     * capacity, reduce `amt' accordingly.
     */
    if (amt >= 0 && totsiz + amt > disksiz)
	amt = disksiz - totsiz;

    if (amt > 0)
    {
	/*
	 * Enforce maximum partition size.
	 */
	siz = disksiz - totsiz;			/* siz = #free */
	if (amt > siz) amt = siz;		/* ensure amt <= siz */
	if (pinfo[pno].p_siz + amt > maxpsiz)	/* ensure partition not */
	    amt = maxpsiz - pinfo[pno].p_siz;	/* too big */

	pinfo[pno].p_siz += amt;		/* bump partition size */
	pinfo[pno].p_flg |= P_EXISTS;
    } else if (amt < 0)
    {
	amt = -amt;
	if (pinfo[pno].p_siz >= amt)		/* reduce partition size */
		pinfo[pno].p_siz -= amt;
	else
		pinfo[pno].p_siz = 0L;
}

    /*
     * Enforce minimum partition size of .5Mb
     */
    if (pinfo[pno].p_siz < 1024L)
	pinfo[pno].p_siz = 0L;

    /*
     * Disable partitions of zero size
     */
    if (!pinfo[pno].p_siz) {
	pinfo[pno].p_flg &= ~P_EXISTS;
}
    /*
     * Redraw the thing;
     * if partition is disabled, shadow it and disable UP/DOWN buttons;
     * otherwise setup the buttons, setup size string, and so on...
     * 
     */
    if (!(pinfo[pno].p_flg & P_EXISTS))
    {
	p[objsiz[pno]].ob_spec = "Unused";
	p[objsiz[pno]].ob_state = NORMAL;
	p[objsiz[pno]].ob_flags = SELECTABLE | TOUCHEXIT;

	p[objup[pno]].ob_state = DISABLED;
	p[objup[pno]].ob_flags = NONE;

	p[objdn[pno]].ob_state = DISABLED;
	p[objdn[pno]].ob_flags = NONE;
    } else {
	stuffamt(pinfo[pno].p_siz, sizstr[pno]);
	p[objsiz[pno]].ob_spec = sizstr[pno];
	p[objsiz[pno]].ob_state = NORMAL;
	p[objsiz[pno]].ob_flags = SELECTABLE | TOUCHEXIT;

	p[objup[pno]].ob_state = NORMAL;
	p[objup[pno]].ob_flags = SELECTABLE | TOUCHEXIT;

	p[objdn[pno]].ob_state = NORMAL;
	p[objdn[pno]].ob_flags = SELECTABLE | TOUCHEXIT;
    }

    if (ok2draw)
    {
	objc_draw(p, objsiz[pno], MAX_DEPTH, 0, 0, wdesk, hdesk);
	objc_draw(p, objup[pno], MAX_DEPTH, 0, 0, wdesk, hdesk);
	objc_draw(p, objdn[pno], 0, MAX_DEPTH, 0, 0, wdesk, hdesk);
    }


fixleft:

    /*
     * Compute and redraw 'space left' indicator.
     */
    siz = disksiz;
    for (i = 0; i < 4; ++i)
	if (pinfo[i].p_flg & P_EXISTS)
	    siz -= pinfo[i].p_siz;
    stuffamt(siz, sizstr[4]);
    p[EPLEFT].ob_spec = sizstr[4];
    if (ok2draw)
	objc_draw(p, EPLEFT, MAX_DEPTH, 0, 0, wdesk, hdesk);
}


/*
 * Atoi `amt', #blocks, into 999.9Mb (or something like that);
 * assumes enough space in `str'.
 *
 */
stuffamt(amt, str)
long amt;
char *str;
{
    long mb, frac;
char *p;
p = str;
    mb = amt / 2048;
    frac = amt - (2048 * mb);
    if (frac / 16)
	frac /= 205;				/* that's MEGABYTE / 10 */
	else frac = 0;
    if (frac < 0) frac = -frac;

    if (mb > 999) mb = 999;
    else if (mb < 0) mb = frac = 0;

    if (mb > 99)
    {
	*str++ = (mb / 100) + '0';
	mb -= 100 * (amt / 100);
    }

    if (mb > 9)
    {
	*str++ = (mb / 10) + '0';
	mb -= 10 * (mb / 10);
    } else *str++ = ' ';

    *str++ = mb + '0';

    if (frac)
    {
	*str++ = '.';
	*str++ = frac + '0';
    }
    *str++ = 'M';
    *str++ = 'b';
    *str++ = '\0';
}


/*
 * Partition button number-to-object translation table.
 */
int ppart[] = {
    PPART0, PPART1, PPART2, PPART3,
    PPART4, PPART5, PPART6, PPART7,
    PPART8, PPART9, PPART10, PPART11,
    PPART12, PPART13, PPART14, PPART15
};


/*
 * Throw up menu of canned partitions;
 *    Return PPOK on [OK],
 *	     PPCN on [CANCEL],
 *	     PPEDIT on [EDIT==>],
 *	     ERROR on some error.
 *
 */
partmenu()
{
    int i, but;
    char *s, *pnam;
    OBJECT *p;

    /* shove partition name text into buttons */
    if (rsrc_gaddr(0, PICKPART, &p) == 0)
	return(corrupt());

    for (i = 0, s = partnames; i < 16 && *s; ++i)
    {
	p[ppart[i]].ob_spec = (long)s;
	p[ppart[i]].ob_state = NORMAL;
	p[ppart[i]].ob_flags = SELECTABLE | RBUTTON;
	while (*s++)
	    ;
    }

    /* rest of buttons are invisible and untouchable */
    for (; i < 16; ++i)
    {
	p[ppart[i]].ob_type = G_IBOX;			/* invisible box */
	p[ppart[i]].ob_spec = 0;			/* no thickness */
	p[ppart[i]].ob_state = DISABLED;		/* nobody home */
	p[ppart[i]].ob_flags = NONE;			/* disabled */
    }

    /* clean up rest of the form and throw it up */
    p[PPOK].ob_state = NORMAL;
    p[PPCN].ob_state = NORMAL;
    p[PPEDIT].ob_state = NORMAL;
    if ((but = execform(p)) == PPCN)
	return(PPCN);

    /* search for partition they picked */
    for (i = 0; i < 16; ++i)
	if (p[ppart[i]].ob_state & SELECTED)
	    break;
    if (i >= 16)
	return(but);		/* nothing changed */

    pnam = p[ppart[i]].ob_spec;

    graf_mouse(HOURGLASS, 0x0L);
    i = wgetent(pnam, "pr");				/* (floppy access) */
    graf_mouse(ARROW, 0x0L);
    if (i != OK)
	return(errs("[3][No such partition as|",	/* "cannot happen" */
		    p[ppart[i]].ob_spec, "][CANCEL]"));

    for (i = 0; i < 4; ++i) {
	fillpart(i, &pinfo[i]);
}
    pinfo[0].p_st = 1L;
    for (i = 1; i < 4; ++i)
	pinfo[i].p_st = pinfo[i-1].p_st + pinfo[i-1].p_siz;

    return(but);
}
