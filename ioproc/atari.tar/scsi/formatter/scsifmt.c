/* scsifmt.c */
/* $Header: scsifmt.c,v 1.1 86/05/29 12:11:08 dyer Exp $ */

/*
 * Perihelion SCSI Hard Disk Installation Utility
 * Copyright 1988 Perhelion Software
 *
 * Associated files
 *	makefile	build control
 *	scsifmt.lod	link SCSIFMT.PRG
 *	scsifmt.rsc	resource file
 *	scsicap		hard disk database (text file)
 *
 *	scsifmt.h	object tree definitions
 *	defs.h		constant definitions
 *	part.h		structure definitions
 *
 *	scsifmt.c	top level, user interface (this file)
 *	epart.c		edit partition sizes
 *	fmt.c		disk formatting
 *	part.c		partition reading/writing
 *	sect.c		sector reading, writing, zeroing
 *	string.c	string functions (matching, concat, ...)
 *	assist.c	markbad(), zero()
 *	wincap.c	hard disk parameter / partition size database
 *	st.c		random ST functions (delay, reboot, ...)
 *
 *----
 * 24-Mar-1986 lmd	Released to software test.
 * 15-Mar-1986 lmd	Hacked up from earlier version by Jim Tittsler.
 *
 */

#include "scsifmt.h"
#include "defs.h"
#include "part.h"
#include "\asm68\obdefs.h"
#include "\asm68\define.h"
#include "\asm68\gemdefs.h"
#include "\asm68\portab.h"
#include "\asm68\osbind.h"

extern int nlogdevs;		/* #logical devs found */
extern LOGMAP logmap[];		/* logical dev map */
extern int livedevs[];		/* live physical dev flag */


#define	RESOURCEFILE	"SCSIFMT.RSC"
#define	MAXPSIZ		((2048*16)-1)		/* 16Mb partition limit */
#define	NAMSIZ		1024
#define WI_KIND		0
#define NO_WINDOW	(-1)
#define	FALSE		0
#define	TRUE		1
#define MIN_WIDTH	(2*gl_wbox)
#define MIN_HEIGHT	(3*gl_hbox)
#define	WWIND		(20*gl_wchar)
#define	HWIND		(5*gl_hchar)

#define	OFF		0
#define	ON		1


int rebootp = 0;	/* 1: must reboot (not return to desktop) */
char sbuf[512];		/* error message buffer */
char partnames[NAMSIZ];	/* partition name buffer */
char devnames[NAMSIZ];	/* device-type name buffer */
long maxpsiz = MAXPSIZ;	/* maximum partition size */

int gl_hchar;		/* height of system font (pixels */
int gl_wchar;		/* width of system font (pixels) */
int gl_wbox;		/* width of box able to hold system font */
int gl_hbox;		/* height of box able to hold system font */

int phys_handle;	/* physical workstation handle */
int handle;		/* virtual workstation handle */
int wi_handle;		/* window handle */
int top_window;		/* handle of topped window */

int xdesk, ydesk, hdesk, wdesk;	/* window X, Y, width, height */
int xold, yold, hold, wold;
int xwork, ywork, hwork, wwork;	/* desktop and work areas */

int msgbuff[8];		/* event message buffer */
int keycode;		/* keycode returned by event-keyboard */
int mx, my;		/* mouse x and y pos. */
int butdown;		/* button state tested for, UP/DOWN */
int ret;		/* dummy return variable */

int hidden;		/* current state of cursor */

int contrl[12];
int intin[128];
int ptsin[128];
int intout[128];
int ptsout[128];	/* storage wasted for idiotic bindings */

int work_in[11];	/* Input to GSX parameter array */
int work_out[57];	/* Output from GSX parameter array */
int pxyarray[10];	/* input point array */

static char *rscorrupt = "[3][Fatal Error!|Corrupt Resource File][EXIT]";

OBJECT *menuobj;	/* -> menu tree */
OBJECT *abtdial;	/* -> about dialouge tree */
int running;		/* 1: continue evnt_multi() loop */


/*
 * Top level;
 * we get control from the desktop.
 *
 */
main()
{
	long nl;
    running = TRUE;
    appl_init();
    phys_handle=graf_handle(&gl_wchar, &gl_hchar, &gl_wbox, &gl_hbox);
    wind_get(0, WF_WORKXYWH, &xdesk, &ydesk, &wdesk, &hdesk);
    open_vwork();
    wi_handle=wind_create(WI_KIND, xdesk, ydesk, wdesk, hdesk);
	i_scsi();
    hidden = FALSE;
    butdown = TRUE;
    if (!rsrc_load(RESOURCEFILE)) {
	graf_mouse(ARROW, 0L);
	errs("[3][Fatal Error!|Resource file ", RESOURCEFILE, "|not found.][EXIT]");
	goto punt;
    }

    /*
     * Get maximum partition size from
     * wincap "@@" entry.
     */
    if (wgetent("Parameters", "@@") == OK)
	if (wgetnum("ms", &maxpsiz) != OK)
	    maxpsiz = MAXPSIZ;

    wallents(partnames, "pr");
    wallents(devnames, "mn");

    graf_mouse(ARROW, 0L);

    /* display menu bar */
    if (rsrc_gaddr(0, MENUBAR, &menuobj) == 0)
	corrupt();

    menu_bar(menuobj, 1);

    rescan();

	while (running)
		domulti();
    /*
     * If nothing has been done to the hard disks
     * then just get out, back to the desktop.
     * Otherwise reboot the system.
     */
punt:
    menu_bar(menuobj, 0);		/* erase menu bar */

    /*
     * If we have to reboot,
     * tell the user and then do it.
     *
     */
    if (rebootp)
    {
	form_alert(1, "[1][The system will reboot;|This is normal.][OK]");
	reboot();
    }

    wind_delete(wi_handle);
    v_clsvwk(handle);
    appl_exit();
}


/*
 * Get a single event, process it, and return.
 *
 */
VOID domulti()
{
    int event;

    event = evnt_multi(MU_MESAG,
			1,1,butdown,
			0,0,0,0,0,
			0,0,0,0,0,
			msgbuff,0,0,&mx,&my,&ret,&ret,&keycode,&ret);

    if (event & MU_MESAG)
	switch (msgbuff[0])
	{
	    case WM_REDRAW:
		do_redraw(msgbuff[4],msgbuff[5],msgbuff[6],msgbuff[7]);
		break;

	    case WM_NEWTOP:
	    case WM_TOPPED:
		wind_set(wi_handle, WF_TOP, 0, 0, 0, 0);
		break;

	    case WM_CLOSED:
		running = FALSE;
		break;

	    case MN_SELECTED:
		switch(msgbuff[3])
		{
		    case MNDESK:
			if(msgbuff[4] == DEABOUT)
			{
			    if(rsrc_gaddr(0, ABOUT, &abtdial) == 0)
				return corrupt();
			    execform(abtdial);
			    abtdial[ABOK].ob_state &= (0xFFFF ^ SELECTED);
			    break;
			}
			break;		/* "cannot happen" */


		    case MNFILE:
			switch (msgbuff[4])
			{
			    case FIQUIT:
				running = 0;
				break;

			    default:
				break;
			}
			break;


		    case MNDISK:
			switch (msgbuff[4])
			{
			    case DIFORM:
			        dodiform();
				break;
			    case DIPART:
				dodipart(-1, NULL);
				break;
/* chopped out at present */
#ifdef NEVER
			    case DIZERO:
				dodizero();
				break;
			    case DIMARK:
				dodimark();
				break;
#endif
			    default:
				    break;
			}
			break;
		default:
			break;
		}

		menu_tnormal(menuobj, msgbuff[3], 1);	/* back to normal */
		break;

	    default:
		break;
    }
}


/*
 * Default partition name (no "pt" entry).
 */
#define	DEF_20PARTNM	"4-6-10"
#define	DEF_40PARTNM	"A-A-A-A"
#define	DEF_80PARTNM	"F-F-F-F"

/*
 * Map from button in format dial.
 */
int pfmt[] = {
    PFMT0, PFMT1, PFMT2, PFMT3,
    PFMT4, PFMT5, PFMT6, PFMT7,
    PFMT8, PFMT9, PFMT10, PFMT11,
    PFMT12, PFMT13, PFMT14, PFMT15
};


/*
 * Handle [FORMAT] item.
 *
 */
dodiform()
{
	extern char bootstop;
	extern char bootend;
	int dev, v, i;
	long cnt;
	long ostack;		/* USP store during SUPER actions */
	char *s, *d, *wgetstr();
	char bs[512];
	char pnam[128];
	char *sdev = "X";
	HINFO hinfo;
	OBJECT *fmtpart;
	OBJECT *warn_dial;
  /*
   * Throw up generic formatting/partition warning,
   * then get physical dev they want to clobber.
   */
	if (rsrc_gaddr(0, FWARNING, &warn_dial) == 0)
		return corrupt();
	warn_dial[FWARNCN].ob_state = NORMAL;
	warn_dial[FWARNOK].ob_state = NORMAL;
	if (execform(warn_dial) != FWARNOK)
		return;
	if ((dev = gphysdev()) < 0)
		return;
  /*
   * Get default format parameters from root sector (if possible);
   * have user confirm them in a dial box.
   */
	getroot(dev, bs);
	if (gfmtparm(bs, &hinfo) < 0)
		fdefault(&hinfo);
  /*
   * Shove format name text into buttons
   */
	if (rsrc_gaddr(0, FMTPART, &fmtpart) == 0)
		return(corrupt());
	for (i = 0, s = devnames; i < 16 && *s; ++i) {
		fmtpart[pfmt[i]].ob_spec = (long)s;
		fmtpart[pfmt[i]].ob_state = NORMAL;
		fmtpart[pfmt[i]].ob_flags = SELECTABLE | RBUTTON;
		while (*s++)
			;
	}
  /* rest of buttons are invisible and untouchable */
	for (; i < 16; ++i) {
		fmtpart[pfmt[i]].ob_type = G_IBOX;		/* invisible box */
		fmtpart[pfmt[i]].ob_spec = 0;			/* no thickness */
		fmtpart[pfmt[i]].ob_state = DISABLED;		/* nobody home */
		fmtpart[pfmt[i]].ob_flags = NONE;		/* disabled */
	}
  /* clean up rest of the form and throw it up */
	fmtpart[PFOK].ob_state = NORMAL;
	fmtpart[PFCN].ob_state = NORMAL;
	if (execform(fmtpart) != PFOK)
		return;
  /* search for format they picked */
	for (i = 0; i < 16; ++i)
		if (fmtpart[pfmt[i]].ob_state & SELECTED)
			break;
	if (i >= 16)
		return;				/* nothing picked */
	if (gfparm(&hinfo, fmtpart[pfmt[i]].ob_spec) != 0)
		return;
  /*
   * Make a copy of the default partition name.
   */
	if ((s = wgetstr("pt")) == NULL)
	{
/* just default to 20mb part. data at the moment

		if(hinfo.hi_gensize >= 80*1024L)
			s = DEF_20PARTNM;
		else if (hinfo.hi_gensize >= 40*1024L)
			s = DEF_40PARTNM;
		else
*/
			s = DEF_20PARTNM;
	}
	strcpy(pnam, s);
  /*
   * One last chance to bail out.
   */
	strcpy(sbuf, "[1][Last chance to quit:|Do you REALLY want to format|\Hard disk unit number ");
	*sdev = dev + '0';
 	strcat(sbuf, sdev);
	strcat(sbuf, "|and erase everthing on it?][Yes|No!]");
	if (form_alert(2, sbuf) != 1)
		return;
	graf_mouse(HOURGLASS, 0L);    
  /*
   * In supervisor mode
   * set disk format parameters
   * and format the disk.
   */
	v = mode_select(dev, &hinfo, i);		/* mode set */
	if (v && ((v >> 8) != SCSI_CHECK || (v & 0xff)))
		return(repscsi("MODE_SELECT", v));
	v = format(dev, (WORD)hinfo.hi_in);	/* format */
	if (v && ((v >> 8) != SCSI_CHECK || (v & 0xff)))
		return(repscsi("FORMAT", v));
	graf_mouse(ARROW, 0L);
	rebootp = 1;
  /*
   * Install format parameters and boot-stopper in sector image;
   * write root sector to device.
   */
	sfmtparm(bs, &hinfo);		/* set soft format parms */
	for (d = bs, s = &bootstop, cnt = (long)(&bootend - &bootstop); --cnt;)
		*d++ = *s++;
	Protobt(bs, -1L, -1, 1);
	if (putroot(dev, bs) == ERROR) {
		rescan();
		return(ERROR);
	}
  /* 
   * Partition the device (using the default partition)
   */
	rescan();
	dodipart(dev, pnam);
	rescan();
	return(OK);
}

/*
 * Handle [PARTITION] item;
 * if `xdev' is -1, throw up dialog boxes;
 * if `xdev' >= 0, just partition the dev,
 * using `pnam' as the partition type.
 *
 */
dodipart(xdev, pnam)
int xdev;
char *pnam;
{
    int dev, i;
    char *sdev = "X";
    char *s;
    char bs[512];
    PART pinfo[4];
    OBJECT *pickpart;
    OBJECT *warn_dial;

    if (xdev < 0)
    {
	/*
	 * Throw up warning saying that partition is dangerous;
	 * then get physical dev they want to clobber.
	 */
	if (rsrc_gaddr(0, PWARNING, &warn_dial) == 0)
	    return corrupt();
	warn_dial[PWARNCN].ob_state = NORMAL;
	warn_dial[PWARNOK].ob_state = NORMAL;
	if (execform(warn_dial) != PWARNOK)
		return;
	if ((dev = gphysdev()) < 0)
		return;
	/*
	 * Let the user edit/pick partitions.
	 */
	if (figpart(dev, pinfo) != OK)
	    return;
    } else {
	if (wgetent(pnam, "pr") != OK)
	    return errs("[3][No such partition as|", pnam, "][CANCEL]");

	dev = xdev;
	for (i = 0; i < 4; ++i)
	    fillpart(i, &pinfo[i]);
	pinfo[0].p_st = 1L;
	for (i = 1; i < 4; ++i)
		pinfo[i].p_st = pinfo[i-1].p_st + pinfo[i-1].p_siz;
    }

    strcpy(sbuf, "[1][Last chance to quit:|Do you REALLY want to|partition unit ");
    *sdev = dev + '0';
    strcat(sbuf, sdev);
    strcat(sbuf, " and|erase everthing on it?][Yes|NO!]");

    if (xdev < 0 && form_alert(2, sbuf) != 1)
	return;

    /*
     * Shove partition parms into root sector.
     */
    if (getroot(dev, bs) < 0)
	return parterr(dev);

    graf_mouse(HOURGLASS, 0L);
    spart(bs, &pinfo[0]);
    putroot(dev, bs);
    rescan();
    rebootp = 1;
    i = dopart(dev, pinfo);
    graf_mouse(ARROW, 0L);
    if (i < 0)
		return parterr(dev);

    return OK;
}



/*
 * Handle [ZERO] item.
 *
 */
dodizero()
{
    int ldev;
    OBJECT *warn_dial;
    char *sdev = "X";

    if (rsrc_gaddr(0, ZWARNING, &warn_dial) == 0)
	return corrupt();

    warn_dial[ZWOK].ob_state = NORMAL;
    warn_dial[ZWCN].ob_state = NORMAL;
    if (execform(warn_dial) != ZWOK)
	return;

    if ((ldev = glogdev()) < 0) return;

    strcpy(sbuf, "[1][Last chance to quit:|Do you REALLY want to zero|drive ");
    *sdev = ldev;
    strcat(sbuf, sdev);
    strcat(sbuf, ": and erase everything|on it?][Yes|NO!]");

    if (form_alert(2, sbuf) != 1)
	return;

    zero(ldev);
}


/*
 * Handle [MARKBAD] item.
 *
 */
dodimark()
{
    int ldev;
    char *sdev = "X";

    if ((ldev = glogdev()) < 0) return;

    strcpy(sbuf, "[1][Markbad may destroy files|on ");
    *sdev = ldev;
    strcat(sbuf, sdev);
    strcat(sbuf, ": -- are you sure you|want to risk it?][Yes|NO!]");

    if (form_alert(2, sbuf) != 1)
	return;

    graf_mouse(HOURGLASS, 0L);    
    markbad(ldev);
    graf_mouse(ARROW, 0L);    
}


/*
 * Warn that partitioning or formatting will
 * blow away ALL information on the drive.
 *
 */
warning()
{
}


/*
 * Translate unit number to tree index.
 *
 */
static int physxlat[] = {
    UNIT0, UNIT1, UNIT2, UNIT3,
    UNIT4, UNIT5, UNIT6, UNIT7
};


/*
 * Get physical device#,
 * return devno or -1.
 *
 */
gphysdev()
{
    int i, flg;
    OBJECT *physdial;

    if (rsrc_gaddr(0, PHYSDEV, &physdial) == 0)
	return corrupt();

    /*
     * Clean up and exec object;
     * shadow devs we KNOW are there.
     */
    physdial[PHYSOK].ob_state = NORMAL;
    physdial[PHYSCN].ob_state = NORMAL;
    for (i = 0; i < MAXPHYSDEVS; ++i)
	physdial[physxlat[i]].ob_state = NORMAL;
    for (i = 0; i < MAXPHYSDEVS; ++i)
	if (livedevs[i])
	    physdial[physxlat[i]].ob_state |= SHADOWED;

    if (execform(physdial) != PHYSOK)
	return ERROR;

    /* search for selected unit */
    for (i = 0; i < MAXPHYSDEVS; ++i)
	if (physdial[physxlat[i]].ob_state & SELECTED)
	    return i;

    return -1;			/* if no object selected */
}


/*
 * Translate from logical device number
 * to object number in logical device
 * dialouge box.
 */
int logxlat[] = {
	CCOLON, DCOLON, ECOLON, FCOLON,
	GCOLON, HCOLON, ICOLON, JCOLON,
	KCOLON, LCOLON, MCOLON, NCOLON,
	OCOLON, PCOLON
};


/*
 * Get logical device,
 * return 'C'...'P'
 * or -1.
 *
 */
glogdev()
{
    int i, flg;
    OBJECT *logdial;

    if (rsrc_gaddr(0, LOGDEV, &logdial) == 0)
	return corrupt();

    /*
     * Setup tree; selectively enable drive buttons
     * and so on.
     */
    logdial[LOGOK].ob_state = NORMAL;
    logdial[LOGCN].ob_state = NORMAL;
    for (i = 0; i < MAXLOGDEVS; ++i)
    {
	if (logmap[i].lm_physdev < 0)
	    flg = DISABLED;
	    else flg = NORMAL;
	logdial[logxlat[i]].ob_state = flg;
    }

    if (execform(logdial) != LOGOK) return -1;

    for (i = 0; i < MAXLOGDEVS; ++i)
	if (logdial[logxlat[i]].ob_state & SELECTED)
	    return i + 'C';

    return -1;
}


/*
 * Open virtual workstation.
 *
 */
open_vwork()
{
    int i;

    for (i = 0; i < 19;)
	work_in[i++] = 1;
    work_in[i] = 2;
    handle = phys_handle;
    v_opnvwk(work_in, &handle, work_out);
}


/*
 * Find and redraw all clipping rectangles
 *
 */
do_redraw(xc, yc, wc, hc)
int xc, yc, wc, hc;
{
    GRECT t1, t2;
    int temp[4];

    wind_update(TRUE);
    hide_mouse();
    t2.g_x=xc;
    t2.g_y=yc;
    t2.g_w=wc;
    t2.g_h=hc;
    vsf_interior(handle, 1);
    vsf_color(handle, 0);
    wind_get(wi_handle, WF_FIRSTXYWH, &t1.g_x, &t1.g_y, &t1.g_w, &t1.g_h);
    while (t1.g_w && t1.g_h)
    {
	if (rc_intersect(&t2, &t1))
	{
	    set_clip(t1.g_x, t1.g_y, t1.g_w, t1.g_h);
	    temp[0] = xwork;
	    temp[1] = ywork;
	    temp[2] = xwork + wwork - 1;
	    temp[3] = ywork + hwork - 1;
	    v_bar(handle, temp);
	}
	wind_get(wi_handle, WF_NEXTXYWH, &t1.g_x, &t1.g_y, &t1.g_w, &t1.g_h);
    }

    show_mouse();
    wind_update(FALSE);
}


/*
 * Hide the mouse.
 *
 */
hide_mouse()
{
    if (!hidden)
    {
	graf_mouse(M_OFF, 0L);
	hidden = TRUE;
    }
}


/*
 * Show the mouse.
 *
 */
show_mouse() 
{
    if (hidden)
    {
	graf_mouse(M_ON, 0L);
	hidden = FALSE;
    }
}


/*
 * Set clipping rectangle.
 *
 */
set_clip(x, y, w, h)
int x, y, w, h;
{
    int clip[4];

    clip[0] = x;
    clip[1] = y;
    clip[2] = x + w;
    clip[3] = y + h;
    vs_clip(handle, 1, clip);
}


/*
 * Open a window.
 *
 */
open_window()
{
    int temp[4];

    graf_growbox(xdesk+wdesk/2,
		 ydesk+hdesk/2,
		 gl_wbox, gl_hbox,
		 xdesk+wdesk/2-(WWIND/2), ydesk+hdesk/2-(HWIND/2),
		 WWIND, HWIND);

    wind_open(wi_handle,
	      xdesk+wdesk/2-(WWIND/2), ydesk+hdesk/2-(HWIND/2),
	      WWIND, HWIND);

    wind_get(wi_handle, WF_WORKXYWH,
	     &xwork, &ywork, &wwork, &hwork);
    vsf_interior(handle, 1);
    vsf_color(handle, 0);
    temp[0] = xwork;
    temp[1] = ywork;
    temp[2] = xwork+wwork-1;
    temp[3] = ywork+hwork-1;
    v_bar(handle, temp);
}


/*
 * "Execute" form,
 * return thingy that caused the exit.
 *
 */
execform(tree)
OBJECT tree[];
{
    int thingy;
    WORD formw, formh;
    WORD lx, ly, sx, sy; 

    formw = tree[0].ob_width;
    formh = tree[0].ob_height;

    sx = wdesk / 2;
    sy = hdesk / 2;
    lx = (wdesk - formw) / 2;
    ly = (hdesk - formh) / 2;

    tree[0].ob_x = lx;				/* set form's location */
    tree[0].ob_y = ly;

    form_dial(0, sx, sy, 0, 0, lx, ly, formw, formh);
    form_dial(1, sx, sy, 0, 0, lx, ly, formw, formh);
    objc_draw(tree, 0, MAX_DEPTH, 0, 0, wdesk, hdesk);
    thingy = form_do(tree, 0);
    form_dial(2, sx, sy, 0, 0, lx, ly, formw, formh);
    form_dial(3, sx, sy, 0, 0, lx-3, ly-3, formw+4, formh+4);
    return thingy;
}


/*
 * Complain about corrupt resource file
 * and setup to return to the desktop.
 *
 */
corrupt()
{
    form_alert(1, rscorrupt);			/* complain */
    running = FALSE;				/* stop multi calls */
    return ERROR;				/* bubble up complaint */
}
