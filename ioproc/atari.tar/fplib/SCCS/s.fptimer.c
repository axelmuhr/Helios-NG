h56625
s 00078/00000/00000
d D 2.1 88/10/26 18:40:29 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
#include <time.h>

double dpop(),pop();
void dup(),add(),sub(),mul(),div(),neg(),dneg(),push(),dpush();
void mulalot(),divalot(),addalot(),subalot();

int cmp(),dcmp();


main()
{
   long count;
   time_t time1,time2;
   double result;

   printf("\n\nTime taken for 10,000,000 single precision f/p multiplications.");
   printf("\n		(only two message sends to transputer)\n\n\n");

/* first the hardware implementation */

   time(&time1);
   push( 123.00013456 );	/* could have chosen any number though! */
   push( -456.123456789 );	/* could have chosen any number */
   mulalot();
   result=pop();
   time(&time2);
   printf("Result returned by transputer: %.12f\n",result);
   printf("Time for 10,000,000 transputer multiplications = %U\n",time2-time1);



   printf("\n\nTime taken for 10,000,000 single precision f/p divisions.");
   printf("\n		(only two message sends to transputer)\n\n\n");

/* first the hardware implementation */

   time(&time1);
   push( 123.00013456 );	/* could have chosen any number though! */
   push( 56.123456789 );	/* could have chosen any number */
   divalot();
   result=pop();
   time(&time2);
   printf("Result returned by transputer: %.12f\n",result);
   printf("Time for 10,000,000 transputer divisions = %U\n",time2-time1);



   printf("\n\nTime taken for 10,000,000 single precision f/p additions.");
   printf("\n		(only two message sends to transputer)\n\n\n");

/* first the hardware implementation */

   time(&time1);
   push( 123.00013456 );	/* could have chosen any number though! */
   push( -456.123456789 );	/* could have chosen any number */
   addalot();
   result=pop();
   time(&time2);
   printf("Result returned by transputer: %.12f\n",result);
   printf("Time for 10,000,000 transputer additions = %U\n",time2-time1);



   printf("\n\nTime taken for 10,000,000 single precision f/p subtractions.");
   printf("\n		(only two message sends to transputer)\n\n\n");

/* first the hardware implementation */

   time(&time1);
   push( 123.00013456 );	/* could have chosen any number though! */
   push( 56.123456789 );	/* could have chosen any number */
   subalot();
   result=pop();
   time(&time2);
   printf("Result returned by transputer: %.12f\n",result);
   printf("Time for 10,000,000 transputer subtractions = %U\n",time2-time1);

}
E 1
