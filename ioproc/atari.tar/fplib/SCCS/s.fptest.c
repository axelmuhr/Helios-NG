h63587
s 00145/00000/00000
d D 2.1 88/10/26 18:40:27 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/****************************************************************************
*
* Demonstration of floating point operations.
*
* A.Evans, 03 September 1987.
*
* Copyright (c) 1987, Perihelion Software Ltd. All rights reserved.
*
*****************************************************************************/


double pop(),dpop();
void dpush(),push(),dup(),add(),sub(),mul(),div(),neg(),dneg();
long cmp(),dcmp();


main()
{ 

   printf("***** Single precision *****\n");

   push( 231.0002 );
   push( 20.0001 );
   push( -3410935.022 );
   printf("Three pushes followed three pops\n");
   printf("		-3410935.022 expected, %f obtained\n",pop());
   printf("		     20.0001 expected, %f obtained\n",pop());
   printf("	    	    231.0002 expected, %f obtained\n",pop());

   push( -234567.00000234 );
   push( 4567891.02034905 );
   add();
   printf("\nAddition of two numbers:  ");
   printf("4333324.02(?) expected, %f obtained\n",pop());

   push( 234.0023 );
   push( 0.0002345 );
   sub();
   printf("\nSubtraction:  ");
   printf("234.0020655 expected, %f obtained\n",pop());

   push( 21.0134 );
   push( -1.0005 );
   mul();
   printf("\nMultiplication:  ");
   printf("-21.0239067 expected, %f obtained\n",pop());

   push( 911.0345 );
   push( 32.01 );
   div();
   printf("\nDivision:  ");
   printf("28.46093408 expected, %f obtained\n",pop());

   push( 123.9872 );
   dup();
   dup();
   printf("\nTwo applications of DUP():  \n");
   printf("3 x 123.9872 expected, %f, %f, %f obtained\n",pop(),pop(),pop());

   push( -124.023 );
   dup();
   neg();
   printf("\nNegation:  ");
   printf("%f is negative of %f\n",pop(),pop());

   push( 110.001 );
   push( 89.01234 );
   printf("\nCompare:  ");
   printf("110.001 is greater than 89.01234  gives %lx\n",cmp());

   push(0.01);
   push(120.987);
   printf("\nCompare:  ");
   printf("0.01 is less than 120.987   gives %lx\n",cmp());

   push(120.5675);
   push(120.5675);
   printf("\nCompare:  ");
   printf("120.5675 is same as 120.5675  gives %lx\n",cmp());

   while(getchar()!='\n');

   printf("***** Double precision *****\n");

   dpush( 231.0002 );
   dpush( 20.0001 );
   dpush( -3410935.022 );
   printf("Three dpushes followed three dpops\n");
   printf("	-3410935.022 expected, %.12f obtained\n",dpop());
   printf("	     20.0001 expected, %.12f obtained\n",dpop());
   printf("	    231.0002 expected, %.12f obtained\n",dpop());

   dpush( -234567.01234 );
   dpush( 478.093 );
   add();
   printf("\nAddition of two numbers:  ");
   printf("-234088.9193(?) expected, %.12f obtained\n",dpop());

   dpush( 234.0023 );
   dpush( 0.0002345 );
   sub();
   printf("\nSubtraction:  ");
   printf("234.0020655 expected, %.12f obtained\n",dpop());

   dpush( 21.0134 );
   dpush( -1.0005 );
   mul();
   printf("\nMultiplication:  ");
   printf("-21.0239067 expected, %.12f obtained\n",dpop());

   dpush( 911.0345 );
   dpush( 32.01 );
   div();
   printf("\nDivision:  ");
   printf("28.46093408 expected, %.12f obtained\n",dpop());

   dpush( 123.9872 );
   dup();
   dup();
   printf("\nTwo applications of DUP():\n");
   printf("3 x 123.9872 expected, %.12f, %.12f, %.12f obtained\n",dpop(),dpop(),dpop());

   dpush( -124.023 );
   dup();
   dneg();
   printf("\nNegation:  ");
   printf("%.12f is negative of %.12f\n",dpop(),dpop());

   dpush( 110.001 );
   dpush( 89.01234 );
   printf("\nCompare:  ");
   printf("110.001 is greater than 89.01234  gives %lx\n",dcmp());

   dpush(0.01);
   dpush(120.987);
   printf("\nCompare:  ");
   printf("0.01 is less than 120.987   gives %lx\n",dcmp());

   dpush(120.5675);
   dpush(120.5675);
   printf("\nCompare:  ");
   printf("120.5675 is same as 120.5675  gives %lx\n",dcmp());

   while(getchar()!='\n');
}
E 1
