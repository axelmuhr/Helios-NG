h60451
s 00148/00000/00000
d D 2.1 88/10/26 18:38:18 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/******************************************************************************
*
*  TDS Server  Global Constant Definitions
*
*  13th February 1987.
*
*  Copyright INMOS Limited, 1987.
*
******************************************************************************/
/* MODIFIED : C.H.R.G  2/10/87                                               */
/*            Ported to ATARI ST with PERIHELION Transputer interface card   */
/*****************************************************************************/


#define TRUE 1
#define FALSE 0

#define BIT_0  1


#define BREAKOUT  TRUE
#define REV_A_FIX TRUE

/* ASCII values */
#define NULL                   0
#define SOH                    1
#define CONTROL_D              4
#define BELL                   7
#define BS                     8
#define HT                     9
#define LF                     10
#define VT                     11
#define FF                     12
#define CR                     13
#define CONTROL_Y              25
#define ESCAPE                 27
#define RS                     30
#define SPACE                  32

/* Terminate codes */
#define T_TERMINATED          0
#define T_USR_BRK             3
#define T_USR_STOP            7
#define T_TRANSPUTER_ERR      8
#define T_BAD_BOOT            9
#define T_ILLEGAL_COMMAND     15
#define T_BAD_COMMAND_LINE    16
#define T_BAD_RECORD          17
#define T_BAD_INT32           18

/* Key values */
#define EXIT_KEY              ESCAPE
#define REBOOT_KEY            SPACE
#define RECORD_LENGTH         512
#define N_STREAMS             8
#define PARAM_STREAM          N_STREAMS + 1
#define INVALID_STREAM        -1
#define FILE_NAME_LENGTH      64
#define COMMAND_LINE_LENGTH   128
#define DEFAULT_BOOT_FILE     "c:\boot.b4"

#define S_INPUT 1
#define S_OUTPUT 2

#define PERMANENT 0
#define TEMPORARY 1
#define SPECIAL 2

#define HOST_ERROR_BASE        -400
#define INT32_VALUE      4
#define NILRECORD_VALUE  8
#define RECORD32_VALUE  12
#define ALIENTERMINATE_CMD 0
#define OPENFILE_CMD 1
#define OPENTEMP_CMD 2
#define OPENINPUTSTREAM_CMD 3
#define OPENOUTPUTSTREAM_CMD 4
#define STREAMACCESS_CMD 5
#define STREAMSTATUS_CMD 6
#define STREAMFILE_CMD 7
#define STREAMLENGTH_CMD 8
#define CLOSESTREAM_CMD 11
#define READBLOCK_CMD 12
#define WRITEBLOCK_CMD 13
#define SEEK_CMD 14
#define STREAMCONNECT_CMD 23
#define TERMINATE_CMD 24
#define SETRESULT_CMD 25
#define RUNCOMMAND_CMD 26
#define RENAMEFILE_CMD 27
#define READTIME_CMD 28
#define READKEY_CMD 29
#define RECIEVEBLOCK_CMD 30
#define SENDBLOCK_CMD 31
#define CALLINTERRUPT_CMD 32
#define READREGS_CMD 33
#define BINARYBYTESTREAM_ACCESS 0
#define TEXTBYTESTREAM_ACCESS 1
#define MAX_ACCESS_METHOD 1
#define READ_MODE 0
#define WRITE_MODE 1
#define UPDATE_MODE 2
#define MAX_OPEN_MODE 2
#define OLD_FILE 0
#define NEW_FILE 1
#define MAX_EXIST_MODE 1
#define SCREEN_USE 0
#define KEYBOARD_USE 1
#define FILE_USE 2
#define TEMP_USE 3
#define PARAMETER_USE 4
#define CLOSE_OPTION 0
#define CLOSEDEL_OPTION 1
#define MAX_CLOSE_OPTION 1
#define F_FILE_EXISTS -300
#define F_OK 0
#define F_EOF 1
#define FILENAMETOOLONG_ERR 2
#define INVALIDACCESSMETHOD_ERR 3
#define INVALIDOPENMODE_ERR 4
#define INVALIDEXISTMODE_ERR 5
#define INVALIDRECORDLENGTH_ERR 6
#define INVALIDSTDSTREAM_ERR 7
#define INVALIDSTREAMID_ERR 8
#define INVALIDCLOSEOPTION_ERR 9
#define NOSEEKPOSSIBLE_ERR 10
#define INVALIDRECORDNUMBER_ERR 11

#define OPERATIONFAILED_ERR 99
#define NOFREECHANNEL_ERR 100
#define NOSUCHFILE_ERR 101
#define FILEALREADYOPENERR 102
#define READOPENFAIL_ERR 103

#define SERVER_PORT 4		/* destination port of task runnin under HELIOS */

struct STREAM_DESC
{
    int inuse;
    FILE *fileptr;
    int open_m;
    int exist_m;
    int access_m;
    int lifetime_m;
    int result;
    char name [FILE_NAME_LENGTH];
};

E 1
