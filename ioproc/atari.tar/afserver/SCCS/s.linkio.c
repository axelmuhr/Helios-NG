h10361
s 00350/00000/00000
d D 2.1 88/10/26 18:38:14 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/******************************************************************************
*
*  TDS Server  INMOS B004 Link Adaptor Driver
*
*  12th March 1987.
*
*  Copyright INMOS Limited, 1987.
*
******************************************************************************/
/* MODIFIED : C.H.R.G   5/10/87                                              */
/*           Ported to ATARI ST with PERIHELION interface board              */
/*****************************************************************************/

#define LINT_ARGS 1;      /* Enable Compiler Parameter Checking */

#include "stdio.h"
#include "srvconst.h"
#include "ttypes.h"
#include <osbind.h>

/* no currently used as reset/analyse not yet available on the board */ 
#define LINK_RESET          16
#define LINK_ERROR          16
#define LINK_ANALYSE        17

#define RESET_COUNT              10000
#define ANALYSE_COUNT            10000
#define MAX_LINK_TIME            32000

char *link_reset;
char *link_error;
char *link_analyse; 


void init_root ()
{
}

int link_in_test ()
/* Return TRUE if a byte is available on the link, FALSE otherwise. */
{
/* this is not possible as the link adapter is not memory mapped */
}


int byte_from_link ()
/* Read a byte from the link adaptor. */
{
WORD val;
    while (!xprdrdy());		/* loop until byte received */
    val = xprdbyte();
    if (Cconis()== -1)
        if (Cconin()==0x03) exit(0); /* allows CTRL-c to terminate */
    return ((int)val);
}

void byte_to_link (ch)
int ch;
/* Write a byte to the link adaptor. */
{
    xpwrbyte((WORD)ch);

}

int byte_to_link_t (ch)
int ch;
/* Write a byte to the link adaptor within a specified time, or timeout.
   Return TRUE if the byte was NOT written, FALSE if the byte was written. */
{
UBYTE temp;
    register int not_written = TRUE, i;
    temp = (UBYTE) ch;
    for (i=0; ((i < MAX_LINK_TIME) && not_written); i++)
        if (xpwrdata((UBYTE *) &temp, (WORD) 1)) {
            not_written = FALSE;
        };
    return (not_written);
}


int error_test ()
/* Test if an error is present in the transputer system. */
{
    return (*link_error);
}


void reset_root ()
/* Reset the root transputer. */
{
/* currently just prompt user to reset */
/*    printf("\n#### RESET TRANSPUTER ####-  press <CR> when ready.");
    while(getchar() != '\n'); */           /* wait for retrun */
/* BLV - xpreset seems reliable enough to do the job now */
    xpreset();                            /* reset xptr & link adaptor */

#ifdef NEVER
    register int i;
    *link_analyse = 0;                  /* deassert analyse */
    *link_reset = 0;                    /* deassert reset   */
    for (i=0; i < RESET_COUNT; i++)     /* wait awhile      */
        ;
    *link_reset = -1;                   /* assert reset     */
    for (i=0; i < RESET_COUNT; i++)     /* wait awhile      */
        ;
    *link_reset = 0;                    /* deassert reset   */
#endif
}


void reset_analyse_root ()
/* Reset the root transputer into analyse mode. */
{
/* currently just prompt user to reset */
    printf("\n#### RESET & ANALYSE TRANSPUTER ####-  press <CR> when ready.");
    while(getchar() != '\n');           /* wait for retrun */
    resetlnk();                         /* reset link adaptor */

#ifdef NEVER
    register int i;
    *link_reset = 0;                    /* deassert reset   */
    *link_analyse = 0;                  /* deassert analyse */
    for (i=0; i < RESET_COUNT; i++)     /* wait awhile      */
        ;
    *link_analyse = -1;                 /* assert analyse   */
    for (i=0; i < ANALYSE_COUNT; i++)   /* wait awhile      */
        ;
    *link_reset = -1;                   /* assert reset     */
    for (i=0; i < RESET_COUNT; i++)     /* wait awhile      */
        ;
    *link_reset = 0;                    /* deassert reset   */
    *link_analyse = 0;                  /* deassert analyse */
#endif
}


int word_from_link ()
/* Read a word from the link. */
/* This routine is host- and transputer- word-length dependent.
   Here we assume a host int length of two bytes, and a transputer int length
   of four bytes.
*/
{
int res;
    while (!xprdrdy());

    res= (int) xprdint();
    if (Cconis()== -1)
        if (Cconin()==0x03) exit(0); /* allows CTRL-c to terminate */
    return (res);
}


void word_to_link (w)
/* Write a word to the link, least significant byte first. */
/* This routine is host- and transputer- word-length dependent.
   Here we assume a host int length of two bytes, and a transputer int length
   of four bytes.
*/
int w;
{
    xpwrint((WORD)w);
}


void slice_from_link (length, slice)
int *length;
char *slice;
/* Read a slice from the link.
   The slice consists of a four-byte length followed by a sequence of bytes. */
{
    register int i, real_len;
    *length = real_len = word_from_link();
#ifdef REV_A_FIX
    if (real_len == 1) real_len = 2;
#endif
    for (i = real_len; i>0; i--)
        *slice++ = byte_from_link();
}


int trunc_slice_from_link (max_length, str)
int max_length;
char *str;
/* Read a slice from the link whose maximum length is max_length.
   If the length read in is longer than this, the remainder of the slice is
   read in, but ignored. Return number of bytes read in. */
{
    int length;
    register int real_len;
    length = real_len = word_from_link();
#ifdef REV_A_FIX
    if (real_len == 1) real_len = 2;
#endif
    if (real_len > max_length)
    {
        register int i;
        for (i = 0; i < max_length; i++)
            *str++ = byte_from_link();
        for (i = max_length; i < real_len; i++)
            byte_from_link();
    } else
    {
        register int i;
        for (i = 0; i < real_len; i++)
            *str++ = byte_from_link();
    };
    return (length);
}


void slice_to_link (length, slice)
int length;
char *slice;
/* Write a slice to the link.
   The slice consists of a four-byte length followed by a sequence of bytes. */
{
    word_to_link (length);
    xpwrdata( slice, (WORD) length );
}


void long_word_to_link (w)
/* Write a long word to the link. */
/* This routine is host- and transputer- word-length dependent.
   Here we assume a host long int length of at least four bytes,
   and a transputer int length of four bytes.
*/
long int w;
{
    register int i;
    for (i = 0; i<4; i++)
    {
        byte_to_link (w & 0xff);
        w >>= 8;
    };
}


long long_word_from_link ()
/* Read a long word from the link. */
/* This routine is host- and transputer- word-length dependent.
   Here we assume a host long int length of at least four bytes,
   and a transputer int length of four bytes.
*/
{
    long int result = 0;
    register int i;
    for (i = 0; i<32; i+= 8)
        result |= (((long) byte_from_link()) << i);
    return (result);
}


void long_slice_to_link (length, slice)
WORD length;
char *slice;
/* Write a slice to the link.
   The slice consists of a four-byte length followed by a sequence of bytes. */
{
    word_to_link (length);
    xpwrdata( slice, length );
}


void long_slice_from_link (length, slice)
long int *length;
char  *slice;
/* Read a slice from the link.
   The slice consists of a four-byte length followed by a sequence of bytes. */
{
    long int i, real_len;
    *length = real_len = long_word_from_link();
#ifdef REV_A_FIX
    if (real_len == 1) real_len = 2;
#endif
    for (i = real_len; i>0; i--)
        *slice++ = byte_from_link();
}


void safe_byte_to_link ( b )
int b;
{
    byte_to_link ( b );
#ifdef REV_A_FIX
    byte_to_link ( b );
#endif
}


int safe_byte_from_link ()
{
    int b, padding;
    b = byte_from_link ();
#ifdef REV_A_FIX
    padding = byte_from_link ();
#endif
    return (b);
}


int boot_root (boot_file_name)
char *boot_file_name;
#define BOOT_BUFFER_LENGTH RECORD_LENGTH
/* Boot the root transputer, ie. reset the root transputer, open the boot file
   and write this down the link adaptor as a stream of bytes. */
{
    int result = FALSE;
    FILE *boot_file;

    if ((boot_file = fopen (boot_file_name, "rb")) != NULL ) {
        register int count = 0;
        char file_buffer [BOOT_BUFFER_LENGTH];
        int do_boot = TRUE;

        while (do_boot)
        {
            count = fread ( file_buffer, sizeof(char), BOOT_BUFFER_LENGTH, boot_file );
            if (count > 0)
            {
                register int i;

                for (i = 0; ((i < count) && do_boot); i++)
                {   
                    do_boot = ! byte_to_link_t ((int) file_buffer[i]);
                }
                if ( ! do_boot )
                    result = OPERATIONFAILED_ERR;
            }
            else
            {
                do_boot = FALSE;
                if feof (boot_file)
                {
                    if (fclose (boot_file) == 0)
                        result = F_OK;
                    else
                        result = OPERATIONFAILED_ERR;
                }
                else
                    result = OPERATIONFAILED_ERR;
            };
        };
    }
    else
        result = OPERATIONFAILED_ERR;
    return (result);
}

E 1
