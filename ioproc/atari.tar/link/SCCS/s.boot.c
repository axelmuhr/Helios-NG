h46046
s 00289/00000/00000
d D 2.1 88/10/26 18:46:07 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
#include <osbind.h>
#include <stdio.h>
#include <ttypes.h>
#include <debug.h>

#define MAXREAD  0xffffL
#define MAXCHUNK 0x1000L

WORD bootsize;
UBYTE *bootstrap;
WORD *ibuf;
WORD isize;

FILE *infd;

WORD *lmalloc();
WORD swap();

WORD xpwrbyte();
WORD xpwrrdy();
WORD xprdrdy();
WORD xpwrword();
WORD xpwrint();
WORD xpwrdata();

WORD xprddata();

WORD dbwrword();
WORD xprdint();
WORD xprdword();
WORD xprdbyte();
WORD dbrdword();
WORD dbrdint();
void resetlnk();
void initmsg();

void timeout();


report(str,a,b,c,d,e,f)
STRING str;
WORD a,b,c,d,e,f;
{
	printf("Report: ");
	printf(str,a,b,c,d,e,f);
	putchar('\n');
}

tload(bootfile,sysfile)
STRING bootfile,sysfile;
{
	infd = NULL;
	if (!loadboot(bootfile)) exit(1);
	if (!loadimage(sysfile)) exit(1);
	xprun();
}

int loadimage(fname)
STRING fname;
{
	WORD l,csize;
	UBYTE *cbuf;
	unsigned int fread();

        infd = fopen(fname,"rb");

        if( infd == NULL ) 
	{ report("Cannot open '%s' for input",fname); return(0); }

	
        if( fread(&isize,1,4,infd) != 4) {
                report("Cannot read image header");
                goto done;
        }

        isize = swap(isize);

/*        report("System size = %ld bytes",isize); */

        ibuf = lmalloc(isize);

        if( ibuf == NULL ) {
                report("Cannot get image buffer");
                goto done;
        }

	csize = isize - 4;
	cbuf  = (UBYTE *)(ibuf  + 1);

	while (csize > 0)
	{ WORD len = csize;
	  if (len > MAXCHUNK) len = MAXCHUNK;
          if( (l = fread(cbuf,1,(int)len,infd)) != len ) {
                report("Image too small, (read %ld)",l);
		}
	  csize -= len;
	  cbuf  = cbuf + len;  /* NB avoids compiler bug */
	}

	ibuf[0] = swap(isize); /* place size back in image */

	fclose( infd );
	infd = NULL;
	return(1);

    done:
        fclose( infd );
        infd = NULL;
	return(0);	/* return error */
}

loadconf()
{
	if (!xpwrint(24L))	/* 6 words in conf vector */
		timeout();
	xpwrint(64L);		/* size of port table */
	xpwrint(1L);		/* incarnation number */
	xpwrint(LoadBase);
	xpwrint(isize);
	xpwrint(1L);		/* just 1 link for now */
	if (!xpwrword(0x40020000L))	/* link conf structure */
		timeout();
}

int loadboot(bootfile)
STRING bootfile;
{
	int s;
	WORD ihdr[3];

        infd = fopen(bootfile,"rb");

        if( infd == NULL ) 
	{ report("Cannot open '%s' for input",bootfile); return(0); }

        if( (s=fread(ihdr,1,12,infd)) != 12) {
                report("Cannot read boot header %d %d",s,ferror(infd));
                goto done;
        }

        if( swap(ihdr[0]) != 0x12345678L )
        {
                report("First word of file not magic number");
                goto done;
        }

        bootsize = swap(ihdr[2]);

        /* report("Boot size = %ld bytes",bootsize); */

        bootstrap = lmalloc(bootsize);

        if( bootstrap == NULL ) {
                report("Cannot get image buffer");
                goto done;
        }

        if( (s=fread(bootstrap,1,(int)bootsize,infd)) != bootsize ) {
                report("Image too small %d %d",s,ferror(infd));
        }

        fclose( infd );
        infd = NULL;
	return(1);

    done:
        fclose( infd );
        infd = NULL;
	return(0);	/* return failure code */
	
}

WORD swap(x)
WORD x;
{
        WORD r = 0;
        r |= ((x>>24)&0xff)<< 0;
        r |= ((x>>16)&0xff)<< 8;
        r |= ((x>> 8)&0xff)<<16;
        r |= ((x>> 0)&0xff)<<24;
	return r;
}

void timeout()
{ report("Timed out");
  exit(1);
}

xprun()
{	UBYTE *cbuf;
	WORD osize = isize;
	WORD len;
	xpreset();
	resetlnk();

	/* report("Installing kernel and trap routines..."); */

	/* report("Sending Bootstrap (%ld bytes) ...",bootsize); */

	if (!xpwrbyte(bootsize))	/* bootstrap size */
		timeout();
        if (!xpwrdata(bootstrap,bootsize))	/* bootstrap */
		timeout();

	/* report("Sending System Image (%ld bytyes) ...",isize); */

	/* we can't send more than 64K at a time */
	cbuf = (UBYTE *)ibuf;
	while (osize>0)
	{ len = osize;
	  if (len > MAXCHUNK) len = MAXCHUNK;
/*	  printf("Sending %ld bytes\n",len); */
	  if (!xpwrdata(cbuf,len))		/* system image */
		timeout();
	  osize -= len;
	  cbuf  = cbuf + len;   /* NB avoids compiler bug */
	}
	  
	/* report("Sending Configuration..."); */
	loadconf();

	helios();
}

helios()
{	
	WORD iocport = 0;
	printf("Booted...\n");
	for(;;)
	{
		if( xprdrdy() )
		{
			WORD b;
			WORD a;

			b = xprdbyte();

			switch( (int) b )
			{
			case 2:
			{
				WORD h,d,r,f;
				WORD dsize;

				h = xprdint();
				d = xprdint();
				r = xprdint();
				f = xprdint();

				if( (dsize=(h & 0x0000ffffL)) != 0 )
				{	WORD ports[3];
					INT i;
					for (i=0;i<3;i++)
					{ ports[i]=xprdint();
/* printf("Port %ld = %lx ",i,ports[i]); */
/*				ports[i] = 0x8000007aL - i * 2; */
					}
					putchar('\n');
					initmsg(ports);
					return;
				}
				printf("Unexpected message received\n");
				break;
			}

			case 0xf0:
				xprdbyte(); 
				xprdbyte(); 
				xprdbyte(); 

				a=xprdword();
				iocport=xprdint();

				if( ( a & 0x0000ff00L ) != 0 )
				{
					xpwrint (0xf0f0f0f0L);
					xpwrword(0x00010000L);
					xpwrint (0x8000AAAAL);
				}
				for (a=0;a<10000;a++);
				break;

			default:
				printf("Unexpected byte %2lx\n",b);
				break;
			}
		}
	}
}
E 1
