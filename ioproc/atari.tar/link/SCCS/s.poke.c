h52541
s 00043/00000/00000
d D 2.1 88/10/26 18:46:20 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
#include <stdio.h>
#include <ttypes.h>

WORD *lmalloc();
WORD swap();

WORD xpwrbyte();
WORD xpwrrdy();
WORD xprdrdy();
WORD xpwrword();
WORD xpwrint();
WORD xpwrdata();

WORD xprddata();

WORD dbwrword();
WORD xprdint();
WORD xprdword();
WORD xprdbyte();
WORD dbrdword();
WORD dbrdint();
void resetlnk();
void initmsg();

main()
{ WORD val;
  xpreset();
  resetlnk();
  /* poke a value to RAM */
  xpwrbyte(0L);
  xpwrint(0x80000048L);
  xpwrint(0xAAAAAAAAL);

  /* now do a peek */
  xpwrbyte(1L);
  xpwrint(0x80000048L);
  if ( (val=xprdint()) != 0xAAAAAAAAL)
     printf("Failed - %lx\n",val);
  else
     printf("OK\n");
}
  

E 1
