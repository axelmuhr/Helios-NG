h60707
s 00043/00000/00000
d D 2.1 88/10/26 18:46:17 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/*************************************************************************
 *
 * messtest.c
 *
 * To read a message from the transputer and display its data on the 
 * ST's screen.
 *
 *************************************************************************/

#include <osbind.h>
#include <sthelios.h>

main()
{
	MsgHdr *message;

	char buffer[500];

	for(;;) {

		message = getmsg(buffer);

		if (message > 0) {

		if (!(message->FnRc==0x22222222L)) {
	  		printf("\ninvalid message, datasize = %8lx FnRc = %lx\n",
				message->DataSize,message->FnRc);
			printf("buffer[0] = %x, buffer[1] = %x\n",
				buffer[0],buffer[1]);
			gemdos(0x7);
		} else {
			int i;
			for (i=0; i<message->DataSize; i++) {
				putchar(buffer[i]);
			}
		}
		}
		else Cconout('!');
		if (Cconis()) break;
	}

	while(getchar() != '\n');
}   
E 1
