h27226
s 00013/00000/00000
d D 2.1 88/10/26 18:46:10 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
#include <stdio.h>
#include <osbind.h>
#include <basepage.h>

/* This loads the transputer message handling traps. It should be
   used once only to set the traps up */

void install(),finish();

void main()
{ install();
  Ptermres( BP->p_hitpa - BP->p_lowtpa, 0);
}
E 1
