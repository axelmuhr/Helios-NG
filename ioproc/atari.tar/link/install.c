#include <stdio.h>
#include <osbind.h>
#include <basepage.h>

/* This loads the transputer message handling traps. It should be
   used once only to set the traps up */

void install(),finish();

void main()
{ install();
  Ptermres( BP->p_hitpa - BP->p_lowtpa, 0);
}
