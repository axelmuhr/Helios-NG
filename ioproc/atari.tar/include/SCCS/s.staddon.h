h37330
s 00097/00000/00000
d D 2.1 88/10/26 18:45:15 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/* some temporary additions to the header files - all this will have to be
   sorted out later */

#define SS_IOproc    0x0a000000L
#define EO_Machine   0x0000800DL
#define EG_Confused  0x000E0000L

/* offsets within the control vector for GSP requests */      
#define Context_off          0   /* offsets in the control vector for all */
#define Pathname_off         1   /* directory requests */
#define Nextname_off         2
#define Cap1_off             3
#define Cap2_off             4
#define cont_minsize         5

#define arg1_off             5  /* additional offsets for directory requests */
#define arg2_off             6
#define arg3_off             7
#define arg4_off             8

#define OpenMode_off         5  /* additional offsets for individual requests */
#define CreateType_off       5
#define CreateRest_off       6
#define RenameToname_off     5
#define LinkPathname_off     5
#define LinkAccess1_off      6
#define LinkAccess2_off      7
#define LinkMatrix_off       8
#define ProtectNewmatrix_off 5
#define RefineNewmatrix_off  5

#define ReadPos_off          0   /* offsets for stream requests */
#define ReadSize_off         1
#define ReadTimeout_off      2
#define WritePos_off         0
#define WriteSize_off        1
#define WriteTimeout_off     2
#define SetFileSizeSize_off  0

#define Reply1_off           0     /* plus offsets for replies */
#define Reply2_off           1
#define Reply3_off           2
#define Reply4_off           3
#define Reply5_off           4
#define Reply6_off           5

#define open_reply           6L    /* size of a reply to open, locate, create */


#define getfnrc(request)   (((request)->MsgHdr).FnRc & FG_Mask)

#define ReqDie             -1L         /* still necessary */
#define ReqOpen            (FG_Open)
#define ReqCreate          (FG_Create)
#define ReqLocate          (FG_Locate)
#define ReqObjectInfo      (FG_ObjectInfo) 
#define ReqServerInfo      (FG_ServerInfo)
#define ReqDelete          (FG_Delete)
#define ReqRename          (FG_Rename)
#define ReqLink            (FG_Link)
#define ReqProtect         (FG_Protect)
#define ReqSetDate         (FG_SetDate)
#define ReqRefine          (FG_Refine)

#define ReqRead            (FG_Read)
#define ReqWrite           (FG_Write)
#define ReqGetSize         (FG_GetSize)
#define ReqSetSize         (FG_SetSize)
#define ReqClose           (FG_Close)

#define ReplyOK            (Err_Null)
#define ReplyOutOfMemory   (EC_Fatal | SS_IOproc | EG_NoMemory | EO_Machine)
#define ReplyPortError     (EC_Error | SS_IOproc | EG_Unknown  | EO_Port)
#define ReplyPortBusy      (EC_Error | SS_IOproc | EG_InUse    | EO_Port)
#define ReplyFnCode        (EC_Error | SS_IOproc | EG_FnCode   | EO_Message)
#define ReplyNotFound      (EC_Error | SS_IOproc | EG_Unknown  | EO_File)
#define ReplyInvalid       (EC_Error | SS_IOproc | EG_Invalid  | EO_Message)
#define ReplyConfused      (EC_Error | SS_IOproc | EG_Confused | EO_Machine)
#define ReplyDirNotEmpty   (EC_Error | SS_IOproc | EG_Delete   | EO_File)
#define ReplyName          (EC_Error | SS_IOproc | EG_Name     | EO_Message)
#define ReplyTimedOut      (EC_Recover | SS_IOproc | EG_Timeout | EO_Stream)

/* data structure returned in response to an object info request. The structure
   is returned in the data vector of the message, with all the words swapped as
   necessary to get them to work on the transputer.
*/
typedef struct Object_Info {
        WORD         type;          /* four fields duplicated in directory */
        WORD         flags;         /* entries */
        WORD         matrix;
        char         name[32];
        WORD         account;       /* accounting identifier */
        WORD         size;          /* object size in bytes */
        time_t       creation;      /* three date stamps */
        time_t       access;
        time_t       modified;
} Object_Info;
E 1
