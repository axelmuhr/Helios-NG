h46674
s 00097/00000/00000
d D 2.1 88/10/26 18:45:24 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/*------------------------------------------------------------------------
--                                                                      --
--                     H E L I O S   N U C L E U S                      --
--                     ---------------------------                      --
--                                                                      --
--             Copyright (C) 1987, Perihelion Software Ltd.             --
--                        All Rights Reserved.                          --
--                                                                      --
-- Helios header used when manipulating messages on a 68000		--
--                                                                      --
--	Author:  NHG 16/8/87						--
--                                                                      --
-- 68000 version TJK 08/10/87						--
------------------------------------------------------------------------*/
/* SccsId: %W%	%G% Copyright (C) 1987, Perihelion Software Ltd.	*/

#ifndef __sthelios_h
#define __sthelios_h

/* standard type definitions */

typedef  long 		WORD    ;       /* a machine word, 32 bits      */
typedef  unsigned long  UWORD   ;       /* a machine word, 32 bits      */
typedef  WORD           INT     ;       /* a synonym                    */
typedef	 WORD		word	;	/* another synonym		*/
typedef  short int	SHORT	;	/* a 16 bit word 		*/
typedef  unsigned short USHORT	;	/* an unsigned 16 bit value	*/
typedef  char           BYTE    ;       /* a byte, used in place of char*/
typedef  BYTE		byte	;	/* a synonym			*/
typedef  unsigned char  UBYTE   ;       /* an unsigned byte             */
typedef  char		*STRING	;       /* character string             */
typedef  char 		*string	; 	/* synonym			*/
typedef  word		bool	;	/* boolean value		*/

typedef  void		(*VoidFnPtr)();	/* pointer to void function	*/
typedef  word		(*WordFnPtr)();	/* pointer to word function	*/

#define PUBLIC				/* an exported symbol		*/
#define PRIVATE		static		/* an unexported symbol		*/
#define FORWARD				/* forward proc reference	*/

/* Syntactic enrichment...						*/

#define forever		for(;;)
#define unless(x)	if(!(x))
#define until(x)	while(!(x))
#define elif(x)		else if(x)

#define TRUE		1l
#define true		1l
#define FALSE		0l
#define false		0l


#define c_dirchar '/'                   /* Helios directory separator */
#define OneSec		1000000L	/* one second in micro-seconds	   */

/* Message port */

typedef word		Port;		/* true structure hidden	*/

#define NullPort	((Port)0)	/* zero is never a valid port	*/


/* Message Header */

typedef struct MsgHdr {
	byte		Flags;		/* flag byte			*/
	byte		ContSize;	/* control vector size		*/
	USHORT		DataSize;	/* 16 bit data size		*/
	Port		Dest;		/* destination port descriptor	*/
	Port		Reply;		/* reply port descriptor	*/
	word		FnRc;		/* function/return code		*/
} MsgHdr;

#define MsgHdr_Flags_nothdr	(1<<7)	/* used by kernel		*/
#define MsgHdr_Flags_preserve	(1<<6)	/* preserve destination route	*/
#define MsgHdr_Flags_exception	(1<<5)	/* exception message		*/
#define MsgHdr_Flags_uselink	(1<<4)	/* receive data from link	*/
#define MsgHdr_Flags_link	0x0F	/* link id			*/

/* Message control block */

typedef struct MCB {
	MsgHdr		MsgHdr;		/* message header buffer	*/
	word		Timeout;	/* message timeout		*/
	word		*Control;	/* pointer to control buffer	*/
	byte		*Data;		/* pointer to data buffer	*/
} MCB;

PUBLIC word   sendmsg();
PUBLIC MsgHdr *getmsg();
PUBLIC word PutMsg();
PUBLIC word GetMsg();
PUBLIC word getports();

#endif
E 1
