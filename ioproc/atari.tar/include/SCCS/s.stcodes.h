h40294
s 00183/00000/00000
d D 2.1 88/10/26 18:45:18 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/*------------------------------------------------------------------------
--                                                                      --
--                     H E L I O S   N U C L E U S                      --
--                     ---------------------------                      --
--                                                                      --
--             Copyright (C) 1987, Perihelion Software Ltd.             --
--                        All Rights Reserved.                          --
--                                                                      --
-- STcodes.h								--
--                                                                      --
--	Error and Function code encoding.				--
--									--
--	Function codes:							--
--	A function code is interpreted as follows			--
--		0 CC SSSSS GGGGGGGGGGGGGGGGGGG FFFF			--
--	where:								--
--	C = function class:						--
--		00 = GSP request					--
--		11 = private protocol					--
--	S = Subsystem identifier, or zero if unknown			--
--	G = General function code					--
--	F = Server specific subfunction					--
--									--
--	Error codes:							--
--	An error code is interpreted as follows:			--
--		1 CC SSSSS GGGGGGGG EEEEEEEEEEEEEEEE			--
--	where:								--
--	C = Error class:						--
--		00 = Recoverable					--
--		11 = Fatal						--
--	S = Subsystem identifier					--
--	G = General error code						--
--	E = Specific error code						--
--                                                                      --
--	Author:  NHG 11/9/87						--
--                                                                      --
--      Moved to Atari: BLV 26/11/87					--
--                                                                      --
------------------------------------------------------------------------*/
/* SccsId: %W%	%G% Copyright (C) 1987, Perihelion Software Ltd.	*/

#ifndef __stcodes_h
#define __stcodes_h

#ifndef __sthelios_h
#include <sthelios.h>
#endif


/*----------------------------------------------------------------
-- 			Subsystems				--
----------------------------------------------------------------*/

#define SS_Mask		0x1f000000L

#define SS_Kernel	0x01000000L
#define SS_SysLib	0x02000000L
#define SS_ProcMan	0x03000000L
#define SS_Loader	0x04000000L
#define SS_ResMan	0x05000000L
#define SS_RamDisk	0x06000000L
#define SS_HardDisk	0x07000000L
#define SS_Fifo		0x08000000L
#define SS_NameTable	0x09000000L

/*----------------------------------------------------------------
-- 			Function Codes				--
----------------------------------------------------------------*/
/*----------------------------------------------------------------
-- Function Classes						--
----------------------------------------------------------------*/

#define FC_Mask		0x60000000L
#define FC_GSP		0x00000000L
#define FC_Private	0x60000000L

/*----------------------------------------------------------------
-- General Functions						--
----------------------------------------------------------------*/

#define FG_Mask		0x00FFFFF0L
#define FG_Shift	4

/* IOC requests */
#define FG_Open		0x00000010L
#define FG_Create	0x00000020L
#define FG_Locate	0x00000030L
#define FG_ObjectInfo	0x00000040L
#define FG_ServerInfo	0x00000050L
#define FG_Delete	0x00000060L
#define FG_Rename	0x00000070L
#define FG_Link		0x00000080L
#define FG_Protect	0x00000090L
#define FG_SetDate	0x000000a0L
#define FG_Refine	0x000000b0L
#define FG_CloseObj	0x000000c0L

/* direct server requests */
#define FG_Read		0x00001010L
#define FG_Write	0x00001020L
#define FG_GetSize	0x00001030L
#define FG_SetSize	0x00001040L
#define FG_Close	0x00001050L
#define FG_Seek		0x00001060L

/* Distributed search codes */
#define FG_Search	0x00002010L

/*----------------------------------------------------------------
-- 			Error Codes				--
----------------------------------------------------------------*/

#define ErrBit		0x80000000L	/* set for all error codes	*/
#define Err_Null	0L		/* no error at all		*/

/*----------------------------------------------------------------
-- Error Classes						--
----------------------------------------------------------------*/

#define EC_Mask		0xe0000000L

#define EC_Recover	ErrBit			/* a retry might succeed */
#define EC_Warn		ErrBit+0x20000000L	/* recover & try again	 */
#define EC_Error	ErrBit+0x40000000L	/* client fatal		 */
#define EC_Fatal	ErrBit+0x60000000L	/* system fatal		 */

/*----------------------------------------------------------------
-- General Error codes						--
----------------------------------------------------------------*/

#define EG_Mask		0x00FF0000L	/* mask to isolate		*/

#define	EG_NoMemory	0x00010000L	/* memory allocation failure	*/
#define EG_Create	0x00020000L	/* failed to create		*/
#define EG_Delete	0x00030000L	/* failed to delete		*/
#define EG_Protected	0x00040000L	/* object is protected		*/
#define EG_Timeout	0x00050000L	/* timeout			*/
#define EG_Unknown	0x00060000L	/* object not found		*/
#define EG_FnCode	0x00070000L	/* unknown function code	*/
#define EG_Name		0x00080000L	/* mal-formed name		*/
#define EG_Invalid	0x00090000L	/* invalid/corrupt object	*/
#define EG_InUse	0x000a0000L	/* object in use/locked		*/
#define EG_Congested	0x000b0000L	/* server/route overloaded	*/
#define EG_WrongFn	0x000c0000L	/* fn inappropriate to object	*/
#define EG_Broken	0x000d0000L	/* object broken in some way	*/

#define EG_Parameter	0x00ff0000L	/* bad parameter value		*/

/*----------------------------------------------------------------
-- Object codes for general errors				--
----------------------------------------------------------------*/

#define EO_Message	0x00008001L	/* error refers to a message	*/
#define	EO_Task		0x00008002L	/* error refers to a task	*/
#define EO_Port		0x00008003L	/* error refers to a port	*/
#define EO_Route	0x00008004L	/* error refers to a route	*/
#define EO_Directory	0x00008005L	/* error refers to a directory	*/
#define EO_Object	0x00008006L	/* error refers to Object struct*/
#define EO_Stream	0x00008007L	/* error refers to Stream	*/
#define EO_Program	0x00008008L
#define EO_Module	0x00008009L
#define EO_Matrix	0x0000800aL	/* access matrix		*/
#define EO_Fifo		0x0000800bL
#define EO_File		0x0000800cL

/*----------------------------------------------------------------
-- Kernel errors						--
----------------------------------------------------------------*/

#define EK_Timeout	EC_Recover+SS_Kernel+EG_Timeout+EO_Message

/*----------------------------------------------------------------
-- Processor Manager Errors					--
----------------------------------------------------------------*/

#define EP_Unknown	EC_Error+SS_ProcMan+EG_Unknown
#define EP_BadFunction	EC_Error+SS_ProcMan+EG_FnCode
#define EP_Protected	EC_Error+SS_ProcMan+EG_Protected
#define EP_Name		EC_Error+SS_ProcMan+EG_Name

#endif

/* -- End of codes.h */
E 1
