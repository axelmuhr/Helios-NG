h30246
s 00101/00000/00000
d D 2.1 88/10/26 18:45:21 tim 1 0
c Version 1.0
e
u
U
t
T
I 1
/*------------------------------------------------------------------------
--                                                                      --
--             H E L I O S   A T A R I   I / O   S Y S T E M            --
--             ---------------------------------------------            --
--                                                                      --
--             Copyright (C) 1987, Perihelion Software Ltd.             --
--                        All Rights Reserved.                          --
--                                                                      --
--      STgsp.h                                                         --
--                                                                      -- 
--           Interface between Helios and the Atari                     --
--                                                                      --
--           NB Atari side                                              --
--                                                                      --
--           Data Structures plus offsets within them                   --
--                                                                      --
--           Request and reply codes                                    --
--                                                                      --
--           Extra manifests for particular actions, e.g. open          --
--                                                                      --
--	Author:  BLV 8/10/87						--
--                                                                      --
------------------------------------------------------------------------*/
/* Copyright (C) 1987, Perihelion Software Ltd.	*/

#include <stcodes.h>         /* the Helios code specifications */
#include <staddon.h>         /* plus some additions */

#define IOCDataMax         512   /* maximum size of full filenames */

/* additional odds and ends needed for specific requests */

#define OpenMode_ReadOnly     0L    /* for the Atari side */
#define OpenMode_WriteOnly    1L
#define OpenMode_ReadWrite    2L

#define O_ReadOnly            1L    /* for the Helios side */
#define O_WriteOnly           2L
#define O_ReadWrite           3L

#define CreateType_File       0L    /* Helios side */
#define CreateType_Dir        1L

typedef struct { word        type;
                 word        flags;
                 word        matrix;
                 char        name[32];
               } DirEntry;


/*----------------------------------------------------------------------*/
/* Object Types								*/
/*----------------------------------------------------------------------*/

#define Type_Server	0x00000001L	/* supports GSP directory proto */
#define Type_Directory	Type_Server	/* synonym			*/
#define Type_Stream	0x00000002L	/* supports GSP stream protocol	*/
#define Type_File	Type_Stream	/* synonym			*/
#define Type_Private	0x00000004L	/* supports own private protocol*/
#define Type_Module	0x00000008L	/* a resident module		*/
#define Type_Program	0x00000010L	/* a loaded program		*/
#define Type_Task	0x00000020L	/* a task			*/
#define Type_Link	0x00000040L	/* a link			*/


/*----------------------------------------------------------------------*/
/*  The read/write protocols						*/


/*
 * The reply to a read will consist of an arbitrary number of messages
 * containing the requested data, or a failure message. In addition to
 * possible error codes, the FnRc field of these messages will contain
 * a sequence number starting from 16 and incrementing in steps of 16
 * (Thus leaving the lower 4 bits clear). These lower 4 bits contain one
 * of the following values.
 */

#define ReadRc_Mask	0xfL	/* mask for lower 4 bits		*/
#define ReadRc_More	0L	/* more data to come			*/
#define ReadRc_EOD	1L	/* end of data				*/
#define ReadRc_EOF	2L	/* end of data and of file		*/

#define ReadRc_SeqInc	16L	/* increment for sequence numbers	*/

/*
 * The first reply to a write will consist of the following structure
 * telling the sender how to format the data transfer. This is so copies
 * may be eliminated at the server end.
 * Once the data has been sent a second reply is made confirming that the
 * data were received.
 */

typedef struct WriteReply {
	word		first;		/* size of first data message	*/
	word		rest;		/* size of rest of messages	*/
} WriteReply;

#define WriteRc_Done	0L		/* return code if data has been	*/
#define WriteRc_Sizes	1L		/* return code indicating sizes	*/

E 1
