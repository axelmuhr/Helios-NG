h41798
s 00025/00000/00000
d D 2.1 88/10/26 18:45:13 tim 1 0
c Version 1.0
e
u
U
t
T
I 1

#define f_pfix          0x2
#define f_nfix          0x6
#define f_call          0x9
#define f_j             0x0
#define f_cj            0xa
#define f_ldc           0x4
#define f_ldnl          0x3
#define f_ldnlp         0x5
#define f_stnl          0xe
#define f_ldl           0x7
#define f_stl           0xd
#define f_ldlp          0x1

#define MinInt	0x80000000L

#ifdef T414
#define MemStart  MinInt+0x48L
#define LoadBase (MinInt+0x800L)
#endif

#ifdef T800
#define MemStart  MinInt+0x70L
#define LoadBase (MinInt+0x1000L)
#endif
E 1
