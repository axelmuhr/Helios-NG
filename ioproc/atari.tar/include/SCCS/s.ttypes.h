h05313
s 00025/00000/00000
d D 2.1 88/10/26 18:45:27 tim 1 0
c Version 1.0
e
u
U
t
T
I 1

/* standard type definitions */

typedef  long int	WORD    ;       /* a machine word, 32 bits      */
typedef  unsigned long  UWORD   ;       /* a machine word, 32 bits      */
typedef  WORD           INT     ;       /* a synonym                    */
typedef  char           BYTE    ;       /* a byte, used in place of char*/
typedef  unsigned char  UBYTE   ;       /* an unsigned byte             */
typedef  char *         STRING  ;       /* character string             */

typedef  char *         APTR    ;       /* a machine pointer            */
typedef  WORD           RPTR    ;       /* a self relative pointer      */

#define PUBLIC				/* an exported symbol		*/
#define PRIVATE		static		/* an unexported symbol		*/

#define  TRUE           1l
#define  FALSE          0l

#define RTOA(x) ((APTR)(&(x)+(x)))      /* convert RPTR to APTR         */
#define ATOR(x) ((RPTR)((x)-&(x)))      /* convert APTR to RPTR         */

#define MinInt          0x80000000L

#define TargetBytesPerWord 4
E 1
